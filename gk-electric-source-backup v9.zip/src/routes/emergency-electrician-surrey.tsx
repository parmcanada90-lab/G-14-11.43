import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Siren,
  Zap,
  Clock,
  ShieldCheck,
  AlertTriangle,
  HelpCircle,
  Activity,
  PhoneCall,
  CheckCircle2,
  MapPin,
  Flame,
  Droplets,
  Info,
  ArrowRight,
  MessageCircle,
  Plus,
  Minus,
  Building2,
  Home,
  Wrench,
  Sparkles
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";

export const Route = createFileRoute("/emergency-electrician-surrey")({
  head: () => ({
    meta: [
      { title: "Emergency Electrician Surrey — 24/7 Emergency Electrical Services" },
      {
        name: "description",
        content: "Need an emergency electrician in Surrey, BC? Licensed, 24/7 emergency electrical repair and troubleshooting across the Lower Mainland. Fast response for outages, sparks, buzzing panels, and safety issues.",
      },
      { property: "og:title", content: "Emergency Electrician Surrey | 24/7 Electrical Repair" },
      {
        property: "og:description",
        content: "Licensed 24/7 emergency electricians in Surrey, BC. Fast response for home and commercial electrical failures, power outages, and safety hazards.",
      },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: EmergencyElectricianSurreyPage,
});

interface EmergencyProblem {
  title: string;
  cause: string;
  risk: string;
  urgency: string;
  icon: typeof AlertTriangle;
}

const EMERGENCY_PROBLEMS: EmergencyProblem[] = [
  {
    title: "Power Outages (Full or Partial)",
    cause: "Usually caused by overloaded circuits, severe weather, damaged service drops, or failing main breakers.",
    risk: "Spoiled food, lack of heating or cooling, loss of security systems, and potential underlying short circuits.",
    urgency: "High — especially during extreme weather or if medical equipment relies on continuous power.",
    icon: Zap,
  },
  {
    title: "Breakers Tripping Repeatedly",
    cause: "Circuit overloading, short circuits, or dangerous ground faults hidden behind your walls.",
    risk: "Repeatedly resetting a breaker forcing current through a fault can cause wire melting and catastrophic electrical fires.",
    urgency: "Immediate — do not attempt to reset a breaker multiple times; let a professional diagnose the fault.",
    icon: Activity,
  },
  {
    title: "Electrical Panel Failures",
    cause: "Loose bus bar connections, corrosion, obsolete equipment (like Federal Pacific or fuse boxes), or severe overloading.",
    risk: "Total power loss, permanent damage to appliances, and high risk of electrical fires originating inside the panel.",
    urgency: "Critical — panels distribute all power in your building and require immediate professional intervention.",
    icon: ShieldCheck,
  },
  {
    title: "Burning Smell from Outlets or Wiring",
    cause: "Overheated connections, melting plastic insulation, or active arcing behind outlets and switches.",
    risk: "This is a direct precursor to an active structure fire. Meltdown is currently occurring.",
    urgency: "Critical — shut off your main electrical breaker immediately and call an emergency electrician.",
    icon: Flame,
  },
  {
    title: "Sparking Outlets or Switches",
    cause: "Loose wiring terminals, worn-out receptacle contacts, or moisture intrusion shorting the connection.",
    risk: "Active arcing generates intense heat, which can instantly ignite surrounding wood, drywall, or insulation.",
    urgency: "High — do not use the outlet, switch off the corresponding breaker, and request emergency repair.",
    icon: Sparkles,
  },
  {
    title: "Hot or Discoloured Outlets",
    cause: "Overloaded circuits, poor wire terminations, or arcing transferring high heat to the cover plate.",
    risk: "Slow smoldering inside the wall box that can burst into an open flame without warning.",
    urgency: "Immediate — unplug all devices from the affected outlet, shut off the circuit, and have it inspected.",
    icon: AlertTriangle,
  },
  {
    title: "Buzzing Electrical Panel",
    cause: "Loose connections, failing breakers that refuse to trip, or a damaged main transformer hum.",
    risk: "Arcing and extreme heat buildup inside the panel, leading to hardware failure or fire.",
    urgency: "Immediate — a panel should operate silently. Buzzing indicates an active electrical anomaly.",
    icon: Siren,
  },
  {
    title: "Flickering or Dimming Lights",
    cause: "Loose neutral connections, overloaded shared circuits, or failing grid connections at the mast.",
    risk: "Can cause severe voltage fluctuations, damaging sensitive electronics and indicating a fire hazard.",
    urgency: "High — if localized to one room, it may be a loose wire; if whole-home, it is a critical main service issue.",
    icon: Clock,
  },
  {
    title: "Exposed or Damaged Wiring",
    cause: "Rodent damage, physical impact, wear-and-tear, or DIY electrical work left uncompleted.",
    risk: "Extreme electric shock hazard to occupants and immediate short-circuit fire risks.",
    urgency: "High — secure the area, keep pets and children away, and call for professional wiring repair.",
    icon: Wrench,
  },
  {
    title: "Storm or Flood Electrical Damage",
    cause: "Heavy rain, burst pipes, localized flooding, or lightning strikes affecting electrical systems.",
    risk: "Water is highly conductive. Wet panels, outlets, or appliances present lethal shock hazards and corrosion.",
    urgency: "Critical — do not walk through standing water if electrical systems are submerged. Cut power and call us.",
    icon: Droplets,
  },
  {
    title: "Dead Outlets",
    cause: "Tripped GFCI receptacles upstream, broken wire connections, or burnt-out outlet terminals.",
    risk: "A loose wire inside a 'dead' outlet box can still carry live voltage, arcing against other wires or the box.",
    urgency: "Medium-High — even if you do not use the outlet, the loose connection can affect other devices on the circuit.",
    icon: AlertTriangle,
  },
  {
    title: "Commercial Electrical Failures",
    cause: "Three-phase power imbalances, equipment overloads, or failing commercial distribution boards.",
    risk: "Massive business downtime, loss of refrigeration, compromised security, and safety hazards for staff and clients.",
    urgency: "Critical — business operations are halted, and code compliance is compromised. Fast dispatch is required.",
    icon: Building2,
  },
];

const WARNING_SIGNS = [
  {
    title: "Acrid Burning Smell or Smoke",
    desc: "A distinct, fishy, or plastic burning smell near outlets, switches, or your main panel indicates wire insulation is actively melting. This is the most urgent warning sign of an impending fire.",
  },
  {
    title: "Frequent, Unexplained Breaker Trips",
    desc: "If your electrical panel trips its breakers multiple times a day or immediately upon being reset, your system is warning you of a severe overload, short circuit, or critical ground fault.",
  },
  {
    title: "Loud Buzzing, Crackling, or Popping",
    desc: "Electricity should flow silently. If you hear buzzing, crackling, or popping noises from switches, outlets, or your breaker box, it is a clear sign of dangerous electrical arcing.",
  },
  {
    title: "Outlets or Switch Plates Warm to the Touch",
    desc: "No electrical wall plate should ever feel warm or hot. Warm plates indicate that heat is building up inside the wall box due to loose terminals, overloaded wires, or arcing.",
  },
  {
    title: "Widespread Flickering or Dimming Lights",
    desc: "While a single flickering bulb is common, whole-house flickering or dimming when major appliances turn on indicates your electrical system cannot handle the load or has a loose neutral connection.",
  },
  {
    title: "Visible Sparks When Plugging in Devices",
    desc: "While a tiny blue spark can occasionally occur, large, bright, popping sparks, or sparks accompanied by smoke or burn marks, indicate a damaged receptacle or short circuit.",
  },
];

const SERVICE_PROCESS = [
  {
    title: "Urgent Assessment",
    desc: "Our team answers your call, gathers critical safety details, and advises you on immediate safety steps (such as shutting off the main breaker if safe).",
  },
  {
    title: "Rapid Dispatch",
    desc: "A licensed, fully equipped emergency electrician is immediately dispatched to your Surrey or Lower Mainland location.",
  },
  {
    title: "On-Site Inspection",
    desc: "We perform a rapid visual and technical inspection of the affected area using advanced diagnostic tools to locate the source of the failure.",
  },
  {
    title: "Immediate Safety Check",
    desc: "We isolate the hazard to ensure your family, building, or staff are completely protected from shock, fire, or electrocution risks.",
  },
  {
    title: "Precision Diagnosis",
    desc: "Our master electricians run complete diagnostics on your circuits, panel, or service entrance to pinpoint the exact failure mechanism.",
  },
  {
    title: "Clear Repair Options",
    desc: "We explain the problem in plain language, outline the necessary repairs, and provide transparent options before starting any work.",
  },
  {
    title: "Permanent Repairs",
    desc: "Using high-grade, code-compliant materials from our fully stocked service vehicles, we execute permanent, safe electrical repairs.",
  },
  {
    title: "Rigorous Safety Testing",
    desc: "We test the repaired system under load, verify safety parameters, and ensure your electrical system is fully restored and completely safe.",
  },
];

const FAQS = [
  {
    q: "What is considered an electrical emergency?",
    a: "An electrical emergency is any situation that poses an immediate risk of fire, severe electric shock, physical injury, or major property damage. This includes active sparks, smoke, a burning smell from outlets or panels, a flooded electrical system, or a complete loss of power where life-safety equipment is affected.",
  },
  {
    q: "Why does my breaker keep tripping?",
    a: "A breaker trips to prevent wires from overheating and catching fire. Repeated tripping is usually caused by an overloaded circuit, a short circuit, or a dangerous ground fault hidden behind your walls. If a breaker trips immediately after resetting it, do not try again—call a licensed electrician to diagnose the fault.",
  },
  {
    q: "Is a burning smell from an outlet dangerous?",
    a: "Yes, a burning smell is an extreme emergency. It indicates that plastic casing, wire insulation, or electrical components are actively melting or smoldering. Shut off the main power breaker immediately and seek urgent professional help before a fire ignites.",
  },
  {
    q: "Are flickering lights serious?",
    a: "They can be. While a single flickering bulb might just be loose, widespread flickering across multiple rooms often points to a loose neutral wire or a failing connection in your main electrical panel or service entrance. This can lead to power surges, appliance damage, or electrical fires.",
  },
  {
    q: "What should I do during a power outage?",
    a: "First, check if your neighbours are also without power to determine if it is a utility grid issue. If it is isolated to your property, check your main panel breakers. If you notice any accompanying smells, buzzing, or if the main breaker is hot, shut off your main power and call an emergency electrician.",
  },
  {
    q: "Do sparking outlets need emergency service?",
    a: "Yes. While a tiny, instantaneous spark when plugging in a high-draw appliance can sometimes occur, any active, sustained, or popping sparks are a major fire hazard. Do not touch or use the outlet, shut off the circuit at the breaker, and call for emergency troubleshooting.",
  },
  {
    q: "Can water damage my electrical wiring?",
    a: "Absolutely. Water is highly conductive and causes immediate short circuits, corrosion, and severe shock hazards. If your home has suffered flooding, a burst pipe, or a roof leak near electrical systems, do not touch any switches or appliances. Shut off the main power and have a professional inspect the system.",
  },
  {
    q: "Are emergency electricians available at night?",
    a: "Yes, our emergency electrical service runs after-hours, overnight, and on weekends. Electrical failures do not follow a schedule, which is why a rapid-dispatch team is always on standby to handle urgent safety issues and restore power.",
  },
  {
    q: "How fast is the emergency response time in Surrey?",
    a: "We prioritize emergency dispatch and aim to have a licensed electrician on-site as quickly as possible. Response times vary depending on traffic and weather conditions across the Lower Mainland, but our local Surrey presence ensures rapid travel times to Fleetwood, Newton, Guildford, and South Surrey.",
  },
  {
    q: "How can I prevent electrical emergencies?",
    a: "Routine preventative maintenance is the best defense. This includes upgrading outdated panels (such as old fuse boxes or Federal Pacific panels), replacing worn outlets, scheduling an electrical safety inspection every few years, and avoiding overloading your circuits with too many high-draw appliances.",
  },
];

function EmergencyElectricianSurreyPage() {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <style>{`
        .custom-emergency-btn {
          padding-block: calc(var(--spacing) * 4) !important;
          font-size: 1.1rem !important;
          height: auto !important;
          box-shadow: none !important;
        }
        .custom-whatsapp-btn {
          padding-block: calc(var(--spacing) * 3) !important;
          font-size: 1.1rem !important;
          height: auto !important;
          box-shadow: none !important;
        }
        .custom-whatsapp-btn::before {
          display: none !important;
        }
        .custom-whatsapp-btn:hover {
          background-color: #ef4444 !important;
          border-color: #ef4444 !important;
          color: white !important;
        }
        .custom-whatsapp-btn:hover * {
          color: white !important;
        }
        .faq-content-div {
          padding-top: calc(var(--spacing) * 4) !important;
        }
        .dispatch-phone-text {
          font-size: 2rem !important;
          color: oklch(0.64 0.24 25.44) !important;
          line-height: 1.2 !important;
        }
      `}</style>
      <Header />

      <main className="flex-grow">
        {/* HERO SECTION */}
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[65vh] flex items-center text-surface-foreground pt-28 pb-16">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-64 h-64 bg-red-500/10 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse delay-1000" />
          </div>
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: "50px 50px",
            }}
          />
          <div className="absolute bottom-8 left-8 text-primary/10 animate-float pointer-events-none">
            <Siren className="h-36 w-36 rotate-12" />
          </div>

          <div className="container relative z-10 mx-auto px-4 py-12">
            <div className="grid lg:grid-cols-12 gap-12 items-center">
              {/* Left Column */}
              <div className="lg:col-span-7">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 text-xs uppercase tracking-widest font-semibold mb-6">
                  <Siren className="h-4 w-4 animate-pulse" />
                  Emergency Dispatch Standby
                </div>
                <h1
                  data-reveal
                  className="font-display text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.05] mb-6 text-white"
                >
                  Emergency Electrician Surrey – <span className="text-primary">24/7 Emergency Electrical Services</span>
                </h1>
                <p className="text-lg md:text-xl font-light text-surface-foreground/80 max-w-3xl leading-relaxed mb-8">
                  Electrical emergencies don't wait for convenient business hours. A sudden power outage, a buzzing panel, sparks, or a burning smell can instantly threaten your safety, family, and property. When dangerous electrical failures occur, you need an immediate, dependable response from a highly qualified, <strong>Emergency Electrician Surrey</strong>.
                </p>
                <p className="text-base text-surface-foreground/70 max-w-3xl leading-relaxed mb-8">
                  Serving homeowners, commercial operations, and property managers throughout Surrey, BC, and the surrounding Lower Mainland, our experienced dispatch team stands ready to send a <strong>Licensed Electrician Surrey</strong> directly to your door. We focus on rapid diagnostic response, permanent safety repairs, and complete peace of mind.
                </p>
                <div className="flex flex-wrap gap-4">
                  <a 
                    href="https://wa.me/17783444567" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="inline-flex items-center justify-center gap-2 whitespace-nowrap focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 btn-shine font-bold uppercase tracking-wide hover:scale-[1.03] transition-all h-14 rounded-md px-10 text-base bg-red-500 hover:bg-red-600 text-white border border-red-500 shadow-none hover:shadow-none"
                  >
                    Request Emergency Service <ArrowRight className="ml-2 h-5 w-5" />
                  </a>
                  <a 
                    href="tel:+17783444567" 
                    className="group inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-bold uppercase tracking-wide transition-all duration-300 h-14 px-10 text-base border-2 border-red-500 bg-surface/40 backdrop-blur-sm text-white hover:bg-red-500 hover:text-white"
                  >
                    <PhoneCall className="mr-2 h-5 w-5 text-red-500 group-hover:text-white transition-colors duration-300" /> Call +1 (778) 344-4567
                  </a>
                </div>
              </div>

              {/* Right Column (SEO and Fast Dispatch Stats) */}
              <div className="lg:col-span-5">
                <div className="relative rounded-3xl border border-white/10 bg-white/[0.03] p-8 backdrop-blur-md shadow-elegant overflow-hidden">
                  <div className="absolute -right-12 -top-12 h-36 w-36 rounded-full bg-red-500/10 blur-2xl" />
                  
                  <h2 className="font-display text-2xl font-extrabold text-white mb-4 uppercase tracking-wide border-b border-white/10 pb-3">
                    Surrey Dispatch Center
                  </h2>
                  
                  <p className="text-sm text-surface-foreground/80 leading-relaxed mb-6">
                    GK Electric provides rapid-response emergency electrical dispatch directly to all residential and commercial properties in Surrey and surrounding Lower Mainland communities.
                  </p>

                  <div className="space-y-4 mb-6">
                    {[
                      { label: "Average Response Time", value: "Under 45 Minutes" },
                      { label: "Coverage Areas", value: "Fleetwood, Newton, Guildford, Cloverdale, South Surrey" },
                      { label: "Licence & Certification", value: "Licensed Electrician - TSBC Licence # LEL0209793" },
                      { label: "Dispatch Availability", value: "24 Hours / 7 Days / 365 Days" },
                      { label: "Emergency Scope", value: "Residential, Commercial & Industrial" }
                    ].map((stat) => (
                      <div key={stat.label} className="border-b border-white/5 pb-2.5">
                        <div className="text-xs text-primary uppercase tracking-wider font-semibold mb-1">{stat.label}</div>
                        <div className="text-sm md:text-base text-white font-bold">{stat.value}</div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 text-center">
                    <div className="text-xs text-red-500 uppercase tracking-widest font-bold mb-1 animate-pulse">Active Emergency?</div>
                    <p className="text-xs text-surface-foreground/70 mb-3">Call our live dispatch desk for immediate technician routing.</p>
                    <a href="tel:+17783444567" className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold text-sm transition-all shadow-[0_0_12px_rgba(239,68,68,0.3)]">
                      <PhoneCall className="h-4 w-4" /> Call Live Dispatch
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CREDENTIALS BAR */}
        <section className="bg-muted/30 border-y border-border py-6">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
              <div className="flex items-center gap-4">
                <img src={tsbcLogo} alt="Technical Safety BC" className="h-16 object-contain brightness-0 dark:brightness-100" />
                <div className="text-left">
                  <div className="text-sm md:text-base text-muted-foreground uppercase tracking-wider font-semibold">Licensed Electrician</div>
                  <div className="text-lg md:text-xl font-extrabold text-foreground">TSBC Licence # LEL0209793</div>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 w-full lg:w-auto">
                {["24/7 Availability", "Surrey Neighborhood Dispatch", "Residential & Commercial", "100% Code Compliant"].map((tag) => (
                  <div key={tag} className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-background border border-border text-sm md:text-base font-bold text-foreground">
                    <CheckCircle2 className="h-5 w-5 text-primary shrink-0" />
                    {tag}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 1: EMERGENCY ELECTRICAL PROBLEMS WE HANDLE */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <ElectricSectionTag label="Critical Response Scopes" icon={Wrench} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 className="font-display text-3xl md:text-5xl font-extrabold mb-5">Emergency Electrical Problems We Handle</h2>
              <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
                Our emergency response trucks are fully stocked with commercial-grade components and advanced diagnostic testing equipment. We are ready to tackle any urgent hazard immediately upon arrival.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {EMERGENCY_PROBLEMS.map((problem) => {
                const Icon = problem.icon;
                return (
                  <div
                    key={problem.title}
                    className="p-6 rounded-2xl bg-card border border-border hover:border-red-500/40 shadow-card hover:shadow-elegant transition-all duration-300 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-500/10 text-red-500 mb-5">
                        <Icon className="h-6 w-6 animate-pulse" />
                      </div>
                      <h3 className="font-display text-xl font-bold mb-3 text-foreground">{problem.title}</h3>
                      <div className="space-y-2 text-sm text-muted-foreground mb-4">
                        <p><strong>Cause:</strong> {problem.cause}</p>
                        <p><strong>Risk:</strong> {problem.risk}</p>
                      </div>
                    </div>
                    <div className="pt-3 border-t border-border/50 flex items-center justify-between text-xs font-bold">
                      <span className="text-muted-foreground uppercase tracking-wider">Urgency Level</span>
                      <span className="text-red-500 uppercase tracking-widest bg-red-500/10 px-2.5 py-1 rounded-md">{problem.urgency}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* SECTION 2: WHY CHOOSE US */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <ElectricSectionTag label="Uncompromising Safety Standards" icon={ShieldCheck} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-3xl md:text-5xl font-extrabold mb-6">Why Choose GK Electric for Emergency Support?</h2>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  In an electrical crisis, choosing the wrong contractor can lead to prolonged downtime, incomplete repairs, and catastrophic safety failures. We stand out as Surrey's premier <strong>Emergency Electrical Contractor Surrey</strong>.
                </p>
                
                <div className="space-y-4">
                  {[
                    { title: "Rapid-Response Local Dispatch", desc: "Our electricians are stationed throughout Surrey, allowing us to arrive at Fleetwood, Guildford, Newton, and Cloverdale in record time." },
                    { title: "Licensed & Safety-First Electricians", desc: "All work is executed by fully certified journeyperson electricians in strict compliance with the Canadian Electrical Code (CEC)." },
                    { title: "Advanced Technical Diagnostics", desc: "We don't guess. We use thermal imaging and industrial load testing to find the exact point of failure for permanent, reliable repairs." },
                    { title: "Fully Stocked Service Vehicles", desc: "Our trucks carry panels, breakers, switches, and heavy-duty wiring to complete most emergency repairs on our first visit." },
                    { title: "Clear, Upfront Communication", desc: "We explain the diagnosis, safety risks, and repair options clearly before any work begins, keeping you fully informed." }
                  ].map((item) => (
                    <div key={item.title} className="flex gap-4">
                      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary mt-1">
                        <CheckCircle2 className="h-4 w-4" />
                      </div>
                      <div>
                        <h4 className="text-base font-bold text-foreground mb-1">{item.title}</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-surface text-surface-foreground p-8 md:p-10 rounded-3xl border border-border shadow-elegant relative overflow-hidden">
                <div className="absolute -right-16 -top-16 h-44 w-44 rounded-full bg-red-500/10 blur-3xl" />
                <h3 className="font-display text-2xl md:text-3xl font-extrabold mb-6 text-white flex items-center gap-3">
                  <Siren className="h-7 w-7 text-red-500 animate-bounce" />
                  Is It An Emergency?
                </h3>
                <p className="text-surface-foreground/80 text-sm md:text-base leading-relaxed mb-6">
                  If you are experiencing any of the following, do not wait for business hours. Isolate the area and call us immediately:
                </p>
                <div className="grid gap-3 text-sm text-surface-foreground/95">
                  {[
                    "Smell of burning plastic or ozone from walls",
                    "Sparking outlets, switches, or buzzing panel board",
                    "Main breaker hot to the touch or repeatedly tripping",
                    "Water leaking directly onto electrical equipment",
                    "Partial power loss indicating a loose neutral line",
                    "Active shocks when touching metallic appliances",
                  ].map((it) => (
                    <div key={it} className="flex gap-3 items-center bg-white/5 p-3 rounded-xl border border-white/10">
                      <AlertTriangle className="h-4 w-4 text-red-500 shrink-0" />
                      <span>{it}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-8 pt-6 border-t border-white/10">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider mb-1">Direct Dispatch Line</div>
                  <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
                    <div className="dispatch-phone-text font-bold leading-none">+1 (778) 344-4567</div>
                    <Button asChild variant="electric" className="bg-red-500 hover:bg-red-600 border-red-500 text-white shadow-none hover:shadow-none shrink-0" style={{ paddingBlock: "calc(var(--spacing) * 4)", height: "auto", fontSize: "1.1rem", boxShadow: "none" }}>
                      <a href="tel:+17783444567" className="flex items-center">
                        <PhoneCall className="mr-2 h-4 w-4 animate-pulse" /> Emergency Dispatch
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 3: EMERGENCY SERVICE PROCESS */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <ElectricSectionTag label="Step-By-Step Protocol" icon={Clock} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 className="font-display text-3xl md:text-5xl font-extrabold mb-5">Our Emergency Service Process</h2>
              <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
                When you call us for emergency electrical repairs, we follow a strict safety and diagnostic process to resolve the hazard efficiently and permanently.
              </p>
            </div>

            <div className="relative">
              <div className="grid md:grid-cols-2 gap-6 relative z-10">
                {SERVICE_PROCESS.map((step, index) => (
                  <div
                    key={step.title}
                    className="flex gap-4 p-5 rounded-2xl bg-card border border-border hover:border-primary/30 shadow-card transition-all"
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary font-bold text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <h3 className="font-display text-lg font-bold text-foreground mb-1">{step.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 4: WARNING SIGNS YOU NEED AN ELECTRICIAN */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <ElectricSectionTag label="Safety Prevention" icon={AlertTriangle} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 className="font-display text-3xl md:text-5xl font-extrabold mb-5">Warning Signs You Need an Electrician</h2>
              <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
                Do not ignore small electrical anomalies. Minor issues are often early indicators of deep system faults that can lead to severe shock or property damage.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {WARNING_SIGNS.map((sign) => (
                <div key={sign.title} className="p-6 rounded-2xl bg-card border border-border hover:border-primary/30 shadow-card transition-all">
                  <div className="h-2 w-12 bg-primary rounded-full mb-4" />
                  <h3 className="font-display text-lg font-bold text-foreground mb-3">{sign.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{sign.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SECTION 5: SERVICE AREAS */}
        <section className="py-20 bg-background relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, black 1px, transparent 0)", backgroundSize: "20px 22px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <ElectricSectionTag label="Local Coverage Map" icon={MapPin} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 className="font-display text-3xl md:text-5xl font-extrabold mb-6">Serving Surrey & The Lower Mainland</h2>
              <p className="text-muted-foreground text-base md:text-lg leading-relaxed mb-8">
                With deep roots in British Columbia, we offer rapid <strong>Emergency Electrician Lower Mainland</strong> support. Our central dispatch is located in Surrey, allowing our trucks to arrive at local neighbourhoods within minutes of your call.
              </p>
              
              <div className="bg-card border border-border p-8 rounded-3xl shadow-card text-left mb-10">
                <h3 className="font-display text-xl font-bold mb-4 text-foreground flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary shrink-0" />
                  Primary Surrey Neighbourhoods Covered:
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  We provide continuous, 24/7 service to Fleetwood, Guildford, Newton, Cloverdale, South Surrey, Fraser Heights, Panorama Ridge, and Sullivan Station. Whether you are situated near Guildford Town Centre, Cloverdale's historic district, or the bustling commercial hubs of Newton, our local team is minutes away.
                </p>

                <h3 className="font-display text-xl font-bold mb-4 text-foreground flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary shrink-0" />
                  Extended Lower Mainland Coverage:
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Beyond Surrey, our emergency services extend across key municipal boundaries. We regularly dispatch licensed technicians to White Rock, Langley, Delta, Richmond, Burnaby, New Westminster, Coquitlam, Port Coquitlam, Port Moody, Maple Ridge, and Vancouver. No matter where you are located in the Lower Mainland, our emergency trucks are ready to roll.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 6 & 7: RESIDENTIAL & COMMERCIAL SERVICES */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Residential */}
              <div className="p-8 rounded-3xl bg-card border border-border shadow-card hover:border-primary/30 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary mb-6">
                    <Home className="h-6 w-6" />
                  </div>
                  <h3 className="font-display text-2xl font-extrabold mb-4 text-foreground">Residential Emergency Services</h3>
                  <p className="text-muted-foreground text-sm md:text-base leading-relaxed mb-6">
                    Your home is your sanctuary, and electrical failures can compromise your safety and comfort. We specialize in rapid-response troubleshooting and repair for single-family custom homes, townhomes, condominiums, apartments, and older character homes across Surrey.
                  </p>
                  <ul className="space-y-2.5 text-sm text-muted-foreground mb-8">
                    {["Restoring power to basement suites and detached garages", "Repairing faulty HVAC circuits to get heating back online", "Replacing wet or water-damaged electrical outlets", "Correcting dangerous DIY wiring mistakes immediately"].map((pt) => (
                      <li key={pt} className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Residential Emergency Action Buttons */}
                <div className="grid sm:grid-cols-2 gap-3 mt-auto">
                  <Button asChild variant="electric" className="custom-emergency-btn w-full bg-red-500 hover:bg-red-600 border-2 border-red-500 text-white shadow-none hover:shadow-none flex items-center justify-center">
                    <a href="tel:+17783444567" className="flex items-center justify-center">
                      <PhoneCall className="mr-2 h-4 w-4" /> Call +1 (778) 344-4567
                    </a>
                  </Button>
                  <a
                    href="https://wa.me/17783444567"
                    target="_blank"
                    rel="noreferrer"
                    className="gap-2 whitespace-nowrap rounded-md text-sm font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 bg-background h-9 px-4 py-2 custom-emergency-btn custom-whatsapp-btn group w-full border-2 border-red-500 hover:bg-red-500 hover:border-red-500 text-red-500 hover:text-white transition-all duration-300 shadow-none hover:shadow-none flex items-center justify-center text-red-500 group-hover:text-white"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-message-circle mr-2 h-4 w-4 text-red-500 group-hover:text-white transition-colors duration-300"
                      aria-hidden="true"
                    >
                      <path d="M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719"></path>
                    </svg>{" "}
                    WhatsApp Dispatch
                  </a>
                </div>
              </div>

              {/* Commercial */}
              <div className="p-8 rounded-3xl bg-card border border-border shadow-card hover:border-primary/30 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary mb-6">
                    <Building2 className="h-6 w-6" />
                  </div>
                  <h3 className="font-display text-2xl font-extrabold mb-4 text-foreground">Commercial Emergency Services</h3>
                  <p className="text-muted-foreground text-sm md:text-base leading-relaxed mb-6">
                    Electrical failure in a commercial setting means lost revenue, safety liabilities, and operational chaos. We provide swift support to retail stores, offices, restaurants, warehouses, and property management firms.
                  </p>
                  <ul className="space-y-2.5 text-sm text-muted-foreground mb-8">
                    {["Resolving three-phase power failures and motor faults", "Restoring lost power to commercial refrigeration units", "Troubleshooting critical lighting and server room circuits", "Providing immediate electrical safety code corrections"].map((pt) => (
                      <li key={pt} className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Commercial Emergency Action Buttons */}
                <div className="grid sm:grid-cols-2 gap-3 mt-auto">
                  <Button asChild variant="electric" className="custom-emergency-btn w-full bg-red-500 hover:bg-red-600 border-2 border-red-500 text-white shadow-none hover:shadow-none flex items-center justify-center">
                    <a href="tel:+17783444567" className="flex items-center justify-center">
                      <PhoneCall className="mr-2 h-4 w-4" /> Call +1 (778) 344-4567
                    </a>
                  </Button>
                  <a
                    href="https://wa.me/17783444567"
                    target="_blank"
                    rel="noreferrer"
                    className="gap-2 whitespace-nowrap rounded-md text-sm font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 bg-background h-9 px-4 py-2 custom-emergency-btn custom-whatsapp-btn group w-full border-2 border-red-500 hover:bg-red-500 hover:border-red-500 text-red-500 hover:text-white transition-all duration-300 shadow-none hover:shadow-none flex items-center justify-center text-red-500 group-hover:text-white"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-message-circle mr-2 h-4 w-4 text-red-500 group-hover:text-white transition-colors duration-300"
                      aria-hidden="true"
                    >
                      <path d="M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719"></path>
                    </svg>{" "}
                    WhatsApp Dispatch
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 8: ELECTRICAL SAFETY DURING EMERGENCIES */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <ElectricSectionTag label="Critical Safety Protocols" icon={ShieldCheck} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
                <h2 className="font-display text-3xl md:text-5xl font-extrabold mb-4">Electrical Safety During Emergencies</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Knowing what to do during an active electrical failure can prevent severe shock, injury, or catastrophic property loss. Follow these vital safety rules.
                </p>
              </div>

              <div className="grid gap-6">
                {[
                  { title: "What to Do During a Power Outage", desc: "Unplug sensitive electronics to protect them from voltage surges when the utility grid is restored. Keep refrigerator and freezer doors closed. If you notice a burning smell, localized buzzing, or warmth from your breaker box, do not attempt to reset any switches—shut off the main breaker if safe to do so." },
                  { title: "What to Do If You See Smoke or Sparks", desc: "Do not touch the sparking outlet, appliance, or wire. If you can safely reach your main electrical panel, shut off the main power breaker immediately. Evacuate the area and call emergency services (911) if there is an active fire, then call a licensed electrician." },
                  { title: "What to Do During a Flood or Water Leak", desc: "Never step into standing water in a basement or room if the water level has reached outlets, extension cords, or electrical panels. If safe, turn off the main breaker before water reaches these areas. If the panel is in a wet area, do not touch it—call us immediately." },
                  { title: "When to Shut Off Your Main Power Breaker", desc: "You should shut off your main breaker if you smell burning plastic, hear loud buzzing or crackling from your panel, see smoke or direct sparks, or if a major plumbing failure is leaking water directly onto electrical infrastructure." },
                  { title: "When to Call 911 vs. an Electrician", desc: "Call 911 immediately if there is an active fire, visible smoke originating from walls, or an immediate threat to human life. Once emergency services have stabilized the immediate threat, or if you have a non-fire hazard like a complete power loss or a buzzing panel, call our emergency team." }
                ].map((item) => (
                  <div key={item.title} className="p-6 rounded-2xl bg-card border border-border hover:border-red-500/20 transition-all">
                    <h3 className="font-display text-lg font-bold text-foreground mb-2 flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-red-500 shrink-0" />
                      {item.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 9: FAQ */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <ElectricSectionTag label="Frequently Asked Questions" icon={HelpCircle} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
                <h2 className="font-display text-3xl md:text-5xl font-extrabold mb-4">Emergency Electrical FAQs</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Find quick answers to common questions about electrical failures, safety steps, and emergency repair processes in Surrey.
                </p>
              </div>

              <div className="space-y-4">
                {FAQS.map((faq, index) => {
                  const isOpen = openFaqIndex === index;
                  return (
                    <div
                      key={faq.q}
                      className={`border rounded-2xl bg-card overflow-hidden transition-all duration-300 ${
                        isOpen 
                          ? "border-red-500/50 shadow-elegant bg-red-500/[0.01]" 
                          : "border-border hover:border-red-500/30 hover:shadow-card"
                      }`}
                    >
                      <button
                        onClick={() => toggleFaq(index)}
                        className="w-full flex items-center justify-between p-5 text-left font-display font-bold text-base md:text-lg text-foreground transition-colors focus:outline-none group"
                      >
                        <span>{faq.q}</span>
                        <div className={`shrink-0 ml-4 h-8 w-8 rounded-full border flex items-center justify-center transition-all ${
                          isOpen 
                            ? "border-red-500 bg-red-500/10 text-red-500" 
                            : "border-border text-muted-foreground group-hover:border-red-500 group-hover:text-red-500"
                        }`}>
                          {isOpen ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                        </div>
                      </button>
                      
                      {isOpen && (
                        <div className="faq-content-div p-5 pt-0 border-t border-border/50 text-sm md:text-base text-muted-foreground leading-relaxed bg-muted/[0.05]">
                          {faq.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* CLOSING SECTION */}
        <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
          <div className="container mx-auto px-4 relative z-10 text-center">
            <div className="mx-auto max-w-4xl">
              <Siren className="mx-auto mb-6 h-16 w-16 text-primary animate-pulse" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold mb-6 text-white">
                Need an Emergency Electrician Surrey Immediately?
              </h2>
              <p className="text-lg text-surface-foreground/80 leading-relaxed mb-8 max-w-2xl mx-auto">
                Do not risk your family's safety or your business continuity. Our licensed, emergency dispatch team is ready to deploy fully stocked service trucks to your Surrey or Lower Mainland location immediately.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="electric" size="xl">
                  <a href="tel:+17783444567">
                    <PhoneCall className="mr-2 h-5 w-5" /> Call +1 (778) 344-4567
                  </a>
                </Button>
                <Button asChild variant="outline" size="xl" className="bg-white/5 border-white/15 text-white hover:bg-white/10">
                  <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                    <MessageCircle className="mr-2 h-5 w-5" /> WhatsApp Dispatch Team
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
