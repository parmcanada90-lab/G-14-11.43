import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { DecorBoltOutlet, DecorPanelCrew } from "@/components/decor/LineArt";
import { Phone, Zap, ShieldCheck, Clock, Award, ArrowRight, Building2, Factory, Home, Plug, Lightbulb, Wrench, Gauge, Cpu, Headphones, FileCheck, FileText, FilePenLine, FolderKanban, Star, Users, MessageCircle, ClipboardCheck, CalendarCheck, BadgeCheck, ScrollText, CheckCircle2 } from "lucide-react";
import { HeroSlideshow } from "@/components/HeroSlideshow";



import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FeaturedProjects } from "@/components/FeaturedProjects";
import { Testimonials } from "@/components/Testimonials";
import { ReviewsShowcase } from "@/components/ReviewsShowcase";
import { SectionKicker } from "@/components/SectionKicker";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-electrician.jpg";
import residentialImage from "@/assets/residential.jpg";
import commercialImage from "@/assets/commercial.jpg";
import industrialImage from "@/assets/industrial.jpg";
import evImage from "@/assets/ev-charger.jpg";
import ourStory from "@/assets/our-story.jpg";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";
import serviceResidential from "@/assets/service-residential.png";
import serviceCommercial from "@/assets/service-commercial.png";
import serviceIndustrial from "@/assets/service-industrial.png";
import serviceEV from "@/assets/service-ev.png";

const serviceTiles = [
  { src: serviceResidential, label: "Residential", to: "/services/residential" },
  { src: serviceCommercial, label: "Commercial", to: "/services/commercial" },
  { src: serviceIndustrial, label: "Industrial", to: "/services/industrial" },
  { src: serviceEV, label: "EV Charging", to: "/ev-charger" },
] as const;

// Service image cards are currently hidden.
// Change this to true when you want to show the section again.
const SHOW_SERVICE_TILES = false;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GK Electric — Residential, Commercial & Industrial Electrician" },
      { name: "description", content: "Licensed electrician for residential, commercial and industrial work. Electrical installation, EV charger installation, permits & code compliance. Fast, reliable service." },
      { property: "og:title", content: "GK Electric — Licensed Electricians for Every Project" },
      { property: "og:description", content: "Residential, commercial & industrial electrical service. EV charger installation, permits, inspections. Get a free estimate today." },
      { property: "og:image", content: heroImage },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: heroImage },
    ],
  }),
  component: HomePage,
});

const services = [
  {
    icon: Home,
    title: "Residential",
    desc: "Full home electrical for safer, brighter, more efficient living spaces.",
    img: residentialImage,
    to: "/services/residential" as const,
    tag: "Click for Residential Services",
    hash: "residential",
    features: [
      { icon: Lightbulb, label: "Lighting & wiring" },
      { icon: Wrench, label: "Repairs & upgrades" },
      { icon: Plug, label: "Outlets & switches" },
    ],
  },
  {
    icon: Building2,
    title: "Commercial",
    desc: "Reliable power for offices, retail and commercial buildings.",
    img: commercialImage,
    to: "/services/commercial" as const,
    tag: "Click for Commercial Services",
    hash: "commercial",
    features: [
      { icon: Gauge, label: "Panel installation" },
      { icon: Lightbulb, label: "LED retrofits" },
      { icon: Wrench, label: "Maintenance" },
    ],
  },
  {
    icon: Factory,
    title: "Industrial",
    desc: "Heavy electrical for factories, warehouses and industrial facilities.",
    img: industrialImage,
    to: "/services/industrial" as const,
    tag: "Click for Industrial Services",
    hash: "industrial",
    features: [
      { icon: Cpu, label: "Machinery wiring" },
      { icon: Gauge, label: "Load management" },
      { icon: Zap, label: "Three-phase power" },
    ],
  },
];

const features = [
  { icon: ShieldCheck, title: "Licensed & Insured", desc: "Fully licensed electricians with full insurance coverage." },
  { icon: FileCheck, title: "Electric Operating Permits", desc: "We obtain all required operating permits so your work is fully authorized." },
  { icon: Award, title: "Code-Compliant", desc: "Every job meets and exceeds electrical safety codes." },
  { icon: Zap, title: "All Project Sizes", desc: "From a single outlet to full industrial installations." },
  { icon: Headphones, title: "24/7 Emergency", desc: "Round-the-clock support for critical electrical issues." },
  { icon: FileText, title: "Electric Planning Reports", desc: "Detailed electrical planning reports for projects of any scale." },
];

const heroTrustItems = [
  {
    icon: ShieldCheck,
    label: "Licensed & Insured",
    detail: "Qualified electrical work backed by proper licensing and coverage.",
  },
  {
    icon: Clock,
    label: "18+ Years Experience",
    detail: "Trusted residential, commercial and industrial service across BC.",
  },
  {
    icon: FileCheck,
    label: "Permits & Compliance",
    detail: "Electrical permits, inspections and code requirements handled properly.",
  },
  {
    icon: Headphones,
    label: "24/7 Emergency Support",
    detail: "Responsive help when critical electrical issues cannot wait.",
  },
];


function HomePage() {
  const [showServiceTiles, setShowServiceTiles] = useState(false);

  useEffect(() => {
    const updateServiceTiles = () => {
      setShowServiceTiles(window.scrollY > 80);
    };

    updateServiceTiles();
    window.addEventListener("scroll", updateServiceTiles, { passive: true });
    return () => window.removeEventListener("scroll", updateServiceTiles);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* HERO */}
      <section className="relative h-screen flex items-center overflow-hidden bg-surface">
        <HeroSlideshow />
      </section>

      {/* TRUST HIGHLIGHTS */}
      <section className="relative z-30 bg-white border-y border-gray-100 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="grid gap-0 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-gray-100">
            {heroTrustItems.map((item, index) => (
              <div
                key={item.label}
                data-reveal="up"
                style={{ transitionDelay: `${index * 70}ms` }}
                className="group flex items-center gap-4 px-2 py-6 sm:px-5 lg:px-7 lg:py-7 transition-colors duration-300 hover:bg-primary/[0.04]"
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary/10 ring-1 ring-primary/15 transition-all duration-300 group-hover:bg-primary group-hover:scale-105 group-hover:shadow-glow">
                  <item.icon className="h-6 w-6 text-primary transition-colors duration-300 group-hover:text-primary-foreground" />
                </div>
                <div className="min-w-0">
                  <h2 className="font-display text-lg font-bold uppercase tracking-[0.08em] text-foreground">
                    {item.label}
                  </h2>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {item.detail}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICE TILES ROW — hidden for now. Set SHOW_SERVICE_TILES to true above to uncomment/show it again. */}
      {SHOW_SERVICE_TILES && (
        <section className="relative bg-background pt-12 pb-14 sm:pt-14 md:pt-16 md:pb-20 lg:pt-20 z-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:gap-6 xl:grid-cols-4 w-full max-w-sm sm:max-w-3xl xl:max-w-6xl mx-auto">
              {serviceTiles.map((tile, i) => (
                <Link
                  key={tile.label}
                  to={tile.to}
                  style={{ transitionDelay: showServiceTiles ? `${i * 130}ms` : "0ms" }}
                  className={`group relative block aspect-square overflow-hidden rounded-2xl shadow-lg transition-all duration-700 ease-out will-change-transform hover:-translate-y-2 hover:shadow-2xl ${
                    showServiceTiles
                      ? "translate-y-0 scale-100 opacity-100 pointer-events-auto"
                      : "translate-y-10 scale-[0.96] opacity-0 pointer-events-none"
                  }`}
                  aria-label={tile.label}
                  title={tile.label}
                >
                  <img
                    src={tile.src}
                    alt={tile.label}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 rounded-2xl ring-1 ring-black/5 transition-all duration-500 group-hover:ring-black/10" />
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ABOUT US */}
      <AboutUsSection />



      {/* SERVICES */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="mb-16 flex items-center justify-between gap-8 flex-wrap">
            <div data-reveal className="text-left max-w-2xl">
              <ElectricSectionTag label="What We Do" icon={Lightbulb} tone="light" variant="electric-v1-2" className="mb-6" />
              <h2 className="text-4xl md:text-6xl mb-4"><span className="text-black">Our</span> <span className="text-primary">Services</span></h2>
              <p className="text-lg text-muted-foreground">
                From a single outlet upgrade to full industrial systems — we handle every electrical job with expertise.
              </p>
            </div>
          </div>


          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {services.map((s, i) => (
              <Link
                key={s.title}
                to={s.to}
                data-reveal="zoom"
                style={{ transitionDelay: `${i * 120}ms` }}
                className="group relative min-h-[430px] overflow-hidden rounded-[2rem] shadow-elegant transition-all duration-500"
                aria-label={s.tag}
              >
                <img
                  src={s.img}
                  alt={`${s.title} electrical service`}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/45 to-transparent" />
                <div className="absolute right-0 top-7 z-10 translate-x-full rounded-l-2xl bg-white/90 px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-surface opacity-100 shadow-xl transition-all duration-500 group-hover:translate-x-0">
                  {s.tag}
                </div>
                <div className="absolute inset-x-0 bottom-0 p-7 text-surface-foreground">
                  <div className="flex min-h-[220px] flex-col items-start">
                    <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                      <s.icon className="h-7 w-7" />
                    </div>
                    <h3 className="mb-3 text-3xl font-bold leading-tight">{s.title}</h3>
                    <p className="mb-4 h-[4.25rem] text-sm leading-relaxed text-surface-foreground/75">
                      {s.desc}
                    </p>
                    <div className="mt-auto inline-flex items-center gap-2 rounded-full border border-primary/70 bg-transparent px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary shadow-none transition-all duration-300 hover:border-primary hover:bg-transparent hover:text-primary-glow hover:shadow-none">
                      More Information <ArrowRight className="h-4 w-4" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* EV CALLOUT (inside Services) */}
          <div data-reveal className="relative overflow-hidden rounded-2xl shadow-elegant mt-16 group">
            <img
              src={evImage}
              alt="EV charger installation in residential garage"
              loading="lazy"
              width={1600}
              height={1200}
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-surface/90 via-surface/60 to-transparent md:via-surface/40" />
            <div className="absolute right-0 top-7 z-10 translate-x-full rounded-l-2xl bg-white/90 px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-surface shadow-xl transition-all duration-500 group-hover:translate-x-0">
              Click for EV Charger Installation
            </div>
            <div className="relative p-8 md:p-12 max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest mb-4">
                <Plug className="h-3 w-3" /> High Demand
              </div>
              <h3 className="font-display text-3xl md:text-4xl text-surface-foreground mb-4">
                EV Charger Installation
              </h3>
              <p className="text-surface-foreground/80 mb-6 leading-relaxed">
                Home and commercial EV chargers — fast, safe installation
                compatible with all major EV brands.
              </p>
              <Link to="/ev-charger" className="mt-auto inline-flex items-center gap-2 rounded-full border border-primary/70 bg-transparent px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary shadow-none transition-all duration-300 hover:border-primary hover:bg-transparent hover:text-primary-glow hover:shadow-none">
                More Information <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>


          <div className="text-center mt-12">
            <Button asChild variant="default" size="lg">
              <Link to="/services">
                View All Services <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* SPECIALIZED SERVICE: PERMITS & COMPLIANCE */}
      <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid gap-12 lg:grid-cols-[2fr_3fr] items-start">
            <div data-reveal="left" className="lg:sticky lg:top-24">
              <ElectricSectionTag label="Specialized Service" icon={ClipboardCheck} tone="dark" variant="electric-v1-2" className="mb-6" />
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6">
                Permits & Compliance <span className="brand-highlight">Made Simple</span>
              </h2>
              <div className="space-y-5 text-lg text-surface-foreground/72 leading-relaxed max-w-2xl">
                <p>
                  We take care of all electrical permits, inspections, and regulatory requirements from start to finish—so your project stays compliant, on schedule, and stress-free.
                </p>
                <p>
                  Our team works directly with local authorities to ensure all work meets the BC Electrical Safety Regulation and the Canadian Electrical Code. From permit applications to final approvals, we handle the paperwork, coordination, and compliance details for you.
                </p>
              </div>

              <div className="mt-8" data-reveal>
                <Button asChild variant="electric" size="lg" className="home-more-info-button shadow-none hover:shadow-none">
                  <Link to="/services">
                    More Info
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                </Button>
              </div>

            </div>

            <div className="grid gap-6 lg:pt-16">
              <div
                data-reveal="right"
                className="group relative"
              >
                <div className="mb-6">
                  <div className="flex items-center gap-4">
                    <span className="h-10 w-1 rounded-full bg-primary shadow-glow" aria-hidden="true" />
                    <h3 className="font-display text-3xl font-bold text-surface-foreground">What We Handle</h3>
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  {[
                    { icon: FileCheck, text: "Electrical permit applications" },
                    { icon: CalendarCheck, text: "Inspection scheduling & coordination" },
                    { icon: BadgeCheck, text: "Code compliance verification" },
                    { icon: Wrench, text: "Deficiency corrections support" },
                    { icon: ClipboardCheck, text: "Final inspection & approvals" },
                    { icon: ScrollText, text: "Regulatory documentation" },
                    { icon: FileCheck, text: "Electric Operating Permits" },
                    { icon: FileText, text: "Electric Planning Reports" },
                  ].map((item, index) => (
                    <div key={item.text} data-reveal style={{ transitionDelay: `${index * 45}ms` }} className="flex items-center gap-4 rounded-2xl bg-white/[0.09] border border-white/15 p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)] hover:border-primary/45 hover:bg-white/[0.12] transition-all">
                      <span className="h-11 w-11 shrink-0 rounded-full bg-primary/20 ring-1 ring-primary/25 flex items-center justify-center">
                        <item.icon className="h-5 w-5 text-primary" />
                      </span>
                      <span className="text-base font-semibold leading-snug text-surface-foreground">{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-[1.75rem] border border-white/12 bg-white/[0.055] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.28)] backdrop-blur-md md:p-6">
            <div className="grid gap-5 md:grid-cols-[1.25fr_1fr_1fr_1fr] md:divide-x md:divide-white/10">
              <div className="flex items-center">
                <p className="font-display text-2xl font-extrabold uppercase tracking-[0.06em] text-white">
                  Ready to start your permit-backed electrical work?
                </p>
              </div>
              {[
                { icon: Phone, label: "Call Now", text: "Speak with our team", href: "tel:+17783444567" },
                { icon: FilePenLine, label: "Request a Quote", text: "Get a custom quote", href: "/contact" },
                { icon: MessageCircle, label: "WhatsApp Us", text: "Chat with us now", href: "https://wa.me/17783444567" },
              ].map((action) => {
                const Icon = action.icon;
                const external = action.href.startsWith("http");
                const isWhatsApp = action.label.includes("WhatsApp");
                const content = (
                  <>
                    <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border transition-all duration-300 group-hover:scale-110 ${isWhatsApp ? "border-green-400/35 bg-green-500/15 text-green-300 group-hover:bg-green-500 group-hover:text-white group-hover:border-green-400" : "border-primary/45 bg-primary/15 text-primary group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary"}`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-extrabold uppercase tracking-[0.12em] text-white group-hover:text-primary transition-colors">{action.label}</div>
                      <div className="mt-1 text-sm text-surface-foreground/55 group-hover:text-surface-foreground/80 transition-colors">{action.text}</div>
                    </div>
                  </>
                );

                return external ? (
                  <a key={action.label} href={action.href} target="_blank" rel="noreferrer" className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-green-400/40 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </a>
                ) : action.href.startsWith("tel:") ? (
                  <a key={action.label} href={action.href} className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </a>
                ) : (
                  <Link key={action.label} to="/contact" className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="bg-background text-foreground py-24">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div data-reveal="left">
              <div className="text-xs uppercase tracking-[0.28em] font-bold mb-3 text-primary">Why Choose Us</div>
              <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-3">Why Choose GK Electric?</h2>
              <p className="text-muted-foreground leading-relaxed max-w-2xl">Dependable electrical service backed by experience, safety and professional care.</p>
            </div>
            <div data-reveal="right" className="rounded-3xl border border-border overflow-hidden bg-card shadow-card">
              {[
                { icon: ShieldCheck, title: "Licensed & Insured", text: "Certified electricians with dependable code-compliant workmanship." },
                { icon: Clock, title: "Fast Response", text: "Quick scheduling and responsive support for urgent electrical needs." },
                { icon: Award, title: "Quality Work", text: "Clean installations, careful finishing and long-lasting results." },
                { icon: Headphones, title: "Clear Support", text: "Friendly communication before, during and after every project." },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.title} className="flex items-center gap-4 p-5 border-b border-border last:border-b-0 hover:bg-muted/40 transition-colors">
                    <CheckCircle2 className="h-6 w-6 text-primary shrink-0" />
                    <Icon className="h-6 w-6 text-muted-foreground shrink-0" />
                    <div>
                      <h3 className="font-bold text-foreground">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{item.text}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>


      {/* FEATURED PROJECTS (moved to where EV banner was) */}
      <FeaturedProjects />

      {/* TESTIMONIALS */}
      <Testimonials />

      {/* REVIEWS SHOWCASE */}
      <ReviewsShowcase />

      {/* CTA */}
      <section className="py-20 bg-gradient-electric relative overflow-hidden">
        <div className="absolute inset-0 animate-shimmer opacity-40 pointer-events-none" />
        <DecorBoltOutlet side="br" className="opacity-25 text-primary-foreground" />
        <div className="container mx-auto px-4 text-center text-primary-foreground relative">
          <h2 data-reveal className="text-4xl md:text-5xl mb-4">Ready to Power Your Project?</h2>
          <p data-reveal className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Get a free, no-obligation estimate today. Our licensed electricians are standing by.
          </p>
          <div data-reveal="zoom" className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="xl" variant="default" className="bg-surface text-surface-foreground hover:bg-surface/90 hover:scale-105 transition-transform">
              <a href="tel:+17783444567"><Phone className="h-5 w-5" /> Call +1 (778) 344-4567</a>
            </Button>
            <Button asChild size="xl" variant="default" className="bg-surface text-primary border-2 border-surface hover:bg-surface/90 hover:scale-105 transition-transform">
              <Link to="/free-estimate">Free Estimate</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function AboutUsSection() {
  return (
    <section className="py-24 md:py-32 bg-background relative overflow-hidden">
      <div className="container mx-auto px-4 relative">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-20 items-center">
          <div data-reveal="left" className="relative">
            <div className="relative max-w-lg mx-auto pb-16 lg:max-w-none">
              <div className="relative">
                <div className="absolute -z-10 -right-4 -bottom-4 w-full h-full bg-primary/10 rounded-3xl" />
                <div className="group relative overflow-hidden rounded-3xl shadow-2xl aspect-[4/3] bg-muted">
                  <img
                    src={ourStory}
                    alt="GK Electric professional electrician at work"
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-surface/60 via-transparent to-transparent" />
                </div>
              </div>
              <div className="absolute bottom-16 left-4 translate-y-1/2 animate-float sm:left-6">
                <div className="inline-flex items-center gap-4 rounded-2xl border-[3px] border-white bg-[#00497b] px-5 py-4 shadow-xl">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl">
                    <img
                      src={tsbcLogo}
                      alt="Technical Safety BC logo"
                      className="h-14 w-14 object-contain"
                      loading="lazy"
                    />
                  </div>
                  <div className="text-white">
                    <div className="text-[1.25rem] tracking-wider text-white">TSBC Licence</div>
                    <div className="text-[1.5rem] tracking-[2px] font-bold text-white"># LEL0209793</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div data-reveal="right">
            <ElectricSectionTag label="Who We Are" icon={Users} tone="light" variant="electric-v1-2" className="mb-8" />
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold leading-[1.1] mb-6">
              Powering British Columbia with
              <span className="block text-primary mt-2">Professional Electrical Services</span>
            </h2>
            <div className="space-y-4 mb-8">
              <p className="text-lg text-muted-foreground leading-relaxed">
                <strong className="text-foreground">GK ELECTRIC</strong> delivers trusted residential, commercial, and industrial electrical services across British Columbia. Our licensed electricians provide electrical repairs, installations, upgrades, maintenance, panel upgrades, EV charger installations, lighting solutions, and complete electrical systems.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                We are more than electricians — we are your partners in powering homes, businesses, and industrial facilities with safe, code-compliant electrical work. Backed by experience, reliability, and a commitment to quality, we bring excellence to every electrical project.
              </p>
            </div>
            <div className="flex flex-wrap gap-4 mb-8">
              <Button asChild variant="electric" size="lg">
                <Link to="/about">
                  ABOUT GK ELECTRIC <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/free-estimate">
                  GET FREE ESTIMATE <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-16 md:mt-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[
              { icon: FolderKanban, value: "1000+", label: "Projects Completed" },
              { icon: Star, value: "100%", label: "Satisfaction Rate" },
              { icon: Headphones, value: "24/7", label: "Emergency Support" },
              { icon: ShieldCheck, value: "BC", label: "Licensed & Insured" },
            ].map((stat) => (
              <div key={stat.label} className="bg-card rounded-2xl p-6 md:p-8 shadow-lg border border-border text-center hover:shadow-xl hover:border-primary/20 transition-all duration-300 group">
                <div className="h-12 w-12 md:h-14 md:w-14 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <stat.icon className="h-6 w-6 md:h-7 md:w-7 text-primary" />
                </div>
                <div className="text-4xl md:text-5xl font-display font-bold text-foreground mb-2">{stat.value}</div>
                <div className="text-sm md:text-base text-muted-foreground font-medium uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

