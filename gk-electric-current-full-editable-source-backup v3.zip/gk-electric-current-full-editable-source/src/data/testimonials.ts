export interface Testimonial {
  name: string;
  role: string;
  quote: string;
  rating: number;
}

export const testimonials: Testimonial[] = [
  {
    name: "Sarah M.",
    role: "Homeowner, Surrey",
    rating: 5,
    quote:
      "GK Electric upgraded our entire panel and installed a Level 2 EV charger in one day. Clean work, fair price, and they handled the permit start to finish.",
  },
  {
    name: "David L.",
    role: "Property Manager, Burnaby",
    rating: 5,
    quote:
      "We've used GK for three commercial buildings now. They're responsive, code-compliant, and never leave a mess behind. Our go-to electricians.",
  },
  {
    name: "Priya K.",
    role: "Restaurant Owner, Vancouver",
    rating: 5,
    quote:
      "An emergency outage on a Saturday — GK had a licensed electrician on-site in under two hours. They saved our weekend service.",
  },
  {
    name: "Mark T.",
    role: "Operations Manager, Richmond",
    rating: 5,
    quote:
      "Industrial rewire on a tight production schedule. GK planned around our downtime windows and delivered exactly what they quoted.",
  },
  {
    name: "Jennifer R.",
    role: "Homeowner, Delta",
    rating: 5,
    quote:
      "Honest, professional, and they explained every option without upselling. Pot lights and smart switches throughout the house — flawless.",
  },
  {
    name: "Alex W.",
    role: "Contractor, Coquitlam",
    rating: 5,
    quote:
      "I sub out all my electrical to GK. Reliable scheduling, accurate quotes, and inspections always pass first time.",
  },
];
