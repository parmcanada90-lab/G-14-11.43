import {
  BadgeCheck,
  Building2,
  Cable,
  CheckCircle2,
  CircuitBoard,
  ClipboardCheck,
  Cpu,
  Factory,
  Gauge,
  HardHat,
  Home,
  LampCeiling,
  Lightbulb,
  PlugZap,
  Radar,
  ShieldCheck,
  Sparkles,
  TimerReset,
  Wrench,
  Zap,
} from "lucide-react";
import residentialImage from "@/assets/residential.jpg";
import commercialImage from "@/assets/commercial.jpg";
import industrialImage from "@/assets/industrial.jpg";

export type ServiceSlug = "residential" | "commercial" | "industrial";

export const servicePageDetails = {
  residential: {
    path: "/services/residential" as const,
    eyebrow: "Residential Services",
    title: "Residential Electrical Services",
    highlight: "For Every Home",
    shortTitle: "Residential Services",
    icon: Home,
    heroIcon: LampCeiling,
    image: residentialImage,
    imageAlt: "Residential electrician installing safe home electrical systems",
    titleMeta: "Residential Electrical Services — Home Wiring, Panels & Lighting | GK Electric",
    description:
      "Licensed residential electricians for home wiring, panel upgrades, renovations, lighting, troubleshooting, EV-ready circuits, safety devices and code-compliant electrical work across Surrey and the Lower Mainland.",
    intro:
      "Safe, clean and code-compliant home electrical work for renovations, custom homes, basement suites, lighting upgrades, panel improvements and everyday repairs.",
    bullets: ["Home wiring & rewiring", "Panel upgrades", "Lighting & smart controls", "Repairs & troubleshooting"],
    services: [
      { icon: Cable, title: "New Home Wiring", desc: "Complete rough-in and finishing for custom homes, additions, garages, shops, suites and remodels." },
      { icon: Gauge, title: "Panel Upgrades", desc: "Service upgrades, sub-panels, breaker replacement, load calculations and future-ready capacity planning." },
      { icon: Lightbulb, title: "Lighting Installation", desc: "Pot lights, feature lighting, under-cabinet lighting, outdoor lighting, dimmers and smart switches." },
      { icon: ShieldCheck, title: "Safety Devices", desc: "Smoke alarms, CO detectors, GFCI/AFCI protection, grounding checks and electrical safety corrections." },
      { icon: PlugZap, title: "EV-Ready Circuits", desc: "Dedicated 240V circuits, panel readiness checks and preparation for Level 2 EV charger installation." },
      { icon: Wrench, title: "Repairs & Troubleshooting", desc: "Fast diagnosis for flickering lights, tripping breakers, dead outlets, warm switches and unsafe wiring." },
    ],
    process: ["Site review and electrical goal planning", "Load calculation, permit needs and code check", "Clean installation with protected work areas", "Testing, labeling and final walkthrough"],
    trust: ["Licensed residential electricians", "Respectful work in occupied homes", "Permit-ready installations", "Clean finish and clear communication"],
  },
  commercial: {
    path: "/services/commercial" as const,
    eyebrow: "Commercial Services",
    title: "Commercial Electrical Services",
    highlight: "Built for Business",
    shortTitle: "Commercial Services",
    icon: Building2,
    heroIcon: ClipboardCheck,
    image: commercialImage,
    imageAlt: "Commercial electrical contractor wiring a business space",
    titleMeta: "Commercial Electrical Services — Offices, Retail, TI & Maintenance | GK Electric",
    description:
      "Commercial electrical contractors for offices, retail, restaurants, tenant improvements, lighting retrofits, panels, maintenance, troubleshooting, emergency repairs and code-compliant installations in BC.",
    intro:
      "Reliable power, lighting and electrical infrastructure for offices, retail stores, restaurants, strata spaces, warehouses and tenant improvement projects.",
    bullets: ["Tenant improvements", "Commercial panels", "LED lighting retrofits", "Maintenance & repairs"],
    services: [
      { icon: ClipboardCheck, title: "Tenant Improvements", desc: "Electrical planning, rough-in, finishing and inspection support for offices, retail and restaurant build-outs." },
      { icon: CircuitBoard, title: "Distribution & Panels", desc: "Panels, sub-panels, feeders, circuits and electrical capacity upgrades for growing operations." },
      { icon: Lightbulb, title: "Commercial Lighting", desc: "LED retrofits, emergency lighting, signage circuits, exterior lighting and lighting control systems." },
      { icon: TimerReset, title: "Maintenance Programs", desc: "Preventive maintenance, repair scheduling and practical troubleshooting to reduce downtime." },
      { icon: Radar, title: "Data-Ready Infrastructure", desc: "Power layouts that support POS systems, equipment, networking, security and future technology needs." },
      { icon: ShieldCheck, title: "Code & Safety", desc: "Deficiency corrections, permit coordination, inspection readiness and safe operation of business spaces." },
    ],
    process: ["Business needs and site condition review", "Electrical planning around schedule and operations", "Professional installation with downtime control", "Testing, documentation and inspection support"],
    trust: ["Business-friendly scheduling", "Tenant improvement experience", "Clear scope and communication", "Code-compliant commercial workmanship"],
  },
  industrial: {
    path: "/services/industrial" as const,
    eyebrow: "Industrial Services",
    title: "Industrial Electrical Services",
    highlight: "Heavy-Duty Power",
    shortTitle: "Industrial Services",
    icon: Factory,
    heroIcon: HardHat,
    image: industrialImage,
    imageAlt: "Industrial electrician working on heavy-duty facility electrical systems",
    titleMeta: "Industrial Electrical Services — Machinery, Three-Phase & Maintenance | GK Electric",
    description:
      "Industrial electrical services for factories, warehouses and facilities: three-phase power, machinery wiring, controls, VFDs, distribution, maintenance, shutdown work and code-compliant upgrades.",
    intro:
      "Heavy-duty electrical expertise for production spaces, warehouses, plants and industrial facilities where reliability, safety and uptime matter.",
    bullets: ["Three-phase power", "Machinery wiring", "Motor controls & VFDs", "Industrial maintenance"],
    services: [
      { icon: Zap, title: "Three-Phase Power", desc: "Feeders, distribution, panels and capacity planning for demanding industrial equipment and production loads." },
      { icon: Cpu, title: "Controls & Automation", desc: "Control wiring, low-voltage interfaces, equipment connections and practical automation support." },
      { icon: Gauge, title: "Motors & VFDs", desc: "Motor circuits, disconnects, VFD wiring, troubleshooting and equipment power requirements." },
      { icon: Factory, title: "Facility Upgrades", desc: "Warehouse, plant and shop electrical upgrades, expansion wiring and system modernization." },
      { icon: TimerReset, title: "Shutdown Work", desc: "Planned maintenance, outage coordination, critical repairs and efficient project sequencing." },
      { icon: BadgeCheck, title: "Industrial Safety", desc: "Code compliance, lockout-aware practices, labeling, testing and inspection-ready workmanship." },
    ],
    process: ["Facility walkthrough and load review", "Shutdown planning and safe work sequencing", "Industrial-grade installation and testing", "Documentation, labeling and ongoing support"],
    trust: ["Heavy electrical experience", "Uptime-focused planning", "Industrial safety mindset", "Scalable power solutions"],
  },
} satisfies Record<ServiceSlug, {
  path: string;
  eyebrow: string;
  title: string;
  highlight: string;
  shortTitle: string;
  icon: typeof Home;
  heroIcon: typeof Home;
  image: string;
  imageAlt: string;
  titleMeta: string;
  description: string;
  intro: string;
  bullets: string[];
  services: { icon: typeof Home; title: string; desc: string }[];
  process: string[];
  trust: string[];
}>;
