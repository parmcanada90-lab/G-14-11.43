export interface Review {
  author: string;
  initial: string;
  rating: number;
  date: string;
  text: string;
}

export const reviewStats = {
  average: 4.9,
  count: 218,
  googleUrl: "https://www.google.com/search?q=GK+Electric+Surrey+BC+reviews",
};

export const featuredReviews: Review[] = [
  {
    author: "Michael B.",
    initial: "M",
    rating: 5,
    date: "2 weeks ago",
    text:
      "Booked an EV charger install — got a quote the same day, work done within the week. Tidy job, fair price, and Greg was great to deal with.",
  },
  {
    author: "Linda P.",
    initial: "L",
    rating: 5,
    date: "1 month ago",
    text:
      "We had flickering lights throughout our condo. GK diagnosed it as a loose service neutral, coordinated with BC Hydro, and resolved it the same day. Highly recommended.",
  },
  {
    author: "Ravi S.",
    initial: "R",
    rating: 5,
    date: "1 month ago",
    text:
      "Whole-home rewire on a 1970s house. The crew was professional, on time every day, and the inspector passed everything on the first walkthrough.",
  },
];
