export interface ServiceArea {
  slug: string;
  name: string;
  description: string;
  highlights: string[];
  /** Approx position on our stylized map (0-100 % of viewBox) */
  x: number;
  y: number;
  featured?: boolean;
}

export const serviceAreas: ServiceArea[] = [
  {
    slug: "vancouver",
    name: "Vancouver",
    description:
      "Heritage homes, condos, restaurants and retail buildouts from East Van to Kitsilano and downtown.",
    highlights: ["Heritage rewiring", "Tenant improvements", "Code compliance"],
    x: 22, y: 46, featured: true,
  },
  {
    slug: "north-vancouver",
    name: "North Vancouver",
    description:
      "Residential service across the North Shore — Lonsdale, Lynn Valley, Deep Cove and Capilano.",
    highlights: ["Panel upgrades", "Lighting design", "EV chargers"],
    x: 26, y: 30,
  },
  {
    slug: "west-vancouver",
    name: "West Vancouver",
    description:
      "Premium residential electrical for West Van — Ambleside, Dundarave, British Properties.",
    highlights: ["Smart homes", "Outdoor lighting", "Hot tub circuits"],
    x: 14, y: 28,
  },
  {
    slug: "burnaby",
    name: "Burnaby",
    description:
      "Metrotown, Brentwood, Lougheed and Edmonds — full residential and commercial coverage.",
    highlights: ["Commercial specialists", "Panel upgrades", "EV chargers"],
    x: 35, y: 47, featured: true,
  },
  {
    slug: "richmond",
    name: "Richmond",
    description:
      "Residential, commercial and light-industrial work across Steveston, Brighouse and Bridgeport.",
    highlights: ["Industrial wiring", "LED retrofits", "Maintenance contracts"],
    x: 26, y: 60, featured: true,
  },
  {
    slug: "new-westminster",
    name: "New Westminster",
    description:
      "Uptown, Sapperton and Queensborough — heritage rewiring and modern service upgrades.",
    highlights: ["Heritage homes", "Service upgrades", "Knob & tube"],
    x: 44, y: 56,
  },
  {
    slug: "coquitlam",
    name: "Coquitlam",
    description:
      "Tri-Cities coverage including Port Coquitlam and Port Moody — residential & commercial.",
    highlights: ["New construction", "Renovations", "Inspections"],
    x: 50, y: 42,
  },
  {
    slug: "surrey",
    name: "Surrey",
    description:
      "Our home base — Newton, Guildford, Cloverdale, Fleetwood and South Surrey. Same-day service.",
    highlights: ["Same-day service", "Residential & commercial", "Permit-ready"],
    x: 55, y: 62, featured: true,
  },
  {
    slug: "delta",
    name: "Delta",
    description:
      "North Delta, Ladner and Tsawwassen — residential, agricultural and commercial electrical.",
    highlights: ["Farm & barn wiring", "Service upgrades", "Generators"],
    x: 38, y: 73,
  },
  {
    slug: "white-rock",
    name: "White Rock",
    description:
      "Oceanfront residential and small commercial work along the South Surrey peninsula.",
    highlights: ["Coastal-rated work", "Outdoor lighting", "Hot tubs"],
    x: 50, y: 82,
  },
  {
    slug: "langley",
    name: "Langley",
    description:
      "Langley City and Township — new builds, farm electrical and growing commercial corridors.",
    highlights: ["New construction", "Agricultural", "EV chargers"],
    x: 67, y: 60,
  },
  {
    slug: "maple-ridge",
    name: "Maple Ridge",
    description:
      "Pitt Meadows and Maple Ridge — residential service, panel changes and rural electrical.",
    highlights: ["Rural service", "Panel changes", "Outbuildings"],
    x: 66, y: 38,
  },
  {
    slug: "abbotsford",
    name: "Abbotsford",
    description:
      "Fraser Valley coverage including Clearbrook, Sumas and McCallum — farm and commercial focus.",
    highlights: ["Agricultural", "Commercial", "Service upgrades"],
    x: 80, y: 55,
  },
  {
    slug: "chilliwack",
    name: "Chilliwack",
    description:
      "Eastern Fraser Valley electrical — Sardis, Promontory and rural Chilliwack properties.",
    highlights: ["Rural & farm", "New construction", "Generators"],
    x: 92, y: 58,
  },
];
