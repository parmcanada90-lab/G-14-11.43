import { Home, Building2, Factory } from "lucide-react";
import villaImg from "@/assets/project-villa.jpg";
import officeImg from "@/assets/project-office.jpg";
import plantImg from "@/assets/project-plant.jpg";
import townhouseImg from "@/assets/project-townhouse.jpg";
import retailImg from "@/assets/project-retail.jpg";
import warehouseImg from "@/assets/project-warehouse.jpg";

export type Category = "residential" | "commercial" | "industrial";
export type Status = "Completed" | "Ongoing";

export interface Project {
  id: string;
  title: string;
  category: Category;
  status: Status;
  rating: number;
  image: string;
  description: string;
  location: string;
  duration: string;
  budget: string;
  client: string;
  features: string[];
  testimonial?: { quote: string; author: string };
}

export const categoryMeta: Record<Category, { label: string; icon: typeof Home }> = {
  residential: { label: "Residential", icon: Home },
  commercial: { label: "Commercial", icon: Building2 },
  industrial: { label: "Industrial", icon: Factory },
};

export const projects: Project[] = [
  {
    id: "luxury-villa",
    title: "Luxury Villa Complete Rewiring",
    category: "residential",
    status: "Completed",
    rating: 5,
    image: villaImg,
    description:
      "Complete electrical renovation of 5,000 sq ft luxury villa with smart home integration, premium lighting systems, and energy-efficient solutions.",
    location: "South Surrey",
    duration: "3 months",
    budget: "$32,000 CAD",
    client: "Private Residence",
    features: [
      "Smart Home Automation",
      "LED Lighting Systems",
      "Solar Panel Integration",
      "Emergency Backup",
    ],
    testimonial: {
      quote: "Exceptional work quality and professional approach. Highly recommended!",
      author: "Mr. Johnson",
    },
  },
  {
    id: "corporate-office",
    title: "Corporate Office Complex",
    category: "commercial",
    status: "Completed",
    rating: 4.9,
    image: officeImg,
    description:
      "Full electrical installation for 50,000 sq ft corporate office including server rooms, conference facilities, and energy management systems.",
    location: "Surrey Central",
    duration: "5 months",
    budget: "$95,000 CAD",
    client: "Westline Holdings",
    features: [
      "Server Room Setup",
      "Conference AV Systems",
      "Energy Management",
      "Access Control Wiring",
    ],
    testimonial: {
      quote: "On time, on budget, and code-perfect. GK Electric delivered every milestone.",
      author: "S. Patel, Facilities Manager",
    },
  },
  {
    id: "manufacturing-plant",
    title: "Manufacturing Plant Upgrade",
    category: "industrial",
    status: "Ongoing",
    rating: 5,
    image: plantImg,
    description:
      "High-voltage electrical upgrade for manufacturing facility including power distribution, machinery connections, and three-phase systems.",
    location: "Cloverdale",
    duration: "8 months",
    budget: "$170,000 CAD",
    client: "Pacific Manufacturing Co.",
    features: [
      "High Voltage Systems",
      "Industrial Automation",
      "Three-Phase Power",
      "PLC Integration",
    ],
    testimonial: {
      quote: "Their industrial expertise kept our production line running without disruption.",
      author: "D. Nguyen, Plant Director",
    },
  },
  {
    id: "townhouse-development",
    title: "Townhouse Development",
    category: "residential",
    status: "Completed",
    rating: 4.8,
    image: townhouseImg,
    description:
      "Full electrical service for a 12-unit townhouse development including individual panels, EV-ready garages, and code-compliant inspections.",
    location: "Langley",
    duration: "6 months",
    budget: "$140,000 CAD",
    client: "Horizon Developments",
    features: [
      "12 Service Panels",
      "EV-Ready Garages",
      "Permits & Inspections",
      "Exterior Lighting",
    ],
  },
  {
    id: "retail-storefront",
    title: "Retail Storefront Build-out",
    category: "commercial",
    status: "Completed",
    rating: 4.9,
    image: retailImg,
    description:
      "Turnkey electrical build-out for a flagship retail location featuring custom feature lighting, signage power, and POS network infrastructure.",
    location: "Guildford",
    duration: "2 months",
    budget: "$48,000 CAD",
    client: "Northshore Retail Group",
    features: [
      "Feature LED Lighting",
      "Illuminated Signage",
      "POS Network Wiring",
      "Security Power",
    ],
  },
  {
    id: "warehouse-lighting",
    title: "Warehouse High-Bay Lighting",
    category: "industrial",
    status: "Completed",
    rating: 5,
    image: warehouseImg,
    description:
      "Energy-efficient retrofit of 80,000 sq ft warehouse with LED high-bay lighting, motion controls, and upgraded distribution panels.",
    location: "Port Kells",
    duration: "4 months",
    budget: "$110,000 CAD",
    client: "Cascade Logistics",
    features: [
      "LED High-Bay Retrofit",
      "Motion Controls",
      "Panel Upgrades",
      "Energy Audit",
    ],
  },
];
