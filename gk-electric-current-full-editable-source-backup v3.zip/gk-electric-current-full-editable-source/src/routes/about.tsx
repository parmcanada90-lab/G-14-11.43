import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Award,
  BadgeCheck,
  Building2,
  CheckCircle2,
  Clock,
  Factory,
  FileCheck,
  Home,
  Lightbulb,
  MapPin,
  MessageCircle,
  Phone,
  Plug,
  ShieldCheck,
  Star,
  Users,
  Wrench,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import residential from "@/assets/residential.jpg";
import commercial from "@/assets/commercial.jpg";
import industrial from "@/assets/industrial.jpg";
import evCharger from "@/assets/ev-charger.jpg";
import aboutWhoWeAre from "@/assets/about-who-we-are.png";
import gkLogo from "@/assets/gk-logo.jpeg";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";

const whoWeAreHighlights = [
  "Licensed & Professional Electricians",
  "Energy-Efficient Electrical Solutions",
  "Residential & Commercial Expertise",
  "Future-Ready Smart Technology Integration",
  "Commitment to Quality & Safety",
] as const;

const proofStats = [
  { value: "18+", label: "Years of Electrical Experience" },
  { value: "1000+", label: "Residential, Commercial & Industrial Projects" },
  { value: "24/7", label: "Emergency Support Availability" },
  { value: "100%", label: "Client Satisfaction Focus" },
] as const;

const serviceExpertise = [
  {
    icon: Home,
    title: "Residential Electricians",
    image: residential,
    text: "Safe, clean and code-compliant residential electrical services for custom homes, renovations, basement suites, lighting upgrades, troubleshooting, panel upgrades and new construction wiring across Surrey and the Lower Mainland.",
    bullets: ["Home wiring & rewiring", "Panel upgrades", "Lighting & smart controls"],
    to: "/services/residential" as const,
  },
  {
    icon: Building2,
    title: "Commercial Electrical Contractors",
    image: commercial,
    text: "Professional electrical planning and installation for offices, retail stores, restaurants, tenant improvements, warehouses and commercial developments that need reliable power, data-ready infrastructure and minimal downtime.",
    bullets: ["Tenant improvements", "Lighting retrofits", "Power distribution"],
    to: "/services/commercial" as const,
  },
  {
    icon: Factory,
    title: "Industrial Electrical Services",
    image: industrial,
    text: "Industrial-grade expertise for factories, plants and production spaces including three-phase power, distribution panels, equipment connections, controls, maintenance and electrical upgrades for demanding environments.",
    bullets: ["Three-phase systems", "Equipment connections", "Controls & automation"],
    to: "/services/industrial" as const,
  },
  {
    icon: Plug,
    title: "EV Charger Installation",
    image: evCharger,
    text: "Future-ready EV charging solutions for homeowners, strata properties, workplaces and commercial parking areas, including load assessments, panel readiness checks, permits and inspection coordination.",
    bullets: ["Level 2 chargers", "Panel load review", "Permit-ready installs"],
    to: "/ev-charger" as const,
  },
] as const;

const processSteps = [
  {
    icon: MessageCircle,
    title: "Listen & Assess",
    text: "We start with your goals, site conditions, timeline and budget so the recommendation fits the property—not a one-size-fits-all template.",
  },
  {
    icon: FileCheck,
    title: "Plan, Permits & Code",
    text: "Our team considers electrical code requirements, load capacity, safety, access, future expansion and inspection needs before work begins.",
  },
  {
    icon: Wrench,
    title: "Install With Precision",
    text: "From rough-in to finishing, we work cleanly, coordinate around active spaces and complete installations with professional workmanship.",
  },
  {
    icon: BadgeCheck,
    title: "Test, Verify & Support",
    text: "We test the work, review final details and remain available for maintenance, upgrades and future electrical service needs.",
  },
] as const;

const values = [
  "Safety-first electrical work for homes, businesses and industrial facilities",
  "Transparent communication before, during and after every project",
  "Code-compliant installations designed for long-term reliability",
  "Modern, energy-efficient solutions that reduce waste and improve performance",
  "Respectful electricians who keep job sites clean, organized and professional",
  "Local service knowledge for Surrey, Langley, Delta, White Rock and nearby BC communities",
] as const;

const serviceAreas = [
  "Surrey",
  "Langley",
  "Delta",
  "White Rock",
  "Cloverdale",
  "South Surrey",
  "Newton",
  "Guildford",
  "Fleetwood",
  "Port Kells",
  "Lower Mainland",
] as const;

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About GK Electric — Licensed Electricians You Can Trust" },
      { name: "description", content: "GK Electric: licensed, insured electricians serving residential, commercial and industrial clients. Learn about our experience, values and team." },
      { property: "og:title", content: "About GK Electric" },
      { property: "og:description", content: "Licensed electricians with deep experience across residential, commercial and industrial work." },
      { property: "og:image", content: industrial },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: industrial },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[50vh] flex items-center text-surface-foreground">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
        </div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <ElectricSectionTag label="About Us" icon={Users} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
            <h1
              data-reveal
              className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6"
            >
              <span className="text-typewriter">
                Meet <span className="text-primary">GK Electric</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-surface-foreground/70 max-w-2xl mx-auto mb-8 leading-relaxed">
              GK Electric is a fully licensed and insured electrical contractor.
              We bring industrial-grade expertise to every project — whether it's
              a single outlet or a full factory installation.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="tel:+17783444567"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
                  <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    Call Us
                  </div>
                  <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
                </div>
              </a>
              <a
                href="https://wa.me/17783444567"
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
                  <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    WhatsApp
                  </div>
                  <div className="text-surface-foreground font-semibold">Quick Response</div>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-10 text-primary/5 animate-float pointer-events-none">
          <Users className="h-32 w-32 rotate-12" />
        </div>
        <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500 pointer-events-none">
          <Users className="h-24 w-24 -rotate-12" />
        </div>
      </section>

      {/* WHO WE ARE — copied from home page */}
      <section className="relative overflow-hidden py-24 bg-background">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
        <div className="absolute -top-32 -right-32 h-80 w-80 rounded-full bg-primary/10 blur-3xl" aria-hidden />
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Image with glossy hover sweep */}
            <div data-reveal="left" className="relative">
              <div className="absolute -left-5 top-8 bottom-8 w-3 bg-gradient-to-b from-primary via-primary/70 to-primary/20 rounded-sm hidden md:block" aria-hidden />
              <div className="absolute -inset-5 rounded-[2rem] bg-primary/15 blur-2xl opacity-70 transition-opacity duration-700 group-hover:opacity-100" aria-hidden />
              <div className="absolute -right-5 -bottom-5 h-36 w-36 rounded-full border border-primary/40 bg-primary/10 blur-[1px]" aria-hidden />
              <div className="group relative overflow-hidden rounded-[1.75rem] shadow-elegant aspect-[4/5] bg-surface ring-1 ring-primary/20">
                <img
                  src={aboutWhoWeAre}
                  alt="GK Electric electrical team at work"
                  loading="lazy"
                  width={1200}
                  height={1500}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06] motion-reduce:transform-none"
                />
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_28%_34%,rgba(247,193,74,0.24),transparent_28%),linear-gradient(180deg,transparent_45%,rgba(20,26,40,0.58)_100%)]" aria-hidden />
                <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-white/18 to-transparent mix-blend-overlay" aria-hidden />
                <div className="absolute right-5 top-5 hidden sm:flex items-center gap-3 rounded-2xl border border-white/30 bg-white/92 px-4 py-3 text-surface shadow-2xl backdrop-blur-md">
                  <img
                    src={gkLogo}
                    alt="GK Electric logo"
                    className="h-11 w-11 rounded-full object-contain ring-2 ring-primary/40"
                  />
                  <div className="leading-tight">
                    <div className="font-display text-lg tracking-widest text-surface">GK ELECTRIC</div>
                    <div className="text-[11px] font-bold uppercase tracking-[0.22em] text-primary">Safe • Smart • Reliable</div>
                  </div>
                </div>
                <div className="absolute left-5 top-5 inline-flex items-center gap-2 rounded-full border border-white/25 bg-surface/65 px-4 py-2 text-xs font-bold uppercase tracking-widest text-white backdrop-blur-md">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Licensed Team
                </div>
                <div className="absolute bottom-5 left-5">
                  <div className="inline-flex items-center gap-4 rounded-2xl border-[3px] border-white bg-[#00497b] px-5 py-4 shadow-xl">
                    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl">
                      <img
                        src={tsbcLogo}
                        alt="Technical Safety BC logo"
                        className="h-14 w-14 object-contain"
                        loading="lazy"
                      />
                    </div>
                    <div className="text-white">
                      <div className="text-[1.25rem] tracking-wider text-white">TSBC Licence</div>
                      <div className="text-[1.5rem] tracking-[2px] font-bold text-white"># LEL0209793</div>
                    </div>
                  </div>
                </div>
                {/* Diagonal gloss sweep — top-left to bottom-right */}
                <span
                  aria-hidden
                  className="pointer-events-none absolute inset-0 rounded-[1.75rem] overflow-hidden motion-reduce:hidden"
                >
                  <span
                  className="absolute inset-0 opacity-0 mix-blend-screen bg-no-repeat bg-[linear-gradient(135deg,transparent_44%,rgba(255,255,255,0.2)_48%,rgba(255,255,255,0.6)_50%,rgba(255,255,255,0.2)_52%,transparent_56%)] bg-[length:400%_400%] bg-[position:150%_150%] transition-[background-position,opacity] duration-[2400ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:opacity-100 group-hover:bg-[position:-50%_-50%]"
                  />
                </span>
              </div>
            </div>

            {/* Content */}
            <div data-reveal="right">
              <ElectricSectionTag label="Who We Are" icon={Users} tone="light" variant="electric-v1-2" className="mb-4" />
              <h2 className="text-4xl md:text-5xl mb-8 leading-tight">
                Surrey electricians delivering <span className="text-primary">safe power, smarter spaces</span> and dependable results.
              </h2>

              <div className="grid gap-4 mb-10">
                {whoWeAreHighlights.map((item, index) => (
                  <div
                    key={item}
                    className="group relative overflow-hidden rounded-2xl border border-border bg-card p-5 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-elegant"
                    style={{ transitionDelay: `${index * 45}ms` }}
                  >
                    <div className="absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-primary via-primary/80 to-primary/20" aria-hidden />
                    <div className="flex items-center gap-4">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary transition-all duration-300 group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-110">
                        <CheckCircle2 className="h-5 w-5" />
                      </div>
                      <span className="text-base md:text-lg font-bold text-foreground">
                        {item}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl border border-primary/25 bg-primary/10 p-6">
                <div className="flex items-start gap-4">
                  <ShieldCheck className="mt-1 h-6 w-6 shrink-0 text-primary" />
                  <p className="text-base md:text-lg font-medium leading-relaxed text-foreground/90">
                    GK Electric delivers safe, efficient, code-compliant electrical
                    work for homes and businesses across Surrey and the Lower Mainland.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-4">
            {proofStats.map((stat) => (
              <div
                key={stat.label}
                className="group rounded-2xl border border-border bg-card p-6 text-center shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-elegant"
              >
                <div className="font-display text-4xl md:text-5xl text-primary mb-2">
                  {stat.value}
                </div>
                <p className="text-xs md:text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden py-24 bg-surface text-surface-foreground">
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)", backgroundSize: "34px 34px" }} />
        <div className="absolute left-0 top-1/3 h-72 w-72 rounded-full bg-primary/10 blur-3xl" aria-hidden />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mb-14">
            <ElectricSectionTag label="Electrical Expertise" icon={Lightbulb} tone="dark" variant="electric-v1-2" className="mb-5" />
            <h2 className="text-4xl md:text-6xl mb-5">
              Full-service electrical solutions for every property type.
            </h2>
            <p className="text-lg text-surface-foreground/75 leading-relaxed">
              Our About page is more than a company profile—it is a promise to deliver
              reliable electrical service, safe installations and practical solutions for
              residential, commercial, industrial and EV charging projects.
            </p>
          </div>

          <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
            {serviceExpertise.map((service, i) => (
              <article
                key={service.title}
                className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] shadow-elegant transition-all duration-500 hover:-translate-y-2 hover:border-primary/50"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <div className="aspect-[4/3] overflow-hidden bg-surface-foreground/10">
                  <img
                    src={service.image}
                    alt={`${service.title} by GK Electric`}
                    loading="lazy"
                    width={900}
                    height={675}
                    className="h-full w-full object-cover opacity-80 transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-glow">
                    <service.icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl mb-3">{service.title}</h3>
                  <p className="text-sm text-surface-foreground/70 leading-relaxed mb-5">
                    {service.text}
                  </p>
                  <ul className="space-y-2 mb-6">
                    {service.bullets.map((item) => (
                      <li key={item} className="flex items-center gap-2 text-sm text-surface-foreground/85">
                        <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    to={service.to}
                    className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-primary hover:text-primary-glow"
                  >
                    Learn More <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-muted/40">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <ElectricSectionTag label="Why Choose GK Electric" icon={ShieldCheck} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
            <h2 className="text-4xl md:text-6xl mb-5">Built on safety, service and long-term trust.</h2>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Choosing an electrical contractor affects safety, performance, future maintenance
              and property value. GK Electric combines licensed workmanship with a customer-first
              process designed to make your project easier from start to finish.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {[
              { icon: Award, title: "Licensed & Insured", desc: "Fully licensed electricians with comprehensive insurance and a commitment to safe electrical practices." },
              { icon: Zap, title: "Fast Response", desc: "Quick scheduling, practical communication and urgent support when electrical issues cannot wait." },
              { icon: Wrench, title: "Clean Work", desc: "Professional, tidy workmanship with respect for occupied homes, active businesses and busy facilities." },
              { icon: Users, title: "Full-Spectrum", desc: "Residential, commercial, industrial and EV charger expertise from one dependable local team." },
            ].map((f) => (
              <div key={f.title} className="group p-7 rounded-2xl bg-card border border-border shadow-card text-center transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:shadow-elegant">
                <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary transition-all duration-300 group-hover:bg-primary group-hover:text-primary-foreground group-hover:rotate-3">
                  <f.icon className="h-8 w-8" />
                </div>
                <h3 className="text-lg mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-8 items-stretch">
            <div className="rounded-3xl bg-card border border-border p-8 md:p-10 shadow-card">
              <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary mb-6">
                <ShieldCheck className="h-7 w-7" />
              </div>
              <h3 className="text-3xl md:text-4xl mb-5">Our core values</h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Every project is guided by the same standards: safe work, reliable scheduling,
                honest recommendations and electrical installations that meet the needs of today
                while preparing your property for tomorrow.
              </p>
              <div className="grid sm:grid-cols-2 gap-3">
                {values.map((value) => (
                  <div key={value} className="flex gap-3 rounded-xl bg-muted/60 p-4 text-sm text-foreground/85">
                    <Star className="h-4 w-4 text-primary shrink-0 mt-0.5 fill-primary" />
                    <span>{value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-3xl bg-surface text-surface-foreground p-8 md:p-10 shadow-elegant relative overflow-hidden">
              <div className="absolute -right-16 -top-16 h-44 w-44 rounded-full bg-primary/20 blur-3xl" aria-hidden />
              <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground mb-6 relative z-10">
                <Clock className="h-7 w-7" />
              </div>
              <h3 className="text-3xl md:text-4xl mb-5 relative z-10">How we work</h3>
              <div className="space-y-5 relative z-10">
                {processSteps.map((step, index) => (
                  <div key={step.title} data-reveal className="group flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary border border-primary/30 transition-all duration-300 group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-110 group-hover:shadow-glow">
                        <step.icon className="h-5 w-5" />
                      </div>
                      {index !== processSteps.length - 1 && <div className="h-full w-px bg-primary/20 my-2" />}
                    </div>
                    <div className="pb-4">
                      <h4 className="text-lg mb-1">{step.title}</h4>
                      <p className="text-sm text-surface-foreground/70 leading-relaxed">{step.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-center">
            <div>
              <ElectricSectionTag label="Local Service Areas" icon={MapPin} tone="light" variant="electric-v1-2" className="mb-4" />
              <h2 className="text-4xl md:text-6xl mb-6">Your Lower Mainland electrical partner.</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                GK Electric serves Surrey and surrounding communities with electrical repair,
                installation, renovation, upgrade and maintenance services. Our local experience
                helps us plan around municipal requirements, property styles, commercial build-out
                needs and the practical realities of BC homes and businesses.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild variant="electric" size="lg">
                  <Link to="/service-areas">
                    View Service Areas <MapPin className="h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link to="/free-estimate">
                    Request Free Estimate <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>

            <div className="rounded-3xl border border-border bg-card p-6 md:p-8 shadow-card">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {serviceAreas.map((area) => (
                  <Link
                    key={area}
                    to="/service-areas"
                    className="group rounded-xl border border-border bg-background px-4 py-4 text-center text-sm font-semibold text-foreground transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:bg-primary hover:text-primary-foreground"
                  >
                    {area}
                  </Link>
                ))}
              </div>
              <div className="mt-6 rounded-2xl bg-muted/60 p-5 text-sm text-muted-foreground leading-relaxed">
                Popular searches we help with include: electrician Surrey BC, residential electrician,
                commercial electrical contractor, industrial electrician, EV charger installer, panel
                upgrade electrician, electrical permits and code-compliant wiring.
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-electric text-primary-foreground text-center">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <ShieldCheck className="h-14 w-14 mx-auto mb-5" />
            <h2 className="text-4xl md:text-6xl mb-4">Let's power your next project safely.</h2>
            <p className="text-primary-foreground/80 mb-8 text-lg leading-relaxed">
              Talk to GK Electric about residential electrical work, commercial upgrades,
              industrial power, EV charging, permits, troubleshooting or code-compliant installations.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button asChild size="xl" variant="default" className="bg-surface text-surface-foreground hover:bg-surface/90">
                <Link to="/free-estimate">Get Free Estimate</Link>
              </Button>
              <Button asChild size="xl" variant="outline" className="border-surface text-surface hover:bg-surface hover:text-surface-foreground">
                <a href="tel:+17783444567">Call +1 (778) 344-4567</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
