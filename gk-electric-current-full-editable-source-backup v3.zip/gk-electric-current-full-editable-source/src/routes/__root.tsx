import { Outlet, Link, createRootRoute, useRouterState } from "@tanstack/react-router";
import { useEffect, useLayoutEffect } from "react";
import { useScrollReveal } from "@/hooks/use-reveal";
import { Preloader } from "@/components/Preloader";

const DEFAULT_TITLE =
  "GK Electric — Licensed Residential, Commercial & Industrial Electrician";
const DEFAULT_DESCRIPTION =
  "Licensed electricians for residential, commercial and industrial projects. EV charger installation, permits & code compliance.";

type MetaTag = Record<string, string>;

function setTag(selector: string, attrs: MetaTag) {
  let el = document.head.querySelector<HTMLMetaElement>(selector);
  if (!el) {
    el = document.createElement("meta");
    document.head.appendChild(el);
  }
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
}

function applyHeadFromMatches(matches: ReadonlyArray<{ meta?: unknown }>) {
  // Merge meta from all matched routes; later routes override earlier ones.
  const merged = new Map<string, MetaTag>();
  for (const m of matches) {
    const meta = (m as { meta?: MetaTag[] }).meta;
    if (!Array.isArray(meta)) continue;
    for (const tag of meta) {
      if (!tag || typeof tag !== "object") continue;
      const key = tag.title
        ? "title"
        : tag.name
          ? `name:${tag.name}`
          : tag.property
            ? `property:${tag.property}`
            : tag.charSet
              ? "charset"
              : JSON.stringify(tag);
      merged.set(key, tag);
    }
  }

  let title = DEFAULT_TITLE;
  let description = DEFAULT_DESCRIPTION;

  for (const [key, tag] of merged) {
    if (key === "title" && typeof tag.title === "string") {
      title = tag.title;
    } else if (key.startsWith("name:") && typeof tag.content === "string") {
      const name = key.slice(5);
      if (name === "description") description = tag.content;
      setTag(`meta[name="${name}"]`, { name, content: tag.content });
    } else if (key.startsWith("property:") && typeof tag.content === "string") {
      const property = key.slice(9);
      setTag(`meta[property="${property}"]`, { property, content: tag.content });
    }
  }

  document.title = title;
  setTag('meta[name="description"]', { name: "description", content: description });
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { title: DEFAULT_TITLE },
      { name: "description", content: DEFAULT_DESCRIPTION },
      { name: "author", content: "GK Electric" },
    ],
  }),
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

export function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function RootComponent() {
  const matches = useRouterState({ select: (s) => s.matches });
  const locationHref = useRouterState({ select: (s) => s.location.href });
  useScrollReveal();

  useLayoutEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, [locationHref]);

  useEffect(() => {
    applyHeadFromMatches(matches as unknown as Array<{ meta?: unknown }>);
  }, [matches]);

  return (
    <>
      <Preloader />
      <Outlet />
    </>
  );
}
