import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  CheckCircle2,
  Clock,
  Factory,
  Home,
  MessageCircle,
  Phone,
  PlugZap,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import gkLogo from "@/assets/gk-logo.jpeg";

export const Route = createFileRoute("/Sample-Contact-1")({
  head: () => ({
    meta: [
      { title: "Sample Contact 1 — 25 New GK Electric Designs" },
      {
        name: "description",
        content:
          "25 new premium contact and service selector designs for GK Electric, inspired by the strongest dark gold sample style with more breathing room and improved spacing.",
      },
    ],
  }),
  component: SampleContactOnePage,
});

const services = [
  { label: "Residential", to: "/services/residential" as const, icon: Home, detail: "Homes, suites, lighting" },
  { label: "Commercial", to: "/services/commercial" as const, icon: Building2, detail: "Retail, offices, TI work" },
  { label: "Industrial", to: "/services/industrial" as const, icon: Factory, detail: "Facilities, machinery, power" },
  { label: "EV Charger", to: "/ev-charger" as const, icon: PlugZap, detail: "Level 2 charger installs" },
];

const contactActions = [
  { label: "Contact Us", sub: "Call our team", href: "tel:+17783444567", icon: Phone, external: true },
  { label: "Request a Quote", sub: "Project pricing", href: "/free-estimate", icon: BadgeCheck, external: false },
  { label: "WhatsApp Us", sub: "Chat now", href: "https://wa.me/17783444567", icon: MessageCircle, external: true },
];

const trust = ["Free Quotes", "Licensed & Insured", "Fast Response", "Permit-Ready Work"];

const designTitles = [
  "Command Center Contact",
  "Premium Quote Console",
  "Emergency Response Panel",
  "Service Selector Hub",
  "Dark Gold Conversion Block",
  "Surrey Power Desk",
  "Split Action Contact",
  "Estimate Launch Pad",
  "Electrical Support Grid",
  "Gold Line Contact Flow",
  "Priority Dispatch Card",
  "Service Matrix Contact",
  "Lower Mainland Connect",
  "Licensed Contractor Panel",
  "Project Intake System",
  "Rapid Quote Interface",
  "High Voltage Contact",
  "Business Power Support",
  "Home Service Gateway",
  "Industrial Contact Deck",
  "EV Ready Request Block",
  "Trust Signal Contact",
  "Permit Support Selector",
  "Modern Call Console",
  "Final CTA Experience",
];

function ServiceButton({ label, to, icon: Icon, detail, compact = false }: { label: string; to: string; icon: typeof Home; detail: string; compact?: boolean }) {
  return (
    <Link
      to={to as never}
      className={`group relative overflow-hidden rounded-2xl border border-white/12 bg-white/[0.055] ${compact ? "p-4" : "p-5 md:p-6"} text-white shadow-[0_18px_55px_rgba(0,0,0,0.22)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-amber-400/70 hover:bg-amber-400 hover:text-slate-950 hover:shadow-[0_24px_70px_rgba(245,181,38,0.18)]`}
    >
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-300/70 to-transparent opacity-0 transition group-hover:opacity-100" />
      <div className="flex items-center justify-between gap-4">
        <span className="flex min-w-0 items-center gap-4">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-slate-950 shadow-[0_0_26px_rgba(245,181,38,0.24)] transition group-hover:bg-slate-950 group-hover:text-amber-400">
            <Icon className="h-5 w-5" />
          </span>
          <span className="min-w-0">
            <span className="block text-sm font-black uppercase tracking-[0.13em]">{label}</span>
            <span className="mt-1 block text-sm text-white/55 transition group-hover:text-slate-800/75">{detail}</span>
          </span>
        </span>
        <ArrowRight className="h-5 w-5 shrink-0 text-amber-400 transition group-hover:translate-x-1 group-hover:text-slate-950" />
      </div>
    </Link>
  );
}

function ActionLink({ action, large = false }: { action: (typeof contactActions)[number]; large?: boolean }) {
  const Icon = action.icon;
  const classes = `group flex items-center gap-4 rounded-2xl border border-white/12 bg-white/[0.07] ${large ? "p-5 md:p-6" : "p-4"} text-white shadow-[0_18px_55px_rgba(0,0,0,0.22)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-amber-400/70 hover:bg-white/[0.12]`;
  const content = (
    <>
      <span className="flex h-13 w-13 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-slate-950 shadow-[0_0_28px_rgba(245,181,38,0.25)] transition group-hover:scale-110">
        <Icon className="h-5 w-5" />
      </span>
      <span className="min-w-0">
        <span className="block text-sm font-black uppercase tracking-[0.13em]">{action.label}</span>
        <span className="mt-1 block text-sm text-white/58">{action.sub}</span>
      </span>
    </>
  );

  if (action.external) {
    return (
      <a href={action.href} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noreferrer" : undefined} className={classes}>
        {content}
      </a>
    );
  }

  return (
    <Link to={action.href as never} className={classes}>
      {content}
    </Link>
  );
}

function TrustPills({ center = false }: { center?: boolean }) {
  return (
    <div className={`flex flex-wrap gap-3 ${center ? "justify-center" : ""}`}>
      {trust.map((item) => (
        <span key={item} className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.06] px-4 py-2 text-[11px] font-black uppercase tracking-[0.11em] text-white/75">
          <CheckCircle2 className="h-3.5 w-3.5 text-amber-400" />
          {item}
        </span>
      ))}
    </div>
  );
}

function GlowFrame({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative overflow-hidden rounded-[2.25rem] border border-white/10 bg-gradient-to-br from-[#111111] via-[#25200f] to-[#070707] p-6 shadow-[0_30px_100px_rgba(15,23,42,0.2)] md:p-8 lg:p-10 ${className}`}>
      <div className="pointer-events-none absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "linear-gradient(90deg,white 1px,transparent 1px),linear-gradient(white 1px,transparent 1px)", backgroundSize: "48px 48px" }} />
      <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-amber-400/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 left-10 h-56 w-56 rounded-full bg-blue-500/10 blur-3xl" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-300/80 to-transparent" />
      <div className="relative">{children}</div>
    </div>
  );
}

function DesignCard({ index }: { index: number }) {
  const title = designTitles[index - 1];
  const variant = index % 5;

  if (variant === 1) {
    return (
      <GlowFrame>
        <div className="grid gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
          <div className="space-y-7">
            <div className="flex items-center justify-between gap-4">
              <div className="inline-flex items-center gap-3 rounded-full bg-amber-400 px-5 py-2.5 text-xs font-black uppercase tracking-[0.18em] text-slate-950">
                <Sparkles className="h-4 w-4" /> Redesign {String(index).padStart(2, "0")}
              </div>
              <img src={gkLogo} alt="GK Electric logo" className="h-12 w-12 rounded-full object-contain" />
            </div>
            <div>
              <h2 className="font-display text-4xl font-black uppercase leading-[0.92] tracking-tight text-white md:text-6xl">{title}</h2>
              <p className="mt-6 max-w-3xl text-lg leading-relaxed text-white/68">Licensed electrical support for Surrey homes, commercial spaces, industrial facilities, EV chargers, emergency repairs, and permit-backed electrical projects.</p>
            </div>
            <TrustPills />
          </div>
          <div className="grid gap-4">
            {services.map((service) => (
              <ServiceButton key={service.label} {...service} />
            ))}
          </div>
        </div>
        <div className="mt-8 grid gap-4 rounded-[1.75rem] border border-white/10 bg-white/[0.045] p-5 md:grid-cols-3 md:p-6">
          {contactActions.map((action) => <ActionLink key={action.label} action={action} />)}
        </div>
      </GlowFrame>
    );
  }

  if (variant === 2) {
    return (
      <GlowFrame>
        <div className="mb-10 text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-3 rounded-full bg-amber-400 px-5 py-2.5 text-xs font-black uppercase tracking-[0.18em] text-slate-950">
            <Zap className="h-4 w-4" /> Redesign {String(index).padStart(2, "0")}
          </div>
          <h2 className="mx-auto max-w-5xl font-display text-4xl font-black uppercase leading-[0.95] tracking-tight text-white md:text-6xl">{title}</h2>
          <p className="mx-auto mt-5 max-w-3xl text-lg leading-relaxed text-white/65">Select a service or contact GK Electric directly for fast quotes and professional electrical support.</p>
        </div>
        <div className="grid gap-5 lg:grid-cols-4">
          {services.map((service) => <ServiceButton key={service.label} {...service} compact />)}
        </div>
        <div className="mt-8 grid gap-5 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <TrustPills center />
          <div className="grid gap-4 md:grid-cols-3">{contactActions.map((action) => <ActionLink key={action.label} action={action} />)}</div>
        </div>
      </GlowFrame>
    );
  }

  if (variant === 3) {
    return (
      <GlowFrame>
        <div className="grid gap-8 xl:grid-cols-[0.7fr_1.3fr]">
          <div className="rounded-[1.75rem] border border-amber-400/25 bg-amber-400 p-7 text-slate-950 shadow-[0_0_60px_rgba(245,181,38,0.18)] md:p-9">
            <div className="mb-8 flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-[0.18em]">Redesign {String(index).padStart(2, "0")}</span>
              <ShieldCheck className="h-9 w-9" />
            </div>
            <h2 className="font-display text-4xl font-black uppercase leading-[0.92] tracking-tight md:text-5xl">{title}</h2>
            <p className="mt-5 text-base font-semibold leading-relaxed text-slate-800">Emergency response, clear estimates, safe installations, and code-compliant electrical work for every property type.</p>
          </div>
          <div className="grid gap-5">
            <div className="grid gap-4 md:grid-cols-2">{services.map((service) => <ServiceButton key={service.label} {...service} />)}</div>
            <div className="grid gap-4 md:grid-cols-3">{contactActions.map((action) => <ActionLink key={action.label} action={action} />)}</div>
          </div>
        </div>
      </GlowFrame>
    );
  }

  if (variant === 4) {
    return (
      <GlowFrame>
        <div className="grid gap-10 lg:grid-cols-[0.82fr_1.18fr]">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-3 rounded-full bg-amber-400 px-5 py-2.5 text-xs font-black uppercase tracking-[0.18em] text-slate-950">
              <Clock className="h-4 w-4" /> Redesign {String(index).padStart(2, "0")}
            </div>
            <h2 className="font-display text-4xl font-black uppercase leading-[0.92] tracking-tight text-white md:text-6xl">{title}</h2>
            <p className="text-lg leading-relaxed text-white/65">Need a licensed electrician? Start with service selection, then call, request a quote, or message our team on WhatsApp.</p>
            <TrustPills />
          </div>
          <div className="rounded-[1.75rem] border border-white/10 bg-black/20 p-5 md:p-6">
            <div className="grid gap-4 md:grid-cols-2">{services.map((service) => <ServiceButton key={service.label} {...service} />)}</div>
            <div className="mt-5 grid gap-4 md:grid-cols-3">{contactActions.map((action) => <ActionLink key={action.label} action={action} />)}</div>
          </div>
        </div>
      </GlowFrame>
    );
  }

  return (
    <GlowFrame>
      <div className="mb-9 flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="mb-5 inline-flex items-center gap-3 rounded-full bg-amber-400 px-5 py-2.5 text-xs font-black uppercase tracking-[0.18em] text-slate-950">
            <Sparkles className="h-4 w-4" /> Redesign {String(index).padStart(2, "0")}
          </div>
          <h2 className="max-w-4xl font-display text-4xl font-black uppercase leading-[0.92] tracking-tight text-white md:text-6xl">{title}</h2>
        </div>
        <img src={gkLogo} alt="GK Electric logo" className="h-16 w-16 rounded-full object-contain" />
      </div>
      <div className="grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
        <div className="grid gap-4 md:grid-cols-2">{services.map((service) => <ServiceButton key={service.label} {...service} />)}</div>
        <div className="grid gap-4">{contactActions.map((action) => <ActionLink key={action.label} action={action} large />)}</div>
      </div>
    </GlowFrame>
  );
}

function SampleContactOnePage() {
  return (
    <div className="min-h-screen bg-[#f5f6f2] text-slate-950">
      <Header />
      <main className="pt-28">
        <section className="px-5 py-16 md:px-8 md:py-24">
          <div className="mx-auto max-w-[1500px] text-center">
            <div className="mx-auto mb-7 inline-flex items-center gap-2 rounded-full border border-amber-200 bg-white px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-amber-700 shadow-sm">
              <Sparkles className="h-4 w-4" /> 25 New Contact Redesigns
            </div>
            <h1 className="font-display text-4xl font-black uppercase leading-tight tracking-tight md:text-7xl">
              Sample Contact 1 — Premium Dark Gold Concepts
            </h1>
            <p className="mx-auto mt-7 max-w-4xl text-lg leading-relaxed text-slate-600 md:text-xl">
              New contact and service selector concepts related to the strongest Design 05 direction, with larger margins, increased padding, clearer spacing, stronger service hierarchy, and improved user readability.
            </p>
          </div>
        </section>

        <section className="px-5 pb-24 md:px-8 md:pb-32">
          <div className="mx-auto grid max-w-[1500px] gap-12 md:gap-14">
            {Array.from({ length: 25 }).map((_, index) => (
              <DesignCard key={index + 1} index={index + 1} />
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
