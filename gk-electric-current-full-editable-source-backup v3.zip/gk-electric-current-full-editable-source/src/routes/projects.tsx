import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Zap, Home, Building2, Factory, FolderKanban, Images, MessageCircle, Phone } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { ProjectCard } from "@/components/ProjectCard";
import { ProjectDialog } from "@/components/ProjectDialog";
import { projects, type Project, type Category } from "@/data/projects";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Our Projects — GK Electric Portfolio" },
      {
        name: "description",
        content:
          "Browse the GK Electric portfolio of residential, commercial and industrial electrical projects across the Lower Mainland.",
      },
      { property: "og:title", content: "Our Projects — GK Electric Portfolio" },
      {
        property: "og:description",
        content:
          "Explore completed and ongoing electrical projects by GK Electric — residential, commercial and industrial.",
      },
    ],
  }),
  component: ProjectsPage,
});

const filters: { id: "all" | Category; label: string; icon: typeof Zap }[] = [
  { id: "all", label: "All Projects", icon: Zap },
  { id: "residential", label: "Residential", icon: Home },
  { id: "commercial", label: "Commercial", icon: Building2 },
  { id: "industrial", label: "Industrial", icon: Factory },
];

function ProjectsPage() {
  const [activeFilter, setActiveFilter] = useState<"all" | Category>("all");
  const [openProject, setOpenProject] = useState<Project | null>(null);

  const visible = useMemo(
    () =>
      projects.filter((p) => activeFilter === "all" || p.category === activeFilter),
    [activeFilter],
  );

  const counts = {
    all: projects.length,
    residential: projects.filter((p) => p.category === "residential").length,
    commercial: projects.filter((p) => p.category === "commercial").length,
    industrial: projects.filter((p) => p.category === "industrial").length,
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[50vh] flex items-center text-surface-foreground">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
        </div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
          <ElectricSectionTag label="Our Portfolio" icon={FolderKanban} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
          <h1 data-reveal className="text-5xl md:text-7xl mb-6"><span className="text-typewriter">All Projects</span></h1>
          <p className="text-lg text-surface-foreground/80 max-w-2xl mx-auto mb-8">
              Every job we deliver — from luxury home rewires to industrial
              facility upgrades. Filter by category to explore.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="tel:+17783444567"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
                  <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    Call Us
                  </div>
                  <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
                </div>
              </a>
              <a
                href="https://wa.me/17783444567"
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
                  <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    WhatsApp
                  </div>
                  <div className="text-surface-foreground font-semibold">Quick Response</div>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-10 text-primary/5 animate-float pointer-events-none">
          <FolderKanban className="h-32 w-32 rotate-12" />
        </div>
        <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500 pointer-events-none">
          <Images className="h-24 w-24 -rotate-12" />
        </div>
      </section>

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          {/* Filters */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {filters.map((f) => {
              const isActive = activeFilter === f.id;
              const count = counts[f.id];
              return (
                <button
                  key={f.id}
                  onClick={() => setActiveFilter(f.id)}
                  className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full border text-sm font-semibold transition-all ${
                    isActive
                      ? "bg-gradient-electric text-primary-foreground border-transparent shadow-glow"
                      : "bg-card text-foreground border-border hover:border-primary/50 hover:text-primary"
                  }`}
                >
                  <f.icon className="h-4 w-4" />
                  {f.label}
                  <span
                    className={`inline-flex items-center justify-center min-w-6 h-6 px-1.5 rounded-full text-xs ${
                      isActive
                        ? "bg-primary-foreground/20 text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Grid */}
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {visible.map((p) => (
              <ProjectCard key={p.id} project={p} onView={setOpenProject} />
            ))}
          </div>
        </div>
      </section>

      <ProjectDialog project={openProject} onClose={() => setOpenProject(null)} />

      <Footer />
    </div>
  );
}
