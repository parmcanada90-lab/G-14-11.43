import { createFileRoute } from "@tanstack/react-router";
import { ResidentialSampleVariant, residentialSampleMeta } from "@/components/ResidentialSampleVariant";

export const Route = createFileRoute("/residential-services-sample-blueprint")({
  head: () => ({
    meta: [
      { title: `${residentialSampleMeta.title} — Blueprint Style Layout | GK Electric` },
      { name: "description", content: residentialSampleMeta.description },
      { property: "og:title", content: `${residentialSampleMeta.title} | GK Electric` },
      { property: "og:description", content: residentialSampleMeta.description },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResidentialServicesSampleBlueprintPage,
});

function ResidentialServicesSampleBlueprintPage() {
  return <ResidentialSampleVariant variant="blueprint" />;
}
