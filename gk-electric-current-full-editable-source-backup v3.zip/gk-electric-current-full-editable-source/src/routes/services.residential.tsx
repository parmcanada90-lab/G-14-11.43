import { createFileRoute } from "@tanstack/react-router";
import { ServicePageTemplate } from "@/components/ServicePageTemplate";
import { servicePageDetails } from "@/data/servicePageDetails";

const detail = servicePageDetails.residential;

export const Route = createFileRoute("/services/residential")({
  head: () => ({
    meta: [
      { title: detail.titleMeta },
      { name: "description", content: detail.description },
      { property: "og:title", content: detail.titleMeta },
      { property: "og:description", content: detail.description },
      { property: "og:image", content: detail.image },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: detail.image },
    ],
  }),
  component: ResidentialServicesPage,
});

function ResidentialServicesPage() {
  return <ServicePageTemplate slug="residential" />;
}
