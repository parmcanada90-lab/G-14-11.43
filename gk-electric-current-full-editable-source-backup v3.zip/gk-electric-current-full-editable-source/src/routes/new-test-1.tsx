import { createFileRoute, Link } from "@tanstack/react-router";
import { Award, BadgeCheck, Bolt, Building2, CheckCircle2, CircuitBoard, ClipboardCheck, Factory, FileCheck2, Home, ShieldCheck, Sparkles, Zap } from "lucide-react";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";

export const Route = createFileRoute("/new-test-1")({
  head: () => ({
    meta: [
      { title: "TSBC Licence Design Set — GK Electric" },
      {
        name: "description",
        content: "A 20-design presentation sheet for GK Electric TSBC licence display concepts.",
      },
    ],
  }),
  component: NewTestOnePage,
});

const licenceNumber = "# LEL0209793";

const iconSet = [ShieldCheck, BadgeCheck, Award, FileCheck2, ClipboardCheck, CircuitBoard, Bolt, Zap, CheckCircle2, Sparkles];

const serviceButtons = [
  { to: "/services/residential" as const, label: "Residential", icon: Home },
  { to: "/services/commercial" as const, label: "Commercial", icon: Building2 },
  { to: "/services/industrial" as const, label: "Industrial", icon: Factory },
];

const conceptThreeTags = [
  "Fully Licensed & Insured",
  "100% Code-Compliant Work",
  "24/7 Emergency Service",
] as const;

const conceptSixTags = [
  "Fully Licensed & Insured",
  "100% Code-Compliant Work",
  "24/7 Emergency Service",
  "Quality Workmanship Guaranteed",
] as const;

const designs = Array.from({ length: 20 }, (_, index) => {
  const n = index + 1;
  const title = [
    "Certified Electrical Contractor",
    "Licensed Power Solutions",
    "Verified Safety Standard",
    "Trusted Electrical Service",
    "Code-Compliant Installations",
    "BC Electrical Expertise",
    "Professional Contractor Mark",
    "Reliable Licensed Team",
    "Safety-First Electrical Work",
    "Inspected Quality Service",
  ][index % 10];

  return {
    id: n,
    title: n === 6 || n === 7 ? "Proudly Serving the Lower Mainland, BC" : title,
    subtitle: [
      "Residential • Commercial • Industrial",
      "Permits • Planning • Installation",
      "Surrey • Lower Mainland • BC",
      "Safe • Smart • Reliable",
      "Powering projects with confidence",
    ][index % 5],
    icon: iconSet[index % iconSet.length],
    accent: ["border-primary/70", "border-foreground/30", "border-primary/40", "border-foreground/20", "border-primary/55"][index % 5],
    line: ["bg-primary", "bg-foreground", "bg-primary/70", "bg-foreground/70", "bg-primary"][index % 5],
  };
});

function TsbcLicenceBadge() {
  return (
    <div className="shrink-0 rounded-2xl bg-[#00497b] px-3 py-2.5 shadow-xl ring-2 ring-white/90">
      <div className="flex items-center justify-end gap-3">
        <img
          src={tsbcLogo}
          alt="Technical Safety BC logo"
          className="h-12 w-12 object-contain"
          loading="lazy"
        />
        <div className="text-right text-white">
          <div className="text-[0.95rem] tracking-wider text-white">TSBC Licence</div>
          <div className="text-[1.1rem] tracking-[1.5px] font-bold text-white">{licenceNumber}</div>
        </div>
      </div>
    </div>
  );
}

function DesignCard({ design }: { design: (typeof designs)[number] }) {
  const Icon = design.icon;
  const isConceptSixOrSeven = design.id === 6 || design.id === 7;

  return (
    <article className={`group relative flex ${isConceptSixOrSeven ? "border-2" : "min-h-[21rem] border"} flex-col overflow-hidden rounded-3xl ${design.accent} bg-transparent p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary hover:shadow-elegant`}>
      <div className="flex items-start justify-between gap-4">
        <div className="text-left">
          <div className={`${isConceptSixOrSeven ? "font-sans" : "font-display"} text-lg font-extrabold uppercase leading-none tracking-[0.22em] text-foreground`}>
            GK ELECTRIC
          </div>
          <div className={`mt-1 ${isConceptSixOrSeven ? "text-[12px]" : "text-[10px]"} uppercase tracking-widest text-muted-foreground`}>
            Licensed Electricians
          </div>
          <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.22em] text-muted-foreground">
            Concept {String(design.id).padStart(2, "0")}
          </div>
        </div>
        {design.id === 3 ? (
          <div className="flex shrink-0 flex-col items-end gap-2">
            <TsbcLicenceBadge />
            <div className="flex max-w-[245px] flex-col items-end gap-1.5">
              {conceptThreeTags.map((tag) => (
                <div
                  key={tag}
                  className="inline-flex items-center gap-1.5 rounded-full border border-primary/20 bg-primary/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-foreground shadow-sm"
                >
                  <CheckCircle2 className="h-3 w-3 shrink-0 text-primary" />
                  <span>{tag}</span>
                </div>
              ))}
            </div>
          </div>
        ) : isConceptSixOrSeven ? (
          <div className="shrink-0">
            <TsbcLicenceBadge />
          </div>
        ) : (
          <TsbcLicenceBadge />
        )}
      </div>

      {isConceptSixOrSeven && (
        <div className="mt-5 grid grid-cols-2 gap-2.5">
          {conceptSixTags.map((tag) => (
            <div
              key={tag}
              className="flex min-h-9 w-full items-center gap-1.5 rounded-[10px] border border-primary/20 bg-primary/10 px-3 py-1.5 text-[14px] font-medium leading-none text-foreground shadow-sm"
            >
              <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
              <span className="truncate">{tag}</span>
            </div>
          ))}
        </div>
      )}

      <div className={`${isConceptSixOrSeven ? "mt-5 flex-none" : "mt-8 flex-1"} flex items-start justify-between gap-5`}>
        <div className={isConceptSixOrSeven ? "w-full text-left" : "max-w-[70%] text-left"}>
          <div className={`mb-4 h-1 w-14 rounded-full ${design.line}`} />
          <h2 className={isConceptSixOrSeven ? "whitespace-nowrap font-sans text-[clamp(0.78rem,1.7vw,0.95rem)] font-semibold uppercase leading-none tracking-[0.18em] text-foreground" : "font-display text-2xl font-bold uppercase leading-tight tracking-tight text-foreground"}>
            {design.title}
          </h2>
          {!isConceptSixOrSeven && (
            <p className="mt-3 text-sm font-medium leading-relaxed text-muted-foreground">
              {design.subtitle}
            </p>
          )}
        </div>
        {!isConceptSixOrSeven && (
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-primary/30 bg-transparent text-primary transition-transform duration-300 group-hover:rotate-3 group-hover:scale-105">
            <Icon className="h-8 w-8" />
          </div>
        )}
      </div>

      <div className={`relative z-10 ${isConceptSixOrSeven ? "mt-3" : "mt-6"} grid grid-cols-3 gap-2`}>
        {serviceButtons.map((service) => (
          <Link
            key={service.label}
            to={service.to}
            className="group/service flex items-center justify-center gap-1.5 rounded-xl border border-border bg-muted/40 px-2.5 py-2 text-center transition-all duration-300 hover:border-primary/45 hover:bg-primary/[0.1] focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-white"
          >
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-primary/20 bg-primary/15 text-primary transition-all duration-300 group-hover/service:bg-primary group-hover/service:text-primary-foreground">
              <service.icon className="h-4 w-4" />
            </div>
            <div className={`${isConceptSixOrSeven ? "font-sans" : "font-display"} text-xs font-bold uppercase tracking-wide text-foreground sm:text-sm`}>
              {service.label}
            </div>
          </Link>
        ))}
      </div>
    </article>
  );
}

function NewTestOnePage() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <section className="container mx-auto px-4 py-10 md:py-14">
        <div className="mb-10 flex flex-col gap-5 border-b border-border pb-8 md:flex-row md:items-start md:justify-between">
          <div className="text-left">
            <div className="font-display text-3xl font-extrabold uppercase tracking-[0.2em] text-foreground md:text-5xl">
              GK ELECTRIC
            </div>
            <div className="mt-1 text-[10px] uppercase tracking-widest text-muted-foreground">
              Licensed Electricians
            </div>
            <p className="mt-3 max-w-2xl text-sm font-medium text-muted-foreground md:text-base">
              20 clean transparent layout concepts focused on clearly presenting the TSBC licence badge and number.
            </p>
          </div>
          <div className="md:pt-1">
            <TsbcLicenceBadge />
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {designs.filter((design) => design.id < 6).map((design) => (
            <DesignCard key={design.id} design={design} />
          ))}
        </div>

        <div className="mt-5 grid gap-5 md:grid-cols-[40%_40%] md:justify-end">
          {designs.filter((design) => design.id === 6 || design.id === 7).map((design) => (
            <DesignCard key={design.id} design={design} />
          ))}
        </div>

        <div className="mt-5 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {designs.filter((design) => design.id > 7).map((design) => (
            <DesignCard key={design.id} design={design} />
          ))}
        </div>
      </section>
    </main>
  );
}
