import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import type { LucideIcon } from "lucide-react";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  CheckCircle2,
  Factory,
  Gauge,
  Home,
  MessageCircle,
  Phone,
  Plug,
  ShieldCheck,
  Wrench,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { servicePageDetails } from "@/data/servicePageDetails";
import evImage from "@/assets/ev-charger.jpg";

export const Route = createFileRoute("/home-services-testing")({
  head: () => ({
    meta: [
      { title: "Electrical Services We Provide — Sticky Scroll Testing | GK Electric" },
      {
        name: "description",
        content:
          "Sticky scroll electrical services section for GK Electric with complete residential, commercial, industrial and EV charger service data for Surrey and the Lower Mainland.",
      },
    ],
  }),
  component: HomeServicesTestingPage,
});

type DetailService = {
  icon: LucideIcon;
  title: string;
  desc?: string;
};

type StickyService = {
  icon: LucideIcon;
  title: string;
  eyebrow: string;
  desc: string;
  img: string;
  to: string;
  bullets: string[];
  detailServices: DetailService[];
};

const stickyServiceSlides: StickyService[] = [
  {
    icon: servicePageDetails.residential.icon,
    title: servicePageDetails.residential.title,
    eyebrow: servicePageDetails.residential.eyebrow,
    desc: servicePageDetails.residential.description,
    img: servicePageDetails.residential.image,
    to: "/residential-electrical-services-details",
    bullets: servicePageDetails.residential.bullets,
    detailServices: [
      ...servicePageDetails.residential.services,
      { icon: Home, title: "Renovation Electrical", desc: "Kitchen, suite, garage and remodel electrical support." },
      { icon: BadgeCheck, title: "Permit-Ready Home Work", desc: "Electrical work prepared for inspections and approvals." },
    ],
  },
  {
    icon: servicePageDetails.commercial.icon,
    title: servicePageDetails.commercial.title,
    eyebrow: servicePageDetails.commercial.eyebrow,
    desc: servicePageDetails.commercial.description,
    img: servicePageDetails.commercial.image,
    to: "/commercial-electrical-services-details",
    bullets: servicePageDetails.commercial.bullets,
    detailServices: [
      ...servicePageDetails.commercial.services,
      { icon: Building2, title: "Office & Retail Build-Outs", desc: "Business electrical planning and finishing." },
      { icon: Zap, title: "Emergency Commercial Repairs", desc: "Fast response for business power problems." },
    ],
  },
  {
    icon: servicePageDetails.industrial.icon,
    title: servicePageDetails.industrial.title,
    eyebrow: servicePageDetails.industrial.eyebrow,
    desc: servicePageDetails.industrial.description,
    img: servicePageDetails.industrial.image,
    to: "/industrial-electrical-services-details",
    bullets: servicePageDetails.industrial.bullets,
    detailServices: [
      ...servicePageDetails.industrial.services,
      { icon: Wrench, title: "Equipment Troubleshooting", desc: "Diagnosis for machinery and facility electrical faults." },
      { icon: ShieldCheck, title: "Code-Ready Upgrades", desc: "Safe industrial upgrades prepared for inspection." },
    ],
  },
  {
    icon: Plug,
    title: "EV Charger Installation",
    eyebrow: "Future-Ready Charging",
    desc:
      "Level 2 EV charger installation for homes, strata properties, commercial parking and business fleets with panel checks, dedicated 240V circuits, load management and safe code-compliant setup.",
    img: evImage,
    to: "/ev-charger",
    bullets: ["Level 2 home chargers", "Panel capacity checks", "Dedicated 240V circuits", "Commercial EV charging"],
    detailServices: [
      { icon: Plug, title: "Level 2 Home Chargers", desc: "Fast home charging for garages and driveways." },
      { icon: Gauge, title: "Panel Capacity Checks", desc: "Load review before charger installation." },
      { icon: Zap, title: "Dedicated 240V Circuits", desc: "Safe, clean charger power circuits." },
      { icon: Building2, title: "Commercial EV Charging", desc: "Charging solutions for parking and fleets." },
      { icon: ShieldCheck, title: "Load Management", desc: "Safer charging for modern electrical demand." },
      { icon: BadgeCheck, title: "Permit & Inspection Support", desc: "Code-compliant installation support." },
      { icon: Wrench, title: "Charger Troubleshooting", desc: "Diagnosis for charger and circuit issues." },
      { icon: CheckCircle2, title: "Future-Ready Installation", desc: "Built for long-term EV ownership." },
    ],
  },
];

const trustData = [
  "🛡️ FULLY LICENSED & INSURED IN BC",
  "✅ TECHNICAL SAFETY BC COMPLIANT",
  "⚡ 24/7 EMERGENCY AVAILABILITY",
  "⏱️ FAST 30–60 MINUTE RESPONSE TIME",
  "📍 SERVING SURREY & THE LOWER MAINLAND",
  "🏠 RESIDENTIAL, COMMERCIAL & INDUSTRIAL EXPERTS",
  "⚙️ ELECTRICAL REPAIRS, INSTALLATIONS & UPGRADES",
  "🔌 EV CHARGER & PANEL UPGRADE SPECIALISTS",
  "💰 FREE ESTIMATES & UPFRONT PRICING",
  "⭐ QUALITY ELECTRICAL WORKMANSHIP",
  "🤝 RELIABLE & PROFESSIONAL SERVICE",
];

const contactActions = [
  { label: "Contact US", sub: "Call our team", href: "tel:+17783444567", icon: Phone, external: true },
  { label: "Request a Quote", sub: "Get project pricing", href: "/free-estimate", icon: BadgeCheck, external: false },
  { label: "WhatsApp US", sub: "Chat with us now", href: "https://wa.me/17783444567", icon: MessageCircle, external: true },
];

const sampleTrust = ["Free Quotes", "Clear Pricing", "Licensed & Insured", "Permit-Ready Work"];

function SectionProgressRail({ active }: { active: number }) {
  return (
    <div className="pointer-events-none fixed left-4 top-1/2 z-50 hidden -translate-y-1/2 rounded-full border border-white/12 bg-black/30 px-2 py-4 backdrop-blur-md xl:flex xl:flex-col xl:items-center xl:gap-3" aria-hidden="true">
      <div className="text-[10px] font-black uppercase tracking-[0.24em] text-white/60 [writing-mode:vertical-rl]">services</div>
      <div className="relative h-52 w-[3px] overflow-hidden rounded-full bg-white/18">
        <div
          className="absolute left-0 top-0 w-full rounded-full bg-primary shadow-[0_0_18px_rgba(245,181,38,.9)] transition-all duration-500"
          style={{ height: `${((active + 1) / stickyServiceSlides.length) * 100}%` }}
        />
      </div>
      <div className="text-[11px] font-black text-primary">0{active + 1}</div>
    </div>
  );
}

function ActionLink({ action }: { action: (typeof contactActions)[number] }) {
  const Icon = action.icon;
  const classes =
    "group flex items-center gap-4 rounded-2xl border border-white/12 bg-white/[0.06] p-4 text-white transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:bg-white/[0.10]";
  const content = (
    <>
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-glow">
        <Icon className="h-5 w-5" />
      </span>
      <span>
        <span className="block text-sm font-black uppercase tracking-[0.12em]">{action.label}</span>
        <span className="mt-1 block text-sm text-white/58">{action.sub}</span>
      </span>
    </>
  );

  if (action.external) {
    return (
      <a href={action.href} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noreferrer" : undefined} className={classes}>
        {content}
      </a>
    );
  }

  return (
    <Link to={action.href as never} className={classes}>
      {content}
    </Link>
  );
}

function StickyServiceCard({ service, index }: { service: StickyService; index: number }) {
  const Icon = service.icon;

  return (
    <Link
      to={service.to as never}
      data-sticky-service-card
      className="group sticky top-28 block overflow-hidden rounded-[1.75rem] border border-white/14 bg-surface transition-all duration-500 hover:-translate-y-1 hover:border-primary/45 hover:shadow-glow"
      style={{ zIndex: index + 10 }}
    >
      <div className="absolute inset-0 rounded-[1.75rem] ring-1 ring-inset ring-white/10" />
      <div className="relative h-[280px] overflow-hidden md:h-[330px] lg:h-[360px]">
        <img src={service.img} alt={`${service.title} electrical service`} className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-t from-surface/85 via-surface/18 to-transparent" />
        <div className="absolute right-5 top-5 rounded-full border border-primary/35 bg-surface/75 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-primary backdrop-blur-md">
          {service.eyebrow}
        </div>
      </div>

      <div className="relative flex flex-col bg-surface p-5 md:p-7">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground transition-transform duration-500 group-hover:rotate-6">
            <Icon className="h-7 w-7" />
          </div>
          <div className="font-display text-6xl font-black text-white/10">{String(index + 1).padStart(2, "0")}</div>
        </div>
        <h3 className="font-display text-3xl font-bold leading-none text-white md:text-4xl xl:text-5xl">{service.title}</h3>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-surface-foreground/72 md:text-base">{service.desc}</p>
        <div className="mt-5 flex flex-wrap gap-2">
          {service.bullets.map((bullet) => (
            <span key={bullet} className="rounded-full border border-white/10 bg-white/[0.06] px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.10em] text-surface-foreground/72">
              {bullet}
            </span>
          ))}
        </div>
        <div className="mt-5 grid gap-2 sm:grid-cols-2">
          {service.detailServices.slice(0, 8).map((detail, detailIndex) => {
            const DetailIcon = detail.icon;
            return (
              <div
                key={detail.title}
                className="group/detail flex min-h-[62px] items-center gap-3 rounded-2xl border border-white/80 bg-white/95 p-3 shadow-sm backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/35"
                style={{ transitionDelay: `${detailIndex * 30}ms` }}
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/20 transition-colors duration-300 group-hover/detail:bg-primary group-hover/detail:text-primary-foreground">
                  <DetailIcon className="h-[18px] w-[18px]" />
                </span>
                <span className="text-[0.86rem] font-medium uppercase leading-snug tracking-[0.07em] text-foreground">{detail.title}</span>
              </div>
            );
          })}
        </div>
        <div className="mt-6 inline-flex w-fit items-center gap-2 rounded-full border border-primary/50 bg-surface/70 px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary backdrop-blur-md transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
          Explore More Services <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  );
}

function ContactServicesPanel() {
  return (
    <div className="mt-8">
      <section className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-surface p-5 text-surface-foreground md:p-7 lg:p-8">
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-primary/20 blur-3xl" />
        <div className="relative grid grid-cols-12 gap-5">
          <div className="col-span-12 lg:col-span-7">
            <h2 className="font-display text-3xl font-black uppercase leading-[0.95] tracking-tight md:text-5xl">
              Licensed Electricians in Surrey & Lower Mainland
            </h2>
            <p className="mt-4 text-base font-semibold leading-relaxed text-white/75 md:text-lg">
              Residential, Commercial, Industrial & EV Charger Electrical Services
            </p>
            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-white/62">
              Choose the electrical service you need or contact GK Electric for a clear quote, emergency support, and code-compliant work across Surrey, BC.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {sampleTrust.map((item) => (
                <span key={item} className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-3 py-2 text-[11px] font-black uppercase tracking-[0.1em] text-white/75">
                  <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
                  {item}
                </span>
              ))}
            </div>
          </div>

          <div className="col-span-12 lg:col-span-5">
            <div className="flex h-full min-h-[360px] flex-col rounded-[1.5rem] border border-white/12 bg-black/20 p-5 backdrop-blur-md md:p-6">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-black uppercase tracking-[0.18em] text-primary">Checkout our services</div>
                  <p className="mt-2 text-sm text-white/60">Select the service that matches your project.</p>
                </div>
                <Zap className="h-8 w-8 text-primary" />
              </div>
              <div className="grid flex-1 gap-4 sm:grid-cols-2">
                {stickyServiceSlides.map((service) => {
                  const Icon = service.icon;
                  return (
                    <Link key={service.title} to={service.to as never} className="group flex min-h-[96px] items-center justify-between rounded-2xl border border-white/15 bg-white/[0.06] p-5 text-sm font-black uppercase tracking-[0.1em] text-white transition-all duration-300 hover:-translate-y-1 hover:border-primary hover:bg-primary hover:text-primary-foreground">
                      <span className="flex items-center gap-3"><Icon className="h-5 w-5 text-primary transition group-hover:text-current" />{service.title.replace(" Electrical Services", "")}</span>
                      <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
                    </Link>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="col-span-12">
            <div className="grid gap-4 rounded-[1.5rem] border border-white/12 bg-white/[0.055] p-4 md:grid-cols-[1.05fr_1.45fr]">
              <div>
                <h3 className="font-display text-2xl font-black uppercase tracking-tight text-white">Ready to start your electrical project?</h3>
                <p className="mt-3 text-sm leading-relaxed text-white/62">
                  Talk with our team for free quotes, clear project pricing, emergency support, and permit-backed electrical work done safely and professionally.
                </p>
              </div>
              <div className="grid gap-3 md:grid-cols-3">
                {contactActions.map((action) => <ActionLink key={action.label} action={action} />)}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function ElectricalServicesStickySection() {
  const [active, setActive] = useState(0);
  const activeService = stickyServiceSlides[active] ?? stickyServiceSlides[0];
  const ActiveIcon = activeService.icon;

  useEffect(() => {
    const update = () => {
      const cards = Array.from(document.querySelectorAll<HTMLElement>("[data-sticky-service-card]"));
      const target = window.innerHeight * 0.42;
      let next = 0;
      cards.forEach((card, index) => {
        const rect = card.getBoundingClientRect();
        if (rect.top <= target && rect.bottom > target) next = index;
      });
      setActive(next);
    };

    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  const activeBullets = useMemo(() => activeService.bullets.slice(0, 4), [activeService]);

  return (
    <section data-scroll-tone="dark" data-sticky-service-section="true" className="py-24 bg-surface text-surface-foreground relative overflow-visible">
      <SectionProgressRail active={active} />
      <div className="pointer-events-none absolute inset-0 opacity-[0.055]" style={{ backgroundImage: "linear-gradient(90deg, white 1px, transparent 1px), linear-gradient(white 1px, transparent 1px)", backgroundSize: "46px 46px" }} />
      <div className="pointer-events-none absolute left-0 top-24 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />

      <div className="container mx-auto grid items-start gap-10 px-4 relative z-10 lg:grid-cols-[0.96fr_1.04fr] lg:[--service-card-height:940px] xl:[--service-card-height:980px]">
        <div className="lg:sticky lg:top-24 lg:h-[var(--service-card-height)] lg:self-start">
          <div className="flex h-full flex-col justify-between">
            <div>
              <ElectricSectionTag label="Electrical Services We Provide" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-6" />
              <h2 className="font-display text-4xl font-extrabold tracking-tight md:text-5xl xl:text-6xl">
                Surrey & Lower Mainland Residential, Commercial & Industrial <span className="brand-highlight">Electrical Services</span>
              </h2>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-surface-foreground/70 xl:text-lg">
                From outlet upgrades and panel replacements to complete commercial and industrial electrical systems, our licensed electricians provide safe, reliable, and code-compliant electrical services throughout Surrey and the Lower Mainland.
              </p>

              <div className="mt-8 rounded-[1.75rem] border border-white/12 bg-white/[0.07] p-5 shadow-[0_24px_80px_rgba(0,0,0,0.28)] backdrop-blur-md">
                <div className="mb-5 flex items-center gap-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-glow">
                    <ActiveIcon className="h-7 w-7" />
                  </div>
                  <div>
                    <div className="text-xs font-black uppercase tracking-[0.2em] text-primary">Active Scroll Card</div>
                    <h3 className="font-display text-2xl font-bold text-white">{activeService.title}</h3>
                  </div>
                </div>
                <div className="grid gap-2 sm:grid-cols-2">
                  {activeBullets.map((bullet) => (
                    <div key={bullet} className="rounded-xl border border-white/10 bg-white/[0.045] px-3 py-2 text-xs font-bold uppercase tracking-[0.08em] text-surface-foreground/76">
                      {bullet}
                    </div>
                  ))}
                </div>
                <div className="mt-5 flex gap-2">
                  {stickyServiceSlides.map((slide, index) => (
                    <span key={slide.title} className={`h-2 rounded-full transition-all duration-300 ${active === index ? "w-10 bg-primary shadow-glow" : "w-2 bg-white/24"}`} />
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 overflow-hidden rounded-[1.75rem] border border-white/12 bg-white/[0.07] shadow-[0_24px_80px_rgba(0,0,0,0.28)] backdrop-blur-md">
              <div className="border-b border-white/10 bg-white/[0.055] px-5 py-4">
                <h3 className="font-display text-2xl font-extrabold uppercase tracking-[0.06em] text-white">Why Customers Choose GK Electric</h3>
              </div>
              <div className="grid gap-2 p-4">
                {trustData.map((label) => (
                  <div key={label} className="rounded-2xl border border-white/10 bg-white/[0.045] px-4 py-3 text-[15px] font-light uppercase leading-snug tracking-[0.08em] text-surface-foreground/86 transition-all duration-300 hover:border-primary/35 hover:bg-primary/10 hover:text-white">
                    {label}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6 lg:space-y-9">
          {stickyServiceSlides.map((service, index) => <StickyServiceCard key={service.title} service={service} index={index} />)}
          <div className="hidden h-[38vh] lg:block" aria-hidden="true" />
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <ContactServicesPanel />
      </div>
    </section>
  );
}

function HomeServicesTestingPage() {
  return (
    <div className="min-h-screen bg-surface text-surface-foreground">
      <Header />
      <main className="relative overflow-visible pt-20">
        <ElectricalServicesStickySection />
      </main>
      <Footer />
    </div>
  );
}
