import { createFileRoute } from "@tanstack/react-router";
import { ResidentialServicesSamplePage } from "./residential-services-sample";

export const Route = createFileRoute("/residential-electrical-services-1")({
  head: () => ({
    meta: [
      {
        title:
          "Residential Electrical Services — Complete Home Electrician Services | GK Electric",
      },
      {
        name: "description",
        content:
          "Professional residential electrical services for repairs, lighting upgrades, panel replacements, EV chargers, rewiring, permits, inspections, new construction, suites, HVAC, appliances and safety upgrades.",
      },
      {
        property: "og:title",
        content: "Residential Electrical Services | GK Electric",
      },
      {
        property: "og:description",
        content:
          "Reliable home electrical services for repairs, renovations, panels, wiring, lighting, EV chargers, safety inspections and code-compliant upgrades.",
      },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResidentialElectricalServicesPage,
});

function ResidentialElectricalServicesPage() {
  return <ResidentialServicesSamplePage />;
}
