import { createFileRoute } from "@tanstack/react-router";
import {
  Award,
  ChevronRight,
  Clock,
  ExternalLink,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Send,
  Shield,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact GK Electric — Free Estimate | Licensed Electricians" },
      {
        name: "description",
        content:
          "Contact GK Electric for residential, commercial, industrial electrical work and EV charger installation. Call, WhatsApp, or send a message for a free estimate.",
      },
      { property: "og:title", content: "Contact GK Electric" },
      {
        property: "og:description",
        content: "Get a free, no-obligation estimate from licensed electricians today.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: ContactPage,
});

const ADDRESS = "8381 128 St #105, Surrey, BC V3W 4G1";
const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(ADDRESS)}`;
const MAPS_EMBED = `https://www.google.com/maps?q=${encodeURIComponent(ADDRESS)}&output=embed`;

const services = [
  "Residential Electrical",
  "Commercial Electrical",
  "Industrial Electrical",
  "EV Charger Installation",
  "Panel Upgrade",
  "Permits & Inspections",
  "Emergency Service",
  "Other",
];

const trustBadges = [
  { icon: Shield, text: "Fully Licensed" },
  { icon: Award, text: "Insured Services" },
  { icon: Zap, text: "Fast Response" },
  { icon: Clock, text: "24/7 Emergency" },
];

function ContactPage() {
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("Thanks! We'll be in touch shortly.", {
        description: "Our team will review your request and contact you within 24 hours.",
      });
      (e.target as HTMLFormElement).reset();
      setFormData({ name: "", email: "", phone: "", service: "", message: "" });
    }, 800);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <Toaster position="top-center" />

      <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[50vh] flex items-center">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
        </div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <ElectricSectionTag label="Free Estimates Available" icon={MessageCircle} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
            <h1
              data-reveal
              className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6"
            >
              <span className="text-typewriter">
                Let&apos;s <span className="text-primary">Connect</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-surface-foreground/70 max-w-2xl mx-auto mb-8 leading-relaxed">
              Ready to power your next project? Get in touch with our licensed
              electricians for a free, no-obligation estimate.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="tel:+17783444567"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
                  <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    Call Us
                  </div>
                  <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
                </div>
              </a>
              <a
                href="https://wa.me/17783444567"
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
                  <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    WhatsApp
                  </div>
                  <div className="text-surface-foreground font-semibold">Quick Response</div>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-10 text-primary/5 animate-float">
          <Phone className="h-32 w-32 rotate-12" />
        </div>
        <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500">
          <Mail className="h-24 w-24 -rotate-12" />
        </div>
      </section>

      <section className="relative bg-background py-20 lg:py-28">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 max-w-7xl mx-auto">
            <div className="order-2 lg:order-1">
              <div className="relative">
                <div className="relative bg-card rounded-3xl border border-border shadow-2xl overflow-hidden">
                  <div className="bg-gradient-to-r from-surface to-surface/80 px-8 py-6 border-b border-border">
                    <h2 className="font-display text-2xl md:text-3xl font-bold text-surface-foreground mb-2">
                      Send Us a Message
                    </h2>
                    <p className="text-surface-foreground/60">
                      Fill out the form below and we&apos;ll get back to you within 24 hours.
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="p-8 space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label
                          htmlFor="name"
                          className="text-sm font-semibold text-foreground uppercase tracking-wider"
                        >
                          Full Name <span className="text-primary">*</span>
                        </label>
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          required
                          placeholder="John Smith"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="h-12 bg-background border-border focus:border-primary focus:ring-primary/20 rounded-xl transition-all"
                        />
                      </div>
                      <div className="space-y-2">
                        <label
                          htmlFor="phone"
                          className="text-sm font-semibold text-foreground uppercase tracking-wider"
                        >
                          Phone Number
                        </label>
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          placeholder="+1 (604) 123-4567"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="h-12 bg-background border-border focus:border-primary focus:ring-primary/20 rounded-xl transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="email"
                        className="text-sm font-semibold text-foreground uppercase tracking-wider"
                      >
                        Email Address <span className="text-primary">*</span>
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="h-12 bg-background border-border focus:border-primary focus:ring-primary/20 rounded-xl transition-all"
                      />
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="service"
                        className="text-sm font-semibold text-foreground uppercase tracking-wider"
                      >
                        Service Needed
                      </label>
                      <div className="relative">
                        <select
                          id="service"
                          name="service"
                          value={formData.service}
                          onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                          className="w-full h-12 px-4 bg-background border border-border rounded-xl text-foreground appearance-none cursor-pointer focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
                        >
                          <option value="">Select a service...</option>
                          {services.map((service) => (
                            <option key={service} value={service}>
                              {service}
                            </option>
                          ))}
                        </select>
                        <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground rotate-90 pointer-events-none" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label
                        htmlFor="message"
                        className="text-sm font-semibold text-foreground uppercase tracking-wider"
                      >
                        Project Details <span className="text-primary">*</span>
                      </label>
                      <Textarea
                        id="message"
                        name="message"
                        required
                        rows={5}
                        placeholder="Tell us about your electrical project..."
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="bg-background border-border focus:border-primary focus:ring-primary/20 rounded-xl resize-none transition-all"
                      />
                    </div>

                    <Button
                      type="submit"
                      variant="electric"
                      size="xl"
                      disabled={submitting}
                      className="w-full rounded-xl font-bold"
                    >
                      {submitting ? (
                        <span className="flex items-center gap-2">
                          <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                              fill="none"
                            />
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            />
                          </svg>
                          Sending...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <Send className="h-5 w-5" />
                          Send Message
                        </span>
                      )}
                    </Button>
                  </form>

                  <div className="px-8 py-6 bg-muted/30 border-t border-border">
                    <div className="flex flex-wrap justify-center gap-6">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Shield className="h-5 w-5 text-primary" />
                        <span>Licensed &amp; Insured</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Award className="h-5 w-5 text-primary" />
                        <span>Quality Guaranteed</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="order-1 lg:order-2 space-y-6">
              <div className="relative rounded-3xl overflow-hidden border border-border shadow-xl bg-card group">
                <a
                  href={MAPS_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="absolute top-4 left-4 z-10 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-background/95 backdrop-blur-md text-primary text-sm font-semibold shadow-lg hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                >
                  Open in Maps <ExternalLink className="h-4 w-4" />
                </a>
                <iframe
                  title="GK Electric location map"
                  src={MAPS_EMBED}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-64 lg:h-80 border-0 grayscale group-hover:grayscale-0 transition-all duration-500"
                  allowFullScreen
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div className="p-6 rounded-2xl bg-card border border-border shadow-lg hover:shadow-xl hover:border-primary/20 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                      <MapPin className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                    </div>
                    <div>
                      <h3 className="text-lg font-display font-bold mb-2">Our Location</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        8381 128 St #105
                        <br />
                        Surrey, BC V3W 4G1
                      </p>
                      <a
                        href={MAPS_URL}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-sm text-primary font-semibold mt-3 hover:underline"
                      >
                        Get Directions <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-card border border-border shadow-lg hover:shadow-xl hover:border-primary/20 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                      <Clock className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-display font-bold mb-3">Business Hours</h3>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-center justify-between">
                          <span className="text-muted-foreground">Mon – Fri</span>
                          <span className="font-semibold text-foreground">9:00 AM – 5:30 PM</span>
                        </li>
                        <li className="flex items-center justify-between">
                          <span className="text-muted-foreground">Sat – Sun</span>
                          <span className="font-bold text-muted-foreground/80 uppercase tracking-wider text-xs">
                            Closed
                          </span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl bg-gradient-to-br from-surface to-surface/80 border border-border shadow-lg">
                <div className="flex items-center gap-4">
                  <div className="h-14 w-14 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
                    <Mail className="h-7 w-7 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-display font-bold text-surface-foreground mb-1">
                      Email Us
                    </h3>
                    <a
                      href="mailto:info@gkelectric.ca"
                      className="text-primary hover:underline text-lg font-semibold"
                    >
                      info@gkelectric.ca
                    </a>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {trustBadges.map((badge) => (
                  <div
                    key={badge.text}
                    className="flex items-center gap-3 p-4 rounded-xl bg-muted/50 border border-border/50"
                  >
                    <badge.icon className="h-5 w-5 text-primary shrink-0" />
                    <span className="text-sm font-medium">{badge.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
