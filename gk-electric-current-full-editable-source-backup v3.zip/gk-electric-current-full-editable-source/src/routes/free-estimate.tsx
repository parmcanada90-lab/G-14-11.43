import { createFileRoute } from "@tanstack/react-router";
import { DecorPhoneBolt } from "@/components/decor/LineArt";
import {
  Phone,
  Mail,
  MapPin,
  MessageCircle,
  Send,
  ShieldCheck,
  Star,
  Clock,
  ExternalLink,
  FileText,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/free-estimate")({
  head: () => ({
    meta: [
      { title: "Free Estimate — GK Electric | Licensed Electricians" },
      {
        name: "description",
        content:
          "Request a free, no-obligation electrical estimate from GK Electric for residential, commercial, industrial and EV charger projects.",
      },
      { property: "og:title", content: "Free Estimate — GK Electric" },
      {
        property: "og:description",
        content: "Get a fast, honest, no-obligation estimate from licensed electricians.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: FreeEstimatePage,
});

const ADDRESS = "8381 128 St #105, Surrey, BC V3W 4G1";
const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(ADDRESS)}`;
const MAPS_EMBED = `https://www.google.com/maps?q=${encodeURIComponent(ADDRESS)}&output=embed`;

const services = [
  "Residential Electrical",
  "Commercial Electrical",
  "Industrial Electrical",
  "EV Charger Installation",
  "Panel Upgrade",
  "Permits & Inspections",
  "Emergency Service",
  "Other",
];

function FreeEstimatePage() {
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("Thanks! We'll be in touch shortly.");
      (e.target as HTMLFormElement).reset();
    }, 600);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <Toaster />

      {/* Hero */}
      <section className="relative overflow-hidden bg-surface text-surface-foreground py-20">
        <DecorPhoneBolt side="tr" />
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <ElectricSectionTag label="No-Obligation Quote" icon={FileText} tone="dark" variant="electric-v1-2" className="mb-6 justify-center" />
          <h1 data-reveal className="text-5xl md:text-7xl mb-6"><span className="text-typewriter">Free Estimate</span></h1>
          <p className="text-lg text-surface-foreground/80 max-w-2xl mx-auto">
            Tell us about your project. We'll respond fast with honest pricing
            and timeline.
          </p>
        </div>
      </section>

      {/* Quick contact strip */}
      <section className="py-10 bg-background border-b border-border">
        <div className="container mx-auto px-4 grid sm:grid-cols-3 gap-4">
          <a
            href="tel:+17783444567"
            className="flex items-center gap-4 p-5 rounded-xl bg-card border border-border shadow-card hover:shadow-elegant hover:border-primary/50 transition-all"
          >
            <div className="h-11 w-11 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Phone className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                Call Us
              </div>
              <div className="font-bold text-foreground">+1 (778) 344-4567</div>
            </div>
          </a>
          <a
            href="https://wa.me/17783444567"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-4 p-5 rounded-xl bg-card border border-border shadow-card hover:shadow-elegant hover:border-primary/50 transition-all"
          >
            <div className="h-11 w-11 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <MessageCircle className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                WhatsApp
              </div>
              <div className="font-bold text-foreground">+1 (778) 344-4567</div>
            </div>
          </a>
          <a
            href="mailto:info@gkelectric.ca"
            className="flex items-center gap-4 p-5 rounded-xl bg-card border border-border shadow-card hover:shadow-elegant hover:border-primary/50 transition-all"
          >
            <div className="h-11 w-11 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                Email
              </div>
              <div className="font-bold text-foreground">info@gkelectric.ca</div>
            </div>
          </a>
        </div>
      </section>

      {/* Form + Map */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4 grid lg:grid-cols-3 gap-8">
          {/* Form card */}
          <div className="lg:col-span-2 p-8 md:p-10 rounded-2xl bg-card border border-border shadow-card">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
              <h2 className="text-3xl md:text-4xl font-display">Request Estimate</h2>
              <div className="flex items-center gap-5 text-sm">
                <span className="inline-flex items-center gap-1.5 font-semibold text-foreground">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Licensed
                </span>
                <span className="inline-flex items-center gap-1.5 font-semibold text-foreground">
                  <Star className="h-4 w-4 fill-primary text-primary" />
                  4.8 Rating
                </span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    name="name"
                    required
                    placeholder="John Doe"
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="john@example.com"
                    className="mt-1.5"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    required
                    placeholder="(555) 123-4567"
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label htmlFor="service">Service Needed</Label>
                  <select
                    id="service"
                    name="service"
                    defaultValue=""
                    className="mt-1.5 flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="" disabled>
                      Select a service
                    </option>
                    {services.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <Label htmlFor="message">Project Details</Label>
                <Textarea
                  id="message"
                  name="message"
                  rows={5}
                  required
                  placeholder="Please describe your electrical needs..."
                  className="mt-1.5"
                />
              </div>

              <Button
                type="submit"
                variant="electric"
                size="lg"
                disabled={submitting}
                className="w-full"
              >
                <Send className="h-4 w-4" />
                {submitting ? "Sending..." : "Send Estimate Request"}
              </Button>
            </form>
          </div>

          {/* Right column: map + location + hours */}
          <div className="space-y-6">
            {/* Map */}
            <div className="relative rounded-2xl overflow-hidden border border-border shadow-card bg-card">
              <a
                href={MAPS_URL}
                target="_blank"
                rel="noreferrer"
                className="absolute top-3 left-3 z-10 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-background/95 backdrop-blur text-primary text-xs font-semibold shadow hover:bg-background transition-colors"
              >
                Open in Maps <ExternalLink className="h-3.5 w-3.5" />
              </a>
              <iframe
                title="GK Electric location map"
                src={MAPS_EMBED}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-64 border-0"
                allowFullScreen
              />
            </div>

            {/* Location */}
            <div className="p-6 rounded-2xl bg-card border border-border shadow-card">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <MapPin className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-xl font-display mb-1">Our Location</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    8381 128 St #105
                    <br />
                    Surrey, BC V3W 4G1
                  </p>
                </div>
              </div>
            </div>

            {/* Hours */}
            <div className="p-6 rounded-2xl bg-card border border-border shadow-card">
              <div className="flex items-start gap-3 mb-4">
                <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <Clock className="h-5 w-5" />
                </div>
                <h3 className="text-xl font-display">Business Hours</h3>
              </div>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center justify-between">
                  <span className="text-foreground font-medium">Monday – Friday</span>
                  <span className="text-foreground/80 font-semibold">
                    9:00 AM – 5:30 PM
                  </span>
                </li>
                <li className="flex items-center justify-between">
                  <span className="text-foreground font-medium">
                    Saturday – Sunday
                  </span>
                  <span className="text-muted-foreground font-bold uppercase tracking-wider">
                    Closed
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
