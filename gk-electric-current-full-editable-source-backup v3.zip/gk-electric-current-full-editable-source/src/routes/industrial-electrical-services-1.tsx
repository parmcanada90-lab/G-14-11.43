import { createFileRoute } from "@tanstack/react-router";
import { Factory } from "lucide-react";
import { ServiceClonePage, serviceCloneConfigs } from "@/components/ServiceClonePage";

const config = serviceCloneConfigs.industrial;

export const Route = createFileRoute("/industrial-electrical-services-1")({
  head: () => ({
    meta: [
      { title: "Industrial Electrical Services — Three-Phase, Machinery & Facility Power | GK Electric" },
      { name: "description", content: config.intro },
      { property: "og:title", content: "Industrial Electrical Services | GK Electric" },
      { property: "og:description", content: config.intro },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IndustrialElectricalServicesPage,
});

function IndustrialElectricalServicesPage() {
  return <ServiceClonePage type="industrial" />;
}

export const pageIcon = Factory;
