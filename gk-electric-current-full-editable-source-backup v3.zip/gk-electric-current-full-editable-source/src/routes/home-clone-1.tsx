import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  CalendarCheck,
  CheckCircle2,
  ClipboardCheck,
  Factory,
  FileCheck,
  FilePenLine,
  FileText,
  Gauge,
  Headphones,
  Home,
  Lightbulb,
  MessageCircle,
  Phone,
  Plug,
  PlugZap,
  ScrollText,
  ShieldCheck,
  Wrench,
  Zap,
} from "lucide-react";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import residentialImage from "@/assets/residential.jpg";
import commercialImage from "@/assets/commercial.jpg";
import industrialImage from "@/assets/industrial.jpg";
import evImage from "@/assets/ev-charger.jpg";
import { servicePageDetails } from "@/data/servicePageDetails";

export const Route = createFileRoute("/home-clone-1")({
  head: () => ({
    meta: [
      { title: "Home Clone 1 — GK Electric Sections" },
      { name: "description", content: "Exact cloned home page sections: What We Do, Electrical Services We Provide, and Specialized Service." },
    ],
  }),
  component: HomeCloneOnePage,
});

const services = [
  {
    icon: Home,
    title: "Residential",
    desc: "Full home electrical for safer, brighter, more efficient living spaces.",
    img: residentialImage,
    to: "/services/residential" as const,
    tag: "Residential Electrical Services",
    hash: "residential",
    features: [
      { icon: Lightbulb, label: "Lighting & wiring" },
      { icon: Wrench, label: "Repairs & upgrades" },
      { icon: Plug, label: "Outlets & switches" },
    ],
  },
  {
    icon: Building2,
    title: "Commercial",
    desc: "Reliable power for offices, retail and commercial buildings.",
    img: commercialImage,
    to: "/services/commercial" as const,
    tag: "Commercial Electrical Services",
    hash: "commercial",
    features: [
      { icon: Gauge, label: "Panel installation" },
      { icon: Lightbulb, label: "LED retrofits" },
      { icon: Wrench, label: "Maintenance" },
    ],
  },
  {
    icon: Factory,
    title: "Industrial",
    desc: "Heavy electrical for factories, warehouses and industrial facilities.",
    img: industrialImage,
    to: "/services/industrial" as const,
    tag: "Industrial Electrical Services",
    hash: "industrial",
    features: [
      { icon: Zap, label: "Machinery wiring" },
      { icon: Gauge, label: "Load management" },
      { icon: Zap, label: "Three-phase power" },
    ],
  },
];

const sampleContactActions = [
  { label: "Contact US", sub: "Call our team", href: "tel:+17783444567", icon: Phone, external: true },
  { label: "Request a Quote", sub: "Get project pricing", href: "/free-estimate", icon: BadgeCheck, external: false },
  { label: "WhatsApp US", sub: "Chat with us now", href: "https://wa.me/17783444567", icon: MessageCircle, external: true },
];

const sampleTrust = ["Free Quotes", "Clear Pricing", "Licensed & Insured", "Permit-Ready Work"];

const customerChoiceItems = [
  "🛡️ FULLY LICENSED & INSURED IN BC",
  "✅ TECHNICAL SAFETY BC COMPLIANT",
  "⚡ 24/7 EMERGENCY AVAILABILITY",
  "⏱️ FAST 30–60 MINUTE RESPONSE TIME",
  "💰 FREE ESTIMATES & UPFRONT PRICING",
  "⭐ QUALITY ELECTRICAL WORKMANSHIP",
  "🤝 RELIABLE & PROFESSIONAL SERVICE",
] as const;

const customerChoiceDesigns = [
  { wrap: "rounded-3xl border border-white/12 bg-white/[0.055] p-4", list: "space-y-2", item: "border-b border-white/10 pb-2 text-white/86" },
  { wrap: "rounded-3xl border border-primary/25 bg-primary/[0.08] p-4", list: "space-y-2", item: "rounded-xl bg-white/[0.055] px-3 py-2 text-white/88" },
  { wrap: "rounded-3xl border border-white/10 bg-black/20 p-4 shadow-[0_20px_60px_rgba(0,0,0,0.22)]", list: "space-y-2", item: "border-l-2 border-primary pl-3 text-white/86" },
  { wrap: "rounded-3xl border border-white/12 bg-gradient-to-br from-white/[0.08] to-transparent p-4", list: "grid gap-2", item: "rounded-full border border-white/10 px-4 py-2 text-white/84" },
  { wrap: "rounded-3xl border border-primary/20 bg-white/[0.035] p-4", list: "grid gap-2", item: "rounded-2xl border border-primary/15 bg-primary/[0.055] px-3 py-2 text-white/86" },
  { wrap: "rounded-3xl border border-white/10 bg-white/[0.07] p-4", list: "space-y-2", item: "border-b border-dashed border-white/18 pb-2 text-white/86" },
  { wrap: "rounded-3xl bg-white/[0.045] p-4 ring-1 ring-inset ring-white/12", list: "space-y-2", item: "rounded-xl px-3 py-2 text-white/86 shadow-[inset_0_0_0_1px_rgba(255,255,255,0.08)]" },
  { wrap: "rounded-3xl border border-white/10 bg-surface p-4", list: "space-y-2", item: "bg-white/[0.06] px-3 py-2 text-white/86 first:rounded-t-2xl last:rounded-b-2xl" },
  { wrap: "rounded-3xl border border-primary/30 bg-primary/[0.04] p-4 shadow-glow", list: "space-y-2", item: "rounded-xl border border-white/10 bg-black/15 px-3 py-2 text-white/86" },
  { wrap: "rounded-3xl border border-white/12 bg-white/[0.04] p-4 backdrop-blur-md", list: "grid gap-2", item: "rounded-xl border-l-4 border-primary bg-white/[0.045] px-3 py-2 text-white/86" },
  { wrap: "rounded-3xl border border-white/12 bg-gradient-to-r from-primary/[0.12] to-white/[0.035] p-4", list: "space-y-2", item: "rounded-2xl bg-surface/55 px-3 py-2 text-white/86" },
  { wrap: "rounded-3xl border border-white/10 bg-white/[0.035] p-4", list: "space-y-2", item: "rounded-xl border border-transparent px-3 py-2 text-white/86 hover:border-primary/35 hover:bg-primary/10" },
  { wrap: "rounded-3xl border border-primary/20 bg-black/10 p-4", list: "space-y-1.5", item: "px-2 py-2 text-white/86 odd:bg-white/[0.055] even:bg-white/[0.025]" },
  { wrap: "rounded-3xl border border-white/10 bg-white/[0.055] p-4", list: "space-y-2", item: "rounded-xl bg-gradient-to-r from-white/[0.09] to-transparent px-3 py-2 text-white/86" },
  { wrap: "rounded-3xl border border-white/10 bg-white/[0.035] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]", list: "grid gap-2", item: "rounded-xl border border-white/10 px-3 py-2 text-white/86 shadow-sm" },
  { wrap: "rounded-3xl border border-primary/25 bg-primary/[0.06] p-4", list: "space-y-2", item: "rounded-xl bg-white/[0.075] px-3 py-2 text-white/90 backdrop-blur" },
  { wrap: "rounded-3xl border border-white/12 bg-[linear-gradient(135deg,rgba(255,255,255,0.08),rgba(255,255,255,0.02))] p-4", list: "space-y-2", item: "border-b border-white/10 px-2 pb-2 text-white/86 last:border-b-0" },
  { wrap: "rounded-3xl border border-white/10 bg-white/[0.045] p-4", list: "space-y-2", item: "rounded-2xl border border-primary/10 bg-primary/[0.035] px-3 py-2 text-white/86" },
  { wrap: "rounded-3xl border border-white/12 bg-black/25 p-4", list: "space-y-2", item: "rounded-xl border-r-2 border-primary bg-white/[0.045] px-3 py-2 text-white/86" },
  { wrap: "rounded-3xl border border-primary/30 bg-white/[0.05] p-4 shadow-[0_24px_70px_rgba(245,181,38,0.10)]", list: "space-y-2", item: "rounded-xl border border-white/10 bg-surface/55 px-3 py-2 text-white/88" },
] as const;

function HomeDesign05ServiceButton({ label, to, icon: Icon }: { label: string; to: string; icon: typeof Home }) {
  return (
    <Link
      to={to as never}
      className="group flex min-h-[92px] items-center justify-between rounded-2xl border border-white/15 bg-white/[0.06] p-5 text-base font-black uppercase tracking-[0.12em] text-white transition-all duration-300 hover:-translate-y-1 hover:border-amber-400 hover:bg-amber-400 hover:text-slate-950 md:min-h-[112px] md:p-6"
    >
      <span className="flex items-center gap-3">
        <Icon className="h-6 w-6 text-amber-500 transition group-hover:text-current" />
        {label}
      </span>
      <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
    </Link>
  );
}

function HomeDesign05ActionLink({ action }: { action: (typeof sampleContactActions)[number] }) {
  const Icon = action.icon;
  const classes = "group flex items-center gap-4 rounded-2xl border border-white/15 bg-white/[0.07] p-4 text-white transition-all duration-300 hover:-translate-y-1 hover:border-amber-400 hover:bg-white/[0.12]";
  const content = (
    <>
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-slate-950 shadow-[0_0_24px_rgba(245,181,38,0.28)]">
        <Icon className="h-5 w-5" />
      </span>
      <span>
        <span className="block text-sm font-black uppercase tracking-[0.12em]">{action.label}</span>
        <span className="mt-1 block text-sm text-white/60">{action.sub}</span>
      </span>
    </>
  );

  if (action.external) {
    return (
      <a href={action.href} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noreferrer" : undefined} className={classes}>
        {content}
      </a>
    );
  }

  return (
    <Link to={action.href as never} className={classes}>
      {content}
    </Link>
  );
}

function HomeSampleContactDesign11() {
  return (
    <div className="mt-6">
      <div className="mx-auto max-w-[1500px]">
        <section className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-surface p-5 text-surface-foreground md:p-7 lg:p-8">
          <div className="relative grid grid-cols-12 gap-5">
            <div className="col-span-12 lg:col-span-7">
              <h2 className="font-display text-3xl font-black uppercase leading-[0.95] tracking-tight md:text-5xl">
                Licensed Electricians in Surrey & Lower Mainland
              </h2>
              <p className="mt-4 text-base font-semibold leading-relaxed text-white/75 md:text-lg">
                Residential, Commercial, Industrial & EV Charger Electrical Services
              </p>
              <p className="mt-4 max-w-2xl text-sm leading-relaxed text-white/62">
                Choose the electrical service you need or contact GK Electric for a clear quote, emergency support, and code-compliant work across Surrey, BC.
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {sampleTrust.map((item) => (
                  <span key={item} className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-3 py-2 text-[11px] font-black uppercase tracking-[0.1em] text-white/75">
                    <CheckCircle2 className="h-3.5 w-3.5 text-amber-500" />
                    {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="col-span-12 lg:col-span-5">
              <div className="flex h-full min-h-[360px] flex-col rounded-[1.5rem] border border-white/12 bg-black/20 p-5 backdrop-blur-md md:p-6">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-black uppercase tracking-[0.18em] text-amber-500">Checkout our services</div>
                    <p className="mt-2 text-sm text-white/60">Select the service that matches your project.</p>
                  </div>
                  <Zap className="h-8 w-8 text-amber-500" />
                </div>
                <div className="grid flex-1 gap-4 sm:grid-cols-2">
                  {[
                    { label: "Residential", to: "/services/residential" as const, icon: Home },
                    { label: "Commercial", to: "/services/commercial" as const, icon: Building2 },
                    { label: "Industrial", to: "/services/industrial" as const, icon: Factory },
                    { label: "EV Charger", to: "/ev-charger" as const, icon: PlugZap },
                  ].map((service) => (
                    <HomeDesign05ServiceButton key={service.label} {...service} />
                  ))}
                </div>
              </div>
            </div>

            <div className="col-span-12">
              <div className="grid gap-4 rounded-[1.5rem] border border-white/12 bg-white/[0.055] p-4 md:grid-cols-[1.05fr_1.45fr]">
                <div>
                  <h3 className="font-display text-2xl font-black uppercase tracking-tight">Ready to start your electrical project?</h3>
                  <p className="mt-3 text-sm leading-relaxed text-white/62">
                    Talk with our team for free quotes, clear project pricing, emergency support, and permit-backed electrical work done safely and professionally.
                  </p>
                </div>
                <div className="grid gap-3 md:grid-cols-3">
                  {sampleContactActions.map((action) => (
                    <HomeDesign05ActionLink key={action.label} action={action} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

const stickyServiceSlides = [
  {
    icon: servicePageDetails.residential.icon,
    title: servicePageDetails.residential.title,
    desc: servicePageDetails.residential.description,
    img: servicePageDetails.residential.image,
    to: "/residential-electrical-services-details" as const,
    detailServices: [
      ...servicePageDetails.residential.services,
      { icon: Home, title: "Renovation Electrical" },
      { icon: BadgeCheck, title: "Permit-Ready Home Work" },
    ],
  },
  {
    icon: servicePageDetails.commercial.icon,
    title: servicePageDetails.commercial.title,
    desc: servicePageDetails.commercial.description,
    img: servicePageDetails.commercial.image,
    to: "/commercial-electrical-services-details" as const,
    detailServices: [
      ...servicePageDetails.commercial.services,
      { icon: Building2, title: "Office & Retail Build-Outs" },
      { icon: Zap, title: "Emergency Commercial Repairs" },
    ],
  },
  {
    icon: servicePageDetails.industrial.icon,
    title: servicePageDetails.industrial.title,
    desc: servicePageDetails.industrial.description,
    img: servicePageDetails.industrial.image,
    to: "/industrial-electrical-services-details" as const,
    detailServices: [
      ...servicePageDetails.industrial.services,
      { icon: Wrench, title: "Equipment Troubleshooting" },
      { icon: ShieldCheck, title: "Code-Ready Upgrades" },
    ],
  },
  {
    icon: Plug,
    title: "EV Charger Installation",
    desc: "Level 2 EV charger installation for homes, strata properties, commercial parking and business fleets with panel checks, dedicated circuits and safe code-compliant setup.",
    img: evImage,
    to: "/ev-charger" as const,
    detailServices: [
      { icon: Plug, title: "Level 2 Home Chargers" },
      { icon: Gauge, title: "Panel Capacity Checks" },
      { icon: Zap, title: "Dedicated 240V Circuits" },
      { icon: Building2, title: "Commercial EV Charging" },
      { icon: ShieldCheck, title: "Load Management" },
      { icon: BadgeCheck, title: "Permit & Inspection Support" },
      { icon: Wrench, title: "Charger Troubleshooting" },
      { icon: CheckCircle2, title: "Future-Ready Installation" },
    ],
  },
];

function StickyServiceScrollEffects() {
  return (
    <section data-scroll-tone="dark" data-sticky-service-section="true" className="py-24 bg-surface text-surface-foreground relative overflow-visible">
      <div className="container mx-auto grid items-start gap-10 px-4 relative z-10 lg:grid-cols-[0.96fr_1.04fr] lg:[--service-card-height:940px] xl:[--service-card-height:980px]">
        <div className="lg:sticky lg:top-24 lg:h-[var(--service-card-height)] lg:self-start">
          <div className="flex h-full flex-col justify-between">
            <div>
            <ElectricSectionTag label="Electrical Services We Provide" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-6" />
            <h2 className="font-display text-4xl font-extrabold tracking-tight md:text-5xl xl:text-6xl">
              Surrey & Lower Mainland Residential, Commercial & Industrial <span className="brand-highlight">Electrical Services</span>
            </h2>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-surface-foreground/70 xl:text-lg">
              From outlet upgrades and panel replacements to complete commercial and industrial electrical systems, our licensed electricians provide safe, reliable, and code-compliant electrical services throughout Surrey and the Lower Mainland.
            </p>
            </div>
          </div>
        </div>

        <div className="space-y-6 lg:space-y-9 lg:[&>:not(:last-child)]:mb-[calc(calc(var(--spacing)*30)*calc(1-var(--tw-space-y-reverse)))] lg:[&>:not(:last-child)]:mt-[calc(calc(var(--spacing)*9)*var(--tw-space-y-reverse))]">
          {stickyServiceSlides.map((service, index) => (
            <Link
              key={service.title}
              to={service.to}
              data-sticky-service-card
              className="group sticky top-28 block overflow-hidden rounded-[1.75rem] border border-white/14 bg-surface transition-colors duration-500 hover:border-primary/45"
              style={{ zIndex: index + 10 }}
            >
              <div className="absolute inset-0 rounded-[1.75rem] ring-1 ring-inset ring-white/10" />
              <div className="relative h-[252px] overflow-hidden md:h-[288px] lg:h-[318px]">
                <img src={service.img} alt={`${service.title} electrical service`} className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-surface/60 via-transparent to-transparent" />
              </div>
              <div className="relative flex flex-col bg-surface p-5 md:p-6">
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground transition-transform duration-500 group-hover:rotate-6">
                    <service.icon className="h-7 w-7" />
                  </div>
                  <div className="font-display text-6xl font-black text-white/10">{String(index + 1).padStart(2, "0")}</div>
                </div>
                <h3 className="font-display text-3xl font-bold leading-none text-white md:text-4xl">{service.title}</h3>
                <p className="mt-2 max-w-2xl line-clamp-2 text-sm leading-relaxed text-surface-foreground/72 md:text-[0.95rem]">{service.desc}</p>
                <div className="mt-4 grid gap-2 sm:grid-cols-2">
                  {service.detailServices.slice(0, 8).map((detail, detailIndex) => (
                    <div
                      key={detail.title}
                      className="group/detail flex min-h-[58px] items-center gap-3 rounded-2xl border border-white/80 bg-white/95 p-3 shadow-sm backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/35"
                      style={{ transitionDelay: `${detailIndex * 35}ms` }}
                    >
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/20 transition-colors duration-300 group-hover/detail:bg-primary group-hover/detail:text-primary-foreground">
                        <detail.icon className="h-[18px] w-[18px]" />
                      </span>
                      <span className="text-[0.90rem] font-medium uppercase leading-snug tracking-[0.08em] text-foreground">
                        {detail.title}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-5 inline-flex w-fit items-center gap-2 rounded-full border border-primary/50 bg-surface/70 px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary backdrop-blur-md transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  Explore More Services <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </Link>
          ))}
          <div className="hidden h-[38vh] lg:block" aria-hidden="true" />
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10 mt-14">
        <div className="rounded-[2rem] border border-white/12 bg-white/[0.045] p-5 shadow-[0_28px_90px_rgba(0,0,0,0.28)] backdrop-blur-md md:p-7">
          <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="mb-2 text-xs font-bold uppercase tracking-[0.24em] text-primary">20 List Style Options</div>
              <h3 className="font-display text-3xl font-extrabold uppercase tracking-[0.04em] text-white">
                Why Customers Choose GK Electric
              </h3>
            </div>
            <p className="max-w-xl text-[16px] font-[300] leading-relaxed text-white/60">
              Same exact customer-choice list shown in twenty visual styles.
            </p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {customerChoiceDesigns.map((design, designIndex) => (
              <div key={designIndex} className={design.wrap}>
                <div className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">
                  Design {String(designIndex + 1).padStart(2, "0")}
                </div>
                <ul className={design.list}>
                  {customerChoiceItems.map((label) => (
                    <li key={label} className={`${design.item} list-none text-[16px] font-[300] leading-snug tracking-normal`}>
                      {label}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <HomeSampleContactDesign11 />
      </div>

    </section>
  );
}

function HomeCloneOnePage() {
  return (
    <div className="min-h-screen bg-background">
      <section data-scroll-tone="light" className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="mb-16 grid gap-8 lg:grid-cols-2 lg:items-end">
            <div data-reveal className="text-left">
              <ElectricSectionTag label="What We Do" icon={Lightbulb} tone="light" variant="electric-v1-2" className="mb-6" />
              <h2 className="text-4xl md:text-6xl mb-4">
                <span className="text-black">Surrey & Lower Mainland Residential, Commercial & Industrial</span>{" "}
                <span className="text-primary">Electrical Services</span>
              </h2>
              <p className="max-w-3xl text-lg text-muted-foreground leading-relaxed">
                From outlet upgrades and panel replacements to complete commercial and industrial electrical systems, our licensed electricians provide safe, reliable, and code-compliant electrical services throughout Surrey and the Lower Mainland.
              </p>
            </div>
            <div data-reveal="right" className="grid gap-3 lg:pl-8 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
              {[
                { icon: ShieldCheck, label: "Fully Licensed & Insured in BC" },
                { icon: CheckCircle2, label: "Same-Day Service Available" },
                { icon: BadgeCheck, label: "Technical Safety BC Compliant" },
                { icon: Headphones, label: "24/7 Emergency Availability" },
              ].map((tag, index) => (
                <div
                  key={tag.label}
                  data-reveal="up"
                  style={{ transitionDelay: `${index * 60}ms` }}
                  className="group flex items-center gap-3 rounded-2xl border border-primary/20 bg-primary/[0.06] px-4 py-4 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-primary/10 hover:shadow-glow"
                >
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/20 transition-all duration-300 group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-105">
                    <tag.icon className="h-5 w-5" />
                  </span>
                  <span className="text-sm font-extrabold uppercase tracking-[0.11em] leading-snug text-foreground">
                    {tag.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {services.map((s, i) => (
              <Link
                key={s.title}
                to={s.to}
                data-reveal="zoom"
                style={{ transitionDelay: `${i * 120}ms` }}
                className="group relative min-h-[430px] overflow-hidden rounded-[2rem] shadow-elegant transition-all duration-500"
                aria-label={s.tag}
              >
                <img
                  src={s.img}
                  alt={`${s.title} electrical service`}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/45 to-transparent" />
                <div className="absolute right-0 top-7 z-10 translate-x-full rounded-l-2xl bg-white/90 px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-surface opacity-100 shadow-xl transition-all duration-500 group-hover:translate-x-0">
                  {s.tag}
                </div>
                <div className="absolute inset-x-0 bottom-0 p-7 text-surface-foreground">
                  <div className="flex min-h-[220px] flex-col items-start">
                    <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                      <s.icon className="h-7 w-7" />
                    </div>
                    <h3 className="mb-3 text-3xl font-bold leading-tight">{s.title}</h3>
                    <p className="mb-4 h-[4.25rem] text-sm leading-relaxed text-surface-foreground/75">
                      {s.desc}
                    </p>
                    <div className="mt-auto inline-flex items-center gap-2 rounded-full border border-primary/70 bg-transparent px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary shadow-none transition-all duration-300 hover:border-primary hover:bg-transparent hover:text-primary-glow hover:shadow-none">
                      More Information <ArrowRight className="h-4 w-4" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div data-reveal className="relative overflow-hidden rounded-2xl shadow-elegant mt-16 group">
            <img
              src={evImage}
              alt="EV charger installation in residential garage"
              loading="lazy"
              width={1600}
              height={1200}
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-surface/90 via-surface/60 to-transparent md:via-surface/40" />
            <div className="absolute right-0 top-7 z-10 translate-x-full rounded-l-2xl bg-white/90 px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-surface shadow-xl transition-all duration-500 group-hover:translate-x-0">
              EV Charger Installation
            </div>
            <div className="relative p-8 md:p-12 max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest mb-4">
                <Plug className="h-3 w-3" /> High Demand
              </div>
              <h3 className="font-display text-3xl md:text-4xl text-surface-foreground mb-4">
                EV Charger Installation
              </h3>
              <p className="text-surface-foreground/80 mb-6 leading-relaxed">
                Home and commercial EV chargers — fast, safe installation
                compatible with all major EV brands.
              </p>
              <Link to="/ev-charger" className="mt-auto inline-flex items-center gap-2 rounded-full border border-primary/70 bg-transparent px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary shadow-none transition-all duration-300 hover:border-primary hover:bg-transparent hover:text-primary-glow hover:shadow-none">
                More Information <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button asChild variant="default" size="lg">
              <Link to="/services">
                View All Services <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <StickyServiceScrollEffects />

      <section data-scroll-tone="dark" className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid gap-8 lg:grid-cols-[2fr_3fr] items-start">
            <div data-reveal="left" className="lg:sticky lg:top-24">
              <ElectricSectionTag label="Specialized Service" icon={ClipboardCheck} tone="dark" variant="electric-v1-2" className="mb-6" />
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6">
                Permits & Compliance <span className="brand-highlight">Made Simple</span>
              </h2>
              <div className="space-y-5 text-lg text-surface-foreground/72 leading-relaxed max-w-2xl">
                <p>
                  We take care of all electrical permits, inspections, and regulatory requirements from start to finish—so your project stays compliant, on schedule, and stress-free.
                </p>
                <p>
                  Our team works directly with local authorities to ensure all work meets the BC Electrical Safety Regulation and the Canadian Electrical Code. From permit applications to final approvals, we handle the paperwork, coordination, and compliance details for you.
                </p>
              </div>

              <div className="mt-8" data-reveal>
                <Button asChild variant="electric" size="lg" className="home-more-info-button shadow-none hover:shadow-none">
                  <Link to="/services">
                    More Info
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                </Button>
              </div>

            </div>

            <div className="grid gap-4 pt-4 text-center md:pl-10 md:text-left lg:pt-[4.25rem]">
              <div
                data-reveal="right"
                className="group relative"
              >
                <div className="mb-4">
                  <div className="flex items-center justify-center gap-4 md:justify-start">
                    <span className="h-10 w-1 rounded-full bg-primary shadow-glow" aria-hidden="true" />
                    <h3 className="font-display text-3xl font-bold text-surface-foreground">What We Handle</h3>
                  </div>
                </div>
                <div className="grid gap-2 sm:grid-cols-2">
                  {[
                    { icon: FileCheck, text: "Electrical permit applications" },
                    { icon: CalendarCheck, text: "Inspection scheduling & coordination" },
                    { icon: BadgeCheck, text: "Code compliance verification" },
                    { icon: Wrench, text: "Deficiency corrections support" },
                    { icon: ClipboardCheck, text: "Final inspection & approvals" },
                    { icon: ScrollText, text: "Regulatory documentation" },
                    { icon: FileCheck, text: "Electric Operating Permits" },
                    { icon: FileText, text: "Electric Planning Reports" },
                  ].map((item, index) => (
                    <div key={item.text} data-reveal style={{ transitionDelay: `${index * 45}ms` }} className="group flex flex-col items-center gap-3 border-b border-white/10 px-1 py-2.5 text-center transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.12] sm:flex-row sm:text-left">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/20 text-primary ring-1 ring-primary/25">
                        <item.icon className="h-5 w-5" />
                      </span>
                      <span className="text-[16px] !font-normal uppercase leading-snug tracking-[0.2px] text-surface-foreground">{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-[1.75rem] border border-white/12 bg-white/[0.055] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.28)] backdrop-blur-md md:p-6">
            <div className="grid gap-5 md:grid-cols-[1.25fr_1fr_1fr_1fr] md:divide-x md:divide-white/10">
              <div className="flex items-center">
                <p className="font-display text-2xl font-extrabold uppercase tracking-[0.06em] text-white">
                  Ready to start your permit-backed electrical work?
                </p>
              </div>
              {[
                { icon: Phone, label: "Call Now", text: "Speak with our team", href: "tel:+17783444567" },
                { icon: FilePenLine, label: "Request a Quote", text: "Get a custom quote", href: "/contact" },
                { icon: MessageCircle, label: "WhatsApp Us", text: "Chat with us now", href: "https://wa.me/17783444567" },
              ].map((action) => {
                const Icon = action.icon;
                const external = action.href.startsWith("http");
                const isWhatsApp = action.label.includes("WhatsApp");
                const content = (
                  <>
                    <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border transition-all duration-300 group-hover:scale-110 ${isWhatsApp ? "border-green-400/35 bg-green-500/15 text-green-300 group-hover:bg-green-500 group-hover:text-white group-hover:border-green-400" : "border-primary/45 bg-primary/15 text-primary group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary"}`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-[16px] font-medium uppercase leading-tight tracking-normal text-white group-hover:text-primary transition-colors">{action.label}</div>
                      <div className="mt-1 text-sm text-surface-foreground/55 group-hover:text-surface-foreground/80 transition-colors">{action.text}</div>
                    </div>
                  </>
                );

                return external ? (
                  <a key={action.label} href={action.href} target="_blank" rel="noreferrer" className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-green-400/40 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </a>
                ) : action.href.startsWith("tel:") ? (
                  <a key={action.label} href={action.href} className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </a>
                ) : (
                  <Link key={action.label} to="/contact" className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
