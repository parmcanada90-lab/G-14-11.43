import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  CheckCircle2,
  Factory,
  Home,
  MessageCircle,
  Phone,
  PlugZap,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import gkLogo from "@/assets/gk-logo.jpeg";

export const Route = createFileRoute("/Sample-Contact-2")({
  head: () => ({
    meta: [
      { title: "Sample Contact 2 — GK Electric Premium Contact Designs" },
      {
        name: "description",
        content:
          "25 new premium contact and service selector layouts for GK Electric electrical services in Surrey and the Lower Mainland.",
      },
    ],
  }),
  component: SampleContact2Page,
});

const services = [
  { label: "Residential", to: "/services/residential" as const, icon: Home },
  { label: "Commercial", to: "/services/commercial" as const, icon: Building2 },
  { label: "Industrial", to: "/services/industrial" as const, icon: Factory },
  { label: "EV Charger", to: "/ev-charger" as const, icon: PlugZap },
];

const contactActions = [
  { label: "Contact US", sub: "Call our team", href: "tel:+17783444567", icon: Phone, external: true },
  { label: "Request a Quote", sub: "Get project pricing", href: "/free-estimate", icon: BadgeCheck, external: false },
  { label: "WhatsApp US", sub: "Chat with us now", href: "https://wa.me/17783444567", icon: MessageCircle, external: true },
];

const trust = ["Free Quotes", "Clear Pricing", "Licensed & Insured", "Permit-Ready Work"];

const designStyles = [
  { bg: "bg-[#0c111d]", panel: "bg-white/[0.06]", accent: "amber", dark: true, shape: "rounded-[2.5rem]" },
  { bg: "bg-white", panel: "bg-[#f8fafc]", accent: "amber", dark: false, shape: "rounded-[2rem]" },
  { bg: "bg-[#0b0b0b]", panel: "bg-[#151515]", accent: "amber", dark: true, shape: "rounded-[3rem]" },
  { bg: "bg-[#fff8e6]", panel: "bg-white", accent: "slate", dark: false, shape: "rounded-[2.25rem]" },
  { bg: "bg-gradient-to-br from-[#080808] via-[#17120a] to-[#2c1f03]", panel: "bg-white/[0.07]", accent: "amber", dark: true, shape: "rounded-[2.75rem]" },
  { bg: "bg-[#101828]", panel: "bg-white/[0.065]", accent: "amber", dark: true, shape: "rounded-[2rem]" },
  { bg: "bg-[#f5f6fc]", panel: "bg-white", accent: "amber", dark: false, shape: "rounded-[2.5rem]" },
  { bg: "bg-gradient-to-br from-[#06131f] via-[#0f172a] to-[#332507]", panel: "bg-white/[0.07]", accent: "amber", dark: true, shape: "rounded-[2.25rem]" },
  { bg: "bg-[#111111]", panel: "bg-[#1e1e1e]", accent: "amber", dark: true, shape: "rounded-[3rem]" },
  { bg: "bg-[#fffdf7]", panel: "bg-white", accent: "slate", dark: false, shape: "rounded-[2rem]" },
  { bg: "bg-[#070707]", panel: "bg-white/[0.055]", accent: "amber", dark: true, shape: "rounded-[2.5rem]" },
  { bg: "bg-gradient-to-br from-white via-[#fffbeb] to-white", panel: "bg-white/80", accent: "amber", dark: false, shape: "rounded-[2.75rem]" },
  { bg: "bg-[#151a26]", panel: "bg-white/[0.065]", accent: "amber", dark: true, shape: "rounded-[2.25rem]" },
  { bg: "bg-[#f8fafc]", panel: "bg-white", accent: "amber", dark: false, shape: "rounded-[3rem]" },
  { bg: "bg-gradient-to-br from-[#171717] via-[#0f172a] to-[#332507]", panel: "bg-white/[0.06]", accent: "amber", dark: true, shape: "rounded-[2rem]" },
  { bg: "bg-[#fffaf0]", panel: "bg-white", accent: "slate", dark: false, shape: "rounded-[2.5rem]" },
  { bg: "bg-[#030712]", panel: "bg-white/[0.065]", accent: "amber", dark: true, shape: "rounded-[2.75rem]" },
  { bg: "bg-[#f9fafb]", panel: "bg-white", accent: "amber", dark: false, shape: "rounded-[2.25rem]" },
  { bg: "bg-[#09090b]", panel: "bg-[#18181b]", accent: "amber", dark: true, shape: "rounded-[3rem]" },
  { bg: "bg-[#fff7ed]", panel: "bg-white", accent: "amber", dark: false, shape: "rounded-[2rem]" },
  { bg: "bg-[#101010]", panel: "bg-white/[0.06]", accent: "amber", dark: true, shape: "rounded-[2.5rem]" },
  { bg: "bg-[#f6f7f9]", panel: "bg-white", accent: "slate", dark: false, shape: "rounded-[2.75rem]" },
  { bg: "bg-gradient-to-br from-[#0b1120] via-[#020617] to-[#1f1300]", panel: "bg-white/[0.065]", accent: "amber", dark: true, shape: "rounded-[2.25rem]" },
  { bg: "bg-white", panel: "bg-[#fff8e1]", accent: "amber", dark: false, shape: "rounded-[3rem]" },
  { bg: "bg-[#111827]", panel: "bg-white/[0.06]", accent: "amber", dark: true, shape: "rounded-[2.5rem]" },
] as const;

function ServiceButton({ service, dark }: { service: (typeof services)[number]; dark: boolean }) {
  const Icon = service.icon;
  return (
    <Link
      to={service.to}
      className={`group flex min-h-20 items-center justify-between rounded-2xl border px-5 py-4 text-sm font-black uppercase tracking-[0.12em] transition-all duration-300 hover:-translate-y-1 ${
        dark
          ? "border-white/12 bg-white/[0.055] text-white hover:border-amber-400 hover:bg-amber-400 hover:text-slate-950"
          : "border-slate-200 bg-white text-slate-950 shadow-sm hover:border-amber-400 hover:bg-amber-50 hover:shadow-lg"
      }`}
    >
      <span className="flex items-center gap-3">
        <Icon className="h-5 w-5 text-amber-500 transition group-hover:text-current" />
        {service.label}
      </span>
      <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
    </Link>
  );
}

function ActionButton({ action, dark }: { action: (typeof contactActions)[number]; dark: boolean }) {
  const Icon = action.icon;
  const className = `group flex min-h-24 items-center gap-4 rounded-2xl border px-5 py-5 transition-all duration-300 hover:-translate-y-1 ${
    dark
      ? "border-white/12 bg-white/[0.065] text-white hover:border-amber-400 hover:bg-white/[0.12]"
      : "border-slate-200 bg-white text-slate-950 shadow-sm hover:border-amber-400 hover:shadow-xl"
  }`;
  const content = (
    <>
      <span className="flex h-13 w-13 shrink-0 items-center justify-center rounded-2xl bg-amber-400 text-slate-950 shadow-[0_0_28px_rgba(245,181,38,0.26)] transition group-hover:scale-105">
        <Icon className="h-5 w-5" />
      </span>
      <span>
        <span className="block text-sm font-black uppercase tracking-[0.13em]">{action.label}</span>
        <span className={`mt-1 block text-sm ${dark ? "text-white/58" : "text-slate-500"}`}>{action.sub}</span>
      </span>
    </>
  );

  if (action.external) {
    return (
      <a href={action.href} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noreferrer" : undefined} className={className}>
        {content}
      </a>
    );
  }

  return (
    <Link to={action.href as never} className={className}>
      {content}
    </Link>
  );
}

function TrustRow({ dark }: { dark: boolean }) {
  return (
    <div className="mt-8 flex flex-wrap gap-3">
      {trust.map((item) => (
        <span
          key={item}
          className={`inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-[11px] font-black uppercase tracking-[0.11em] ${
            dark ? "border-white/12 bg-white/[0.055] text-white/72" : "border-slate-200 bg-white text-slate-600 shadow-sm"
          }`}
        >
          <CheckCircle2 className="h-4 w-4 text-amber-500" />
          {item}
        </span>
      ))}
    </div>
  );
}

function DesignCard({ index }: { index: number }) {
  const style = designStyles[index - 1];
  const dark = style.dark;
  const reversed = index % 3 === 0;
  const compactServices = index % 4 === 0;

  return (
    <section className={`relative overflow-hidden border ${style.shape} ${style.bg} ${dark ? "border-white/10 text-white" : "border-slate-200 text-slate-950"} p-6 shadow-[0_30px_100px_rgba(15,23,42,0.12)] md:p-10 lg:p-12`}>
      <div className="pointer-events-none absolute inset-0 opacity-[0.055]" style={{ backgroundImage: "linear-gradient(90deg,currentColor 1px,transparent 1px),linear-gradient(currentColor 1px,transparent 1px)", backgroundSize: index % 2 ? "44px 44px" : "32px 32px" }} />
      <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-amber-400/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-28 left-1/4 h-64 w-64 rounded-full bg-blue-500/10 blur-3xl" />

      <div className={`relative grid gap-8 lg:grid-cols-12 lg:items-stretch ${reversed ? "lg:[&>*:first-child]:order-2" : ""}`}>
        <div className="lg:col-span-6 xl:col-span-7">
          <div className="mb-8 flex items-center justify-between gap-4">
            <div className="inline-flex items-center gap-3 rounded-full bg-amber-400 px-5 py-3 text-xs font-black uppercase tracking-[0.17em] text-slate-950 shadow-[0_12px_30px_rgba(245,181,38,0.18)]">
              <Sparkles className="h-4 w-4" /> Design {String(index).padStart(2, "0")}
            </div>
            <img src={gkLogo} alt="GK Electric logo" className="h-12 w-12 rounded-full object-contain shadow-md" />
          </div>

          <h2 className="max-w-4xl font-display text-4xl font-black uppercase leading-[0.95] tracking-tight md:text-6xl">
            Licensed Electricians in Surrey & Lower Mainland
          </h2>
          <p className={`mt-6 text-lg font-semibold leading-relaxed md:text-xl ${dark ? "text-white/78" : "text-slate-650"}`}>
            Residential, Commercial, Industrial & EV Charger Electrical Services
          </p>
          <p className={`mt-5 max-w-3xl text-base leading-relaxed md:text-lg ${dark ? "text-white/62" : "text-slate-500"}`}>
            Choose the electrical service you need or contact GK Electric for a clear quote, emergency support, and code-compliant work across Surrey, BC.
          </p>
          <TrustRow dark={dark} />
        </div>

        <div className="lg:col-span-6 xl:col-span-5">
          <div className={`h-full rounded-[2rem] border ${style.panel} ${dark ? "border-white/12" : "border-slate-200"} p-5 backdrop-blur-md md:p-7`}>
            <div className="mb-7 flex items-start justify-between gap-4">
              <div>
                <div className="text-xs font-black uppercase tracking-[0.2em] text-amber-500">Checkout our services</div>
                <p className={`mt-2 text-sm leading-relaxed ${dark ? "text-white/58" : "text-slate-500"}`}>Select the service that matches your project.</p>
              </div>
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-amber-400 text-slate-950">
                <Zap className="h-6 w-6" />
              </span>
            </div>
            <div className={`grid gap-4 ${compactServices ? "grid-cols-1 xl:grid-cols-4" : "sm:grid-cols-2"}`}>
              {services.map((service) => (
                <ServiceButton key={service.label} service={service} dark={dark} />
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-12">
          <div className={`grid gap-7 rounded-[2rem] border ${dark ? "border-white/12 bg-white/[0.055]" : "border-slate-200 bg-white/80"} p-6 backdrop-blur-md md:p-8 xl:grid-cols-[0.9fr_1.4fr] xl:items-center`}>
            <div>
              <div className="mb-3 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-amber-500">
                <ShieldCheck className="h-4 w-4" /> Ready to start?
              </div>
              <h3 className="font-display text-3xl font-black uppercase tracking-tight md:text-4xl">Ready to start your electrical project?</h3>
              <p className={`mt-4 text-base leading-relaxed ${dark ? "text-white/62" : "text-slate-500"}`}>
                Talk with our team for free quotes, clear project pricing, emergency support, and permit-backed electrical work done safely and professionally.
              </p>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {contactActions.map((action) => (
                <ActionButton key={action.label} action={action} dark={dark} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SampleContact2Page() {
  return (
    <div className="min-h-screen bg-[#f5f6f2] text-slate-950">
      <Header />
      <main className="pt-24">
        <section className="px-5 py-16 md:px-8 md:py-24">
          <div className="mx-auto max-w-[1540px] text-center">
            <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-amber-200 bg-white px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-amber-700 shadow-sm">
              <Sparkles className="h-4 w-4" /> Sample Contact 2
            </div>
            <h1 className="font-display text-5xl font-black uppercase leading-tight tracking-tight md:text-8xl">
              25 New Premium Contact Designs
            </h1>
            <p className="mx-auto mt-7 max-w-4xl text-lg leading-relaxed text-slate-600 md:text-xl">
              New clean and stylish contact/service selector sections inspired by Design 05, with larger padding, improved spacing, stronger CTA alignment, and complete GK Electric service context.
            </p>
          </div>
        </section>

        <section className="px-5 pb-24 md:px-8">
          <div className="mx-auto grid max-w-[1540px] gap-10 md:gap-12">
            {Array.from({ length: 25 }).map((_, index) => (
              <DesignCard key={index + 1} index={index + 1} />
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
