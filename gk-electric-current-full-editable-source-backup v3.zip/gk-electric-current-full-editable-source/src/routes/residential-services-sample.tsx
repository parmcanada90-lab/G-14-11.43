import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Bath,
  BatteryCharging,
  Bolt,
  Building2,
  Cable,
  CheckCircle2,
  CircuitBoard,
  ClipboardCheck,
  Clock,
  Cpu,
  DoorOpen,
  Factory,
  Flame,
  Gauge,
  Home,
  HardHat,
  KeyRound,
  LampCeiling,
  Lightbulb,
  MessageCircle,
  PanelTop,
  Phone,
  Plug,
  ShieldCheck,
  Siren,
  Sparkles,
  Snowflake,
  Sun,
  Trees,
  Wrench,
  Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";

export const Route = createFileRoute("/residential-services-sample")({
  head: () => ({
    meta: [
      {
        title:
          "Residential Electrical Services — Complete Home Electrician Services | GK Electric",
      },
      {
        name: "description",
        content:
          "Professional residential electrical services for repairs, lighting upgrades, panel replacements, EV chargers, rewiring, permits, inspections, new construction, suites, HVAC, appliances and safety upgrades.",
      },
      {
        property: "og:title",
        content: "Residential Electrical Services | GK Electric",
      },
      {
        property: "og:description",
        content:
          "Reliable home electrical services for repairs, renovations, panels, wiring, lighting, EV chargers, safety inspections and code-compliant upgrades.",
      },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResidentialServicesSamplePage,
});

type ServiceCategory = {
  icon: LucideIcon;
  title: string;
  description: string;
  services: string[];
  accent: string;
};

const residentialServices: ServiceCategory[] = [
  {
    icon: Home,
    title: "New Construction Electrical",
    description:
      "Complete electrical planning, rough-in and finishing for new custom homes, laneway homes and residential builds.",
    accent: "from-amber-400 to-yellow-500",
    services: [
      "New home electrical layout and planning",
      "Service entrance and main panel installation",
      "Full rough-in wiring for every room",
      "Lighting, switch and outlet placement",
      "Dedicated circuits: kitchen, laundry & mechanical rooms",
      "Smart-home and low-voltage wiring preparation",
      "Garage, exterior and landscape power provisions",
      "Permit, inspection and final finishing coordination",
    ],
  },
  {
    icon: PanelTop,
    title: "Panels, Breakers & Service Upgrades",
    description:
      "Main panel improvements, breaker safety, capacity planning and power upgrades for modern homes.",
    accent: "from-yellow-300 to-amber-500",
    services: [
      "100A to 200A service upgrades",
      "Main electrical panel replacement",
      "Subpanel installation for suites, garages and workshops",
      "Breaker replacement and circuit balancing",
      "AFCI and GFCI breaker upgrades",
      "Dedicated circuits for appliances and equipment",
      "Load calculations and capacity assessments",
      "Meter base and service equipment coordination",
    ],
  },
  {
    icon: Cable,
    title: "Home Wiring, Rewiring & Suites",
    description:
      "Clean, code-compliant wiring for older homes, additions, renovations, basement suites and secondary suites.",
    accent: "from-blue-400 to-cyan-500",
    services: [
      "Whole-home rewiring and partial rewiring",
      "Knob-and-tube and aluminum wiring corrections",
      "Basement suites and secondary suite wiring",
      "Suite subpanels, separation and dedicated circuits",
      "Basement, garage and laneway home wiring",
      "Kitchen and bathroom renovation wiring",
      "Home addition electrical wiring",
      "Low-voltage, data, TV and network cabling",
    ],
  },
  {
    icon: LampCeiling,
    title: "Lighting Design & Installation",
    description:
      "Interior, exterior, feature and security lighting designed to make homes brighter, safer and efficient.",
    accent: "from-orange-400 to-rose-500",
    services: [
      "Pot light and recessed lighting installation",
      "LED lighting upgrades and retrofits",
      "Chandeliers, pendants and ceiling fixtures",
      "Under-cabinet and toe-kick lighting",
      "Landscape and pathway lighting",
      "Motion sensor and security lighting",
      "Dimmers, lighting zones and scene controls",
      "Troubleshooting flickering or failed lights",
    ],
  },
  {
    icon: Cpu,
    title: "Smart Home & Controls",
    description:
      "Modern controls for lighting, comfort, security and connected-home convenience.",
    accent: "from-indigo-400 to-violet-600",
    services: [
      "Smart switches and smart dimmers",
      "Smart thermostats and doorbell wiring",
      "Security camera and low-voltage wiring",
      "Automated lighting controls",
      "Occupancy and vacancy sensors",
      "Wi-Fi controlled outdoor lighting",
      "Home office power and data upgrades",
      "Structured media and network panels",
    ],
  },
  {
    icon: Snowflake,
    title: "HVAC, Heating & Ventilation",
    description:
      "Dedicated electrical connections and controls for heating, cooling, ceiling fans and ventilation upgrades.",
    accent: "from-cyan-400 to-blue-600",
    services: [
      "Heat pump circuits",
      "HVAC equipment wiring",
      "Baseboard & furnace circuits",
      "Thermostat controls",
      "Bathroom exhaust fans",
      "Ceiling fan wiring",
      "Fan-rated electrical boxes",
      "Timer & humidity controls",
    ],
  },
  {
    icon: BatteryCharging,
    title: "EV Chargers & Future-Ready Power",
    description:
      "Home charging solutions with panel checks, dedicated circuits and safe Level 2 installation.",
    accent: "from-emerald-400 to-green-600",
    services: [
      "Level 2 EV charger installation",
      "Garage and driveway charger circuits",
      "Hardwired and plug-in charger setup",
      "EV load management solutions",
      "Panel capacity checks before installation",
      "Conduit, disconnects and weather-rated equipment",
      "Tesla, ChargePoint, Wallbox and universal charger support",
      "Permit and inspection coordination",
    ],
  },
  {
    icon: Sun,
    title: "Solar & Energy Storage Preparation",
    description:
      "Future-ready electrical preparation for solar readiness, battery storage, energy monitoring and backup power planning.",
    accent: "from-orange-300 to-amber-500",
    services: [
      "Solar-ready conduit and electrical pathways",
      "Panel capacity review for solar preparation",
      "Battery storage readiness planning",
      "Critical-load panel preparation",
      "Energy monitoring equipment connections",
      "Inverter and disconnect location planning",
      "Roof, garage and mechanical-room wiring provisions",
      "Coordination with solar and energy-storage installers",
    ],
  },
  {
    icon: ShieldCheck,
    title: "Safety, Detectors & Protection",
    description:
      "Protection systems that help prevent shocks, fire risks, surge damage and code issues.",
    accent: "from-red-400 to-orange-500",
    services: [
      "Smoke detector installation and replacement",
      "Carbon monoxide detector installation",
      "Hardwired detector interconnection",
      "Whole-home surge protection",
      "Grounding and bonding corrections",
      "Electrical safety inspections",
      "Child-safe and tamper-resistant device upgrades",
      "Code deficiency repairs",
    ],
  },
  {
    icon: Plug,
    title: "Outlets, Switches, Circuits & Appliances",
    description:
      "Everyday electrical upgrades that improve convenience, appliance performance, safety and usable power throughout the home.",
    accent: "from-violet-400 to-purple-600",
    services: [
      "Outlet repair and replacement",
      "New outlets and switch locations",
      "USB, smart and tamper-resistant outlets",
      "GFCI outlets for kitchens, bathrooms and outdoors",
      "Dedicated appliance circuits",
      "Range, Oven & Cooktop Connections",
      "Dishwasher, Microwave & Laundry circuit connections",
      "Troubleshooting dead outlets and tripping circuits",
    ],
  },
  {
    icon: Trees,
    title: "Outdoor, Garage & Specialty Power",
    description:
      "Weather-rated electrical systems for outdoor living, detached buildings and specialty equipment.",
    accent: "from-lime-400 to-emerald-600",
    services: [
      "Outdoor outlets and weatherproof covers",
      "Garage and workshop power upgrades",
      "Shed and detached building wiring",
      "Hot tub and spa electrical connections",
      "Pool equipment bonding and power",
      "Patio, deck and pergola lighting",
      "Gate, pump and exterior equipment circuits",
      "Christmas light and seasonal power outlets",
    ],
  },
  {
    icon: Wrench,
    title: "Repairs, Troubleshooting & Emergency Work",
    description:
      "Fast diagnostics and practical repairs when something is unsafe, unreliable or not working.",
    accent: "from-slate-400 to-slate-700",
    services: [
      "Breaker trips and overload troubleshooting",
      "Burning smell, buzzing or warm device checks",
      "Power loss and partial outage diagnostics",
      "Flickering light repairs",
      "Faulty switches, outlets and fixtures",
      "Electrical code corrections",
      "Emergency repair support",
      "Pre-sale and post-inspection repair lists",
    ],
  },
  {
    icon: Gauge,
    title: "Backup Power & Energy Efficiency",
    description:
      "Reliable backup and efficient electrical upgrades to support comfort, savings and resilience.",
    accent: "from-teal-400 to-cyan-600",
    services: [
      "Portable generator transfer switch installation",
      "Standby generator electrical connections",
      "Interlock kit and inlet wiring where permitted",
      "Energy-efficient LED conversions",
      "Timer and photocell controls",
      "Load shedding and power management",
      "High-consumption circuit review",
      "Electrical planning for heat pumps and appliances",
    ],
  },
  {
    icon: Bath,
    title: "Kitchen, Bathroom & Renovation Electrical",
    description:
      "Detailed renovation electrical work for the highest-use rooms in the home.",
    accent: "from-fuchsia-400 to-pink-600",
    services: [
      "Kitchen appliance circuits",
      "Bathroom fan and vanity lighting wiring",
      "Island, pantry and cabinet power",
      "Heated floor electrical connections",
      "Range, cooktop and wall oven circuits",
      "Microwave, dishwasher and garburator wiring",
      "Renovation rough-in and final device installation",
      "Contractor-friendly scheduling and coordination",
    ],
  },
  {
    icon: ClipboardCheck,
    title: "Permits, Inspections & Code Compliance",
    description:
      "Professional support for safe, documented and inspection-ready residential electrical work.",
    accent: "from-yellow-300 to-amber-500",
    services: [
      "Residential electrical permits",
      "Inspection preparation and deficiency correction",
      "Renovation and suite compliance support",
      "Electrical safety reports",
      "Insurance and real-estate repair documentation",
      "Code-compliant installation planning",
      "Utility coordination where required",
      "Final testing and homeowner walkthroughs",
    ],
  },
];

const highlights = [
  { icon: Clock, label: "Fast Scheduling", value: "Quick response for home electrical needs" },
  { icon: ShieldCheck, label: "Code Compliant", value: "Safety-first work with proper protection" },
  { icon: Home, label: "Complete Homes", value: "Small repairs to full home rewiring" },
  { icon: Sparkles, label: "Clean Finish", value: "Tidy workmanship and polished details" },
];

const residentialLicenceTags = [
  "Fully Licensed & Insured",
  "100% Code-Compliant Work",
  "24/7 Emergency Service",
  "Quality Workmanship Guaranteed",
] as const;

const faqs = [
  {
    q: "What residential electrical work is included?",
    a: "Our residential electrical services include panels, wiring, lighting, outlets, EV chargers, detectors, surge protection, smart controls, outdoor power, generators, inspections, troubleshooting, new construction wiring, suites, HVAC connections and appliance circuits.",
  },
  {
    q: "Do residential projects need permits?",
    a: "Many panel, service, renovation, suite, EV charger and new circuit projects require permits and inspections. A licensed electrician should confirm requirements before work begins.",
  },
  {
    q: "Can one electrician handle both small repairs and major upgrades?",
    a: "Yes. A full-service residential electrician can handle small service calls, safety repairs, renovations, rewiring, panel upgrades and future-ready additions like EV chargers.",
  },
];

export function ResidentialServicesSamplePage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: "Residential Electrical Services",
    provider: {
      "@type": "Electrician",
      name: "GK Electric",
      telephone: "+1-778-344-4567",
      areaServed: "British Columbia Lower Mainland",
    },
    serviceType: residentialServices.map((category) => category.title),
    description:
      "Complete residential electrical services including home wiring, panel upgrades, lighting, outlets, EV chargers, smoke detectors, surge protection, generators and safety inspections.",
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main>
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[58vh] flex items-center text-surface-foreground">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
          </div>
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: "50px 50px",
            }}
          />
          <div className="container mx-auto px-4 py-24 relative z-10">
            <div className="max-w-5xl mx-auto text-center">
              <ElectricSectionTag label="Homes" icon={Home} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
              <h1
                data-reveal
                className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6"
              >
                <span className="text-typewriter">
                  Residential <span className="brand-highlight">Services</span>
                </span>
              </h1>
              <p className="text-lg md:text-xl text-surface-foreground/70 max-w-3xl mx-auto mb-8 leading-relaxed">
                Keep your home safe, efficient, and fully powered with expert residential electrical services. From electrical repairs and lighting upgrades to panel replacements, EV charger installations, rewiring, permits, and safety inspections, we deliver reliable, code-compliant solutions for every home.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href="tel:+17783444567"
                  className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
                >
                  <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
                    <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">Call Us</div>
                    <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
                  </div>
                </a>
                <a
                  href="https://wa.me/17783444567"
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
                >
                  <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
                    <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">WhatsApp</div>
                    <div className="text-surface-foreground font-semibold">Quick Response</div>
                  </div>
                </a>
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-10 text-primary/5 animate-float pointer-events-none">
            <Home className="h-32 w-32 rotate-12" />
          </div>
          <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500 pointer-events-none">
            <Bolt className="h-24 w-24 -rotate-12" />
          </div>
        </section>

        <section className="py-12 bg-background border-b border-border">
          <div className="container mx-auto px-4">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {highlights.map((item) => (
                <div key={item.label} className="group rounded-2xl bg-card border border-border p-5 shadow-card hover:shadow-elegant hover:border-primary/40 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:scale-105 transition-all duration-300">
                      <item.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                    </div>
                    <div>
                      <h2 className="font-display text-lg font-bold text-foreground">{item.label}</h2>
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.value}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 md:py-28 bg-muted/35">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 lg:grid-cols-[1fr_0.82fr] lg:items-center mb-14">
              <div className="max-w-3xl" data-reveal>
                <ElectricSectionTag label="Home Electrical Services" icon={ClipboardCheck} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 data-reveal className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">
                  Complete Electrical Care For Your Home
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Explore the residential services homeowners request most often, organized by project type so you can quickly find the right solution for repairs, upgrades, renovations, new construction, safety improvements and future-ready power.
                </p>
              </div>

              <div data-reveal="right" className="relative">
                <article className="group relative flex border-2 flex-col overflow-hidden rounded-3xl border-foreground/30 bg-transparent p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary hover:shadow-elegant">
                  <div className="flex items-start justify-between gap-4">
                    <div className="text-left">
                      <div className="font-sans text-lg font-extrabold uppercase leading-none tracking-[0.22em] text-foreground">
                        GK ELECTRIC
                      </div>
                      <div className="mt-1 text-[12px] uppercase tracking-widest text-muted-foreground">
                        Licensed Electricians
                      </div>
                    </div>
                    <div className="shrink-0">
                      <div className="shrink-0 rounded-2xl bg-[#00497b] px-3 py-2.5 shadow-xl ring-2 ring-white/90">
                        <div className="flex items-center justify-end gap-3">
                          <img
                            src={tsbcLogo}
                            alt="Technical Safety BC logo"
                            className="h-12 w-12 object-contain"
                            loading="lazy"
                          />
                          <div className="text-right text-white">
                            <div className="text-[0.95rem] tracking-wider text-white">TSBC Licence</div>
                            <div className="text-[1.1rem] tracking-[1.5px] font-bold text-white"># LEL0209793</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 grid grid-cols-2 gap-2.5">
                    {residentialLicenceTags.map((tag) => (
                      <div
                        key={tag}
                        className="flex min-h-9 w-full items-center gap-1.5 rounded-[10px] border border-primary/20 bg-primary/10 px-3 py-1.5 text-[14px] font-medium leading-none text-foreground shadow-sm"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                        <span className="truncate">{tag}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-5 flex-none flex items-start justify-between gap-5">
                    <div className="w-full text-left">
                      <div className="mb-4 h-1 w-14 rounded-full bg-foreground" />
                      <h2 className="whitespace-nowrap font-sans text-[clamp(0.78rem,1.7vw,0.95rem)] font-semibold uppercase leading-none tracking-[0.18em] text-foreground">
                        Proudly Serving the Lower Mainland, BC
                      </h2>
                    </div>
                  </div>

                  <div className="relative z-10 mt-3 grid grid-cols-3 gap-2">
                    {[
                      { icon: Home, label: "Residential", to: "/services/residential" as const },
                      { icon: Building2, label: "Commercial", to: "/services/commercial" as const },
                      { icon: Factory, label: "Industrial", to: "/services/industrial" as const },
                    ].map((item) => (
                      <Link
                        key={item.label}
                        to={item.to}
                        className="group/service flex items-center justify-center gap-1.5 rounded-xl border border-border bg-muted/40 px-2.5 py-2 text-center transition-all duration-300 hover:border-primary/45 hover:bg-primary/[0.1] focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-white"
                      >
                        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-primary/20 bg-primary/15 text-primary transition-all duration-300 group-hover/service:bg-primary group-hover/service:text-primary-foreground">
                          <item.icon className="h-4 w-4" />
                        </div>
                        <div className="font-sans text-xs font-bold uppercase tracking-wide text-foreground sm:text-sm">{item.label}</div>
                      </Link>
                    ))}
                  </div>
                </article>
              </div>
            </div>

            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6 items-stretch">
              {residentialServices.map((category, index) => (
                <article
                  key={category.title}
                  data-reveal
                  className="group relative flex h-full min-h-[430px] overflow-hidden rounded-3xl bg-card border border-border shadow-card hover:border-primary/45 hover:shadow-[0_18px_42px_-28px_rgba(26,32,48,0.45)] transition-all duration-500"
                  style={{ transitionDelay: `${(index % 3) * 60}ms` }}
                >
                  <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${category.accent}`} />
                  <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/5 blur-2xl group-hover:bg-primary/10 transition-colors" />
                  <div className="p-7 relative flex h-full w-full flex-col transition-transform duration-500 group-hover:-translate-y-1">
                    <div className="flex min-h-[132px] items-start gap-4 mb-5">
                      <div className="flex shrink-0 flex-col items-center gap-2">
                        <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${category.accent} flex items-center justify-center shadow-glow group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300`}>
                          <category.icon className="h-7 w-7 text-primary-foreground" />
                        </div>
                        <div className="inline-flex rounded-full border border-border/50 bg-foreground/[0.02] px-2.5 py-0.5 text-[14px] font-bold uppercase tracking-[0.16em] text-foreground/25 transition-colors duration-300 group-hover:text-foreground/35">
                          {String(index + 1).padStart(2, "0")}
                        </div>
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-display text-2xl font-bold text-foreground leading-tight line-clamp-2">{category.title}</h3>
                        <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{category.description}</p>
                      </div>
                    </div>
                    <ul className="mt-0 space-y-2.5">
                      {category.services.map((service) => (
                        <li key={service} className="flex min-w-0 items-center gap-2.5 text-[14px] text-foreground/85">
                          <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                          <span className="min-w-0 overflow-hidden text-ellipsis whitespace-nowrap">{service}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] items-center">
              <div data-reveal="left">
                <ElectricSectionTag label="Residential Properties We Service" icon={Home} tone="light" variant="electric-v1-2" className="mb-6" />
                <h2 className="font-display text-4xl md:text-5xl font-bold mb-5">
                  Residential Electrical Services for Homes, Renovations, and New Construction
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed mb-8">
                  GK ELECTRIC provides professional residential electrical services for homeowners, property managers, landlords, and builders. We support electrical repairs, panel upgrades, EV charger installations, lighting upgrades, home renovations, safety inspections, electrical troubleshooting, and complete residential electrical installations.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="electric" size="lg">
                    <Link to="/contact">Request An Estimate</Link>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                      <MessageCircle className="h-5 w-5" /> WhatsApp
                    </a>
                  </Button>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2" data-reveal="right">
                {[
                  { title: "Single-family homes", icon: Home },
                  { title: "Townhomes and duplexes", icon: Building2 },
                  { title: "Condominiums and apartments", icon: DoorOpen },
                  { title: "Basement suites and secondary suites", icon: Cpu },
                  { title: "Home additions and renovations", icon: Wrench },
                  { title: "New residential construction", icon: HardHat },
                  { title: "Custom homes and luxury residences", icon: Sparkles },
                  { title: "Rental and investment properties", icon: KeyRound },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.title} className="rounded-2xl border border-border bg-card p-5 shadow-sm transition-all hover:border-primary/50 hover:shadow-card">
                      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <p className="font-semibold text-foreground">{item.title}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
                <div>
                  <ElectricSectionTag label="Complete Electrical Coverage" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-5" />
                  <h2 className="font-display text-3xl md:text-5xl font-extrabold leading-tight mb-4">
                    <span className="text-primary">GK ELECTRIC</span> provides all types of residential, commercial and industrial electrical services.
                  </h2>
                  <p className="text-surface-foreground/70 text-base md:text-lg leading-relaxed max-w-3xl">
                    One licensed team for home upgrades, business power, facility wiring, permits, safety repairs, EV chargers, panels, lighting and complete electrical installations.
                  </p>
                </div>
                <div className="flex flex-col items-center gap-4">
                  {[
                    { icon: Home, label: "Residential", to: "/services/residential" as const },
                    { icon: Building2, label: "Commercial", to: "/services/commercial" as const },
                    { icon: Factory, label: "Industrial", to: "/services/industrial" as const },
                  ].map((item) => (
                    <Link key={item.label} to={item.to} className="group/coverage relative mx-auto flex w-1/2 min-w-[220px] max-w-[320px] items-center justify-center gap-3 overflow-hidden rounded-[5px] border border-primary/45 bg-transparent px-5 py-3.5 text-primary backdrop-blur-sm transition-all duration-500 ease-out hover:-translate-y-0.5 hover:border-primary hover:text-primary-foreground hover:shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2 focus:ring-offset-surface before:absolute before:inset-0 before:origin-left before:scale-x-0 before:bg-gradient-electric before:transition-transform before:duration-500 before:ease-out hover:before:scale-x-100">
                      <div className="relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-[5px] bg-transparent text-primary transition-all duration-500 group-hover/coverage:rotate-3 group-hover/coverage:scale-105 group-hover/coverage:text-primary-foreground">
                        <item.icon className="h-10 w-10" />
                      </div>
                      <div className="relative z-10 font-display text-base font-extrabold uppercase tracking-[0.18em]">{item.label}</div>
                      <ArrowRight className="relative z-10 h-5 w-5 opacity-70 transition-all duration-500 group-hover/coverage:translate-x-1.5 group-hover/coverage:opacity-100" />
                    </Link>
                  ))}
                </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-start">
              <div className="lg:sticky lg:top-28">
                <ElectricSectionTag label="Our Process" icon={Siren} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">
                  Safe, Planned, Professional
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                  Residential electrical work should feel clear and stress-free from the first call to final testing. We review your needs, explain the safest options, complete the work with care, and confirm everything is ready for reliable everyday use.
                </p>
                <Button asChild variant="electric" size="lg">
                  <Link to="/contact">
                    Request a Residential Estimate <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
              <div className="grid gap-5">
                {[
                  { icon: Phone, title: "1. Discuss Your Electrical Needs", text: "Share the repair, upgrade, renovation, or safety concern so we can clearly understand the scope of work." },
                  { icon: ClipboardCheck, title: "2. Review Safety, Load, and Code Requirements", text: "Panel capacity, circuit protection, permit requirements, and inspection needs are reviewed before installation begins." },
                  { icon: Wrench, title: "3. Complete a Clean, Professional Installation", text: "Work is completed using quality materials, neat workmanship, and respect for your home and occupied spaces." },
                  { icon: ShieldCheck, title: "4. Test and Walk Through the Completed Work", text: "Devices, breakers, detectors, EV chargers, and controls are tested and reviewed with you before final handoff." },
                ].map((step) => (
                  <div key={step.title} className="group rounded-2xl border border-border bg-card p-6 shadow-card hover:shadow-elegant hover:border-primary/40 transition-all duration-300">
                    <div className="flex items-center gap-5">
                      <div className="h-12 w-12 shrink-0 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors">
                        <step.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                      </div>
                      <div>
                        <h3 className="font-display text-xl font-bold text-foreground mb-2">{step.title}</h3>
                        <p className="text-muted-foreground leading-relaxed">{step.text}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <ElectricSectionTag label="Homeowner FAQ" icon={Flame} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
                <h2 className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">
                  Residential Service Questions
                </h2>
              </div>
              <div className="grid gap-5">
                {faqs.map((faq) => (
                  <article key={faq.q} className="rounded-2xl bg-card border border-border p-6 shadow-card">
                    <h3 className="font-display text-xl font-bold text-foreground mb-2">{faq.q}</h3>
                    <p className="text-muted-foreground leading-relaxed">{faq.a}</p>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <ElectricSectionTag label="Ready To Get Started" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-6 justify-center" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold mb-6">
                Need Reliable Electrical Work At Home?
              </h2>
              <p className="text-lg text-surface-foreground/70 leading-relaxed mb-8 max-w-2xl mx-auto">
                Speak with GK Electric about repairs, upgrades, renovations, inspections, EV charging, panel work or complete home wiring. We will help you choose a safe, practical and code-compliant solution.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="electric" size="xl">
                  <a href="tel:+17783444567">
                    <Phone className="h-5 w-5" /> Call +1 (778) 344-4567
                  </a>
                </Button>
                <Button asChild variant="outline" size="xl" className="bg-white/5 border-white/15 text-white hover:bg-white/10">
                  <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                    <MessageCircle className="h-5 w-5" /> WhatsApp Quick Response
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </div>
  );
}
