import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  CalendarCheck,
  CheckCircle2,
  ClipboardCheck,
  ClipboardList,
  Factory,
  FileCheck,
  FileText,
  Home,
  MessageCircle,
  Phone,
  ScrollText,
  ShieldCheck,
  Siren,
  Stamp,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/permits-regulatory-compliance")({
  head: () => ({
    meta: [
      { title: "Permits & Regulatory Compliance — GK Electric" },
      {
        name: "description",
        content:
          "Electrical permit applications, inspections, code compliance, regulatory documentation, and approval management handled by GK Electric.",
      },
      { property: "og:title", content: "Permits & Regulatory Compliance — GK Electric" },
      {
        property: "og:description",
        content:
          "Permits, inspections and electrical regulatory compliance handled from application to final approval.",
      },
    ],
  }),
  component: PermitsRegulatoryCompliancePage,
});

const keyBenefits = [
  {
    icon: FileCheck,
    title: "Permit Applications to Final Approval",
    description:
      "We manage every stage of the permitting process, saving you time and eliminating administrative headaches.",
  },
  {
    icon: BadgeCheck,
    title: "Code-Compliant, Inspected & Approved",
    description:
      "All work is completed to meet current electrical regulations and inspection requirements.",
  },
  {
    icon: ClipboardCheck,
    title: "End-to-End Permit & Inspection Management",
    description:
      "From documentation and submissions to scheduling inspections and addressing deficiencies, we handle it all.",
  },
  {
    icon: ShieldCheck,
    title: "Full Regulatory Compliance",
    description:
      "Ensuring your project meets BC Electrical Safety Regulation requirements and applicable Canadian Electrical Code standards.",
  },
  {
    icon: ScrollText,
    title: "We Handle the Paperwork",
    description:
      "Our team prepares and submits all required documentation, allowing you to focus on your project.",
  },
  {
    icon: CalendarCheck,
    title: "Safe, Compliant & On Schedule",
    description:
      "Proactive permit management helps avoid delays, costly corrections, and compliance issues.",
  },
];

const servicesIncluded = [
  "Electrical Permit Applications",
  "Inspection Scheduling & Coordination",
  "Electrical Code Compliance Verification",
  "Deficiency Resolution Support",
  "Final Inspection & Approval Assistance",
  "Regulatory Documentation Management",
];

const whyChooseUs = [
  {
    icon: ShieldCheck,
    title: "Licensed & Insured",
    description: "Fully licensed electricians backed by comprehensive insurance coverage.",
  },
  {
    icon: Stamp,
    title: "Electrical Operating Permits",
    description: "We obtain all required permits to ensure your project is properly authorized and documented.",
  },
  {
    icon: BadgeCheck,
    title: "Code-Compliant Workmanship",
    description: "Every installation is completed to meet or exceed applicable electrical safety standards.",
  },
  {
    icon: Building2,
    title: "Residential, Commercial & Industrial Projects",
    description: "From minor electrical upgrades to large-scale installations, we deliver dependable solutions.",
  },
  {
    icon: Siren,
    title: "24/7 Emergency Support",
    description: "Rapid response when urgent electrical issues require immediate attention.",
  },
  {
    icon: ClipboardList,
    title: "Detailed Planning & Documentation",
    description: "Comprehensive reports, permit documentation, and project support for projects of any size.",
  },
];

function PermitsRegulatoryCompliancePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero — matched to Projects page hero style */}
      <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[50vh] flex items-center text-surface-foreground">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
        </div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <ElectricSectionTag label="Specialized Service" icon={ClipboardCheck} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
            <h1
              data-reveal
              className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6"
            >
              <span className="text-typewriter">
                Permits & <span className="brand-highlight">Compliance</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-surface-foreground/70 max-w-2xl mx-auto mb-8 leading-relaxed">
              Permits, Inspections & Compliance — Handled for You
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="tel:+17783444567"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
                  <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">Call Us</div>
                  <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
                </div>
              </a>
              <a
                href="https://wa.me/17783444567"
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
                  <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">WhatsApp</div>
                  <div className="text-surface-foreground font-semibold">Quick Response</div>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-10 text-primary/5 animate-float pointer-events-none">
          <FileText className="h-32 w-32 rotate-12" />
        </div>
        <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500 pointer-events-none">
          <Stamp className="h-24 w-24 -rotate-12" />
        </div>
      </section>

      <section className="relative overflow-hidden py-24 bg-background">
        <div className="absolute inset-0 pointer-events-none opacity-60">
          <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute bottom-10 -left-24 h-72 w-72 rounded-full bg-accent/10 blur-3xl" />
        </div>
        <div className="container mx-auto px-4 relative">
          <div className="grid gap-12 lg:grid-cols-[1.05fr_0.95fr] items-center">
            <div data-reveal="left">
              <ElectricSectionTag label="Handled for You" icon={ClipboardCheck} tone="light" variant="electric-v1-2" className="mb-6" />
              <h2 className="font-display text-4xl md:text-5xl font-extrabold tracking-tight text-foreground mb-6">
                Permits, Inspections & Compliance — <span className="text-primary">Handled for You</span>
              </h2>
              <div className="space-y-5 text-lg text-muted-foreground leading-relaxed">
                <p>
                  Navigating electrical permits, inspections, and regulatory requirements can be complex and time-consuming. Our team manages the entire process on your behalf—from permit applications to final approvals—ensuring your project remains compliant, on schedule, and free from unnecessary delays.
                </p>
                <p>
                  We work closely with local authorities and inspection agencies to ensure all electrical work meets the requirements of the BC Electrical Safety Regulation and the Canadian Electrical Code. With proactive planning and attention to detail, we help reduce compliance risks and keep your project moving forward with confidence.
                </p>
              </div>
            </div>

            <div data-reveal="right" className="relative">
              <div className="absolute -inset-4 rounded-[2rem] bg-primary/5 opacity-40 blur-2xl animate-pulse" />
              <div className="relative rounded-[2rem] bg-surface text-surface-foreground border border-white/10 shadow-xl overflow-hidden">
                <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />
                <div className="relative p-8 md:p-10">
                  <div className="h-16 w-16 rounded-2xl bg-primary/10 ring-1 ring-primary/20 flex items-center justify-center mb-6">
                    <ClipboardCheck className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-display text-3xl font-bold mb-4">Compliance Confidence</h3>
                  <p className="text-surface-foreground/70 leading-relaxed mb-8">
                    Permit applications, inspections, documentation, deficiency support, and final approvals are coordinated by one experienced electrical team.
                  </p>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { icon: Home, label: "Residential" },
                      { icon: Building2, label: "Commercial" },
                      { icon: Factory, label: "Industrial" },
                    ].map((item) => (
                      <div key={item.label} className="rounded-2xl bg-white/5 border border-white/10 p-4 text-center hover:border-primary/40 hover:bg-white/[0.07] transition-colors">
                        <item.icon className="mx-auto h-6 w-6 text-primary mb-2" />
                        <div className="text-xs uppercase tracking-wider text-surface-foreground/60">{item.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-muted/40">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-14" data-reveal>
            <ElectricSectionTag label="Key Benefits" icon={BadgeCheck} tone="light" variant="electric-v1-2" className="mb-6 justify-center" />
            <h2 className="font-display text-4xl md:text-5xl font-extrabold tracking-tight text-foreground mb-4">
              Built to Reduce Risk, Delays & Paperwork
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Practical permit support that protects your timeline, budget, and electrical safety obligations.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {keyBenefits.map((benefit, index) => (
              <div
                key={benefit.title}
                data-reveal
                style={{ transitionDelay: `${index * 70}ms` }}
                className="group rounded-3xl bg-card border border-border p-7 shadow-card hover:shadow-xl hover:border-primary/40 transition-[box-shadow,border-color,background-color] duration-300"
              >
                <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary group-hover:scale-110 transition-all">
                  <benefit.icon className="h-7 w-7 text-primary group-hover:text-primary-foreground" />
                </div>
                <h3 className="font-display text-xl font-bold text-foreground mb-3">{benefit.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] items-start">
            <div data-reveal="left" className="lg:sticky lg:top-24">
              <ElectricSectionTag label="Services Included" icon={CheckCircle2} tone="light" variant="electric-v1-2" className="mb-6" />
              <h2 className="font-display text-4xl md:text-5xl font-extrabold tracking-tight text-foreground mb-5">
                Permit & Inspection Support From Start to Finish
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Our process is structured to keep documentation organized, inspections coordinated, and approval requirements clear.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {servicesIncluded.map((service, index) => (
                <div
                  key={service}
                  data-reveal
                  style={{ transitionDelay: `${index * 60}ms` }}
                  className="flex items-start gap-4 rounded-2xl bg-card border border-border p-5 shadow-sm hover:shadow-card hover:border-primary/30 transition-all"
                >
                  <span className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-electric shadow-glow">
                    <CheckCircle2 className="h-4 w-4 text-primary-foreground" />
                  </span>
                  <span className="font-semibold text-foreground leading-snug">{service}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />
        <div className="container mx-auto px-4 relative">
          <div className="text-center max-w-3xl mx-auto mb-14" data-reveal>
            <ElectricSectionTag label="Why Choose Us" icon={ShieldCheck} tone="dark" variant="electric-v1-2" className="mb-6 justify-center" />
            <h2 className="font-display text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
              Licensed Electrical Support You Can Trust
            </h2>
            <p className="text-lg text-surface-foreground/70 leading-relaxed">
              A dependable team for compliant installations, clear documentation, and responsive project support.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {whyChooseUs.map((item, index) => (
              <div
                key={item.title}
                data-reveal
                style={{
                  transitionDelay: `${index * 70}ms`,
                  backgroundColor: "color-mix(in oklab,var(--color-white) 0.5%,transparent)",
                }}
                className="group relative overflow-hidden rounded-3xl border border-white/10 p-7 shadow-[0_10px_28px_rgba(0,0,0,0.16)] backdrop-blur-sm hover:border-primary/35 hover:shadow-[0_12px_32px_rgba(0,0,0,0.22)] transition-all duration-300"
              >
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/25 to-transparent" />
                <div className="relative h-14 w-14 rounded-2xl bg-primary/15 ring-1 ring-primary/20 flex items-center justify-center mb-5 group-hover:bg-primary group-hover:scale-105 transition-all duration-300">
                  <item.icon className="h-7 w-7 text-primary group-hover:text-primary-foreground" />
                </div>
                <h3 className="relative font-display text-xl font-bold mb-3">{item.title}</h3>
                <p className="relative text-surface-foreground/68 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div data-reveal className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-surface via-surface to-surface/95 text-surface-foreground p-8 md:p-12 lg:p-16 shadow-elegant">
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute bottom-0 left-0 h-64 w-64 rounded-full bg-accent/10 blur-3xl" />
            </div>
            <div className="relative grid gap-8 lg:grid-cols-[1fr_auto] items-center">
              <div>
                <ElectricSectionTag label="Need Help?" icon={Phone} tone="dark" variant="electric-v1-2" className="mb-6" />
                <h2 className="font-display text-4xl md:text-5xl font-extrabold tracking-tight mb-5">
                  Need Help With Electrical Permits or Code Compliance?
                </h2>
                <p className="text-lg text-surface-foreground/70 leading-relaxed max-w-3xl">
                  Let our experienced team handle the permits, inspections, and regulatory requirements so your project can move forward smoothly, safely, and without unnecessary delays.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row lg:flex-col gap-4">
                <Button asChild variant="electric" size="xl" className="shadow-none hover:shadow-none">
                  <a href="tel:+17783444567">
                    <Phone className="h-5 w-5" /> Call Now
                  </a>
                </Button>
                <Button asChild variant="outlineLight" size="xl">
                  <Link to="/free-estimate">
                    Request a Quote <ArrowRight className="h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild variant="outlineLight" size="xl" className="border-green-500/50 text-green-300 hover:border-green-500">
                  <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                    <MessageCircle className="h-5 w-5" /> WhatsApp Us
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
