import { createFileRoute } from "@tanstack/react-router";
import {
  Award,
  BadgeCheck,
  Bolt,
  CheckCircle2,
  Clock,
  Cpu,
  Gem,
  Headphones,
  HeartHandshake,
  Lightbulb,
  Medal,
  Rocket,
  ShieldCheck,
  Sparkles,
  Star,
  Target,
  ThumbsUp,
  Trophy,
  Users,
  Wrench,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";

export const Route = createFileRoute("/sample")({
  head: () => ({
    meta: [
      { title: "Why Choose Us Design Samples | GK Electric" },
      {
        name: "description",
        content: "Twenty different Why Choose Us section design samples for GK Electric.",
      },
    ],
  }),
  component: SamplePage,
});

const reasons = [
  { icon: ShieldCheck, title: "Licensed & Insured", text: "Certified electricians with dependable code-compliant workmanship." },
  { icon: Clock, title: "Fast Response", text: "Quick scheduling and responsive support for urgent electrical needs." },
  { icon: Award, title: "Quality Work", text: "Clean installations, careful finishing and long-lasting results." },
  { icon: Headphones, title: "Clear Support", text: "Friendly communication before, during and after every project." },
];

const samples = [
  { name: "01 / Classic Cards", style: "classic" },
  { name: "02 / Dark Premium", style: "dark" },
  { name: "03 / Numbered Steps", style: "numbered" },
  { name: "04 / Glass Panels", style: "glass" },
  { name: "05 / Split Feature", style: "split" },
  { name: "06 / Icon Rings", style: "rings" },
  { name: "07 / Timeline", style: "timeline" },
  { name: "08 / Amber Blocks", style: "amber" },
  { name: "09 / Minimal Lines", style: "minimal" },
  { name: "10 / Blueprint Grid", style: "blueprint" },
  { name: "11 / Diagonal Cards", style: "diagonal" },
  { name: "12 / Badge Stack", style: "badges" },
  { name: "13 / Metric Focus", style: "metrics" },
  { name: "14 / Soft Neutral", style: "soft" },
  { name: "15 / Neon Edge", style: "neon" },
  { name: "16 / Editorial", style: "editorial" },
  { name: "17 / Checklist", style: "checklist" },
  { name: "18 / Floating Tiles", style: "floating" },
  { name: "19 / Compact Bar", style: "compact" },
  { name: "20 / Luxury Grid", style: "luxury" },
] as const;

const extraIcons = [Trophy, Medal, Target, Users, Wrench, Star, Bolt, Gem, Rocket, Cpu, HeartHandshake, BadgeCheck, Sparkles, Lightbulb, ThumbsUp, CheckCircle2];

function SamplePage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[45vh] flex items-center text-surface-foreground">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
          </div>
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: "50px 50px",
            }}
          />
          <div className="container mx-auto px-4 py-24 relative z-10 text-center">
            <ElectricSectionTag label="Sample Page" icon={Sparkles} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
            <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tight mb-6">
              Why Choose Us <span className="brand-highlight">Samples</span>
            </h1>
            <p className="text-lg md:text-xl text-surface-foreground/70 max-w-2xl mx-auto leading-relaxed">
              Twenty different section directions using the same GK Electric brand language, spacing, and responsive structure.
            </p>
          </div>
        </section>

        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4 space-y-10">
            {samples.map((sample, index) => (
              <WhyChooseSample key={sample.name} index={index} name={sample.name} styleName={sample.style} />
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}

function WhyChooseSample({ index, name, styleName }: { index: number; name: string; styleName: string }) {
  const Icon = extraIcons[index % extraIcons.length];

  if (styleName === "dark") {
    return (
      <SampleShell name={name} className="bg-surface text-surface-foreground border-surface">
        <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-8 items-center">
          <div>
            <Kicker dark />
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Why Choose GK Electric?</h2>
            <p className="text-surface-foreground/65 leading-relaxed">Industrial-grade expertise with a polished residential service experience.</p>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            {reasons.map((item) => <DarkCard key={item.title} {...item} />)}
          </div>
        </div>
      </SampleShell>
    );
  }

  if (styleName === "numbered") {
    return (
      <SampleShell name={name}>
        <SectionHeading />
        <div className="grid md:grid-cols-4 gap-4">
          {reasons.map((item, i) => <NumberCard key={item.title} item={item} number={i + 1} />)}
        </div>
      </SampleShell>
    );
  }

  if (styleName === "split") {
    return (
      <SampleShell name={name} className="overflow-hidden">
        <div className="grid lg:grid-cols-2 gap-0 -m-8 md:-m-10">
          <div className="p-8 md:p-12 bg-surface text-surface-foreground">
            <Kicker dark />
            <h2 className="font-display text-5xl font-bold mb-5">Powerful Reasons to Work With Us</h2>
            <p className="text-surface-foreground/70">A practical team for homes, commercial sites, facilities and EV charger projects.</p>
          </div>
          <div className="p-8 md:p-12 grid gap-4">
            {reasons.map((item) => <HorizontalReason key={item.title} {...item} />)}
          </div>
        </div>
      </SampleShell>
    );
  }

  if (styleName === "timeline") {
    return (
      <SampleShell name={name}>
        <SectionHeading />
        <div className="relative grid md:grid-cols-4 gap-6 before:hidden md:before:block before:absolute before:top-8 before:left-10 before:right-10 before:h-px before:bg-border">
          {reasons.map((item, i) => <TimelineItem key={item.title} item={item} step={i + 1} />)}
        </div>
      </SampleShell>
    );
  }

  if (styleName === "metrics") {
    return (
      <SampleShell name={name}>
        <div className="grid lg:grid-cols-[0.8fr_1.2fr] gap-8 items-center">
          <SectionHeading compact />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {["18+", "1000+", "24/7", "BC"].map((value, i) => (
              <div key={value} className="rounded-2xl bg-gradient-to-br from-primary/15 to-card border border-primary/20 p-6 text-center shadow-card">
                <div className="text-4xl font-display font-bold text-foreground mb-2">{value}</div>
                <div className="text-xs uppercase tracking-[0.22em] text-muted-foreground">{reasons[i].title}</div>
              </div>
            ))}
          </div>
        </div>
      </SampleShell>
    );
  }

  if (styleName === "checklist") {
    return (
      <SampleShell name={name}>
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <SectionHeading compact />
          <div className="rounded-3xl border border-border overflow-hidden">
            {reasons.map((item) => <ChecklistRow key={item.title} {...item} />)}
          </div>
        </div>
      </SampleShell>
    );
  }

  if (styleName === "compact") {
    return (
      <SampleShell name={name}>
        <div className="flex flex-col lg:flex-row lg:items-center gap-6">
          <div className="lg:w-72 shrink-0"><SectionHeading compact /></div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 flex-1">
            {reasons.map((item) => <CompactPill key={item.title} {...item} />)}
          </div>
        </div>
      </SampleShell>
    );
  }

  const variants: Record<string, string> = {
    classic: "bg-card border-border shadow-card",
    glass: "bg-white/70 backdrop-blur-xl border-white shadow-elegant",
    rings: "bg-card border-primary/15 shadow-card",
    amber: "bg-primary/10 border-primary/25 shadow-glow",
    minimal: "bg-background border-border shadow-none",
    blueprint: "bg-surface text-surface-foreground border-surface shadow-elegant",
    diagonal: "bg-card border-border shadow-card skew-y-[-1deg]",
    badges: "bg-card border-border shadow-card",
    soft: "bg-muted/60 border-transparent shadow-none",
    neon: "bg-surface text-surface-foreground border-primary/40 shadow-glow",
    editorial: "bg-card border-border shadow-card",
    floating: "bg-gradient-to-br from-background to-muted border-border shadow-elegant",
    luxury: "bg-[#151515] text-white border-[#2a2a2a] shadow-elegant",
  };

  return (
    <SampleShell name={name} className={variants[styleName] ?? "bg-card border-border shadow-card"}>
      <div className={styleName === "diagonal" ? "skew-y-[1deg]" : ""}>
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-5 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-primary font-bold mb-3">
              <Icon className="h-4 w-4" /> Why Choose Us
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">Built for Safe, Clean Electrical Work</h2>
          </div>
          <p className="md:max-w-md text-muted-foreground leading-relaxed">Four core advantages presented in a unique visual style for comparison.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {reasons.map((item, i) => <VariantCard key={item.title} item={item} index={i} styleName={styleName} />)}
        </div>
      </div>
    </SampleShell>
  );
}

function SampleShell({ name, className = "bg-card border-border shadow-card", children }: { name: string; className?: string; children: React.ReactNode }) {
  return (
    <article className={`rounded-[2rem] border p-6 md:p-10 ${className}`}>
      <div className="text-xs font-bold uppercase tracking-[0.28em] text-primary mb-6">{name}</div>
      {children}
    </article>
  );
}

function Kicker({ dark = false }: { dark?: boolean }) {
  return <div className={`text-xs uppercase tracking-[0.28em] font-bold mb-3 ${dark ? "text-primary" : "text-primary"}`}>Why Choose Us</div>;
}

function SectionHeading({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? "" : "text-center mb-8"}>
      <Kicker />
      <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-3">Why Choose GK Electric?</h2>
      <p className="text-muted-foreground leading-relaxed max-w-2xl mx-auto">Dependable electrical service backed by experience, safety and professional care.</p>
    </div>
  );
}

function DarkCard({ icon: Icon, title, text }: typeof reasons[number]) {
  return (
    <div className="rounded-2xl bg-white/5 border border-white/10 p-5 hover:border-primary/40 transition-colors">
      <Icon className="h-7 w-7 text-primary mb-4" />
      <h3 className="font-bold text-lg mb-2">{title}</h3>
      <p className="text-sm text-surface-foreground/60 leading-relaxed">{text}</p>
    </div>
  );
}

function NumberCard({ item, number }: { item: typeof reasons[number]; number: number }) {
  const Icon = item.icon;
  return (
    <div className="rounded-2xl bg-card border border-border p-6 shadow-card relative overflow-hidden">
      <div className="absolute -top-5 -right-2 text-7xl font-display font-bold text-primary/10">0{number}</div>
      <Icon className="h-8 w-8 text-primary mb-5 relative" />
      <h3 className="font-bold text-lg mb-2 relative">{item.title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed relative">{item.text}</p>
    </div>
  );
}

function HorizontalReason({ icon: Icon, title, text }: typeof reasons[number]) {
  return (
    <div className="flex gap-4 rounded-2xl bg-muted/50 border border-border p-5">
      <div className="h-12 w-12 rounded-xl bg-primary/15 flex items-center justify-center shrink-0"><Icon className="h-6 w-6 text-primary" /></div>
      <div><h3 className="font-bold mb-1">{title}</h3><p className="text-sm text-muted-foreground leading-relaxed">{text}</p></div>
    </div>
  );
}

function TimelineItem({ item, step }: { item: typeof reasons[number]; step: number }) {
  const Icon = item.icon;
  return (
    <div className="relative text-center">
      <div className="mx-auto h-16 w-16 rounded-full bg-gradient-electric shadow-glow flex items-center justify-center relative z-10 mb-4">
        <Icon className="h-7 w-7 text-primary-foreground" />
      </div>
      <div className="text-xs text-primary font-bold uppercase tracking-widest mb-2">Step {step}</div>
      <h3 className="font-bold text-lg mb-2">{item.title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{item.text}</p>
    </div>
  );
}

function ChecklistRow({ icon: Icon, title, text }: typeof reasons[number]) {
  return (
    <div className="flex items-center gap-4 p-5 border-b border-border last:border-b-0 hover:bg-muted/40 transition-colors">
      <CheckCircle2 className="h-6 w-6 text-primary shrink-0" />
      <Icon className="h-6 w-6 text-muted-foreground shrink-0" />
      <div><h3 className="font-bold">{title}</h3><p className="text-sm text-muted-foreground">{text}</p></div>
    </div>
  );
}

function CompactPill({ icon: Icon, title }: typeof reasons[number]) {
  return (
    <div className="rounded-full border border-border bg-card px-4 py-3 flex items-center gap-3 shadow-sm">
      <Icon className="h-5 w-5 text-primary shrink-0" />
      <span className="text-sm font-bold">{title}</span>
    </div>
  );
}

function VariantCard({ item, index, styleName }: { item: typeof reasons[number]; index: number; styleName: string }) {
  const Icon = item.icon;
  const special = styleName === "blueprint" || styleName === "neon" || styleName === "luxury";
  return (
    <div className={`rounded-2xl p-5 border transition-all duration-300 hover:-translate-y-1 ${special ? "bg-white/5 border-white/10 hover:border-primary/50" : "bg-card border-border hover:border-primary/40 shadow-sm"}`}>
      <div className={`h-12 w-12 rounded-xl flex items-center justify-center mb-5 ${index % 2 === 0 ? "bg-primary text-primary-foreground" : "bg-primary/15 text-primary"}`}>
        <Icon className="h-6 w-6" />
      </div>
      <h3 className="font-bold text-lg mb-2">{item.title}</h3>
      <p className={`text-sm leading-relaxed ${special ? "text-white/60" : "text-muted-foreground"}`}>{item.text}</p>
    </div>
  );
}
