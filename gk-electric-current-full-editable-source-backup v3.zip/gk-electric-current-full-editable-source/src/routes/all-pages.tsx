import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import {
  Search,
  Layers,
  Layout,
  FileText,
  Hammer,
  Zap,
  Sliders,
  ChevronRight,
  Sparkles,
  Filter,
  Package,
  Boxes
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/all-pages")({
  head: () => ({
    meta: [
      { title: "Sitemap & Page Directory — GK Electric" },
      { name: "description", content: "Explore all pages, service variants, and live design templates of GK Electric." },
    ],
  }),
  component: AllPagesDirectory,
});

interface PageItem {
  path: string;
  title: string;
  description: string;
  category: "core" | "services" | "forms" | "variants" | "samples";
  badge?: string;
  zone: 1 | 2;
}

const PAGES_DIRECTORY: PageItem[] = [
  // ZONE 1: Core & Official Site Pages
  {
    path: "/",
    title: "Home Page",
    description: "The main landing page with interactive hero slideshow, feature carousels, service connections, and customer reviews.",
    category: "core",
    badge: "Main",
    zone: 1
  },
  {
    path: "/services",
    title: "All Services Hub",
    description: "Main services directory showing comprehensive solutions for residential, commercial, industrial, and EV projects.",
    category: "core",
    zone: 1
  },
  {
    path: "/projects",
    title: "Projects Portfolio",
    description: "Filterable grid of completed electrical works with deep-dive project detail dialogs and imagery.",
    category: "core",
    zone: 1
  },
  {
    path: "/about",
    title: "About Company",
    description: "Our experience, core values, safety standards, and team credentials as licensed electricians.",
    category: "core",
    zone: 1
  },
  {
    path: "/service-areas",
    title: "Service Areas Map",
    description: "Detailed coverage across Surrey, Langley, Delta, White Rock, and the wider Lower Mainland.",
    category: "core",
    zone: 1
  },
  {
    path: "/careers",
    title: "Careers & Recruitment",
    description: "Join our growing team of journeyperson and apprentice electricians. Interactive job application portal.",
    category: "core",
    zone: 1
  },
  {
    path: "/blog",
    title: "Company Blog",
    description: "Insights, electrical guides, and safety updates from our master electricians.",
    category: "core",
    zone: 1
  },
  {
    path: "/surrey",
    title: "Surrey Local SEO Page",
    description: "Targeted landing page for Surrey, BC electrical services, emergency repairs, upgrades, and local dispatch.",
    category: "core",
    badge: "SEO Targeted",
    zone: 1
  },
  {
    path: "/residential-electrical-services",
    title: "Residential Electrical Services (Rich Clone)",
    description: "Complete home electrical solutions, panel upgrades, lighting installations, troubleshooting, and code-compliant upgrades.",
    category: "services",
    badge: "New Rich Clone",
    zone: 1
  },
  {
    path: "/commercial-electrical-services",
    title: "Commercial Electrical Services",
    description: "Tenant improvements, power distribution, energy-efficient commercial lighting retrofits, and maintenance.",
    category: "services",
    zone: 1
  },
  {
    path: "/industrial-electrical-services",
    title: "Industrial Electrical Services (Rich Clone)",
    description: "Industrial three-phase power systems, heavy machinery connections, control wiring, electrical testing/commissioning, power quality engineering, backup power resilience, low voltage communication, and energy optimization.",
    category: "services",
    badge: "New Rich Clone",
    zone: 1
  },
  {
    path: "/ev-charger",
    title: "EV Charger Installation",
    description: "Level 2 smart EV charger installations, home load calculations, permit coordination, and utility rebates.",
    category: "services",
    zone: 1
  },
  {
    path: "/permits-regulatory-compliance",
    title: "Permits & Regulatory Compliance",
    description: "Guidance on TSBC electrical permits, code compliance, load calculations, and inspections.",
    category: "services",
    zone: 1
  },
  {
    path: "/emergency-electrician-surrey",
    title: "Emergency Electrician Surrey",
    description: "24/7 Emergency electrical services, troubleshooting, and repairs in Surrey and surrounding Lower Mainland communities.",
    category: "services",
    badge: "SEO Service",
    zone: 1
  },
  {
    path: "/residential-electrical-services-details",
    title: "Residential Electrical Services Details",
    description: "Complete home electrical solutions, panel upgrades, lighting installations, troubleshooting, and code-compliant upgrades (Duplicate Detail Page).",
    category: "services",
    badge: "Details",
    zone: 1
  },
  {
    path: "/commercial-electrical-services-details",
    title: "Commercial Electrical Services Details",
    description: "Tenant improvements, power distribution, energy-efficient commercial lighting retrofits, and maintenance (Duplicate Detail Page).",
    category: "services",
    badge: "Details",
    zone: 1
  },
  {
    path: "/industrial-electrical-services-details",
    title: "Industrial Electrical Services Details",
    description: "Industrial three-phase power systems, heavy machinery connections, control wiring, electrical testing/commissioning, power quality engineering, backup power resilience, low voltage communication, and energy optimization (Duplicate Detail Page).",
    category: "services",
    badge: "Details",
    zone: 1
  },
  {
    path: "/free-estimate",
    title: "Free Estimate Request Form",
    description: "Comprehensive step-by-step quote request builder with Zod schema validation.",
    category: "forms",
    badge: "Interactive",
    zone: 1
  },
  {
    path: "/contact",
    title: "Contact & Location Form",
    description: "Direct contact form, map integration, and rapid response emergency support dispatch.",
    category: "forms",
    zone: 1
  },

  // ZONE 2: Extra Pages, Design Variants, Clones & Sandboxes
  {
    path: "/services/residential",
    title: "Residential Services Nested Route",
    description: "Nested route serving residential services.",
    category: "samples",
    zone: 2
  },
  {
    path: "/services/commercial",
    title: "Commercial Services Nested Route",
    description: "Nested route serving commercial services.",
    category: "samples",
    zone: 2
  },
  {
    path: "/services/industrial",
    title: "Industrial Services Nested Route",
    description: "Nested route serving industrial services.",
    category: "samples",
    zone: 2
  },
  {
    path: "/residential-services-clone",
    title: "Residential Services 100% Exact Clone (New Path)",
    description: "A 100% exact, pixel-perfect clone of the residential services clone page hosted on a brand new path.",
    category: "variants",
    badge: "New Clone",
    zone: 2
  },
  {
    path: "/residential-services-sample-clone",
    title: "Residential Services Sample Clone",
    description: "A redesigned variant of the residential services template with enhanced visuals and layout.",
    category: "variants",
    zone: 2
  },
  {
    path: "/residential-services-sample-clone-copy",
    title: "Residential Services Sample Clone Copy",
    description: "Alternative experimental copy of the residential services redesign layout.",
    category: "variants",
    zone: 2
  },
  {
    path: "/residential-services-sample-blueprint",
    title: "Residential Services Sample Blueprint",
    description: "Blueprint-themed design variant showcasing technical specs and architectural focus.",
    category: "variants",
    zone: 2
  },
  {
    path: "/residential-services-sample-modern",
    title: "Residential Services Sample Modern",
    description: "Ultra-modern, high-contrast styled layout for residential services.",
    category: "variants",
    zone: 2
  },
  {
    path: "/residential-services-sample-premium",
    title: "Residential Services Sample Premium",
    description: "Luxury, gold-accented premium theme variation for residential electrical services.",
    category: "variants",
    zone: 2
  },
  {
    path: "/residential-services-sample-new-clone",
    title: "Residential Services Sample New Clone (Exact Match)",
    description: "A 100% exact, pixel-perfect clone of the residential services clone page built directly using the requested GitHub file.",
    category: "variants",
    badge: "Requested File Clone",
    zone: 2
  },
  {
    path: "/commercial-services-sample",
    title: "Commercial Services Sample Page",
    description: "Tenant improvements and corporate office electrical setup layout example.",
    category: "variants",
    zone: 2
  },
  {
    path: "/commercial-electrical-services-clone",
    title: "Commercial Electrical Services Clone",
    description: "Cloned variant of the commercial services dashboard layout.",
    category: "variants",
    zone: 2
  },
  {
    path: "/commercial-electrical-services-exact-clone",
    title: "Commercial Electrical Services Exact Clone",
    description: "Exact duplicate variant for testing performance and layout rendering.",
    category: "variants",
    zone: 2
  },
  {
    path: "/commercial-electrical-services-modern",
    title: "Commercial Electrical Services Modern",
    description: "A sleek, modern design variant with dark-mode optimized components for commercial clients.",
    category: "variants",
    zone: 2
  },
  {
    path: "/commercial-electrical-services-original",
    title: "Commercial Electrical Services Original",
    description: "The classic, original layout for commercial electrical services.",
    category: "variants",
    zone: 2
  },
  {
    path: "/commercial-electrical-services-premium",
    title: "Commercial Electrical Services Premium",
    description: "High-end corporate aesthetics and clean layout variations.",
    category: "variants",
    zone: 2
  },
  {
    path: "/commercial-electrical-services-copy",
    title: "Commercial Electrical Services Copy",
    description: "Alternative layout and content copy for the commercial electrical services hub.",
    category: "variants",
    zone: 2
  },
  {
    path: "/sample-industrial-services",
    title: "Industrial Services Sample Page",
    description: "Comprehensive industrial electrical services showcase with detailed machinery controls section.",
    category: "variants",
    zone: 2
  },
  {
    path: "/new-test-1",
    title: "TSBC Licence Design Set",
    description: "A specialized design review set focused on Technical Safety BC licensing and credentials.",
    category: "variants",
    zone: 2
  },
  {
    path: "/sample",
    title: "Why Choose Us Design Samples",
    description: "A collection of interactive layout designs showcasing value propositions and trust symbols.",
    category: "variants",
    zone: 2
  },
  {
    path: "/residential-electrical-services-1",
    title: "Residential Electrical Services 1",
    description: "The original residential electrical services page layout.",
    category: "variants",
    zone: 2
  },
  {
    path: "/industrial-electrical-services-1",
    title: "Industrial Electrical Services 1",
    description: "The original industrial electrical services page layout.",
    category: "variants",
    zone: 2
  },
  {
    path: "/sample-1",
    title: "Development Sample 1",
    description: "Minimal developer sandbox page 1.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-2",
    title: "Development Sample 2",
    description: "Minimal developer sandbox page 2.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-3",
    title: "Development Sample 3",
    description: "Minimal developer sandbox page 3.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-4",
    title: "Development Sample 4",
    description: "Minimal developer sandbox page 4.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-5",
    title: "Development Sample 5",
    description: "Minimal developer sandbox page 5.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-6",
    title: "Development Sample 6",
    description: "Minimal developer sandbox page 6.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-7",
    title: "Development Sample 7",
    description: "Minimal developer sandbox page 7.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-8",
    title: "Development Sample 8",
    description: "Minimal developer sandbox page 8.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-9",
    title: "Development Sample 9",
    description: "Minimal developer sandbox page 9.",
    category: "samples",
    zone: 2
  },
  {
    path: "/sample-10",
    title: "Development Sample 10",
    description: "Minimal developer sandbox page 10.",
    category: "samples",
    zone: 2
  }
];

function AllPagesDirectory() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const categories = [
    { id: "all", label: "All Pages", icon: Layers, count: PAGES_DIRECTORY.length },
    { id: "core", label: "Core Pages", icon: Layout, count: PAGES_DIRECTORY.filter(p => p.category === "core").length },
    { id: "services", label: "Services", icon: Zap, count: PAGES_DIRECTORY.filter(p => p.category === "services").length },
    { id: "forms", label: "Forms & Tools", icon: FileText, count: PAGES_DIRECTORY.filter(p => p.category === "forms").length },
    { id: "variants", label: "Design Variants", icon: Sliders, count: PAGES_DIRECTORY.filter(p => p.category === "variants").length },
    { id: "samples", label: "Nested & Dev Samples", icon: Hammer, count: PAGES_DIRECTORY.filter(p => p.category === "samples").length },
  ];

  const filteredPages = useMemo(() => {
    return PAGES_DIRECTORY.filter((page) => {
      const matchesSearch =
        page.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        page.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
        page.description.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory = selectedCategory === "all" || page.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const zone1Pages = useMemo(() => filteredPages.filter(p => p.zone === 1), [filteredPages]);
  const zone2Pages = useMemo(() => filteredPages.filter(p => p.zone === 2), [filteredPages]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Header Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 pt-32 pb-16 text-surface-foreground">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
        </div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs uppercase tracking-widest font-semibold mb-6">
              <Sparkles className="h-3.5 w-3.5" />
              Complete Site Index
            </div>
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-extrabold text-surface-foreground tracking-tight mb-6">
              GK ELECTRIC <span className="text-primary">SITEMAP</span>
            </h1>
            <p className="text-lg text-surface-foreground/70 max-w-2xl mx-auto mb-8 leading-relaxed">
              Access every core section, premium design variant, interactive form, and development sample built into this pixel-perfect system.
            </p>
          </div>
        </div>
      </section>

      {/* Filter and Directory Section */}
      <section className="py-12 flex-grow">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            
            {/* Search & Filter Controls */}
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-8 bg-card border border-border p-4 rounded-2xl shadow-card">
              <div className="relative w-full md:max-w-md">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search pages, paths, or features..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 text-sm bg-muted/50 border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all text-foreground"
                />
              </div>
              
              <div className="flex items-center gap-2 text-xs text-muted-foreground font-semibold">
                <Filter className="h-3.5 w-3.5" />
                Showing {filteredPages.length} of {PAGES_DIRECTORY.length} Pages
              </div>
            </div>

            {/* Category Tabs */}
            <div className="flex flex-wrap gap-2 mb-12">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-xl border transition-all ${
                      isSelected
                        ? "bg-primary border-primary text-primary-foreground shadow-glow"
                        : "bg-card border-border hover:border-primary/40 text-foreground/80 hover:text-foreground"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{cat.label}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                      isSelected ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-muted-foreground"
                    }`}>
                      {cat.count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* ZONE 1 SECTION */}
            <div className="mb-16">
              <div className="flex items-center gap-3 mb-6 border-b border-border pb-4">
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                  <Package className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-2xl md:text-3xl font-display font-extrabold tracking-wide uppercase text-foreground">
                    Zone 1: Core & Official Site Pages
                  </h2>
                  <p className="text-xs text-muted-foreground">
                    Primary navigational routes, contact portals, official estimate builders, and core service offerings.
                  </p>
                </div>
                <div className="ml-auto text-xs font-bold uppercase tracking-wider bg-blue-500/10 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full">
                  {zone1Pages.length} Pages
                </div>
              </div>

              {zone1Pages.length > 0 ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {zone1Pages.map((page) => (
                    <div
                      key={page.path}
                      className="group flex flex-col justify-between p-6 rounded-2xl bg-card border border-border hover:border-primary/40 shadow-card hover:shadow-elegant transition-all duration-300"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                            page.category === "core"
                              ? "bg-blue-500/10 text-blue-600 dark:text-blue-400"
                              : page.category === "services"
                              ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                              : "bg-green-500/10 text-green-600 dark:text-green-400"
                          }`}>
                            {page.category === "core" && "Core Page"}
                            {page.category === "services" && "Service Hub"}
                            {page.category === "forms" && "Form / Tool"}
                          </span>
                          
                          {page.badge && (
                            <span className="text-[10px] font-bold uppercase tracking-wider bg-primary/20 text-primary-glow px-2.5 py-1 rounded-full">
                              {page.badge}
                            </span>
                          )}
                        </div>

                        <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-1">
                          {page.title}
                        </h3>
                        
                        <code className="text-xs text-primary font-mono block mb-3 break-all">
                          {page.path}
                        </code>

                        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mb-6">
                          {page.description}
                        </p>
                      </div>

                      <Button asChild variant="electric" className="w-full group/btn">
                        <Link to={page.path as any}>
                          Open Page 
                          <ChevronRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                        </Link>
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">No Zone 1 pages match your search criteria.</p>
              )}
            </div>

            {/* ZONE 2 SECTION */}
            <div>
              <div className="flex items-center gap-3 mb-6 border-b border-border pb-4">
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                  <Boxes className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-2xl md:text-3xl font-display font-extrabold tracking-wide uppercase text-foreground">
                    Zone 2: Extra Pages, Design Variants & Sandboxes
                  </h2>
                  <p className="text-xs text-muted-foreground">
                    Custom cloned layouts, alternative design variants, blueprints, premium variants, nested routes, and experimental sandbox pages.
                  </p>
                </div>
                <div className="ml-auto text-xs font-bold uppercase tracking-wider bg-purple-500/10 text-purple-600 dark:text-purple-400 px-3 py-1 rounded-full">
                  {zone2Pages.length} Pages
                </div>
              </div>

              {zone2Pages.length > 0 ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {zone2Pages.map((page) => (
                    <div
                      key={page.path}
                      className="group flex flex-col justify-between p-6 rounded-2xl bg-card border border-border hover:border-primary/40 shadow-card hover:shadow-elegant transition-all duration-300"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                            page.category === "variants"
                              ? "bg-purple-500/10 text-purple-600 dark:text-purple-400"
                              : "bg-slate-500/10 text-slate-600 dark:text-slate-400"
                          }`}>
                            {page.category === "variants" ? "Design Variant" : "Dev Sample"}
                          </span>
                          
                          {page.badge && (
                            <span className="text-[10px] font-bold uppercase tracking-wider bg-primary/20 text-primary-glow px-2.5 py-1 rounded-full">
                              {page.badge}
                            </span>
                          )}
                        </div>

                        <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-1">
                          {page.title}
                        </h3>
                        
                        <code className="text-xs text-primary font-mono block mb-3 break-all">
                          {page.path}
                        </code>

                        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mb-6">
                          {page.description}
                        </p>
                      </div>

                      <Button asChild variant="electric" className="w-full group/btn">
                        <Link to={page.path as any}>
                          Open Page 
                          <ChevronRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                        </Link>
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">No Zone 2 pages match your search criteria.</p>
              )}
            </div>

            {/* Empty State */}
            {filteredPages.length === 0 && (
              <div className="text-center py-20 bg-card border border-border rounded-3xl">
                <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-bold text-foreground mb-2">No pages found</h3>
                <p className="text-muted-foreground max-w-md mx-auto">
                  We couldn't find any pages matching "{searchQuery}". Try searching for categories like "residential", "estimate", or "sample".
                </p>
              </div>
            )}

          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
