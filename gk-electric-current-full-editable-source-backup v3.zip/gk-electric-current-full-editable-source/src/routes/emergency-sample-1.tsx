import { createFileRoute, Link } from "@tanstack/react-router";
import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  CheckCircle2,
  ChevronRight,
  Clock,
  Flame,
  Headphones,
  MessageCircle,
  Phone,
  PlugZap,
  ShieldCheck,
  Siren,
  Sparkles,
  Zap,
} from "lucide-react";

export const Route = createFileRoute("/emergency-sample-1")({
  head: () => ({
    meta: [
      { title: "Emergency Service Section Samples — GK Electric" },
      {
        name: "description",
        content:
          "Twenty light-background emergency service section design samples for GK Electric's 24/7 Emergency Electrician in Surrey content.",
      },
    ],
  }),
  component: EmergencySamplePage,
});

const emergencyCards = [
  {
    icon: Siren,
    title: "24/7 Emergency Repairs",
    desc: "Fast help for urgent electrical failures, outage issues, sparks, burning smells, buzzing panels and unsafe wiring.",
  },
  {
    icon: Zap,
    title: "Power Outages",
    desc: "Troubleshooting for full or partial power loss in homes, offices, retail spaces and commercial buildings.",
  },
  {
    icon: Flame,
    title: "Burning Smell or Sparks",
    desc: "Immediate safety checks for overheated outlets, active arcing, melted devices and fire-risk warning signs.",
  },
  {
    icon: AlertTriangle,
    title: "Breaker & Panel Issues",
    desc: "Diagnosis for repeated breaker trips, buzzing panels, warm breakers and overloaded electrical systems.",
  },
  {
    icon: Sparkles,
    title: "Flickering or Dimming Lights",
    desc: "Emergency troubleshooting for flickering lights, loose neutrals, overloaded circuits and unstable power in Surrey homes and businesses.",
  },
  {
    icon: PlugZap,
    title: "Hot or Dead Outlets",
    desc: "Fast repair for dead outlets, warm switch plates, discoloured receptacles and unsafe electrical connections across the Lower Mainland.",
  },
];

const trustBullets = [
  "Upfront pricing before work begins",
  "Fully licensed and insured in British Columbia",
  "Residential, commercial & industrial electricians",
  "Emergency service available 24/7",
  "Quality workmanship backed by experience",
];

const actions = [
  { icon: Phone, label: "Call", text: "Speak with our team", href: "tel:+17783444567", external: false },
  { icon: BadgeCheck, label: "Free Estimate", text: "Get a custom quote", href: "/free-estimate", external: false },
  { icon: MessageCircle, label: "Whatsapp", text: "Chat with us now", href: "https://wa.me/17783444567", external: true },
];

const baseCopy = {
  kicker: "Emergency Service",
  title: "24/7 Emergency Electrician in Surrey",
  description:
    "Electrical problems can become safety hazards quickly. Our licensed electricians are ready day or night for urgent issues that need immediate attention across Surrey and the Lower Mainland.",
  phone: "+1 (778) 344-4567",
  estimateTitle: "Request a Free Estimate",
  estimateText:
    "Need electrical work in Surrey or the Lower Mainland? Call now or request a free estimate.",
};

const variants = [
  { name: "Split Hero Cards", style: "split" },
  { name: "Centered Premium Grid", style: "center" },
  { name: "Left Rail Timeline", style: "timeline" },
  { name: "Rounded Bento", style: "bento" },
  { name: "Diagonal Accent", style: "diagonal" },
  { name: "Soft Glass Cards", style: "glass" },
  { name: "Numbered Matrix", style: "numbers" },
  { name: "Compact CTA Banner", style: "banner" },
  { name: "Floating Checklist", style: "floating" },
  { name: "Editorial Layout", style: "editorial" },
  { name: "Service Command Center", style: "command" },
  { name: "Minimal Lines", style: "minimal" },
  { name: "Gold Header Block", style: "gold" },
  { name: "Layered Panels", style: "layers" },
  { name: "Icon Spotlight", style: "spotlight" },
  { name: "Map-Like Coverage", style: "map" },
  { name: "Urgency Strip", style: "urgency" },
  { name: "Quote Style", style: "quote" },
  { name: "Stacked Cards", style: "stacked" },
  { name: "Final Conversion", style: "conversion" },
] as const;

type Variant = (typeof variants)[number];

function EmergencySamplePage() {
  return (
    <main className="min-h-screen bg-[#f7f7f3] text-[#151923]">
      <section className="border-b border-black/10 bg-white px-4 py-14">
        <div className="mx-auto max-w-7xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-amber-100 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-amber-700">
            <Siren className="h-4 w-4" /> Emergency section samples
          </div>
          <h1 className="mt-5 max-w-5xl font-display text-5xl font-black uppercase leading-[0.95] tracking-tight md:text-7xl">
            20 Light Background Designs for the Home Emergency Service Section
          </h1>
          <p className="mt-5 max-w-3xl text-lg leading-relaxed text-slate-600">
            Same GK Electric emergency content, redesigned in twenty different white/light layouts. Original pages are not changed.
          </p>
        </div>
      </section>

      <div className="space-y-12 px-4 py-12">
        {variants.map((variant, index) => (
          <EmergencyVariant key={variant.name} variant={variant} index={index} />
        ))}
      </div>
    </main>
  );
}

function EmergencyVariant({ variant, index }: { variant: Variant; index: number }) {
  const wrapper = wrapperClass(variant.style);
  const header = headerClass(variant.style);
  const cardGrid = cardGridClass(variant.style);
  const card = cardClass(variant.style);

  return (
    <section className={`mx-auto max-w-7xl overflow-hidden border border-slate-200 ${wrapper}`}>
      <div className="mb-6 flex items-center justify-between gap-4 border-b border-slate-200/70 pb-4">
        <div className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">
          Sample {String(index + 1).padStart(2, "0")}
        </div>
        <div className="text-xs font-black uppercase tracking-[0.2em] text-amber-600">{variant.name}</div>
      </div>

      <div className={header}>
        <div>
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-amber-100 px-4 py-2 text-xs font-black uppercase tracking-[0.16em] text-amber-700">
            <Siren className="h-4 w-4" /> {baseCopy.kicker}
          </div>
          <h2 className="font-display text-4xl font-black uppercase leading-tight tracking-tight text-slate-950 md:text-6xl">
            {baseCopy.title}
          </h2>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-slate-600 md:text-lg">
            {baseCopy.description}
          </p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <a href="tel:+17783444567" className="inline-flex items-center justify-center gap-2 rounded-full bg-slate-950 px-6 py-3 text-sm font-black uppercase tracking-wider text-white transition hover:bg-amber-500 hover:text-slate-950">
              <Phone className="h-4 w-4" /> Call Now: {baseCopy.phone}
            </a>
            <Link to="/emergency-electrician-surrey" className="inline-flex items-center justify-center gap-2 rounded-full border border-slate-300 bg-white px-6 py-3 text-sm font-black uppercase tracking-wider text-slate-950 transition hover:border-amber-500 hover:text-amber-700">
              Learn More <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

        <EstimateBox styleName={variant.style} />
      </div>

      <div className={cardGrid}>
        {emergencyCards.map((item, cardIndex) => (
          <EmergencyCard key={item.title} item={item} index={cardIndex} className={card} styleName={variant.style} />
        ))}
      </div>
    </section>
  );
}

function EstimateBox({ styleName }: { styleName: string }) {
  const isDarkAccent = ["gold", "command", "conversion", "urgency"].includes(styleName);

  return (
    <aside className={`${isDarkAccent ? "bg-slate-950 text-white" : "bg-white text-slate-950"} rounded-[1.5rem] border border-slate-200 p-6 shadow-xl`}>
      <h3 className="font-display text-2xl font-black uppercase tracking-tight">{baseCopy.estimateTitle}</h3>
      <p className={`mt-3 text-sm leading-relaxed ${isDarkAccent ? "text-white/70" : "text-slate-600"}`}>{baseCopy.estimateText}</p>
      <ul className="mt-5 space-y-2">
        {trustBullets.map((bullet) => (
          <li key={bullet} className="flex gap-2 text-sm font-semibold leading-snug">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
            <span>{bullet}</span>
          </li>
        ))}
      </ul>
      <div className="mt-6 grid gap-3">
        {actions.map((action) => {
          const Icon = action.icon;
          const content = (
            <>
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
                <Icon className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-sm font-black uppercase tracking-wider">{action.label}</span>
                <span className={`block text-xs ${isDarkAccent ? "text-white/55" : "text-slate-500"}`}>{action.text}</span>
              </span>
            </>
          );

          return action.external ? (
            <a key={action.label} href={action.href} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-2xl border border-slate-200/60 bg-white/80 p-3 text-slate-950 transition hover:-translate-y-1 hover:border-amber-400">
              {content}
            </a>
          ) : action.href.startsWith("tel:") ? (
            <a key={action.label} href={action.href} className="flex items-center gap-3 rounded-2xl border border-slate-200/60 bg-white/80 p-3 text-slate-950 transition hover:-translate-y-1 hover:border-amber-400">
              {content}
            </a>
          ) : (
            <Link key={action.label} to="/free-estimate" className="flex items-center gap-3 rounded-2xl border border-slate-200/60 bg-white/80 p-3 text-slate-950 transition hover:-translate-y-1 hover:border-amber-400">
              {content}
            </Link>
          );
        })}
      </div>
    </aside>
  );
}

function EmergencyCard({ item, index, className, styleName }: { item: (typeof emergencyCards)[number]; index: number; className: string; styleName: string }) {
  const Icon = item.icon;
  return (
    <Link to="/emergency-electrician-surrey" className={className}>
      <div className="mb-5 flex items-center justify-between gap-4">
        <span className={`${styleName === "minimal" ? "rounded-none" : "rounded-2xl"} flex h-12 w-12 items-center justify-center bg-amber-100 text-amber-700 ring-1 ring-amber-200`}>
          <Icon className="h-6 w-6" />
        </span>
        <span className="font-display text-3xl font-black text-slate-200">{String(index + 1).padStart(2, "0")}</span>
      </div>
      <h3 className="font-display text-2xl font-black uppercase leading-tight tracking-tight text-slate-950">{item.title}</h3>
      <p className="mt-3 text-sm leading-relaxed text-slate-600">{item.desc}</p>
      <div className="mt-5 inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-amber-700">
        Emergency Info <ChevronRight className="h-4 w-4" />
      </div>
    </Link>
  );
}

function wrapperClass(style: string) {
  const map: Record<string, string> = {
    split: "rounded-[2rem] bg-[#fbfbf7] p-6 shadow-sm md:p-8",
    center: "rounded-[2.5rem] bg-white p-6 text-center shadow-xl md:p-10",
    timeline: "rounded-none bg-[#f8fafc] p-6 shadow-sm md:p-8",
    bento: "rounded-[2rem] bg-[#fffaf0] p-6 shadow-xl md:p-8",
    diagonal: "rounded-[2rem] bg-gradient-to-br from-white via-amber-50 to-slate-100 p-6 shadow-xl md:p-8",
    glass: "rounded-[2rem] bg-white/75 p-6 shadow-2xl backdrop-blur-xl md:p-8",
    numbers: "rounded-[1rem] bg-white p-6 shadow-sm md:p-8",
    banner: "rounded-[2.5rem] bg-[#f4f1e8] p-6 shadow-lg md:p-8",
    floating: "rounded-[2rem] bg-gradient-to-b from-white to-slate-50 p-6 shadow-2xl md:p-8",
    editorial: "rounded-none bg-white p-6 shadow-sm md:p-10",
    command: "rounded-[2rem] bg-slate-100 p-6 shadow-2xl md:p-8",
    minimal: "rounded-none bg-[#fcfcfa] p-6 md:p-8",
    gold: "rounded-[2rem] bg-amber-50 p-6 shadow-xl md:p-8",
    layers: "rounded-[2rem] bg-white p-6 shadow-2xl md:p-8",
    spotlight: "rounded-[3rem] bg-[#f8f7f1] p-6 shadow-xl md:p-8",
    map: "rounded-[2rem] bg-slate-50 p-6 shadow-lg md:p-8",
    urgency: "rounded-[2rem] bg-white p-6 shadow-2xl ring-4 ring-red-50 md:p-8",
    quote: "rounded-[2rem] bg-[#fffdf7] p-6 shadow-xl md:p-10",
    stacked: "rounded-[2rem] bg-white p-6 shadow-2xl md:p-8",
    conversion: "rounded-[2rem] bg-gradient-to-br from-slate-950 to-slate-800 p-6 shadow-2xl md:p-8",
  };
  return map[style] ?? map.split;
}

function headerClass(style: string) {
  const map: Record<string, string> = {
    split: "grid gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-start",
    center: "mx-auto grid max-w-5xl gap-8 lg:grid-cols-1",
    timeline: "grid gap-8 border-l-4 border-amber-400 pl-6 lg:grid-cols-[1fr_0.8fr]",
    bento: "grid gap-5 lg:grid-cols-[1.2fr_0.8fr]",
    diagonal: "grid gap-8 lg:grid-cols-[1fr_0.9fr] lg:items-center",
    glass: "grid gap-8 lg:grid-cols-[0.95fr_1.05fr]",
    numbers: "grid gap-8 lg:grid-cols-[1fr_0.75fr]",
    banner: "grid gap-8 lg:grid-cols-[1.25fr_0.75fr]",
    floating: "grid gap-8 lg:grid-cols-[0.9fr_1.1fr]",
    editorial: "grid gap-10 lg:grid-cols-[1.35fr_0.65fr]",
    command: "grid gap-8 lg:grid-cols-[0.85fr_1.15fr]",
    minimal: "grid gap-8 lg:grid-cols-[1fr_1fr]",
    gold: "grid gap-8 rounded-[2rem] bg-amber-400 p-6 lg:grid-cols-[1fr_0.85fr]",
    layers: "grid gap-8 lg:grid-cols-[1.1fr_0.9fr]",
    spotlight: "grid gap-8 lg:grid-cols-[0.9fr_1.1fr]",
    map: "grid gap-8 lg:grid-cols-[1fr_0.9fr]",
    urgency: "grid gap-8 border-t-8 border-red-500 pt-6 lg:grid-cols-[1fr_0.9fr]",
    quote: "grid gap-8 lg:grid-cols-[1.15fr_0.85fr]",
    stacked: "grid gap-8 lg:grid-cols-[1fr_1fr]",
    conversion: "grid gap-8 text-white lg:grid-cols-[1fr_0.9fr]",
  };
  return map[style] ?? map.split;
}

function cardGridClass(style: string) {
  const map: Record<string, string> = {
    split: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
    center: "mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
    timeline: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
    bento: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3 [&>*:first-child]:md:col-span-2",
    diagonal: "mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
    glass: "mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
    numbers: "mt-8 grid gap-px overflow-hidden rounded-2xl border border-slate-200 bg-slate-200 md:grid-cols-2 lg:grid-cols-3",
    banner: "mt-8 grid gap-4 md:grid-cols-3",
    floating: "mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
    editorial: "mt-10 grid gap-0 divide-y divide-slate-200 border-y border-slate-200 md:grid-cols-2 md:divide-x md:divide-y-0 lg:grid-cols-3",
    command: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
    minimal: "mt-8 grid gap-0 border-y border-slate-200 md:grid-cols-2 lg:grid-cols-3",
    gold: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
    layers: "mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
    spotlight: "mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
    map: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
    urgency: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
    quote: "mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
    stacked: "mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
    conversion: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
  };
  return map[style] ?? map.split;
}

function cardClass(style: string) {
  const map: Record<string, string> = {
    split: "group rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl",
    center: "group rounded-[2rem] border border-slate-200 bg-slate-50 p-6 text-left transition hover:-translate-y-2 hover:bg-white hover:shadow-xl",
    timeline: "group rounded-xl border-l-4 border-amber-400 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg",
    bento: "group rounded-[2rem] border border-amber-100 bg-white p-6 shadow-md transition hover:-translate-y-2 hover:shadow-xl",
    diagonal: "group rounded-[1.5rem] border border-white bg-white/80 p-6 shadow-lg transition hover:-translate-y-2 hover:rotate-1",
    glass: "group rounded-[2rem] border border-white bg-white/60 p-6 shadow-xl backdrop-blur transition hover:-translate-y-2",
    numbers: "group bg-white p-6 transition hover:bg-amber-50",
    banner: "group rounded-[1.25rem] border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:border-amber-300",
    floating: "group rounded-[2rem] border border-slate-200 bg-white p-6 shadow-xl transition hover:-translate-y-3",
    editorial: "group bg-white p-6 transition hover:bg-slate-50",
    command: "group rounded-[1.25rem] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:bg-slate-950 hover:[&_*]:text-white",
    minimal: "group border-b border-slate-200 bg-transparent p-6 transition hover:bg-white",
    gold: "group rounded-[1.5rem] border border-amber-200 bg-white p-6 shadow-sm transition hover:-translate-y-2 hover:shadow-xl",
    layers: "group rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-[8px_8px_0_rgba(245,158,11,.18)] transition hover:-translate-y-2 hover:shadow-[14px_14px_0_rgba(245,158,11,.22)]",
    spotlight: "group rounded-[2rem] border border-slate-200 bg-white p-6 shadow-lg transition hover:-translate-y-2 hover:shadow-2xl",
    map: "group rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-amber-400",
    urgency: "group rounded-[1.25rem] border border-red-100 bg-white p-6 shadow-sm transition hover:-translate-y-2 hover:border-red-300",
    quote: "group rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-2 hover:shadow-xl",
    stacked: "group rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-lg transition hover:-translate-y-2 hover:translate-x-1",
    conversion: "group rounded-[1.5rem] border border-white/10 bg-white p-6 shadow-lg transition hover:-translate-y-2 hover:shadow-amber-500/20",
  };
  return map[style] ?? map.split;
}
