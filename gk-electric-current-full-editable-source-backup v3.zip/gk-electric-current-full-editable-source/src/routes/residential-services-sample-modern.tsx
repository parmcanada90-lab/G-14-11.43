import { createFileRoute } from "@tanstack/react-router";
import { ResidentialSampleVariant, residentialSampleMeta } from "@/components/ResidentialSampleVariant";

export const Route = createFileRoute("/residential-services-sample-modern")({
  head: () => ({
    meta: [
      { title: `${residentialSampleMeta.title} — Modern Service Layout | GK Electric` },
      { name: "description", content: residentialSampleMeta.description },
      { property: "og:title", content: `${residentialSampleMeta.title} | GK Electric` },
      { property: "og:description", content: residentialSampleMeta.description },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResidentialServicesSampleModernPage,
});

function ResidentialServicesSampleModernPage() {
  return <ResidentialSampleVariant variant="modern" />;
}
