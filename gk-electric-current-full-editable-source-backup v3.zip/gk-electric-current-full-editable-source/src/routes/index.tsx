import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { DecorBoltOutlet, DecorPanelCrew } from "@/components/decor/LineArt";
import { Phone, Zap, ShieldCheck, Clock, Award, ArrowRight, Building2, Factory, Home, Plug, PlugZap, Lightbulb, Wrench, Gauge, Cpu, Headphones, FileCheck, FileText, FilePenLine, FolderKanban, Star, Users, MessageCircle, ClipboardCheck, CalendarCheck, BadgeCheck, ScrollText, CheckCircle2, AlertTriangle, Flame, MapPin, Siren, Sparkles, ChevronRight } from "lucide-react";
import { HeroSlideshow } from "@/components/HeroSlideshow";



import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FeaturedProjects } from "@/components/FeaturedProjects";
import { Testimonials } from "@/components/Testimonials";
import { ReviewsShowcase } from "@/components/ReviewsShowcase";
import { SectionKicker } from "@/components/SectionKicker";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-electrician.jpg";
import residentialImage from "@/assets/residential.jpg";
import commercialImage from "@/assets/commercial.jpg";
import industrialImage from "@/assets/industrial.jpg";
import evImage from "@/assets/ev-charger.jpg";
import ourStory from "@/assets/our-story.jpg";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";
import gkLogo from "@/assets/gk-logo.jpeg";
import serviceResidential from "@/assets/service-residential.png";
import serviceCommercial from "@/assets/service-commercial.png";
import serviceIndustrial from "@/assets/service-industrial.png";
import serviceEV from "@/assets/service-ev.png";
import { serviceAreas } from "@/data/serviceAreas";
import { servicePageDetails } from "@/data/servicePageDetails";

const serviceTiles = [
  { src: serviceResidential, label: "Residential", to: "/services/residential" },
  { src: serviceCommercial, label: "Commercial", to: "/services/commercial" },
  { src: serviceIndustrial, label: "Industrial", to: "/services/industrial" },
  { src: serviceEV, label: "EV Charging", to: "/ev-charger" },
] as const;

// Service image cards are currently hidden.
// Change this to true when you want to show the section again.
const SHOW_SERVICE_TILES = false;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GK Electric — Residential, Commercial & Industrial Electrician" },
      { name: "description", content: "Licensed electrician for residential, commercial and industrial work. Electrical installation, EV charger installation, permits & code compliance. Fast, reliable service." },
      { property: "og:title", content: "GK Electric — Licensed Electricians for Every Project" },
      { property: "og:description", content: "Residential, commercial & industrial electrical service. EV charger installation, permits, inspections. Get a free estimate today." },
      { property: "og:image", content: heroImage },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: heroImage },
    ],
  }),
  component: HomePage,
});

const services = [
  {
    icon: Home,
    title: "Residential",
    desc: "Full home electrical for safer, brighter, more efficient living spaces.",
    img: residentialImage,
    to: "/services/residential" as const,
    tag: "Residential Electrical Services",
    hash: "residential",
    features: [
      { icon: Lightbulb, label: "Lighting & wiring" },
      { icon: Wrench, label: "Repairs & upgrades" },
      { icon: Plug, label: "Outlets & switches" },
    ],
  },
  {
    icon: Building2,
    title: "Commercial",
    desc: "Reliable power for offices, retail and commercial buildings.",
    img: commercialImage,
    to: "/services/commercial" as const,
    tag: "Commercial Electrical Services",
    hash: "commercial",
    features: [
      { icon: Gauge, label: "Panel installation" },
      { icon: Lightbulb, label: "LED retrofits" },
      { icon: Wrench, label: "Maintenance" },
    ],
  },
  {
    icon: Factory,
    title: "Industrial",
    desc: "Heavy electrical for factories, warehouses and industrial facilities.",
    img: industrialImage,
    to: "/services/industrial" as const,
    tag: "Industrial Electrical Services",
    hash: "industrial",
    features: [
      { icon: Cpu, label: "Machinery wiring" },
      { icon: Gauge, label: "Load management" },
      { icon: Zap, label: "Three-phase power" },
    ],
  },
];

const features = [
  { icon: ShieldCheck, title: "Licensed & Insured", desc: "Fully licensed electricians with full insurance coverage." },
  { icon: FileCheck, title: "Electric Operating Permits", desc: "We obtain all required operating permits so your work is fully authorized." },
  { icon: Award, title: "Code-Compliant", desc: "Every job meets and exceeds electrical safety codes." },
  { icon: Zap, title: "All Project Sizes", desc: "From a single outlet to full industrial installations." },
  { icon: Headphones, title: "24/7 Emergency", desc: "Round-the-clock support for critical electrical issues." },
  { icon: FileText, title: "Electric Planning Reports", desc: "Detailed electrical planning reports for projects of any scale." },
];

const heroTrustItems = [
  {
    icon: ShieldCheck,
    label: "Licensed & Insured",
    detail: "Qualified electrical work backed by proper licensing and coverage.",
    to: "/services" as const,
    actionLabel: "OUR SERVICES",
  },
  {
    icon: Clock,
    label: "18+ Years Experience",
    detail: "Trusted residential, commercial and industrial service across BC.",
    to: "/about" as const,
    actionLabel: "ABOUT GK ELECTRIC",
  },
  {
    icon: FileCheck,
    label: "Permits & Compliance",
    detail: "100% Electrical Permits, Inspections & Codes Covered",
    to: "/permits-regulatory-compliance" as const,
    actionLabel: "PERMITS & REGULATORY COMPLIANCE",
  },
  {
    icon: Headphones,
    label: "24/7 Emergency Support",
    detail: "Responsive help when critical electrical issues cannot wait.",
    to: "/emergency-electrician-surrey" as const,
    actionLabel: "EMERGENCY ELECTRICIAN",
  },
];

const emergencyServiceItems = [
  {
    icon: Siren,
    title: "24/7 Emergency Repairs",
    desc: "Fast help for urgent electrical failures, outage issues, sparks, burning smells, buzzing panels and unsafe wiring.",
  },
  {
    icon: Zap,
    title: "Power Outages",
    desc: "Troubleshooting for full or partial power loss in homes, offices, retail spaces and commercial buildings.",
  },
  {
    icon: Flame,
    title: "Burning Smell or Sparks",
    desc: "Immediate safety checks for overheated outlets, active arcing, melted devices and fire-risk warning signs.",
  },
  {
    icon: AlertTriangle,
    title: "Breaker & Panel Issues",
    desc: "Diagnosis for repeated breaker trips, buzzing panels, warm breakers and overloaded electrical systems.",
  },
  {
    icon: Lightbulb,
    title: "Flickering or Dimming Lights",
    desc: "Emergency troubleshooting for flickering lights, loose neutrals, overloaded circuits and unstable power in Surrey homes and businesses.",
  },
  {
    icon: Plug,
    title: "Hot or Dead Outlets",
    desc: "Fast repair for dead outlets, warm switch plates, discoloured receptacles and unsafe electrical connections across the Lower Mainland.",
  },
];

const featuredCoverageAreas = serviceAreas.filter((area) => area.featured || area.slug === "surrey").slice(0, 8);

const sampleContactActions = [
  { label: "Contact US", sub: "Call our team", href: "tel:+17783444567", icon: Phone, external: true },
  { label: "Request a Quote", sub: "Get project pricing", href: "/free-estimate", icon: BadgeCheck, external: false },
  { label: "WhatsApp US", sub: "Chat with us now", href: "https://wa.me/17783444567", icon: MessageCircle, external: true },
];

const sampleTrust = ["Free Quotes", "Clear Pricing", "Licensed & Insured", "Permit-Ready Work"];

function HomeDesign05ServiceButton({ label, to, icon: Icon }: { label: string; to: string; icon: typeof Home }) {
  return (
    <Link
      to={to as never}
      className="group flex min-h-[92px] items-center justify-between rounded-2xl border border-white/15 bg-white/[0.06] p-5 text-base font-black uppercase tracking-[0.12em] text-white transition-all duration-300 hover:-translate-y-1 hover:border-amber-400 hover:bg-amber-400 hover:text-slate-950 md:min-h-[112px] md:p-6"
    >
      <span className="flex items-center gap-3">
        <Icon className="h-6 w-6 text-amber-500 transition group-hover:text-current" />
        {label}
      </span>
      <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
    </Link>
  );
}

function HomeDesign05ActionLink({ action }: { action: (typeof sampleContactActions)[number] }) {
  const Icon = action.icon;
  const classes = "group flex items-center gap-4 rounded-2xl border border-white/15 bg-white/[0.07] p-4 text-white transition-all duration-300 hover:-translate-y-1 hover:border-amber-400 hover:bg-white/[0.12]";
  const content = (
    <>
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-slate-950 shadow-[0_0_24px_rgba(245,181,38,0.28)]">
        <Icon className="h-5 w-5" />
      </span>
      <span>
        <span className="block text-sm font-black uppercase tracking-[0.12em]">{action.label}</span>
        <span className="mt-1 block text-sm text-white/60">{action.sub}</span>
      </span>
    </>
  );

  if (action.external) {
    return (
      <a href={action.href} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noreferrer" : undefined} className={classes}>
        {content}
      </a>
    );
  }

  return (
    <Link to={action.href as never} className={classes}>
      {content}
    </Link>
  );
}

function HomeSampleContactDesign05() {
  return (
    <section data-scroll-tone="dark" className="bg-background px-4 py-16 md:py-20">
      <div className="mx-auto max-w-[1500px]">
        <section className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-br from-black via-[#17120a] to-black p-5 text-white shadow-[0_24px_80px_rgba(15,23,42,0.12)] md:p-7 lg:p-8">
          <div className="pointer-events-none absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "linear-gradient(90deg,currentColor 1px,transparent 1px),linear-gradient(currentColor 1px,transparent 1px)", backgroundSize: "32px 32px" }} />
          <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-amber-400/20 blur-3xl" />
          <div className="relative grid grid-cols-12 gap-5">
            <div className="col-span-12 lg:col-span-6">
              <div className="mb-5 flex items-center justify-between gap-4">
                <div className="inline-flex items-center gap-3 rounded-full bg-amber-400 px-4 py-2 text-xs font-black uppercase tracking-[0.16em] text-slate-950">
                  <Sparkles className="h-4 w-4" /> Service Help
                </div>
                <img src={gkLogo} alt="GK Electric logo" className="h-10 w-10 rounded-full object-contain" />
              </div>
              <h2 className="font-display text-3xl font-black uppercase leading-[0.95] tracking-tight md:text-5xl">
                Connect With GK Electric
              </h2>
              <p className="mt-4 text-base font-semibold leading-relaxed text-white/75 md:text-lg">
                Clear support for electrical quotes, service calls, and urgent project needs
              </p>
              <p className="mt-4 max-w-2xl text-sm leading-relaxed text-white/62">
                Tell us what you need and our team will guide you toward the right next step.
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {sampleTrust.map((item) => (
                  <span key={item} className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-3 py-2 text-[11px] font-black uppercase tracking-[0.1em] text-white/75">
                    <CheckCircle2 className="h-3.5 w-3.5 text-amber-500" />
                    {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="col-span-12 lg:col-span-6">
              <div className="h-full rounded-[1.5rem] border border-white/12 bg-black/20 p-4 backdrop-blur-md">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-black uppercase tracking-[0.18em] text-amber-500">Checkout our services</div>
                    <p className="mt-2 text-sm text-white/60">Select the service that matches your project.</p>
                  </div>
                  <Zap className="h-8 w-8 text-amber-500" />
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {[
                    { label: "Residential", to: "/services/residential" as const, icon: Home },
                    { label: "Commercial", to: "/services/commercial" as const, icon: Building2 },
                    { label: "Industrial", to: "/services/industrial" as const, icon: Factory },
                    { label: "EV Charger", to: "/ev-charger" as const, icon: PlugZap },
                  ].map((service) => (
                    <HomeDesign05ServiceButton key={service.label} {...service} />
                  ))}
                </div>
              </div>
            </div>

            <div className="col-span-12">
              <div className="grid gap-4 rounded-[1.5rem] border border-white/12 bg-white/[0.055] p-4 md:grid-cols-[1.05fr_1.45fr]">
                <div>
                  <h3 className="font-display text-2xl font-black uppercase tracking-tight">Ready to start your electrical project?</h3>
                  <p className="mt-3 text-sm leading-relaxed text-white/62">
                    Talk with our team for free quotes, clear project pricing, emergency support, and permit-backed electrical work done safely and professionally.
                  </p>
                </div>
                <div className="grid gap-3 md:grid-cols-3">
                  {sampleContactActions.map((action) => (
                    <HomeDesign05ActionLink key={action.label} action={action} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  );
}

function HomeSampleContactDesign11() {
  return (
    <div className="mt-6">
      <div className="mx-auto max-w-[1500px]">
        <section className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-surface p-5 text-surface-foreground md:p-7 lg:p-8">
          <div className="relative grid grid-cols-12 gap-5">
            <div className="col-span-12 lg:col-span-7">
              <h2 className="font-display text-3xl font-black uppercase leading-[0.95] tracking-tight md:text-5xl">
                Licensed Electricians in Surrey & Lower Mainland
              </h2>
              <p className="mt-4 text-base font-semibold leading-relaxed text-white/75 md:text-lg">
                Residential, Commercial, Industrial & EV Charger Electrical Services
              </p>
              <p className="mt-4 max-w-2xl text-sm leading-relaxed text-white/62">
                Choose the electrical service you need or contact GK Electric for a clear quote, emergency support, and code-compliant work across Surrey, BC.
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {sampleTrust.map((item) => (
                  <span key={item} className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-3 py-2 text-[11px] font-black uppercase tracking-[0.1em] text-white/75">
                    <CheckCircle2 className="h-3.5 w-3.5 text-amber-500" />
                    {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="col-span-12 lg:col-span-5">
              <div className="flex h-full min-h-[360px] flex-col rounded-[1.5rem] border border-white/12 bg-black/20 p-5 backdrop-blur-md md:p-6">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-black uppercase tracking-[0.18em] text-amber-500">Checkout our services</div>
                    <p className="mt-2 text-sm text-white/60">Select the service that matches your project.</p>
                  </div>
                  <Zap className="h-8 w-8 text-amber-500" />
                </div>
                <div className="grid flex-1 gap-4 sm:grid-cols-2">
                  {[
                    { label: "Residential", to: "/services/residential" as const, icon: Home },
                    { label: "Commercial", to: "/services/commercial" as const, icon: Building2 },
                    { label: "Industrial", to: "/services/industrial" as const, icon: Factory },
                    { label: "EV Charger", to: "/ev-charger" as const, icon: PlugZap },
                  ].map((service) => (
                    <HomeDesign05ServiceButton key={service.label} {...service} />
                  ))}
                </div>
              </div>
            </div>

            <div className="col-span-12">
              <div className="grid gap-4 rounded-[1.5rem] border border-white/12 bg-white/[0.055] p-4 md:grid-cols-[1.05fr_1.45fr]">
                <div>
                  <h3 className="font-display text-2xl font-black uppercase tracking-tight">Ready to start your electrical project?</h3>
                  <p className="mt-3 text-sm leading-relaxed text-white/62">
                    Talk with our team for free quotes, clear project pricing, emergency support, and permit-backed electrical work done safely and professionally.
                  </p>
                </div>
                <div className="grid gap-3 md:grid-cols-3">
                  {sampleContactActions.map((action) => (
                    <HomeDesign05ActionLink key={action.label} action={action} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

const sample07EmergencyCards = [
  {
    icon: Siren,
    title: "24/7 Emergency Repairs",
    desc: "Fast help for urgent electrical failures, outage issues, sparks, burning smells, buzzing panels and unsafe wiring.",
  },
  {
    icon: Zap,
    title: "Power Outages",
    desc: "Troubleshooting for full or partial power loss in homes, offices, retail spaces and commercial buildings.",
  },
  {
    icon: Flame,
    title: "Burning Smell or Sparks",
    desc: "Immediate safety checks for overheated outlets, active arcing, melted devices and fire-risk warning signs.",
  },
  {
    icon: AlertTriangle,
    title: "Breaker & Panel Issues",
    desc: "Diagnosis for repeated breaker trips, buzzing panels, warm breakers and overloaded electrical systems.",
  },
  {
    icon: Sparkles,
    title: "Flickering or Dimming Lights",
    desc: "Emergency troubleshooting for flickering lights, loose neutrals, overloaded circuits and unstable power in Surrey homes and businesses.",
  },
  {
    icon: PlugZap,
    title: "Hot or Dead Outlets",
    desc: "Fast repair for dead outlets, warm switch plates, discoloured receptacles and unsafe electrical connections across the Lower Mainland.",
  },
];

function EmergencySample07Section() {
  return (
    <section data-scroll-tone="light" className="bg-[#f7f7f3] px-4 py-16 text-[#151923] md:py-24">
      <div className="mx-auto w-full max-w-[1500px] overflow-hidden rounded-[1.75rem] border border-slate-200 bg-white p-6 shadow-sm md:p-8 lg:p-10">
        <div className="grid gap-8 lg:grid-cols-[1fr_0.75fr]">
          <div>
            <div className="group mb-6 inline-flex items-center gap-4 text-xs font-black uppercase tracking-[0.22em] text-amber-700">
              <span className="h-10 w-1 rounded-full bg-amber-500 shadow-[0_0_24px_rgba(245,181,38,0.65)]" aria-hidden="true" />
              <span className="relative flex h-11 w-11 scale-110 items-center justify-center rounded-2xl bg-amber-500 text-slate-950 shadow-[0_0_30px_rgba(245,181,38,0.35)] ring-1 ring-amber-300 transition-all duration-300">
                <span className="absolute inset-0 animate-ping rounded-2xl bg-amber-400/25 opacity-100" aria-hidden="true" />
                <Siren className="relative h-5 w-5 scale-125 animate-pulse" />
              </span>
              Emergency Service
            </div>
            <h2 className="font-display text-4xl font-black uppercase leading-tight tracking-tight text-slate-950 md:text-6xl">
              24/7 Emergency Electrician in Surrey
            </h2>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-slate-600 md:text-lg">
              Electrical problems can become safety hazards quickly. Our licensed electricians are ready day or night for urgent issues that need immediate attention across Surrey and the Lower Mainland.
            </p>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <a href="tel:+17783444567" className="inline-flex items-center justify-center gap-2 rounded-full bg-slate-950 px-6 py-3 text-sm font-medium uppercase tracking-wider text-white transition hover:bg-amber-500 hover:text-slate-950">
                <Phone className="h-4 w-4" /> Call Now: +1 (778) 344-4567
              </a>
              <Link to="/emergency-electrician-surrey" className="inline-flex items-center justify-center gap-2 rounded-full border border-slate-300 bg-white px-6 py-3 text-sm font-medium uppercase tracking-wider text-slate-950 transition hover:border-amber-500 hover:text-amber-700">
                Learn More <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>

          <aside className="bg-white text-slate-950 rounded-[1.5rem] border border-slate-200 p-6 shadow-xl">
            <h3 className="font-display text-2xl font-black uppercase tracking-tight">Request a Free Estimate</h3>
            <p className="mt-3 text-sm leading-relaxed text-slate-600">Need electrical work in Surrey or the Lower Mainland? Call now or request a free estimate.</p>
            <ul className="mt-5 space-y-2">
              {[
                "Upfront pricing before work begins",
                "Fully licensed and insured in British Columbia",
                "Residential, commercial & industrial electricians",
                "Emergency service available 24/7",
                "Quality workmanship backed by experience",
              ].map((bullet) => (
                <li key={bullet} className="grid grid-cols-[24px_1fr] items-start gap-3 text-[17px] font-normal leading-snug">
                  <CheckCircle2 className="mt-[1px] h-6 w-6 shrink-0 text-amber-500" />
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>
            <div className="mt-6 grid gap-3">
              {[
                { icon: Phone, label: "Call", text: "Speak with our team", href: "tel:+17783444567", external: false },
                { icon: BadgeCheck, label: "Free Estimate", text: "Get a custom quote", href: "/free-estimate", external: false },
                { icon: MessageCircle, label: "Whatsapp US", text: "Chat with us now", href: "https://wa.me/17783444567", external: true },
              ].map((action) => {
                const Icon = action.icon;
                const content = (
                  <>
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
                      <Icon className="h-5 w-5" />
                    </span>
                    <span>
                      <span className="block text-[16px] font-medium uppercase leading-tight tracking-normal">{action.label}</span>
                      <span className="block text-xs text-slate-500">{action.text}</span>
                    </span>
                  </>
                );

                return action.external ? (
                  <a key={action.label} href={action.href} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-2xl border border-slate-200/60 bg-white/80 p-3 text-slate-950 transition hover:-translate-y-1 hover:border-amber-400">
                    {content}
                  </a>
                ) : action.href.startsWith("tel:") ? (
                  <a key={action.label} href={action.href} className="flex items-center gap-3 rounded-2xl border border-slate-200/60 bg-white/80 p-3 text-slate-950 transition hover:-translate-y-1 hover:border-amber-400">
                    {content}
                  </a>
                ) : (
                  <Link key={action.label} to="/free-estimate" className="flex items-center gap-3 rounded-2xl border border-slate-200/60 bg-white/80 p-3 text-slate-950 transition hover:-translate-y-1 hover:border-amber-400">
                    {content}
                  </Link>
                );
              })}
            </div>
          </aside>
        </div>

        <div className="mt-8 grid gap-px overflow-hidden rounded-2xl border border-slate-200 bg-slate-200 md:grid-cols-2 lg:grid-cols-3">
          {sample07EmergencyCards.map((item, index) => {
            const Icon = item.icon;
            return (
              <Link key={item.title} to="/emergency-electrician-surrey" className="group bg-white p-6 transition hover:bg-amber-50">
                <div className="mb-5 flex items-center justify-between gap-4">
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 text-amber-700 ring-1 ring-amber-200">
                    <Icon className="h-6 w-6" />
                  </span>
                  <span className="font-display text-3xl font-black text-slate-200">{String(index + 1).padStart(2, "0")}</span>
                </div>
                <h3 className="font-display text-2xl font-black uppercase leading-tight tracking-tight text-slate-950">{item.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-slate-600">{item.desc}</p>
                <div className="mt-5 inline-flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-amber-700">
                  Emergency Info <ChevronRight className="h-4 w-4" />
                </div>
              </Link>
            );
          })}
        </div>

        <div className="mt-8 rounded-[1.75rem] border border-white/12 bg-surface p-5 text-surface-foreground shadow-[0_20px_70px_rgba(0,0,0,0.28)] backdrop-blur-md md:p-6">
          <div className="grid gap-5 md:grid-cols-[1.25fr_1fr_1fr_1fr] md:divide-x md:divide-white/10">
            <div className="flex items-center">
              <p className="font-display text-2xl font-extrabold uppercase tracking-[0.06em] text-white">
                Need emergency electrical help right now?
              </p>
            </div>
            {[
              { icon: Phone, label: "Call Now", text: "Speak with our team", href: "tel:+17783444567" },
              { icon: FilePenLine, label: "Request a Quote", text: "Get a custom quote", href: "/contact" },
              { icon: MessageCircle, label: "WhatsApp US", text: "Chat with us now", href: "https://wa.me/17783444567" },
            ].map((action) => {
              const Icon = action.icon;
              const external = action.href.startsWith("http");
              const isWhatsApp = action.label.includes("WhatsApp");
              const content = (
                <>
                  <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border transition-all duration-300 group-hover:scale-110 ${isWhatsApp ? "border-green-400/35 bg-green-500/15 text-green-300 group-hover:bg-green-500 group-hover:text-white group-hover:border-green-400" : "border-primary/45 bg-primary/15 text-primary group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary"}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[16px] font-medium uppercase leading-tight tracking-normal text-white transition-colors group-hover:text-primary">{action.label}</div>
                    <div className="mt-1 text-sm text-surface-foreground/55 transition-colors group-hover:text-surface-foreground/80">{action.text}</div>
                  </div>
                </>
              );

              return external ? (
                <a key={action.label} href={action.href} target="_blank" rel="noreferrer" className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-green-400/40 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                  {content}
                </a>
              ) : action.href.startsWith("tel:") ? (
                <a key={action.label} href={action.href} className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                  {content}
                </a>
              ) : (
                <Link key={action.label} to="/contact" className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                  {content}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

const stickyServiceSlides = [
  {
    icon: servicePageDetails.residential.icon,
    title: servicePageDetails.residential.title,
    desc: servicePageDetails.residential.description,
    img: servicePageDetails.residential.image,
    to: "/residential-electrical-services-details" as const,
    detailServices: [
      ...servicePageDetails.residential.services,
      { icon: Home, title: "Renovation Electrical" },
      { icon: BadgeCheck, title: "Permit-Ready Home Work" },
    ],
  },
  {
    icon: servicePageDetails.commercial.icon,
    title: servicePageDetails.commercial.title,
    desc: servicePageDetails.commercial.description,
    img: servicePageDetails.commercial.image,
    to: "/commercial-electrical-services-details" as const,
    detailServices: [
      ...servicePageDetails.commercial.services,
      { icon: Building2, title: "Office & Retail Build-Outs" },
      { icon: Zap, title: "Emergency Commercial Repairs" },
    ],
  },
  {
    icon: servicePageDetails.industrial.icon,
    title: servicePageDetails.industrial.title,
    desc: servicePageDetails.industrial.description,
    img: servicePageDetails.industrial.image,
    to: "/industrial-electrical-services-details" as const,
    detailServices: [
      ...servicePageDetails.industrial.services,
      { icon: Wrench, title: "Equipment Troubleshooting" },
      { icon: ShieldCheck, title: "Code-Ready Upgrades" },
    ],
  },
  {
    icon: Plug,
    title: "EV Charger Installation",
    desc: "Level 2 EV charger installation for homes, strata properties, commercial parking and business fleets with panel checks, dedicated circuits and safe code-compliant setup.",
    img: evImage,
    to: "/ev-charger" as const,
    detailServices: [
      { icon: Plug, title: "Level 2 Home Chargers" },
      { icon: Gauge, title: "Panel Capacity Checks" },
      { icon: Zap, title: "Dedicated 240V Circuits" },
      { icon: Building2, title: "Commercial EV Charging" },
      { icon: ShieldCheck, title: "Load Management" },
      { icon: BadgeCheck, title: "Permit & Inspection Support" },
      { icon: Wrench, title: "Charger Troubleshooting" },
      { icon: CheckCircle2, title: "Future-Ready Installation" },
    ],
  },
];

function StickyServiceScrollEffects() {
  return (
    <section data-scroll-tone="dark" data-sticky-service-section="true" className="py-24 bg-surface text-surface-foreground relative overflow-visible">
      <div className="container mx-auto grid items-start gap-10 px-4 relative z-10 lg:grid-cols-[0.96fr_1.04fr] lg:[--service-card-height:940px] xl:[--service-card-height:980px]">
        <div className="lg:sticky lg:top-24 lg:h-[var(--service-card-height)] lg:self-start">
          <div className="flex h-full flex-col justify-between">
            <div>
            <ElectricSectionTag label="Electrical Services We Provide" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-6" />
            <h2 className="font-display text-4xl font-extrabold tracking-tight md:text-5xl xl:text-6xl">
              Surrey & Lower Mainland Residential, Commercial & Industrial <span className="brand-highlight">Electrical Services</span>
            </h2>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-surface-foreground/70 xl:text-lg">
              From outlet upgrades and panel replacements to complete commercial and industrial electrical systems, our licensed electricians provide safe, reliable, and code-compliant electrical services throughout Surrey and the Lower Mainland.
            </p>
            </div>
            <div className="mt-8 overflow-hidden rounded-[1.75rem] border border-white/12 bg-white/[0.07] shadow-[0_24px_80px_rgba(0,0,0,0.28)] backdrop-blur-md">
              <div className="border-b border-white/10 bg-white/[0.055] px-5 py-4">
                <h3 className="font-display text-2xl font-extrabold uppercase tracking-[0.06em] text-white">
                  Why Customers Choose GK Electric
                </h3>
              </div>
              <div className="grid gap-2 p-4">
                {[
                  "🛡️ FULLY LICENSED & INSURED IN BC",
                  "✅ TECHNICAL SAFETY BC COMPLIANT",
                  "⚡ 24/7 EMERGENCY AVAILABILITY",
                  "⏱️ FAST 30–60 MINUTE RESPONSE TIME",
                  "📍 SERVING SURREY & THE LOWER MAINLAND",
                  "🏠 RESIDENTIAL, COMMERCIAL & INDUSTRIAL EXPERTS",
                  "⚙️ ELECTRICAL REPAIRS, INSTALLATIONS & UPGRADES",
                  "🔌 EV CHARGER & PANEL UPGRADE SPECIALISTS",
                  "💰 FREE ESTIMATES & UPFRONT PRICING",
                  "⭐ QUALITY ELECTRICAL WORKMANSHIP",
                  "🤝 RELIABLE & PROFESSIONAL SERVICE",
                ].map((label) => (
                  <div key={label} className="rounded-2xl border border-white/10 bg-white/[0.045] px-4 py-3 text-[15px] font-light uppercase leading-snug tracking-[0.08em] text-surface-foreground/86 transition-all duration-300 hover:border-primary/35 hover:bg-primary/10 hover:text-white">
                    {label}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6 lg:space-y-9 lg:[&>:not(:last-child)]:mb-[calc(calc(var(--spacing)*30)*calc(1-var(--tw-space-y-reverse)))] lg:[&>:not(:last-child)]:mt-[calc(calc(var(--spacing)*9)*var(--tw-space-y-reverse))]">
          {stickyServiceSlides.map((service, index) => (
            <Link
              key={service.title}
              to={service.to}
              data-sticky-service-card
              className="group sticky top-28 block overflow-hidden rounded-[1.75rem] border border-white/14 bg-surface transition-colors duration-500 hover:border-primary/45"
              style={{ zIndex: index + 10 }}
            >
              <div className="absolute inset-0 rounded-[1.75rem] ring-1 ring-inset ring-white/10" />
              <div className="relative h-[252px] overflow-hidden md:h-[288px] lg:h-[318px]">
                <img src={service.img} alt={`${service.title} electrical service`} className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-surface/60 via-transparent to-transparent" />
              </div>
              <div className="relative flex flex-col bg-surface p-5 md:p-6">
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground transition-transform duration-500 group-hover:rotate-6">
                    <service.icon className="h-7 w-7" />
                  </div>
                  <div className="font-display text-6xl font-black text-white/10">{String(index + 1).padStart(2, "0")}</div>
                </div>
                <h3 className="font-display text-3xl font-bold leading-none text-white md:text-4xl">{service.title}</h3>
                <p className="mt-2 max-w-2xl line-clamp-2 text-sm leading-relaxed text-surface-foreground/72 md:text-[0.95rem]">{service.desc}</p>
                <div className="mt-4 grid gap-2 sm:grid-cols-2">
                  {service.detailServices.slice(0, 8).map((detail, detailIndex) => (
                    <div
                      key={detail.title}
                      className="group/detail flex min-h-[58px] items-center gap-3 rounded-2xl border border-white/80 bg-white/95 p-3 shadow-sm backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/35"
                      style={{ transitionDelay: `${detailIndex * 35}ms` }}
                    >
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/20 transition-colors duration-300 group-hover/detail:bg-primary group-hover/detail:text-primary-foreground">
                        <detail.icon className="h-[18px] w-[18px]" />
                      </span>
                      <span className="text-[0.90rem] font-medium uppercase leading-snug tracking-[0.08em] text-foreground">
                        {detail.title}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-5 inline-flex w-fit items-center gap-2 rounded-full border border-primary/50 bg-surface/70 px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary backdrop-blur-md transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  Explore More Services <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </Link>
          ))}
          <div className="hidden h-[38vh] lg:block" aria-hidden="true" />
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <HomeSampleContactDesign11 />
      </div>

    </section>
  );
}

function StickyCoverageScrollEffects() {
  const coverageGroups = [featuredCoverageAreas.slice(0, 4), featuredCoverageAreas.slice(4, 8)];

  return (
    <section data-scroll-tone="light" className="relative overflow-visible bg-background py-24 md:py-32">
      <div className="container mx-auto grid gap-10 px-4 lg:grid-cols-[0.85fr_1.15fr]">
        <div className="lg:sticky lg:top-28 lg:h-fit">
          <ElectricSectionTag label="Lower Mainland" icon={MapPin} tone="light" variant="electric-v1-2" className="mb-6" />
          <h2 className="font-display text-4xl font-extrabold tracking-tight md:text-5xl lg:text-6xl">
            Scroll our service coverage.
          </h2>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
            GK Electric supports Surrey and key Lower Mainland communities with residential, commercial, industrial and emergency electrical service.
          </p>
          <Button asChild variant="electric" size="lg" className="mt-8">
            <Link to="/service-areas">All Service Areas <ArrowRight className="h-4 w-4" /></Link>
          </Button>
        </div>

        <div className="space-y-8">
          {coverageGroups.map((group, groupIndex) => (
            <div key={groupIndex} className="sticky top-28 grid min-h-[68vh] gap-4 rounded-[2rem] border border-border bg-card p-5 shadow-elegant sm:grid-cols-2" style={{ zIndex: groupIndex + 1 }}>
              {group.map((area, index) => (
                <Link
                  key={area.slug}
                  to={area.slug === "surrey" ? "/surrey" : "/service-areas"}
                  className="group rounded-2xl border border-border bg-background p-5 shadow-card transition-all duration-500 hover:-translate-y-2 hover:border-primary/40 hover:shadow-glow"
                >
                  <div className="mb-5 flex items-center justify-between">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary ring-1 ring-primary/20 transition-all group-hover:bg-primary group-hover:text-primary-foreground">
                      <MapPin className="h-6 w-6" />
                    </div>
                    <span className="font-display text-3xl font-bold text-primary/30">0{groupIndex * 4 + index + 1}</span>
                  </div>
                  <h3 className="font-display text-2xl font-bold text-foreground">{area.name}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{area.description}</p>
                </Link>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function HomeScrollMeasure() {
  const [progress, setProgress] = useState(0);
  const [onDark, setOnDark] = useState(true);

  useEffect(() => {
    const update = () => {
      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      setProgress(Math.min(1, Math.max(0, scrollTop / max)));

      const sampleLine = window.innerHeight / 2;
      const samplePoints = [28, Math.round(window.innerWidth * 0.5), Math.round(window.innerWidth * 0.82)];
      const currentTone = samplePoints
        .map((x) => document.elementFromPoint(x, sampleLine) as HTMLElement | null)
        .map((element) => element?.closest<HTMLElement>("[data-scroll-tone]")?.dataset.scrollTone)
        .find(Boolean);

      if (currentTone) {
        setOnDark(currentTone === "dark");
        return;
      }

      const element = document.elementFromPoint(Math.round(window.innerWidth * 0.5), sampleLine) as HTMLElement | null;
      const section = element?.closest("section, footer, header, main, div") as HTMLElement | null;
      const className = section?.className?.toString() ?? "";
      setOnDark(scrollTop < window.innerHeight || className.includes("bg-surface") || className.includes("bg-gradient") || className.includes("text-surface-foreground"));
    };

    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  return (
    <div className={`pointer-events-none fixed left-3 top-1/2 z-[60] hidden -translate-y-1/2 flex-col items-center gap-3 rounded-full border px-2 py-4 backdrop-blur-md transition-all duration-300 lg:flex ${onDark ? "border-white/15 bg-black/20" : "border-surface/10 bg-white/55 shadow-lg"}`} aria-hidden="true">
      <div className={`text-[10px] font-black uppercase tracking-[0.24em] transition-colors [writing-mode:vertical-rl] ${onDark ? "text-white/80" : "text-surface/80"}`}>
        scroll
      </div>
      <div className={`relative h-52 w-[3px] overflow-hidden rounded-full transition-colors ${onDark ? "bg-white/25" : "bg-surface/20"}`}>
        <div
          className={`absolute left-0 top-0 w-full origin-top rounded-full transition-colors ${onDark ? "bg-primary shadow-[0_0_16px_rgba(245,181,38,.85)]" : "bg-surface shadow-[0_0_14px_rgba(26,32,48,.35)]"}`}
          style={{ height: `${progress * 100}%` }}
        />
      </div>
      <div className={`h-2.5 w-2.5 rounded-full transition-colors ${onDark ? "bg-primary shadow-[0_0_18px_rgba(245,181,38,1)]" : "bg-surface"}`} />
    </div>
  );
}


function HomePage() {
  const [showServiceTiles, setShowServiceTiles] = useState(false);

  useEffect(() => {
    const updateServiceTiles = () => {
      setShowServiceTiles(window.scrollY > 80);
    };

    updateServiceTiles();
    window.addEventListener("scroll", updateServiceTiles, { passive: true });
    return () => window.removeEventListener("scroll", updateServiceTiles);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <HomeScrollMeasure />
      <Header />

      {/* HERO */}
      <section data-scroll-tone="dark" className="relative h-screen flex items-center overflow-hidden bg-surface">
        <HeroSlideshow />
      </section>

      {/* TRUST HIGHLIGHTS */}
      <section data-scroll-tone="light" className="relative z-30 bg-white border-y border-gray-100 shadow-sm py-7">
        <div className="container mx-auto px-4">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {heroTrustItems.map((item, index) => (
              <Link
                key={item.label}
                to={item.to}
                data-reveal="up"
                style={{ transitionDelay: `${index * 70}ms` }}
                className="group/coverage relative mx-auto flex min-h-[118px] w-full items-center justify-start gap-4 overflow-hidden rounded-[5px] border border-primary/45 bg-transparent px-5 py-4 text-primary backdrop-blur-sm transition-all duration-500 ease-out hover:-translate-y-0.5 hover:border-primary hover:text-primary-foreground hover:shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2 focus:ring-offset-white before:absolute before:inset-0 before:origin-left before:scale-x-0 before:bg-gradient-electric before:transition-transform before:duration-500 before:ease-out hover:before:scale-x-100"
              >
                <div className="relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-[5px] bg-transparent text-primary transition-all duration-500 group-hover/coverage:rotate-3 group-hover/coverage:scale-105 group-hover/coverage:text-primary-foreground">
                  <item.icon className="h-9 w-9" />
                </div>
                <div className="relative z-10 min-w-0 flex-1">
                  <h2 className="font-display text-base font-extrabold uppercase tracking-[0.12em] text-foreground transition-colors duration-500 group-hover/coverage:text-primary-foreground">
                    {item.label}
                  </h2>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground transition-colors duration-500 group-hover/coverage:text-primary-foreground/85">
                    <span className="transition-opacity duration-300 group-hover/coverage:hidden">{item.detail}</span>
                    <span className="hidden font-extrabold uppercase tracking-[0.08em] group-hover/coverage:inline">{item.actionLabel}</span>
                  </p>
                </div>
                <ArrowRight className="relative z-10 h-5 w-5 shrink-0 opacity-70 transition-all duration-500 group-hover/coverage:translate-x-1.5 group-hover/coverage:opacity-100" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICE TILES ROW — hidden for now. Set SHOW_SERVICE_TILES to true above to uncomment/show it again. */}
      {SHOW_SERVICE_TILES && (
        <section data-scroll-tone="light" className="relative bg-background pt-12 pb-14 sm:pt-14 md:pt-16 md:pb-20 lg:pt-20 z-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:gap-6 xl:grid-cols-4 w-full max-w-sm sm:max-w-3xl xl:max-w-6xl mx-auto">
              {serviceTiles.map((tile, i) => (
                <Link
                  key={tile.label}
                  to={tile.to}
                  style={{ transitionDelay: showServiceTiles ? `${i * 130}ms` : "0ms" }}
                  className={`group relative block aspect-square overflow-hidden rounded-2xl shadow-lg transition-all duration-700 ease-out will-change-transform hover:-translate-y-2 hover:shadow-2xl ${
                    showServiceTiles
                      ? "translate-y-0 scale-100 opacity-100 pointer-events-auto"
                      : "translate-y-10 scale-[0.96] opacity-0 pointer-events-none"
                  }`}
                  aria-label={tile.label}
                  title={tile.label}
                >
                  <img
                    src={tile.src}
                    alt={tile.label}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 rounded-2xl ring-1 ring-black/5 transition-all duration-500 group-hover:ring-black/10" />
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ABOUT US */}
      <AboutUsSection />



      {/* SERVICES */}
      <section data-scroll-tone="light" className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="mb-16 grid gap-8 lg:grid-cols-2 lg:items-end">
            <div data-reveal className="text-left">
              <ElectricSectionTag label="What We Do" icon={Lightbulb} tone="light" variant="electric-v1-2" className="mb-6" />
              <h2 className="text-4xl md:text-6xl mb-4">
                <span className="text-black">Surrey & Lower Mainland Residential, Commercial & Industrial</span>{" "}
                <span className="text-primary">Electrical Services</span>
              </h2>
              <p className="max-w-3xl text-lg text-muted-foreground leading-relaxed">
                From outlet upgrades and panel replacements to complete commercial and industrial electrical systems, our licensed electricians provide safe, reliable, and code-compliant electrical services throughout Surrey and the Lower Mainland.
              </p>
            </div>
            <div data-reveal="right" className="grid gap-3 lg:pl-8 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
              {[
                { icon: ShieldCheck, label: "Fully Licensed & Insured in BC" },
                { icon: Clock, label: "Same-Day Service Available" },
                { icon: BadgeCheck, label: "Technical Safety BC Compliant" },
                { icon: Headphones, label: "24/7 Emergency Availability" },
              ].map((tag, index) => (
                <div
                  key={tag.label}
                  data-reveal="up"
                  style={{ transitionDelay: `${index * 60}ms` }}
                  className="group flex items-center gap-3 rounded-2xl border border-primary/20 bg-primary/[0.06] px-4 py-4 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-primary/10 hover:shadow-glow"
                >
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/20 transition-all duration-300 group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-105">
                    <tag.icon className="h-5 w-5" />
                  </span>
                  <span className="text-sm font-extrabold uppercase tracking-[0.11em] leading-snug text-foreground">
                    {tag.label}
                  </span>
                </div>
              ))}
            </div>
          </div>


          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {services.map((s, i) => (
              <Link
                key={s.title}
                to={s.to}
                data-reveal="zoom"
                style={{ transitionDelay: `${i * 120}ms` }}
                className="group relative min-h-[430px] overflow-hidden rounded-[2rem] shadow-elegant transition-all duration-500"
                aria-label={s.tag}
              >
                <img
                  src={s.img}
                  alt={`${s.title} electrical service`}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/45 to-transparent" />
                <div className="absolute right-0 top-7 z-10 translate-x-full rounded-l-2xl bg-white/90 px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-surface opacity-100 shadow-xl transition-all duration-500 group-hover:translate-x-0">
                  {s.tag}
                </div>
                <div className="absolute inset-x-0 bottom-0 p-7 text-surface-foreground">
                  <div className="flex min-h-[220px] flex-col items-start">
                    <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                      <s.icon className="h-7 w-7" />
                    </div>
                    <h3 className="mb-3 text-3xl font-bold leading-tight">{s.title}</h3>
                    <p className="mb-4 h-[4.25rem] text-sm leading-relaxed text-surface-foreground/75">
                      {s.desc}
                    </p>
                    <div className="mt-auto inline-flex items-center gap-2 rounded-full border border-primary/70 bg-transparent px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary shadow-none transition-all duration-300 hover:border-primary hover:bg-transparent hover:text-primary-glow hover:shadow-none">
                      More Information <ArrowRight className="h-4 w-4" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* EV CALLOUT (inside Services) */}
          <div data-reveal className="relative overflow-hidden rounded-2xl shadow-elegant mt-16 group">
            <img
              src={evImage}
              alt="EV charger installation in residential garage"
              loading="lazy"
              width={1600}
              height={1200}
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-surface/90 via-surface/60 to-transparent md:via-surface/40" />
            <div className="absolute right-0 top-7 z-10 translate-x-full rounded-l-2xl bg-white/90 px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-surface shadow-xl transition-all duration-500 group-hover:translate-x-0">
              EV Charger Installation
            </div>
            <div className="relative p-8 md:p-12 max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest mb-4">
                <Plug className="h-3 w-3" /> High Demand
              </div>
              <h3 className="font-display text-3xl md:text-4xl text-surface-foreground mb-4">
                EV Charger Installation
              </h3>
              <p className="text-surface-foreground/80 mb-6 leading-relaxed">
                Home and commercial EV chargers — fast, safe installation
                compatible with all major EV brands.
              </p>
              <Link to="/ev-charger" className="mt-auto inline-flex items-center gap-2 rounded-full border border-primary/70 bg-transparent px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary shadow-none transition-all duration-300 hover:border-primary hover:bg-transparent hover:text-primary-glow hover:shadow-none">
                More Information <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>


          <div className="text-center mt-12">
            <Button asChild variant="default" size="lg">
              <Link to="/services">
                View All Services <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <StickyServiceScrollEffects />

      {/* SPECIALIZED SERVICE: PERMITS & COMPLIANCE */}
      <section data-scroll-tone="dark" className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid gap-8 lg:grid-cols-[2fr_3fr] items-start">
            <div data-reveal="left" className="lg:sticky lg:top-24">
              <ElectricSectionTag label="Specialized Service" icon={ClipboardCheck} tone="dark" variant="electric-v1-2" className="mb-6" />
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6">
                Permits & Compliance <span className="brand-highlight">Made Simple</span>
              </h2>
              <div className="space-y-5 text-lg text-surface-foreground/72 leading-relaxed max-w-2xl">
                <p>
                  We take care of all electrical permits, inspections, and regulatory requirements from start to finish—so your project stays compliant, on schedule, and stress-free.
                </p>
                <p>
                  Our team works directly with local authorities to ensure all work meets the BC Electrical Safety Regulation and the Canadian Electrical Code. From permit applications to final approvals, we handle the paperwork, coordination, and compliance details for you.
                </p>
              </div>

              <div className="mt-8" data-reveal>
                <Button asChild variant="electric" size="lg" className="home-more-info-button shadow-none hover:shadow-none">
                  <Link to="/services">
                    More Info
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                </Button>
              </div>

            </div>

            <div className="grid gap-4 pt-4 text-center md:pl-10 md:text-left lg:pt-[4.25rem]">
              <div
                data-reveal="right"
                className="group relative"
              >
                <div className="mb-4">
                  <div className="flex items-center justify-center gap-4 md:justify-start">
                    <span className="h-10 w-1 rounded-full bg-primary shadow-glow" aria-hidden="true" />
                    <h3 className="font-display text-3xl font-bold text-surface-foreground">What We Handle</h3>
                  </div>
                </div>
                <div className="grid gap-2 sm:grid-cols-2">
                  {[
                    { icon: FileCheck, text: "Electrical permit applications" },
                    { icon: CalendarCheck, text: "Inspection scheduling & coordination" },
                    { icon: BadgeCheck, text: "Code compliance verification" },
                    { icon: Wrench, text: "Deficiency corrections support" },
                    { icon: ClipboardCheck, text: "Final inspection & approvals" },
                    { icon: ScrollText, text: "Regulatory documentation" },
                    { icon: FileCheck, text: "Electric Operating Permits" },
                    { icon: FileText, text: "Electric Planning Reports" },
                  ].map((item, index) => (
                    <div key={item.text} data-reveal style={{ transitionDelay: `${index * 45}ms` }} className="group flex flex-col items-center gap-3 border-b border-white/10 px-1 py-2.5 text-center transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.12] sm:flex-row sm:text-left">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/20 text-primary ring-1 ring-primary/25">
                        <item.icon className="h-5 w-5" />
                      </span>
                      <span className="text-[16px] !font-normal uppercase leading-snug tracking-[0.2px] text-surface-foreground">{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-[1.75rem] border border-white/12 bg-white/[0.055] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.28)] backdrop-blur-md md:p-6">
            <div className="grid gap-5 md:grid-cols-[1.25fr_1fr_1fr_1fr] md:divide-x md:divide-white/10">
              <div className="flex items-center">
                <p className="font-display text-2xl font-extrabold uppercase tracking-[0.06em] text-white">
                  Ready to start your permit-backed electrical work?
                </p>
              </div>
              {[
                { icon: Phone, label: "Call Now", text: "Speak with our team", href: "tel:+17783444567" },
                { icon: FilePenLine, label: "Request a Quote", text: "Get a custom quote", href: "/contact" },
                { icon: MessageCircle, label: "WhatsApp Us", text: "Chat with us now", href: "https://wa.me/17783444567" },
              ].map((action) => {
                const Icon = action.icon;
                const external = action.href.startsWith("http");
                const isWhatsApp = action.label.includes("WhatsApp");
                const content = (
                  <>
                    <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border transition-all duration-300 group-hover:scale-110 ${isWhatsApp ? "border-green-400/35 bg-green-500/15 text-green-300 group-hover:bg-green-500 group-hover:text-white group-hover:border-green-400" : "border-primary/45 bg-primary/15 text-primary group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary"}`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-[16px] font-medium uppercase leading-tight tracking-normal text-white group-hover:text-primary transition-colors">{action.label}</div>
                      <div className="mt-1 text-sm text-surface-foreground/55 group-hover:text-surface-foreground/80 transition-colors">{action.text}</div>
                    </div>
                  </>
                );

                return external ? (
                  <a key={action.label} href={action.href} target="_blank" rel="noreferrer" className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-green-400/40 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </a>
                ) : action.href.startsWith("tel:") ? (
                  <a key={action.label} href={action.href} className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </a>
                ) : (
                  <Link key={action.label} to="/contact" className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4">
                    {content}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      <EmergencySample07Section />

      {/* LOWER MAINLAND COVERAGE */}
      <section data-scroll-tone="dark" className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] items-start">
            <div data-reveal="left" className="lg:sticky lg:top-28">
              <ElectricSectionTag label="Service Areas" icon={MapPin} tone="dark" variant="electric-v1-2" className="mb-6" />
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-5">
                Lower Mainland <span className="brand-highlight">Coverage</span>
              </h2>
              <p className="text-lg text-surface-foreground/72 leading-relaxed max-w-2xl mb-8">
                From our Surrey home base, GK Electric serves homes, businesses and industrial facilities across the Lower Mainland with same-day support, permit-ready work and professional electrical service.
              </p>
              <Button asChild variant="electric" size="lg">
                <Link to="/service-areas">
                  View Service Areas <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {featuredCoverageAreas.map((area, index) => (
                <Link
                  key={area.slug}
                  to={area.slug === "surrey" ? "/surrey" : "/service-areas"}
                  data-reveal="up"
                  style={{ transitionDelay: `${index * 50}ms` }}
                  className="group rounded-2xl border border-white/12 bg-white/[0.055] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.22)] backdrop-blur-md transition-all duration-500 hover:-translate-y-2 hover:border-primary/45 hover:bg-white/[0.09]"
                >
                  <div className="mb-5 flex items-center justify-between gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/15 text-primary ring-1 ring-primary/25 transition-all group-hover:bg-primary group-hover:text-primary-foreground">
                      <MapPin className="h-6 w-6" />
                    </div>
                    <span className="text-xs font-black uppercase tracking-[0.18em] text-primary">{String(index + 1).padStart(2, "0")}</span>
                  </div>
                  <h3 className="font-display text-2xl font-bold tracking-tight text-white mb-2">{area.name}</h3>
                  <p className="text-sm leading-relaxed text-surface-foreground/62 mb-4">{area.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {area.highlights.slice(0, 2).map((highlight) => (
                      <span key={highlight} className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-surface-foreground/55">
                        {highlight}
                      </span>
                    ))}
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <StickyCoverageScrollEffects />

      {/* WHY CHOOSE US */}
      <section data-scroll-tone="light" className="bg-background text-foreground py-24">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div data-reveal="left">
              <ElectricSectionTag label="Why Choose Us" icon={Award} tone="light" variant="electric-v1-2" className="mb-6" />
              <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-3">Why Choose GK Electric?</h2>
              <p className="text-[15px] text-muted-foreground leading-relaxed max-w-2xl">Licensed electricians providing residential, commercial, and industrial electrical services in Surrey, the Lower Mainland, and across British Columbia. We deliver safe workmanship, clear upfront pricing, and reliable 24/7 emergency electrical support.</p>
            </div>
            <div data-reveal="right" className="rounded-3xl border border-border overflow-hidden bg-card shadow-card">
              {[
                { icon: ShieldCheck, title: "Licensed & Insured Electricians in British Columbia", text: "All our electricians are fully certified, insured, and follow Technical Safety BC standards for safe, code-compliant electrical work." },
                { icon: Zap, title: "24/7 Emergency Electrical Service", text: "Nights, weekends, and holidays — our licensed electricians are available for fast emergency response across Surrey and the Lower Mainland when urgent electrical issues happen." },
                { icon: Clock, title: "Fast 30–60 Minute Response Time", text: "We respond quickly across Surrey, Vancouver, Burnaby, and surrounding Lower Mainland areas to restore safety and power without delay." },
                { icon: BadgeCheck, title: "Clear Upfront Pricing", text: "Clear quotes before work begins, with honest communication and transparent pricing every time." },
                { icon: Award, title: "Quality Electrical Work You Can Trust", text: "Clean, precise, and code-compliant electrical work across Surrey and the Lower Mainland. We focus on safe installations, careful finishing, and long-lasting results." },
                { icon: Headphones, title: "Customer-Focused Service", text: "We prioritize clear communication, reliable scheduling, and a smooth customer experience from start to finish." },
                { icon: Building2, title: "Residential, Commercial & Industrial Electricians", text: "From homes and condos to commercial buildings and industrial facilities, we handle all types of electrical work with safety and expertise." },
                { icon: Plug, title: "EV Charger & Panel Upgrade Specialists", text: "We specialize in EV charger installations, panel upgrades, and electrical service improvements for modern homes and businesses across BC." },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.title} className="flex items-center gap-4 p-5 border-b border-border last:border-b-0 hover:bg-muted/40 transition-colors">
                    <Icon className="h-6 w-6 text-muted-foreground shrink-0" />
                    <div>
                      <h3 className="text-[20px] font-semibold tracking-[0.2px] text-foreground">{item.title}</h3>
                      <p className="text-[15px] text-muted-foreground">{item.text}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>


      {/* FEATURED PROJECTS (moved to where EV banner was) */}
      <FeaturedProjects />

      {/* TESTIMONIALS */}
      <Testimonials />

      {/* REVIEWS SHOWCASE */}
      <ReviewsShowcase />

      {/* CTA */}
      <section data-scroll-tone="light" className="py-20 bg-gradient-electric relative overflow-hidden">
        <div className="absolute inset-0 animate-shimmer opacity-40 pointer-events-none" />
        <DecorBoltOutlet side="br" className="opacity-25 text-primary-foreground" />
        <div className="container mx-auto px-4 text-center text-primary-foreground relative">
          <h2 data-reveal className="text-4xl md:text-5xl mb-4">Ready to Power Your Project?</h2>
          <p data-reveal className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Get a free, no-obligation estimate today. Our licensed electricians are standing by.
          </p>
          <div data-reveal="zoom" className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="xl" variant="default" className="bg-surface text-surface-foreground hover:bg-surface/90 hover:scale-105 transition-transform">
              <a href="tel:+17783444567"><Phone className="h-5 w-5" /> Call +1 (778) 344-4567</a>
            </Button>
            <Button asChild size="xl" variant="default" className="bg-surface text-primary border-2 border-surface hover:bg-surface/90 hover:scale-105 transition-transform">
              <Link to="/free-estimate">Free Estimate</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function AboutUsSection() {
  return (
    <section data-scroll-tone="light" className="py-24 md:py-32 bg-background relative overflow-hidden">
      <div className="container mx-auto px-4 relative">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-20 items-center">
          <div data-reveal="left" className="relative">
            <div className="relative max-w-lg mx-auto pb-16 lg:max-w-none">
              <div className="relative">
                <div className="absolute -z-10 -right-4 -bottom-4 w-full h-full bg-primary/10 rounded-3xl" />
                <div className="group relative overflow-hidden rounded-3xl shadow-2xl aspect-[4/3] bg-muted">
                  <img
                    src={ourStory}
                    alt="GK Electric professional electrician at work"
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-surface/60 via-transparent to-transparent" />
                </div>
              </div>
              <div className="absolute bottom-16 left-4 translate-y-1/2 animate-float sm:left-6">
                <div className="inline-flex items-center gap-4 rounded-2xl border-[3px] border-white bg-[#00497b] px-5 py-4 shadow-xl">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl">
                    <img
                      src={tsbcLogo}
                      alt="Technical Safety BC logo"
                      className="h-14 w-14 object-contain"
                      loading="lazy"
                    />
                  </div>
                  <div className="text-white">
                    <div className="text-[1.25rem] tracking-wider text-white">TSBC Licence</div>
                    <div className="text-[1.5rem] tracking-[2px] font-bold text-white"># LEL0209793</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div data-reveal="right">
            <ElectricSectionTag label="Who We Are" icon={Users} tone="light" variant="electric-v1-2" className="mb-8" />
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold leading-[1.1] mb-6">
              Licensed Electricians Delivering Residential, Commercial & Industrial Electrical Services
              <span className="block text-primary mt-2">Across British Columbia</span>
            </h2>
            <div className="space-y-4 mb-8">
              <p className="text-lg text-muted-foreground leading-relaxed">
                <strong className="text-foreground">GK ELECTRIC</strong> provides reliable residential, commercial, and industrial electrical services throughout British Columbia. Our licensed electricians specialize in electrical repairs, installations, panel upgrades, electrical maintenance, EV charger installations, lighting solutions, troubleshooting, and complete electrical system upgrades.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                As a trusted electrical contractor, we help homeowners, businesses, and industrial facilities with safe, reliable, and code-compliant electrical work. Whether you need a new installation, electrical upgrade, emergency repair, or ongoing maintenance, our experienced team delivers quality workmanship and dependable service on every project.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Backed by industry expertise, safety-focused practices, and a commitment to customer satisfaction, <strong className="text-foreground">GK ELECTRIC</strong> is your trusted partner for professional electrical services across British Columbia.
              </p>
            </div>
            <div className="flex flex-wrap gap-4 mb-8">
              <Button asChild variant="electric" size="lg">
                <Link to="/free-estimate">
                  GET FREE ESTIMATE <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/about">
                  ABOUT GK ELECTRIC <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-16 md:mt-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[
              { icon: FolderKanban, value: "1000+", label: "Projects Completed" },
              { icon: Star, value: "100%", label: "Satisfaction Rate" },
              { icon: Headphones, value: "24/7", label: "Emergency Support" },
              { icon: ShieldCheck, value: "BC", label: "Licensed & Insured" },
            ].map((stat) => (
              <div key={stat.label} className="bg-card rounded-2xl p-6 md:p-8 shadow-lg border border-border text-center hover:shadow-xl hover:border-primary/20 transition-all duration-300 group">
                <div className="h-12 w-12 md:h-14 md:w-14 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <stat.icon className="h-6 w-6 md:h-7 md:w-7 text-primary" />
                </div>
                <div className="text-4xl md:text-5xl font-display font-bold text-foreground mb-2">{stat.value}</div>
                <div className="text-sm md:text-base text-muted-foreground font-medium uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

