import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { motion, useMotionTemplate, useMotionValue, useScroll, useSpring, useTransform } from "framer-motion";
import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  Building2,
  CheckCircle2,
  Clock,
  Factory,
  FileCheck,
  FileText,
  Flame,
  Gauge,
  Headphones,
  Home,
  Lightbulb,
  MapPin,
  Phone,
  PlugZap,
  ShieldCheck,
  Sparkles,
  Star,
  Users,
  Wrench,
  Zap,
} from "lucide-react";
import gkLogo from "@/assets/gk-logo.jpeg";
import heroImage from "@/assets/hero-electrician.jpg";
import ourStory from "@/assets/our-story.jpg";
import residentialImage from "@/assets/residential.jpg";
import commercialImage from "@/assets/commercial.jpg";
import industrialImage from "@/assets/industrial.jpg";
import evImage from "@/assets/ev-charger.jpg";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";
import { Footer } from "@/components/Footer";
import { projects } from "@/data/projects";
import { testimonials } from "@/data/testimonials";
import { featuredReviews, reviewStats } from "@/data/reviews";
import { serviceAreas } from "@/data/serviceAreas";

export const Route = createFileRoute("/new/home")({
  head: () => ({
    meta: [
      {
        title:
          "GK Electric Surrey — 24/7 Emergency Electrician, Residential & Commercial Electrical Services",
      },
      {
        name: "description",
        content:
          "GK Electric provides licensed electrical services in Surrey, BC and the Lower Mainland: 24/7 emergency electrician response, panel upgrades, EV chargers, residential wiring, commercial electrical, industrial power and code-compliant permits.",
      },
      {
        name: "keywords",
        content:
          "electrician Surrey, emergency electrician Surrey, 24/7 electrician Surrey BC, GK Electric, residential electrician Surrey, commercial electrician Surrey, EV charger installation Surrey, panel upgrade Surrey, industrial electrician Lower Mainland",
      },
      {
        property: "og:title",
        content: "GK Electric Surrey — 24/7 Emergency Electrician & Electrical Contractor",
      },
      {
        property: "og:description",
        content:
          "Licensed and insured electricians serving Surrey and the Lower Mainland. Emergency repairs, panels, EV chargers, residential, commercial and industrial electrical work.",
      },
      { property: "og:type", content: "website" },
      { property: "og:image", content: heroImage },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: heroImage },
    ],
  }),
  component: NewHomePage,
});

const navItems = [
  { number: "01", label: "Home", href: "#home" },
  { number: "02", label: "Services", href: "#services" },
  { number: "03", label: "Emergency", href: "#emergency" },
  { number: "04", label: "Surrey", href: "#surrey" },
  { number: "05", label: "Contact", href: "#contact" },
];

const proofStats = [
  { value: "24/7", label: "Emergency electrical support" },
  { value: "18+", label: "Years of field experience" },
  { value: "30–60", label: "Minute Surrey priority dispatch" },
  { value: "100%", label: "Permit-ready, code-compliant work" },
];

const trustHighlights = [
  { icon: ShieldCheck, label: "Licensed & Insured", detail: "Qualified electrical work backed by proper licensing and insurance coverage." },
  { icon: Clock, label: "18+ Years Experience", detail: "Trusted residential, commercial and industrial service across BC." },
  { icon: FileCheck, label: "Permits & Compliance", detail: "Electrical permits, inspections and code requirements handled correctly." },
  { icon: Headphones, label: "24/7 Emergency Support", detail: "Responsive help when critical electrical issues cannot wait." },
];

const serviceLayers = [
  {
    number: "01",
    title: "Residential Power",
    phrase: "safe homes, brighter spaces",
    icon: Home,
    image: residentialImage,
    href: "/services/residential",
    points: ["Home wiring & rewiring", "Panel and sub-panel upgrades", "Lighting, outlets and smart controls"],
  },
  {
    number: "02",
    title: "Commercial Systems",
    phrase: "reliable power for business",
    icon: Building2,
    image: commercialImage,
    href: "/services/commercial",
    points: ["Tenant improvements", "Commercial panels and circuits", "LED retrofits and maintenance"],
  },
  {
    number: "03",
    title: "Industrial Infrastructure",
    phrase: "heavy-duty electrical backbone",
    icon: Factory,
    image: industrialImage,
    href: "/services/industrial",
    points: ["Three-phase power", "Machinery wiring and controls", "Shutdown work and facility upgrades"],
  },
];

const emergencyProblems = [
  { icon: Flame, title: "Burning smell", desc: "Shut power off if safe and call immediately." },
  { icon: Zap, title: "Power outage", desc: "Full or partial power loss at home or business." },
  { icon: AlertTriangle, title: "Tripping breakers", desc: "Repeated trips can mean overloads or hidden faults." },
  { icon: Sparkles, title: "Sparking outlets", desc: "Do not use the outlet until inspected." },
];

const seoAreas = [
  "Surrey",
  "Fleetwood",
  "Guildford",
  "Newton",
  "Cloverdale",
  "Whalley",
  "South Surrey",
  "Clayton Heights",
  "Port Kells",
  "Fraser Heights",
];

const capabilityStack = [
  { icon: ShieldCheck, title: "Licensed & Insured", desc: "Qualified electrical work backed by proper licensing, insurance and safe procedures." },
  { icon: BadgeCheck, title: "TSBC Permit Support", desc: "Permit-ready installations, inspection support and clean documentation." },
  { icon: Gauge, title: "Panel Upgrades", desc: "Service upgrades, breakers, load calculations and EV-ready capacity planning." },
  { icon: PlugZap, title: "EV Chargers", desc: "Level 2 charger installation, dedicated circuits and panel readiness checks." },
  { icon: Headphones, title: "Emergency Response", desc: "Fast support for urgent electrical hazards, outages, buzzing panels and unsafe wiring." },
  { icon: Wrench, title: "Troubleshooting", desc: "Practical diagnosis for flickering lights, warm devices, dead outlets and wiring faults." },
];

const complianceItems = [
  "Electrical permit applications",
  "Inspection scheduling & coordination",
  "Code compliance verification",
  "Deficiency corrections support",
  "Final inspection & approvals",
  "Regulatory documentation",
  "Electric operating permits",
  "Electric planning reports",
];

const featuredServiceAreas = serviceAreas.filter((area) => area.featured || area.slug === "surrey").slice(0, 8);

const tickerItems = [
  "24/7 Emergency Electrician Surrey",
  "Panel Upgrades",
  "EV Charger Installation",
  "Commercial Electrical Maintenance",
  "Industrial Three-Phase Power",
  "Permits & Compliance",
  "Residential Wiring",
  "Lower Mainland Service",
];

function JsonLd() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Electrician",
    name: "GK Electric",
    image: "https://gkelectric.ca/assets/gk-logo.jpeg",
    telephone: "+1-778-344-4567",
    url: "https://gkelectric.ca/new/home",
    address: {
      "@type": "PostalAddress",
      addressLocality: "Surrey",
      addressRegion: "BC",
      addressCountry: "CA",
    },
    areaServed: seoAreas.map((name) => ({ "@type": "City", name })),
    openingHoursSpecification: [
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        opens: "00:00",
        closes: "23:59",
      },
    ],
    serviceType: [
      "Emergency Electrician Surrey",
      "Residential Electrical Services",
      "Commercial Electrical Services",
      "Industrial Electrical Services",
      "EV Charger Installation",
      "Electrical Panel Upgrades",
    ],
  };

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />;
}

function SectionLabel({ number, label }: { number: string; label: string }) {
  return (
    <div className="mb-6 flex items-center gap-4 text-xs font-black uppercase tracking-[0.28em] text-[#f7c14a]">
      <span>{number}</span>
      <span className="h-px w-12 bg-[#f7c14a]/50" />
      <span>{label}</span>
    </div>
  );
}

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.75, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

function Tracer({ className = "", mirror = false }: { className?: string; mirror?: boolean }) {
  return (
    <div
      data-module="tracer"
      className={`standard_block_path floating_left w-embed pointer-events-none absolute ${className}`}
      style={{ transform: mirror ? "scaleX(-1)" : undefined }}
      aria-hidden="true"
    >
      <svg xmlns="http://www.w3.org/2000/svg" width="315" height="214" fill="none" viewBox="0 0 315 214" className="h-full w-full overflow-visible">
        <g className="tracer-right_tall">
          <path
            stroke="#171B33"
            d="M310.976 122.84h-61v89.5h-118.5v-208H5.933"
            className="backer"
            opacity=".75"
            style={{ strokeDashoffset: 0, strokeDasharray: "602.543px, 0.1px" }}
          />
          <motion.path
            stroke="#f7c14a"
            strokeOpacity="1"
            strokeWidth="3"
            d="M310.976 122.84h-61v89.5h-118.5v-208H5.934"
            className="tracer"
            initial={{ strokeDashoffset: 0 }}
            animate={{ strokeDashoffset: [-20, -603] }}
            transition={{ duration: 3.8, repeat: Infinity, ease: "linear" }}
            style={{ strokeDasharray: "34px, 568px", opacity: 1, filter: "drop-shadow(0 0 10px rgba(247,193,74,.85))" }}
          />
          <motion.path
            stroke="#2D4CFF"
            strokeOpacity="1"
            strokeWidth="3"
            d="M310.976 122.84h-61v89.5h-118.5v-208H5.934"
            className="tracer"
            initial={{ strokeDashoffset: -220 }}
            animate={{ strokeDashoffset: [-220, -803] }}
            transition={{ duration: 5.2, repeat: Infinity, ease: "linear" }}
            style={{ strokeDasharray: "4px, 598px", opacity: 1, filter: "drop-shadow(0 0 8px rgba(45,76,255,.9))" }}
          />
          <motion.path
            fill="#f7c14a"
            d="M309.476 125.34v-5h5v5h-5Z"
            className="dot"
            animate={{ opacity: [0.45, 1, 0.45], scale: [0.9, 1.35, 0.9] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
            style={{ transformOrigin: "312px 123px", filter: "drop-shadow(0 0 12px rgba(247,193,74,1))" }}
          />
          <path fill="url(#aer)" d="M.124.34h107.021v38.862H.124V.34Z" className="fade" />
        </g>
        <defs>
          <linearGradient id="aer" x1="17.751" x2="107.145" y1="24.296" y2="24.296" className="a" gradientUnits="userSpaceOnUse">
            <stop stopColor="#070707" />
            <stop offset="1" stopColor="#070707" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function PowerCore3D() {
  return (
    <motion.div
      className="pointer-events-none absolute right-[4%] top-[18%] hidden h-[420px] w-[420px] lg:block"
      initial={{ opacity: 0, rotateX: 18, rotateY: -28, scale: 0.86 }}
      animate={{ opacity: 1, rotateX: [18, 23, 18], rotateY: [-28, -16, -28], y: [0, -18, 0] }}
      transition={{ opacity: { duration: 1 }, rotateX: { duration: 7, repeat: Infinity, ease: "easeInOut" }, rotateY: { duration: 7, repeat: Infinity, ease: "easeInOut" }, y: { duration: 5, repeat: Infinity, ease: "easeInOut" } }}
      style={{ transformStyle: "preserve-3d", perspective: 900 }}
      aria-hidden="true"
    >
      <div className="absolute inset-12 rounded-[3rem] border border-[#f7c14a]/35 bg-[#f7c14a]/10 shadow-[0_0_90px_rgba(247,193,74,.28)] backdrop-blur-md" style={{ transform: "translateZ(70px) rotate(8deg)" }} />
      <div className="absolute inset-24 rounded-[2rem] border border-white/15 bg-white/[0.055] shadow-[0_30px_90px_rgba(0,0,0,.55)]" style={{ transform: "translateZ(135px) rotate(-10deg)" }} />
      <div className="absolute left-28 top-12 h-28 w-28 border border-[#2D4CFF]/45 bg-[#2D4CFF]/15 shadow-[0_0_45px_rgba(45,76,255,.28)]" style={{ transform: "translateZ(185px) rotate(14deg)" }} />
      <div className="absolute bottom-20 right-20 flex h-32 w-32 items-center justify-center rounded-full border border-[#f7c14a]/50 bg-black/50 text-[#f7c14a] shadow-[0_0_55px_rgba(247,193,74,.32)]" style={{ transform: "translateZ(220px)" }}>
        <Zap className="h-14 w-14" />
      </div>
    </motion.div>
  );
}

function PremiumPlate({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative overflow-hidden border border-white/10 bg-white/[0.035] shadow-[0_35px_120px_rgba(0,0,0,.35)] backdrop-blur-xl ${className}`}>
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#f7c14a]/70 to-transparent" />
      <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-[#f7c14a]/10 blur-3xl" />
      {children}
    </div>
  );
}

function CursorGlow() {
  const mouseX = useMotionValue(-400);
  const mouseY = useMotionValue(-400);
  const background = useMotionTemplate`radial-gradient(520px circle at ${mouseX}px ${mouseY}px, rgba(247,193,74,0.16), rgba(45,76,255,0.055) 32%, transparent 68%)`;

  useEffect(() => {
    const move = (event: PointerEvent) => {
      mouseX.set(event.clientX);
      mouseY.set(event.clientY);
    };
    window.addEventListener("pointermove", move, { passive: true });
    return () => window.removeEventListener("pointermove", move);
  }, [mouseX, mouseY]);

  return <motion.div className="pointer-events-none fixed inset-0 z-[35] hidden mix-blend-screen lg:block" style={{ background }} aria-hidden="true" />;
}

function FloatingQuickActions() {
  return (
    <motion.div
      className="fixed bottom-5 right-5 z-50 hidden flex-col gap-3 md:flex"
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1, duration: 0.6 }}
    >
      <a href="tel:+17783444567" className="group flex h-14 w-14 items-center justify-center rounded-full border border-[#f7c14a]/45 bg-[#f7c14a] text-black shadow-[0_0_45px_rgba(247,193,74,.28)] transition hover:scale-110 hover:bg-white" aria-label="Call GK Electric">
        <Phone className="h-5 w-5 transition group-hover:rotate-12" />
      </a>
      <Link to="/contact" className="group flex h-14 w-14 items-center justify-center rounded-full border border-white/15 bg-black/70 text-[#f7c14a] shadow-[0_20px_60px_rgba(0,0,0,.35)] backdrop-blur-xl transition hover:scale-110 hover:border-[#f7c14a] hover:bg-[#f7c14a] hover:text-black" aria-label="Get a free estimate">
        <ArrowRight className="h-5 w-5 transition group-hover:-rotate-45" />
      </Link>
    </motion.div>
  );
}

function MagneticCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const rotateX = useMotionValue(0);
  const rotateY = useMotionValue(0);

  return (
    <motion.div
      className={className}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      onMouseMove={(event) => {
        const rect = event.currentTarget.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        rotateX.set(((y / rect.height) - 0.5) * -7);
        rotateY.set(((x / rect.width) - 0.5) * 7);
      }}
      onMouseLeave={() => {
        rotateX.set(0);
        rotateY.set(0);
      }}
      transition={{ type: "spring", stiffness: 260, damping: 22 }}
    >
      {children}
    </motion.div>
  );
}

function MarqueeBand() {
  const items = [...tickerItems, ...tickerItems];
  return (
    <section className="relative overflow-hidden border-y border-[#f7c14a]/20 bg-[#f7c14a] py-4 text-black">
      <motion.div
        className="flex w-max gap-10 whitespace-nowrap"
        animate={{ x: [0, -900] }}
        transition={{ duration: 22, repeat: Infinity, ease: "linear" }}
      >
        {items.map((item, index) => (
          <div key={`${item}-${index}`} className="flex items-center gap-10 text-sm font-black uppercase tracking-[0.22em]">
            <span>{item}</span>
            <Zap className="h-4 w-4" />
          </div>
        ))}
      </motion.div>
    </section>
  );
}

function ScrollMorphShowcase() {
  const { scrollYProgress } = useScroll();
  const rotate = useTransform(scrollYProgress, [0.12, 0.42], [-10, 18]);
  const y = useTransform(scrollYProgress, [0.12, 0.42], [90, -80]);
  const scale = useTransform(scrollYProgress, [0.12, 0.42], [0.92, 1.06]);

  return (
    <section className="relative overflow-hidden border-y border-white/10 bg-black py-24 md:py-32">
      <div className="absolute inset-0 opacity-[0.06] [background-image:linear-gradient(90deg,#fff_1px,transparent_1px),linear-gradient(#fff_1px,transparent_1px)] [background-size:88px_88px]" />
      <Tracer className="right-10 top-14 h-[214px] w-[315px] opacity-45" mirror />
      <div className="relative mx-auto grid max-w-[1480px] gap-12 px-5 md:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
        <Reveal>
          <SectionLabel number="01B" label="Modern electrical interface" />
          <h2 className="font-display text-5xl font-black uppercase leading-[0.86] tracking-[-0.06em] md:text-8xl">
            Designed for speed, safety and future capacity.
          </h2>
          <p className="mt-8 max-w-2xl text-lg leading-relaxed text-white/64">
            A premium electrical experience starts before the first wire is installed: clear diagnosis, accurate planning, clean execution and systems that are ready for EV charging, smart controls and heavier property demand.
          </p>
        </Reveal>
        <div className="relative min-h-[540px] [perspective:1200px]">
          <motion.div className="absolute inset-12 rounded-[3rem] border border-[#f7c14a]/25 bg-[#f7c14a]/10 shadow-[0_0_120px_rgba(247,193,74,.18)]" style={{ rotate, y, scale }} />
          <motion.div className="absolute left-4 top-16 h-72 w-[58%] overflow-hidden border border-white/10 bg-white/[0.045] shadow-[0_50px_140px_rgba(0,0,0,.45)] backdrop-blur-xl" style={{ y: useTransform(scrollYProgress, [0.12, 0.42], [-30, 70]), rotate: useTransform(scrollYProgress, [0.12, 0.42], [8, -5]) }}>
            <img src={commercialImage} alt="Commercial electrical systems" className="h-full w-full object-cover opacity-70 grayscale" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
            <div className="absolute bottom-5 left-5 font-display text-4xl font-black uppercase leading-none">Commercial</div>
          </motion.div>
          <motion.div className="absolute bottom-12 right-4 h-80 w-[62%] overflow-hidden border border-white/10 bg-white/[0.045] shadow-[0_50px_140px_rgba(0,0,0,.45)] backdrop-blur-xl" style={{ y: useTransform(scrollYProgress, [0.12, 0.42], [80, -40]), rotate: useTransform(scrollYProgress, [0.12, 0.42], [-7, 6]) }}>
            <img src={residentialImage} alt="Residential electrical services" className="h-full w-full object-cover opacity-74 grayscale" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/82 to-transparent" />
            <div className="absolute bottom-5 left-5 font-display text-4xl font-black uppercase leading-none">Residential</div>
          </motion.div>
          <motion.div className="absolute left-[32%] top-[34%] flex h-32 w-32 items-center justify-center rounded-full border border-[#f7c14a]/45 bg-black/80 text-[#f7c14a] shadow-[0_0_80px_rgba(247,193,74,.28)] backdrop-blur-xl" animate={{ rotate: 360 }} transition={{ duration: 16, repeat: Infinity, ease: "linear" }}>
            <Zap className="h-14 w-14" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function ScrollProgressRail({ progress }: { progress: ReturnType<typeof useSpring> }) {
  return (
    <div className="fixed left-4 top-1/2 z-40 hidden -translate-y-1/2 flex-col items-center gap-4 xl:flex" aria-hidden="true">
      <div className="text-[10px] font-black uppercase tracking-[0.24em] text-white/35 [writing-mode:vertical-rl]">scroll</div>
      <div className="relative h-56 w-px overflow-hidden bg-white/15">
        <motion.div className="absolute left-0 top-0 h-full w-px origin-top bg-[#f7c14a] shadow-[0_0_16px_rgba(247,193,74,.9)]" style={{ scaleY: progress }} />
      </div>
      <div className="h-2 w-2 rounded-full bg-[#f7c14a] shadow-[0_0_18px_rgba(247,193,74,1)]" />
    </div>
  );
}

function StickyServiceJourney() {
  const steps = [
    { title: "Emergency", text: "Immediate troubleshooting for outages, burning smells, sparks, buzzing panels and tripping breakers.", icon: Flame, image: heroImage },
    { title: "Residential", text: "Home wiring, lighting, panel upgrades, renovations, safety devices and EV-ready circuits.", icon: Home, image: residentialImage },
    { title: "Commercial", text: "Tenant improvements, LED retrofits, commercial panels, repairs and business-friendly scheduling.", icon: Building2, image: commercialImage },
    { title: "Industrial", text: "Three-phase power, machinery wiring, facility upgrades, controls, shutdown work and maintenance.", icon: Factory, image: industrialImage },
  ];

  return (
    <section className="relative border-y border-white/10 bg-black py-24 md:py-32">
      <Tracer className="right-8 top-28 h-[214px] w-[315px] opacity-40" mirror />
      <div className="mx-auto grid max-w-[1480px] gap-10 px-5 md:px-8 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="lg:sticky lg:top-28 lg:h-[calc(100vh-8rem)]">
          <SectionLabel number="02B" label="Scroll journey" />
          <h2 className="font-display text-5xl font-black uppercase leading-[0.86] tracking-[-0.06em] md:text-8xl">
            One team across every electrical need.
          </h2>
          <p className="mt-8 max-w-xl text-lg leading-relaxed text-white/62">
            Scroll through the service path: emergency response, residential wiring, commercial systems and industrial infrastructure connected by one licensed electrical contractor.
          </p>
          <div className="mt-10 hidden h-[28vh] items-end lg:flex">
            <motion.div
              className="h-28 w-28 rounded-full border border-[#f7c14a]/40 bg-[#f7c14a]/10 shadow-[0_0_80px_rgba(247,193,74,.18)]"
              animate={{ rotate: 360 }}
              transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
            />
          </div>
        </div>

        <div className="space-y-8">
          {steps.map((step, index) => (
            <motion.article
              key={step.title}
              className="group sticky top-24 min-h-[72vh] overflow-hidden border border-white/10 bg-[#0b0b0b] shadow-[0_35px_120px_rgba(0,0,0,.35)]"
              style={{ zIndex: index + 1 }}
              initial={{ opacity: 0.82, scale: 0.96 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ amount: 0.6 }}
              transition={{ duration: 0.55 }}
            >
              <img src={step.image} alt={`${step.title} electrical service`} className="absolute inset-0 h-full w-full object-cover opacity-34 grayscale transition duration-700 group-hover:scale-105 group-hover:grayscale-0" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/72 to-black/20" />
              <div className="relative flex min-h-[72vh] flex-col justify-end p-7 md:p-10">
                <div className="mb-8 flex items-center justify-between">
                  <div className="flex h-16 w-16 items-center justify-center border border-[#f7c14a]/45 bg-[#f7c14a] text-black shadow-[0_0_45px_rgba(247,193,74,.25)]">
                    <step.icon className="h-8 w-8" />
                  </div>
                  <div className="font-display text-8xl font-black text-white/10">0{index + 1}</div>
                </div>
                <h3 className="font-display text-5xl font-black uppercase leading-none tracking-[-0.055em] md:text-7xl">{step.title}</h3>
                <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/66">{step.text}</p>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

function StickyProjectShowcase() {
  return (
    <section className="relative overflow-visible bg-[#080808] py-24 md:py-32">
      <Tracer className="left-4 top-12 h-[214px] w-[315px] opacity-30" />
      <div className="mx-auto grid max-w-[1480px] gap-12 px-5 md:px-8 lg:grid-cols-[0.78fr_1.22fr]">
        <div className="lg:sticky lg:top-28 lg:h-fit">
          <SectionLabel number="07" label="Featured projects" />
          <h2 className="font-display text-5xl font-black uppercase leading-[0.88] tracking-[-0.055em] md:text-8xl">Proof in the field.</h2>
          <p className="mt-8 max-w-xl text-lg leading-relaxed text-white/64">
            From South Surrey luxury homes to Surrey Central offices and Port Kells warehouses, GK Electric delivers clean, inspection-ready electrical work across every property type.
          </p>
          <Link to="/projects" className="mt-9 inline-flex items-center gap-3 rounded-full border border-[#f7c14a]/50 px-6 py-4 text-sm font-black uppercase tracking-[0.16em] text-[#f7c14a] transition hover:bg-[#f7c14a] hover:text-black">
            View Projects <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="space-y-5">
          {projects.slice(0, 6).map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.65, delay: index * 0.035 }}
              className="group"
            >
              <Link to="/projects" className="grid overflow-hidden border border-white/10 bg-white/[0.035] shadow-[0_30px_100px_rgba(0,0,0,.28)] transition duration-500 hover:-translate-y-2 hover:border-[#f7c14a]/45 md:grid-cols-[0.48fr_0.52fr]">
                <div className="relative min-h-72 overflow-hidden">
                  <img src={project.image} alt={project.title} className="absolute inset-0 h-full w-full object-cover opacity-75 grayscale transition duration-700 group-hover:scale-110 group-hover:grayscale-0" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                </div>
                <div className="p-7">
                  <div className="mb-8 flex items-center justify-between text-xs font-black uppercase tracking-[0.16em] text-white/45">
                    <span className="text-[#f7c14a]">0{index + 1}</span>
                    <span>{project.location}</span>
                  </div>
                  <h3 className="font-display text-4xl font-black uppercase leading-none tracking-[-0.04em] text-white">{project.title}</h3>
                  <p className="mt-5 text-sm leading-relaxed text-white/56">{project.description}</p>
                  <div className="mt-7 flex flex-wrap gap-2">
                    {project.features.slice(0, 3).map((feature) => (
                      <span key={feature} className="border border-white/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-white/45">{feature}</span>
                    ))}
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function NewHomePage() {
  const { scrollYProgress } = useScroll();
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });
  const heroY = useTransform(scrollYProgress, [0, 0.28], [0, -120]);
  const heroScale = useTransform(scrollYProgress, [0, 0.28], [1.05, 1]);
  const headerBg = useTransform(scrollYProgress, [0, 0.08], ["rgba(0,0,0,0.35)", "rgba(0,0,0,0.82)"]);
  const headerBlur = useTransform(scrollYProgress, [0, 0.08], ["blur(12px)", "blur(24px)"]);

  return (
    <main className="min-h-screen bg-[#070707] text-white selection:bg-[#f7c14a] selection:text-black">
      <JsonLd />
      <CursorGlow />
      <FloatingQuickActions />
      <ScrollProgressRail progress={smoothProgress} />

      <motion.header className="fixed inset-x-0 top-0 z-50 border-b border-white/10" style={{ backgroundColor: headerBg, backdropFilter: headerBlur, WebkitBackdropFilter: headerBlur }}>
        <div className="mx-auto flex h-20 max-w-[1480px] items-center justify-between px-5 md:px-8">
          <a href="#home" className="flex items-center gap-3" aria-label="GK Electric new home">
            <img src={gkLogo} alt="GK Electric logo" className="h-12 w-12 rounded-full border border-[#f7c14a]/35 object-contain shadow-[0_0_30px_rgba(247,193,74,0.22)]" />
            <div className="leading-none">
              <div className="font-display text-xl font-black uppercase tracking-[0.18em] text-white">GK Electric</div>
              <div className="mt-1 text-[10px] font-bold uppercase tracking-[0.28em] text-[#f7c14a]">Surrey Licensed Electricians</div>
            </div>
          </a>

          <nav className="hidden items-center gap-6 xl:flex">
            {navItems.map((item) => (
              <a key={item.href} href={item.href} className="group flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-white/64 transition hover:text-white">
                <span className="text-[#f7c14a]">{item.number}</span>
                <span className="relative after:absolute after:-bottom-2 after:left-0 after:h-px after:w-0 after:bg-[#f7c14a] after:transition-all after:duration-300 group-hover:after:w-full">{item.label}</span>
              </a>
            ))}
          </nav>

          <a href="tel:+17783444567" className="group inline-flex items-center gap-3 rounded-full border border-[#f7c14a]/40 bg-[#f7c14a] px-4 py-3 text-xs font-black uppercase tracking-[0.16em] text-black shadow-[0_0_30px_rgba(247,193,74,0.2)] transition hover:bg-white">
            <Phone className="h-4 w-4 transition group-hover:rotate-12" />
            <span className="hidden sm:inline">Emergency Call</span>
          </a>
        </div>
      </motion.header>

      <section id="home" className="relative flex min-h-screen items-end overflow-hidden pt-28">
        <Tracer className="left-[3%] top-[16%] h-[214px] w-[315px] opacity-70 mix-blend-screen" />
        <Tracer className="bottom-[12%] right-[7%] h-[214px] w-[315px] opacity-50 mix-blend-screen" mirror />
        <PowerCore3D />
        <motion.img
          src={heroImage}
          alt="Licensed Surrey electrician working on electrical wiring"
          style={{ y: heroY, scale: heroScale }}
          className="absolute inset-0 h-full w-full object-cover opacity-38 grayscale"
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_72%_20%,rgba(247,193,74,0.22),transparent_32%),linear-gradient(90deg,#070707_0%,rgba(7,7,7,0.82)_42%,rgba(7,7,7,0.45)_100%)]" />
        <div className="absolute inset-0 opacity-[0.075] [background-image:linear-gradient(90deg,#fff_1px,transparent_1px),linear-gradient(#fff_1px,transparent_1px)] [background-size:72px_72px]" />
        <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-[#070707] to-transparent" />

        <div className="relative z-10 mx-auto grid w-full max-w-[1480px] gap-10 px-5 pb-14 md:px-8 lg:grid-cols-[1.15fr_0.85fr] lg:pb-20">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="mb-7 inline-flex items-center gap-3 rounded-full border border-[#f7c14a]/35 bg-[#f7c14a]/10 px-4 py-2 text-xs font-black uppercase tracking-[0.24em] text-[#f7c14a]"
            >
              <span className="h-2 w-2 rounded-full bg-[#f7c14a] shadow-[0_0_18px_#f7c14a]" />
              24/7 Emergency Electrician in Surrey
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 36 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
              className="max-w-5xl font-display text-[clamp(3.55rem,9.4vw,10.8rem)] font-black uppercase leading-[0.82] tracking-[-0.075em] text-white"
            >
              Building Surrey's Electrical Backbone
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 26 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.18 }}
              className="mt-8 max-w-3xl text-lg leading-relaxed text-white/72 md:text-xl"
            >
              Licensed residential, commercial and industrial electricians for Surrey and the Lower Mainland. Emergency repairs, panel upgrades, EV chargers, permits and code-compliant electrical work delivered with speed and precision.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.28 }}
              className="mt-10 flex flex-col gap-4 sm:flex-row"
            >
              <a href="tel:+17783444567" className="inline-flex items-center justify-center gap-3 rounded-full bg-[#f7c14a] px-7 py-4 text-sm font-black uppercase tracking-[0.18em] text-black transition hover:bg-white">
                Call +1 (778) 344-4567 <Phone className="h-4 w-4" />
              </a>
              <Link to="/contact" className="inline-flex items-center justify-center gap-3 rounded-full border border-white/20 px-7 py-4 text-sm font-black uppercase tracking-[0.18em] text-white transition hover:border-[#f7c14a] hover:text-[#f7c14a]">
                Get Free Estimate <ArrowRight className="h-4 w-4" />
              </Link>
            </motion.div>
          </div>

          <motion.aside
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.35 }}
            className="relative self-end border border-white/12 bg-white/[0.045] p-5 shadow-[0_40px_120px_rgba(0,0,0,.45)] backdrop-blur-xl md:p-7"
          >
            <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-[#f7c14a]/20 blur-2xl" />
            <div className="mb-5 flex items-center justify-between border-b border-white/10 pb-5">
              <span className="text-xs font-black uppercase tracking-[0.24em] text-white/55">Last updated</span>
              <span className="font-display text-5xl font-black text-[#f7c14a]">2026</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
              {proofStats.map((stat) => (
                <div key={stat.label} className="border border-white/10 bg-black/30 p-5 transition hover:border-[#f7c14a]/45 hover:bg-[#f7c14a]/10">
                  <div className="font-display text-4xl font-black uppercase text-white">{stat.value}</div>
                  <div className="mt-2 text-xs font-bold uppercase tracking-[0.16em] text-white/55">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.aside>
        </div>
      </section>

      <MarqueeBand />

      <section className="relative overflow-hidden border-y border-white/10 bg-[#0b0b0b] py-14">
        <Tracer className="-right-20 top-4 h-[214px] w-[315px] opacity-35" mirror />
        <div className="mx-auto grid max-w-[1480px] gap-8 px-5 md:px-8 lg:grid-cols-[0.85fr_1.15fr]">
          <Reveal>
            <SectionLabel number="01" label="Our conviction" />
            <h2 className="font-display text-4xl font-black uppercase leading-none tracking-[-0.04em] md:text-7xl">
              Safe power is the foundation of every Surrey property.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="text-lg leading-relaxed text-white/68 md:text-xl">
              GK Electric focuses on practical electrical infrastructure: homes that feel safe, businesses that stay open, industrial facilities that keep running, and emergency calls that get handled before hazards become expensive problems.
            </p>
            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              {["Licensed", "Insured", "Code-Compliant"].map((item) => (
                <div key={item} className="flex items-center gap-3 border border-white/10 bg-white/[0.035] p-4 text-sm font-black uppercase tracking-[0.14em] text-white/76">
                  <CheckCircle2 className="h-5 w-5 text-[#f7c14a]" /> {item}
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <ScrollMorphShowcase />

      <section className="relative overflow-hidden border-b border-white/10 bg-black py-8">
        <div className="mx-auto grid max-w-[1480px] divide-y divide-white/10 px-5 md:px-8 lg:grid-cols-4 lg:divide-x lg:divide-y-0">
          {trustHighlights.map((item, index) => (
            <Reveal key={item.label} delay={index * 0.04}>
              <div className="group flex min-h-36 items-center gap-4 px-2 py-7 transition hover:bg-[#f7c14a]/[0.055] lg:px-7">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center border border-[#f7c14a]/35 bg-[#f7c14a]/10 text-[#f7c14a] shadow-[0_0_35px_rgba(247,193,74,.12)] transition duration-500 group-hover:rotate-6 group-hover:bg-[#f7c14a] group-hover:text-black">
                  <item.icon className="h-7 w-7" />
                </div>
                <div>
                  <h2 className="font-display text-xl font-black uppercase leading-none tracking-[-0.02em] text-white">{item.label}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-white/52">{item.detail}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="relative overflow-hidden py-24 md:py-32">
        <Tracer className="right-10 top-24 h-[214px] w-[315px] opacity-35" mirror />
        <div className="mx-auto grid max-w-[1480px] gap-14 px-5 md:px-8 lg:grid-cols-[0.92fr_1.08fr] lg:items-center">
          <Reveal>
            <div className="relative [perspective:1100px]">
              <motion.div
                className="relative overflow-hidden border border-white/10 bg-white/[0.035] shadow-[0_45px_140px_rgba(0,0,0,.45)]"
                whileHover={{ rotateY: -4, rotateX: 3, y: -8 }}
                transition={{ duration: 0.45 }}
                style={{ transformStyle: "preserve-3d" }}
              >
                <img src={ourStory} alt="GK Electric professional electrician at work" className="aspect-[4/3] w-full object-cover opacity-82 grayscale transition duration-700 hover:grayscale-0" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6 flex items-center gap-4 border border-white/15 bg-black/70 p-4 backdrop-blur-xl">
                  <img src={tsbcLogo} alt="Technical Safety BC logo" className="h-14 w-14 object-contain" loading="lazy" />
                  <div>
                    <div className="text-xs font-black uppercase tracking-[0.2em] text-[#f7c14a]">TSBC Licence</div>
                    <div className="font-display text-2xl font-black uppercase text-white"># LEL0209793</div>
                  </div>
                </div>
              </motion.div>
            </div>
          </Reveal>

          <Reveal delay={0.08}>
            <SectionLabel number="01A" label="Who we are" />
            <h2 className="font-display text-5xl font-black uppercase leading-[0.88] tracking-[-0.055em] md:text-8xl">
              Powering British Columbia with professional electrical service.
            </h2>
            <div className="mt-8 space-y-5 text-lg leading-relaxed text-white/66">
              <p>
                GK Electric delivers trusted residential, commercial and industrial electrical services across British Columbia. Our licensed electricians provide electrical repairs, installations, upgrades, maintenance, panel upgrades, EV charger installations, lighting solutions and complete electrical systems.
              </p>
              <p>
                We are more than electricians — we are partners in powering homes, businesses and industrial facilities with safe, code-compliant electrical work backed by experience, reliability and clean workmanship.
              </p>
            </div>
            <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4">
              {[
                { value: "1000+", label: "Projects" },
                { value: "100%", label: "Satisfaction" },
                { value: "24/7", label: "Emergency" },
                { value: "BC", label: "Licensed" },
              ].map((stat) => (
                <div key={stat.label} className="border border-white/10 bg-white/[0.035] p-5 text-center transition hover:border-[#f7c14a]/45 hover:bg-[#f7c14a]/10">
                  <div className="font-display text-4xl font-black text-[#f7c14a]">{stat.value}</div>
                  <div className="mt-2 text-xs font-black uppercase tracking-[0.18em] text-white/50">{stat.label}</div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section id="services" className="relative overflow-hidden py-24 md:py-32">
        <Tracer className="left-0 top-20 h-[214px] w-[315px] opacity-30" />
        <div className="mx-auto max-w-[1480px] px-5 md:px-8">
          <Reveal>
            <SectionLabel number="02" label="Three service layers. One objective." />
            <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
              <h2 className="font-display text-5xl font-black uppercase leading-[0.88] tracking-[-0.055em] md:text-8xl">
                Electrical services built for scale.
              </h2>
              <p className="max-w-2xl text-lg leading-relaxed text-white/64">
                A clear electrical delivery model for safer homes, business continuity and heavy-duty facility power across Surrey and the Lower Mainland.
              </p>
            </div>
          </Reveal>

          <div className="mt-14 grid gap-5 lg:grid-cols-3">
            {serviceLayers.map((service, index) => (
              <Reveal key={service.title} delay={index * 0.08}>
                <MagneticCard className="group h-full">
                  <Link to={service.href} className="block h-full overflow-hidden border border-white/10 bg-white/[0.035] shadow-[0_25px_90px_rgba(0,0,0,.25)] transition duration-500 [transform-style:preserve-3d] hover:-translate-y-2 hover:border-[#f7c14a]/50 hover:bg-[#f7c14a]/[0.06] hover:shadow-[0_40px_120px_rgba(247,193,74,.12)]">
                    <div className="relative h-72 overflow-hidden">
                      <img src={service.image} alt={`${service.title} electrical service`} className="h-full w-full object-cover opacity-62 grayscale transition duration-700 group-hover:scale-110 group-hover:grayscale-0" loading="lazy" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/35 to-transparent" />
                      <div className="absolute left-6 top-6 flex h-14 w-14 items-center justify-center border border-[#f7c14a]/55 bg-[#f7c14a] text-black shadow-[0_0_35px_rgba(247,193,74,.35)] transition duration-500 group-hover:rotate-6">
                        <service.icon className="h-7 w-7" />
                      </div>
                      <div className="absolute bottom-6 right-6 font-display text-7xl font-black text-white/12">{service.number}</div>
                    </div>
                    <div className="p-7">
                      <div className="text-xs font-black uppercase tracking-[0.24em] text-[#f7c14a]">Layer {service.number}</div>
                      <h3 className="mt-3 font-display text-4xl font-black uppercase leading-none tracking-[-0.04em]">{service.title}</h3>
                      <p className="mt-3 text-sm font-bold uppercase tracking-[0.16em] text-white/45">{service.phrase}</p>
                      <ul className="mt-7 space-y-3">
                        {service.points.map((point) => (
                          <li key={point} className="flex items-center gap-3 text-sm text-white/70">
                            <span className="h-1.5 w-1.5 bg-[#f7c14a]" /> {point}
                          </li>
                        ))}
                      </ul>
                      <div className="mt-8 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.2em] text-[#f7c14a]">
                        View service <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                      </div>
                    </div>
                  </Link>
                </MagneticCard>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.1}>
            <PremiumPlate className="mt-8 grid gap-0 lg:grid-cols-[0.82fr_1.18fr]">
              <div className="relative min-h-[360px] overflow-hidden">
                <img src={evImage} alt="EV charger installation in Surrey garage" className="absolute inset-0 h-full w-full object-cover opacity-75 grayscale transition duration-700 hover:scale-105 hover:grayscale-0" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-r from-black/45 to-black/80 lg:bg-gradient-to-t" />
                <div className="absolute left-7 top-7 inline-flex items-center gap-2 bg-[#f7c14a] px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-black">
                  <PlugZap className="h-4 w-4" /> High Demand
                </div>
              </div>
              <div className="p-8 md:p-12">
                <div className="text-xs font-black uppercase tracking-[0.24em] text-[#f7c14a]">EV charger installation</div>
                <h3 className="mt-4 font-display text-4xl font-black uppercase leading-none tracking-[-0.04em] md:text-6xl">Fast, safe EV charging for homes and businesses.</h3>
                <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/62">
                  Home and commercial EV chargers compatible with major EV brands. GK Electric checks panel capacity, installs dedicated circuits and completes clean, code-ready charging setups.
                </p>
                <Link to="/ev-charger" className="mt-8 inline-flex items-center gap-3 rounded-full border border-[#f7c14a]/55 px-6 py-4 text-sm font-black uppercase tracking-[0.16em] text-[#f7c14a] transition hover:bg-[#f7c14a] hover:text-black">
                  More Information <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </PremiumPlate>
          </Reveal>
        </div>
      </section>

      <section className="relative overflow-hidden border-y border-white/10 bg-[#0c0c0c] py-24 md:py-32">
        <Tracer className="right-8 top-12 h-[214px] w-[315px] opacity-30" mirror />
        <div className="mx-auto grid max-w-[1480px] gap-12 px-5 md:px-8 lg:grid-cols-[0.82fr_1.18fr]">
          <Reveal>
            <SectionLabel number="02A" label="Permits & compliance" />
            <h2 className="font-display text-5xl font-black uppercase leading-[0.88] tracking-[-0.055em] md:text-8xl">
              Permits and code requirements made simple.
            </h2>
            <p className="mt-8 text-lg leading-relaxed text-white/64">
              Electrical work must be safe, inspected and properly documented. GK Electric handles permit applications, inspection coordination, deficiency corrections and final approvals so your project stays compliant and on schedule.
            </p>
            <Link to="/permits-regulatory-compliance" className="mt-8 inline-flex items-center gap-3 rounded-full bg-[#f7c14a] px-7 py-4 text-sm font-black uppercase tracking-[0.16em] text-black transition hover:bg-white">
              Permit Support <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>
          <div className="grid gap-3 sm:grid-cols-2">
            {complianceItems.map((item, index) => (
              <Reveal key={item} delay={index * 0.035}>
                <div className="flex min-h-24 items-center gap-4 border border-white/10 bg-white/[0.035] p-5 shadow-[0_20px_70px_rgba(0,0,0,.18)] transition hover:-translate-y-1 hover:border-[#f7c14a]/45 hover:bg-[#f7c14a]/10">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center border border-[#f7c14a]/35 bg-[#f7c14a]/10 text-[#f7c14a]">
                    <FileText className="h-5 w-5" />
                  </div>
                  <span className="text-sm font-black uppercase tracking-[0.12em] text-white/78">{item}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <StickyServiceJourney />

      <section id="emergency" className="relative overflow-hidden border-y border-[#f7c14a]/20 bg-[#f7c14a] py-24 text-black md:py-32">
        <div className="absolute inset-0 opacity-15 [background-image:linear-gradient(90deg,#000_1px,transparent_1px),linear-gradient(#000_1px,transparent_1px)] [background-size:54px_54px]" />
        <Tracer className="right-8 top-10 h-[214px] w-[315px] opacity-45 invert" mirror />
        <div className="relative mx-auto grid max-w-[1480px] gap-12 px-5 md:px-8 lg:grid-cols-[0.95fr_1.05fr]">
          <Reveal>
            <div className="mb-6 flex items-center gap-4 text-xs font-black uppercase tracking-[0.28em] text-black/70">
              <span>03</span><span className="h-px w-12 bg-black/40" /><span>Emergency services</span>
            </div>
            <h2 className="font-display text-5xl font-black uppercase leading-[0.86] tracking-[-0.06em] md:text-8xl">
              When power fails, speed matters.
            </h2>
            <p className="mt-8 max-w-2xl text-lg font-medium leading-relaxed text-black/72">
              For emergency electrician searches in Surrey, the message is simple: call GK Electric when you smell burning, lose power, hear buzzing from a panel, see sparks, or experience repeated breaker trips.
            </p>
            <a href="tel:+17783444567" className="mt-9 inline-flex items-center gap-3 rounded-full bg-black px-8 py-4 text-sm font-black uppercase tracking-[0.18em] text-white transition hover:bg-white hover:text-black">
              24/7 Emergency Call <Phone className="h-4 w-4" />
            </a>
          </Reveal>

          <div className="grid gap-4 sm:grid-cols-2">
            {emergencyProblems.map((problem, index) => (
              <Reveal key={problem.title} delay={index * 0.06}>
                <div className="h-full border border-black/15 bg-black/[0.055] p-6 shadow-[0_24px_70px_rgba(0,0,0,.12)] transition duration-500 [transform-style:preserve-3d] hover:-translate-y-2 hover:rotate-x-2 hover:bg-black hover:text-white hover:shadow-[0_38px_95px_rgba(0,0,0,.24)]">
                  <problem.icon className="mb-8 h-9 w-9" />
                  <h3 className="font-display text-3xl font-black uppercase leading-none tracking-[-0.03em]">{problem.title}</h3>
                  <p className="mt-4 text-sm font-medium leading-relaxed opacity-75">{problem.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section id="surrey" className="relative overflow-hidden py-24 md:py-32">
        <Tracer className="bottom-12 left-4 h-[214px] w-[315px] opacity-25" />
        <div className="mx-auto max-w-[1480px] px-5 md:px-8">
          <Reveal>
            <SectionLabel number="04" label="Surrey service area" />
            <div className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-start">
              <div>
                <h2 className="font-display text-5xl font-black uppercase leading-[0.88] tracking-[-0.055em] md:text-8xl">
                  Surrey electricians with local coverage.
                </h2>
                <p className="mt-8 text-lg leading-relaxed text-white/65">
                  GK Electric serves Surrey homes, businesses and facilities with emergency electrical repair, panel upgrades, EV charger installation, lighting, wiring, permits and commercial electrical maintenance.
                </p>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {seoAreas.map((area, index) => (
                  <Reveal key={area} delay={index * 0.025}>
                    <div className="flex items-center gap-3 border border-white/10 bg-white/[0.035] p-4 text-sm font-black uppercase tracking-[0.14em] text-white/70 shadow-[0_18px_45px_rgba(0,0,0,.18)] transition duration-300 hover:-translate-y-1 hover:border-[#f7c14a]/45 hover:text-[#f7c14a]">
                      <MapPin className="h-4 w-4 text-[#f7c14a]" /> {area}
                    </div>
                  </Reveal>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="relative overflow-hidden bg-[#0c0c0c] py-24 md:py-32">
        <div className="absolute right-[-10rem] top-20 h-96 w-96 rounded-full bg-[#f7c14a]/10 blur-3xl" />
        <Tracer className="right-16 bottom-20 h-[214px] w-[315px] opacity-30" mirror />
        <div className="mx-auto max-w-[1480px] px-5 md:px-8">
          <Reveal>
            <SectionLabel number="05" label="Capabilities" />
            <h2 className="max-w-5xl font-display text-5xl font-black uppercase leading-[0.9] tracking-[-0.055em] md:text-8xl">
              One contractor for urgent repairs and planned upgrades.
            </h2>
          </Reveal>
          <div className="mt-14 grid gap-px overflow-hidden border border-white/10 bg-white/10 md:grid-cols-2 lg:grid-cols-3">
            {capabilityStack.map((item, index) => (
              <Reveal key={item.title} delay={index * 0.04}>
                <div className="group min-h-72 bg-[#0c0c0c] p-7 transition duration-500 [transform-style:preserve-3d] hover:-translate-y-2 hover:rotate-x-2 hover:bg-[#f7c14a] hover:text-black hover:shadow-[0_35px_100px_rgba(247,193,74,.16)]">
                  <item.icon className="mb-12 h-9 w-9 text-[#f7c14a] transition group-hover:text-black" />
                  <h3 className="font-display text-3xl font-black uppercase leading-none tracking-[-0.035em]">{item.title}</h3>
                  <p className="mt-5 text-sm leading-relaxed text-white/58 transition group-hover:text-black/70">{item.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="relative min-h-[620px] overflow-hidden py-24 md:py-32">
        <Tracer className="left-[45%] top-10 h-[214px] w-[315px] opacity-45 mix-blend-screen" />
        <img src={evImage} alt="EV charger installation by licensed electrician" className="absolute inset-0 h-full w-full object-cover opacity-40 grayscale" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/40" />
        <div className="relative mx-auto max-w-[1480px] px-5 md:px-8">
          <Reveal>
            <SectionLabel number="06" label="Modern electrical demand" />
            <h2 className="max-w-5xl font-display text-5xl font-black uppercase leading-[0.87] tracking-[-0.055em] md:text-8xl">
              EV charging, panels, permits and future-ready capacity.
            </h2>
            <p className="mt-8 max-w-2xl text-lg leading-relaxed text-white/67">
              Surrey homes and businesses need more power than ever. GK Electric plans upgrades around safety, load calculations, inspections and long-term electrical capacity.
            </p>
            <div className="mt-10 flex flex-col gap-4 sm:flex-row">
              <Link to="/ev-charger" className="inline-flex items-center justify-center gap-3 rounded-full bg-[#f7c14a] px-7 py-4 text-sm font-black uppercase tracking-[0.18em] text-black transition hover:bg-white">
                EV Charger Services <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/surrey" className="inline-flex items-center justify-center gap-3 rounded-full border border-white/20 px-7 py-4 text-sm font-black uppercase tracking-[0.18em] text-white transition hover:border-[#f7c14a] hover:text-[#f7c14a]">
                Surrey Service Page <MapPin className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      <StickyProjectShowcase />

      <section className="relative overflow-hidden border-y border-white/10 bg-black py-24 md:py-32">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(247,193,74,.16),transparent_28%),radial-gradient(circle_at_86%_50%,rgba(45,76,255,.1),transparent_26%)]" />
        <div className="relative mx-auto grid max-w-[1480px] gap-12 px-5 md:px-8 lg:grid-cols-[0.72fr_1.28fr]">
          <Reveal>
            <SectionLabel number="08" label="Client confidence" />
            <h2 className="font-display text-5xl font-black uppercase leading-[0.88] tracking-[-0.055em] md:text-8xl">Trusted by homeowners and businesses.</h2>
            <div className="mt-8 inline-flex items-center gap-4 border border-[#f7c14a]/35 bg-[#f7c14a]/10 p-5">
              <div className="font-display text-6xl font-black text-[#f7c14a]">{reviewStats.average}</div>
              <div>
                <div className="flex gap-1 text-[#f7c14a]">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}</div>
                <div className="mt-2 text-xs font-black uppercase tracking-[0.18em] text-white/55">{reviewStats.count}+ review signals</div>
              </div>
            </div>
          </Reveal>
          <div className="grid gap-5 lg:grid-cols-2">
            {[...testimonials.slice(0, 3), ...featuredReviews.slice(0, 3).map((review) => ({ name: review.author, role: review.date, quote: review.text, rating: review.rating }))].map((review, index) => (
              <Reveal key={`${review.name}-${index}`} delay={index * 0.035}>
                <PremiumPlate className="h-full p-6 transition duration-500 hover:-translate-y-2 hover:border-[#f7c14a]/45">
                  <div className="mb-7 flex gap-1 text-[#f7c14a]">{Array.from({ length: review.rating }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}</div>
                  <p className="text-base leading-relaxed text-white/68">“{review.quote}”</p>
                  <div className="mt-7 flex items-center gap-3 border-t border-white/10 pt-5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#f7c14a] text-sm font-black text-black"><Users className="h-5 w-5" /></div>
                    <div>
                      <div className="font-black uppercase tracking-[0.12em] text-white">{review.name}</div>
                      <div className="text-xs text-white/45">{review.role}</div>
                    </div>
                  </div>
                </PremiumPlate>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden py-24 md:py-32">
        <Tracer className="right-6 top-20 h-[214px] w-[315px] opacity-30" mirror />
        <div className="mx-auto max-w-[1480px] px-5 md:px-8">
          <Reveal>
            <SectionLabel number="09" label="Lower Mainland coverage" />
            <h2 className="max-w-5xl font-display text-5xl font-black uppercase leading-[0.88] tracking-[-0.055em] md:text-8xl">Service areas connected by one electrical team.</h2>
          </Reveal>
          <div className="mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {featuredServiceAreas.map((area, index) => (
              <Reveal key={area.slug} delay={index * 0.035}>
                <Link to={area.slug === "surrey" ? "/surrey" : "/service-areas"} className="group block min-h-64 border border-white/10 bg-white/[0.035] p-6 transition duration-500 hover:-translate-y-2 hover:border-[#f7c14a]/45 hover:bg-[#f7c14a]/10">
                  <MapPin className="mb-10 h-8 w-8 text-[#f7c14a] transition group-hover:scale-110" />
                  <h3 className="font-display text-3xl font-black uppercase leading-none tracking-[-0.035em] text-white">{area.name}</h3>
                  <p className="mt-4 text-sm leading-relaxed text-white/55">{area.description}</p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {area.highlights.slice(0, 2).map((highlight) => (
                      <span key={highlight} className="border border-white/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-white/46">{highlight}</span>
                    ))}
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="border-t border-white/10 bg-black py-20">
        <div className="mx-auto grid max-w-[1480px] gap-10 px-5 md:px-8 lg:grid-cols-[1fr_0.75fr] lg:items-center">
          <Reveal>
            <div className="text-xs font-black uppercase tracking-[0.28em] text-[#f7c14a]">Explore GK Electric</div>
            <h2 className="mt-6 font-display text-5xl font-black uppercase leading-[0.9] tracking-[-0.055em] md:text-8xl">
              Need an electrician in Surrey today?
            </h2>
          </Reveal>
          <Reveal delay={0.08}>
            <div className="border border-white/10 bg-white/[0.035] p-7">
              <p className="text-lg leading-relaxed text-white/66">
                Call for emergency service, request a free estimate, or explore the original GK Electric pages. This page is separate and does not change the existing website.
              </p>
              <div className="mt-8 grid gap-3">
                <a href="tel:+17783444567" className="flex items-center justify-between border border-[#f7c14a]/35 bg-[#f7c14a] px-5 py-4 text-sm font-black uppercase tracking-[0.16em] text-black transition hover:bg-white">
                  Call +1 (778) 344-4567 <Phone className="h-4 w-4" />
                </a>
                <Link to="/contact" className="flex items-center justify-between border border-white/15 px-5 py-4 text-sm font-black uppercase tracking-[0.16em] text-white transition hover:border-[#f7c14a] hover:text-[#f7c14a]">
                  Free Estimate <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/emergency-electrician-surrey" className="flex items-center justify-between border border-white/15 px-5 py-4 text-sm font-black uppercase tracking-[0.16em] text-white transition hover:border-[#f7c14a] hover:text-[#f7c14a]">
                  Emergency Surrey Page <Clock className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <Footer />
    </main>
  );
}
