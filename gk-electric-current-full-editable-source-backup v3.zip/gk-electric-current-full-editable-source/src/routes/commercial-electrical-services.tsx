import { createFileRoute } from "@tanstack/react-router";
import { Building2 } from "lucide-react";
import { CommercialElectricalServicesProfessional, commercialProfessionalMeta } from "@/components/CommercialElectricalServicesProfessional";

const config = commercialProfessionalMeta;

export const Route = createFileRoute("/commercial-electrical-services")({
  head: () => ({
    meta: [
      { title: "Commercial Electrical Services — Business Power, Lighting & Maintenance | GK Electric" },
      { name: "description", content: config.description },
      { property: "og:title", content: "Commercial Electrical Services | GK Electric" },
      { property: "og:description", content: config.description },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CommercialElectricalServicesPage,
});

function CommercialElectricalServicesPage() {
  return <CommercialElectricalServicesProfessional useRequestedCopy />;
}

export const pageIcon = Building2;
