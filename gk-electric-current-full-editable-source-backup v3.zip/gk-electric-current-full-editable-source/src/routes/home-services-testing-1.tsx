import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  BatteryCharging,
  Building2,
  CheckCircle2,
  Factory,
  FileCheck,
  Gauge,
  Headphones,
  Home,
  Lightbulb,
  MessageCircle,
  Phone,
  PlugZap,
  ShieldCheck,
  Sparkles,
  Wrench,
  Zap,
} from "lucide-react";
import { servicePageDetails } from "@/data/servicePageDetails";
import residentialImage from "@/assets/residential.jpg";
import commercialImage from "@/assets/commercial.jpg";
import industrialImage from "@/assets/industrial.jpg";
import evImage from "@/assets/ev-charger.jpg";

export const Route = createFileRoute("/home-services-testing-1")({
  head: () => ({
    meta: [
      { title: "Electrical Services We Provide — 50 Sticky Section Designs | GK Electric" },
      {
        name: "description",
        content:
          "A testing page with 50 dark sticky-scroll design variations for GK Electric residential, commercial, industrial and EV charger electrical services in Surrey and the Lower Mainland.",
      },
    ],
  }),
  component: HomeServicesTestingPage,
});

type ServiceCard = {
  title: string;
  eyebrow: string;
  desc: string;
  href: string;
  icon: typeof Home;
  image: string;
  bullets: string[];
  details: { title: string; desc: string; icon: typeof Home }[];
  trust: string[];
};

const services: ServiceCard[] = [
  {
    title: "Residential",
    eyebrow: "Home Electrical",
    desc: servicePageDetails.residential.intro,
    href: "/services/residential",
    icon: Home,
    image: residentialImage,
    bullets: servicePageDetails.residential.bullets,
    details: servicePageDetails.residential.services,
    trust: servicePageDetails.residential.trust,
  },
  {
    title: "Commercial",
    eyebrow: "Business Electrical",
    desc: servicePageDetails.commercial.intro,
    href: "/services/commercial",
    icon: Building2,
    image: commercialImage,
    bullets: servicePageDetails.commercial.bullets,
    details: servicePageDetails.commercial.services,
    trust: servicePageDetails.commercial.trust,
  },
  {
    title: "Industrial",
    eyebrow: "Facility Power",
    desc: servicePageDetails.industrial.intro,
    href: "/services/industrial",
    icon: Factory,
    image: industrialImage,
    bullets: servicePageDetails.industrial.bullets,
    details: servicePageDetails.industrial.services,
    trust: servicePageDetails.industrial.trust,
  },
  {
    title: "EV Charger",
    eyebrow: "Level 2 Charging",
    desc:
      "Home and commercial EV charger installation with dedicated circuits, load checks, panel readiness review and clean code-compliant installation for major EV brands.",
    href: "/ev-charger",
    icon: BatteryCharging,
    image: evImage,
    bullets: ["Level 2 EV chargers", "Dedicated 240V circuits", "Load calculation", "Panel readiness checks"],
    details: [
      { icon: PlugZap, title: "Home EV Chargers", desc: "Garage and driveway Level 2 charging installations with clean routing and safe circuit protection." },
      { icon: Gauge, title: "Load Management", desc: "Panel capacity review, load calculation and future-ready planning for EV charging demand." },
      { icon: Building2, title: "Commercial Charging", desc: "EV charging infrastructure for offices, strata, fleet, retail and commercial properties." },
      { icon: ShieldCheck, title: "Safe Installation", desc: "Permit-ready installation, correct breaker sizing, testing and code-compliant workmanship." },
      { icon: Zap, title: "Fast Charging Setup", desc: "Dedicated 240V circuits for reliable daily charging performance." },
      { icon: Wrench, title: "Troubleshooting", desc: "Diagnosis and correction for charging faults, wiring issues and underperforming installations." },
    ],
    trust: ["Panel capacity checked", "Permit-ready work", "Clean installation", "All major EV brands"],
  },
];

const trustPoints = [
  { icon: ShieldCheck, title: "Licensed Electricians", desc: "Licensed, insured and code-compliant work across Surrey and the Lower Mainland." },
  { icon: FileCheck, title: "Permit Support", desc: "Permit applications, inspections, documentation and deficiency corrections handled properly." },
  { icon: Headphones, title: "Emergency Support", desc: "Responsive support for urgent electrical failures, tripping breakers and unsafe wiring." },
  { icon: BadgeCheck, title: "Clean Workmanship", desc: "Professional installations, careful finishing, clear labels and tested systems." },
];

const palettes = [
  { bg: "#111827", card: "rgba(255,255,255,.06)", line: "#f5b526", accent: "#f7c14a", text: "#ffffff" },
  { bg: "#0b1020", card: "rgba(245,181,38,.08)", line: "#4f7cff", accent: "#f5b526", text: "#f8fafc" },
  { bg: "#141a28", card: "rgba(255,255,255,.055)", line: "#f7c14a", accent: "#ffd267", text: "#ffffff" },
  { bg: "#080b12", card: "rgba(255,255,255,.07)", line: "#22d3ee", accent: "#f5b526", text: "#ffffff" },
  { bg: "#17120a", card: "rgba(255,210,103,.08)", line: "#ffd267", accent: "#f5b526", text: "#ffffff" },
];

const layoutNames = [
  "split-panel",
  "circuit-grid",
  "stacked-cards",
  "image-ledger",
  "diagonal-flow",
  "terminal-board",
  "control-room",
  "power-map",
  "glass-console",
  "inspection-layer",
];

const designVariants = Array.from({ length: 50 }, (_, index) => ({
  id: index + 1,
  palette: palettes[index % palettes.length],
  layout: layoutNames[index % layoutNames.length],
  reverse: index % 2 === 1,
  dense: index % 3 === 0,
  serviceOffset: index % services.length,
}));

function CircuitFlow({ color = "#f5b526", variant = 0 }: { color?: string; variant?: number }) {
  const pathA = variant % 2 === 0 ? "M8 44 H160 V12 H302" : "M8 18 H82 V78 H188 V42 H302";
  const pathB = variant % 3 === 0 ? "M26 132 H128 V92 H246 V168 H310" : "M14 162 H96 V112 H180 V154 H300";

  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full opacity-70" viewBox="0 0 320 190" fill="none" aria-hidden="true">
      <path d={pathA} stroke="rgba(255,255,255,.14)" strokeWidth="1" />
      <path d={pathB} stroke="rgba(255,255,255,.1)" strokeWidth="1" />
      <path className="circuit-flow circuit-flow-a" d={pathA} stroke={color} strokeWidth="3" strokeLinecap="round" />
      <path className="circuit-flow circuit-flow-b" d={pathB} stroke={color} strokeWidth="2" strokeLinecap="round" />
      <circle cx="302" cy={variant % 2 === 0 ? 12 : 42} r="4" fill={color} className="circuit-dot" />
      <circle cx="26" cy={variant % 3 === 0 ? 132 : 162} r="3" fill={color} className="circuit-dot" />
    </svg>
  );
}

function ServiceMiniCard({ service, variant }: { service: ServiceCard; variant: number }) {
  const Icon = service.icon;
  const detail = service.details[variant % service.details.length];
  const DetailIcon = detail.icon;

  return (
    <Link to={service.href} className="group relative block overflow-hidden rounded-[1.35rem] border border-white/10 bg-white/[0.055] p-4 shadow-[0_20px_70px_rgba(0,0,0,.24)] backdrop-blur-md transition-all duration-500 hover:-translate-y-2 hover:border-[var(--accent)] hover:bg-white/[0.09]">
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[var(--accent)] text-black shadow-[0_0_30px_color-mix(in_oklab,var(--accent)_35%,transparent)]">
          <Icon className="h-5 w-5" />
        </span>
        <div>
          <div className="text-[10px] font-black uppercase tracking-[0.18em] text-[var(--accent)]">{service.eyebrow}</div>
          <h3 className="font-display text-2xl font-bold leading-none text-white">{service.title}</h3>
        </div>
      </div>
      <p className="mt-4 line-clamp-3 text-sm leading-relaxed text-white/62">{service.desc}</p>
      <div className="mt-5 rounded-xl border border-white/10 bg-black/20 p-3">
        <div className="flex items-start gap-3">
          <DetailIcon className="mt-0.5 h-4 w-4 shrink-0 text-[var(--accent)]" />
          <div>
            <div className="text-xs font-extrabold uppercase tracking-[0.12em] text-white">{detail.title}</div>
            <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-white/50">{detail.desc}</p>
          </div>
        </div>
      </div>
      <div className="mt-5 flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-[var(--accent)]">
        More Information <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
      </div>
    </Link>
  );
}

function DesignBlock({ variant }: { variant: (typeof designVariants)[number] }) {
  const ordered = services.map((_, i) => services[(i + variant.serviceOffset) % services.length]);
  const heroService = ordered[0];
  const HeroIcon = heroService.icon;

  return (
    <section
      className="relative min-h-[145vh] overflow-visible border-t border-white/10"
      style={{ background: variant.palette.bg, color: variant.palette.text, ["--accent" as string]: variant.palette.accent }}
    >
      <div className="sticky top-0 min-h-screen overflow-hidden py-20 md:py-24">
        <div className="absolute inset-0 opacity-[0.08]" style={{ backgroundImage: "linear-gradient(90deg, white 1px, transparent 1px), linear-gradient(white 1px, transparent 1px)", backgroundSize: variant.dense ? "34px 34px" : "58px 58px" }} />
        <CircuitFlow color={variant.palette.line} variant={variant.id} />
        <div className="absolute -right-32 top-12 h-96 w-96 rounded-full blur-3xl" style={{ background: `${variant.palette.accent}22` }} />
        <div className="absolute -left-28 bottom-10 h-80 w-80 rounded-full blur-3xl" style={{ background: `${variant.palette.line}18` }} />

        <div className="container relative z-10 mx-auto flex min-h-[calc(100vh-10rem)] flex-col justify-center px-4">
          <div className={`grid gap-8 lg:grid-cols-[0.86fr_1.14fr] lg:items-center ${variant.reverse ? "lg:[&>*:first-child]:order-2" : ""}`}>
            <div className="relative">
              <div className="mb-5 inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.06] px-4 py-2 text-xs font-black uppercase tracking-[0.22em] text-[var(--accent)] backdrop-blur-md">
                <Sparkles className="h-3.5 w-3.5" /> Design {String(variant.id).padStart(2, "0")} / {variant.layout}
              </div>
              <h2 className="font-display text-4xl font-extrabold uppercase leading-[0.92] tracking-tight text-white md:text-6xl lg:text-7xl">
                Electrical Services We Provide
              </h2>
              <p className="mt-5 max-w-2xl text-lg leading-relaxed text-white/70">
                Surrey & Lower Mainland Residential, Commercial & Industrial Electrical Services.
              </p>
              <div className="mt-7 rounded-[1.5rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-md">
                <div className="flex items-start gap-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[var(--accent)] text-black">
                    <HeroIcon className="h-7 w-7" />
                  </div>
                  <div>
                    <div className="text-xs font-black uppercase tracking-[0.2em] text-[var(--accent)]">Licensed Electricians in Surrey & Lower Mainland</div>
                    <h3 className="mt-2 font-display text-3xl font-bold text-white">Residential, Commercial, Industrial & EV Charger Electrical Services</h3>
                    <p className="mt-3 text-sm leading-relaxed text-white/58">Choose the electrical service you need and connect with licensed electricians for safe, code-compliant installation, repair, upgrades and emergency support.</p>
                  </div>
                </div>
              </div>
              <div className="mt-7 flex flex-wrap gap-3">
                <a href="tel:+17783444567" className="inline-flex items-center gap-2 rounded-full bg-[var(--accent)] px-5 py-3 text-sm font-black uppercase tracking-widest text-black transition hover:bg-white">
                  <Phone className="h-4 w-4" /> Call Now
                </a>
                <Link to="/contact" className="inline-flex items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-sm font-black uppercase tracking-widest text-white transition hover:border-[var(--accent)] hover:text-[var(--accent)]">
                  Get Quote <ArrowRight className="h-4 w-4" />
                </Link>
                <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-green-400/30 px-5 py-3 text-sm font-black uppercase tracking-widest text-green-300 transition hover:bg-green-500 hover:text-white">
                  <MessageCircle className="h-4 w-4" /> WhatsApp
                </a>
              </div>
            </div>

            <div>
              <div className={`grid gap-4 ${variant.dense ? "sm:grid-cols-2" : "md:grid-cols-2"}`}>
                {ordered.map((service, index) => (
                  <ServiceMiniCard key={service.title} service={service} variant={variant.id + index} />
                ))}
              </div>
              <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {trustPoints.map((point) => {
                  const Icon = point.icon;
                  return (
                    <div key={point.title} className="rounded-2xl border border-white/10 bg-white/[0.045] p-4 backdrop-blur-md">
                      <Icon className="mb-3 h-5 w-5 text-[var(--accent)]" />
                      <div className="text-xs font-black uppercase tracking-[0.14em] text-white">{point.title}</div>
                      <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-white/48">{point.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function HomeServicesTestingPage() {
  return (
    <main className="min-h-screen bg-surface text-surface-foreground">
      <style>{`
        @keyframes circuitPulse {
          from { stroke-dashoffset: 0; }
          to { stroke-dashoffset: -520; }
        }
        @keyframes circuitBlink {
          0%, 100% { opacity: .35; transform: scale(.8); }
          50% { opacity: 1; transform: scale(1.35); }
        }
        .circuit-flow {
          stroke-dasharray: 34 486;
          animation: circuitPulse 3.4s linear infinite;
          filter: drop-shadow(0 0 10px currentColor);
        }
        .circuit-flow-b {
          stroke-dasharray: 12 508;
          animation-duration: 4.8s;
          animation-direction: reverse;
        }
        .circuit-dot {
          transform-origin: center;
          animation: circuitBlink 1.7s ease-in-out infinite;
          filter: drop-shadow(0 0 10px currentColor);
        }
      `}</style>

      <section className="relative overflow-hidden bg-surface py-24 text-surface-foreground">
        <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
        <CircuitFlow color="#f5b526" variant={1} />
        <div className="container relative z-10 mx-auto px-4 text-center">
          <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-xs font-black uppercase tracking-[0.22em] text-primary-foreground">
            <Zap className="h-4 w-4" /> Sticky Scroll Testing Page
          </div>
          <h1 className="mx-auto max-w-5xl font-display text-5xl font-extrabold uppercase leading-[0.92] tracking-tight md:text-7xl">
            Electrical Services We Provide
          </h1>
          <p className="mx-auto mt-6 max-w-3xl text-lg leading-relaxed text-surface-foreground/72">
            50 different sticky-scroll dark/surface design directions using the full GK Electric residential, commercial, industrial and EV charger service data.
          </p>
        </div>
      </section>

      {designVariants.map((variant) => (
        <DesignBlock key={variant.id} variant={variant} />
      ))}
    </main>
  );
}
