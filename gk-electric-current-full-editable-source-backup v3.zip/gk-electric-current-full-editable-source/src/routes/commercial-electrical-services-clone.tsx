import { createFileRoute } from "@tanstack/react-router";
import { CommercialElectricalCloneVariant, commercialCloneMeta } from "@/components/CommercialElectricalCloneVariant";

export const Route = createFileRoute("/commercial-electrical-services-clone")({
  head: () => ({
    meta: [
      { title: `${commercialCloneMeta.title} — Clone | GK Electric` },
      { name: "description", content: commercialCloneMeta.description },
      { property: "og:title", content: `${commercialCloneMeta.title} | GK Electric` },
      { property: "og:description", content: commercialCloneMeta.description },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CommercialElectricalServicesClonePage,
});

function CommercialElectricalServicesClonePage() {
  return <CommercialElectricalCloneVariant variant="clone" />;
}
