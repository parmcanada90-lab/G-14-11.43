import { createFileRoute, Link } from "@tanstack/react-router";
import { MapPin, Phone, CheckCircle2, MessageCircle } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import { ServiceAreaMap } from "@/components/ServiceAreaMap";
import { serviceAreas } from "@/data/serviceAreas";

export const Route = createFileRoute("/service-areas")({
  head: () => ({
    meta: [
      {
        title: "Service Areas — Vancouver, Surrey, Burnaby, Richmond & Lower Mainland | GK Electric",
      },
      {
        name: "description",
        content:
          "Licensed electricians serving the entire Lower Mainland BC: Vancouver, Surrey, Burnaby, Richmond, Coquitlam, Langley, Delta, New Westminster, Maple Ridge, Abbotsford, Chilliwack, White Rock, North & West Vancouver.",
      },
      { property: "og:title", content: "Service Areas | GK Electric" },
      {
        property: "og:description",
        content:
          "Licensed electricians across the Lower Mainland — same-day service available.",
      },
    ],
    links: [
      {
        rel: "canonical",
        href: "https://volt-craft-link.lovable.app/service-areas",
      },
    ],
  }),
  component: ServiceAreasPage,
});

function ServiceAreasPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[50vh] flex items-center">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
        </div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <ElectricSectionTag label="Coverage" icon={MapPin} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
            <h1
              data-reveal
              className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6"
            >
              <span className="text-typewriter">
                Service <span className="brand-highlight">Areas</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-surface-foreground/70 max-w-2xl mx-auto mb-8 leading-relaxed">
              Proudly serving the Lower Mainland BC with licensed residential,
              commercial and industrial electrical work.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="tel:+17783444567"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
                  <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    Call Us
                  </div>
                  <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
                </div>
              </a>
              <a
                href="https://wa.me/17783444567"
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
                  <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    WhatsApp
                  </div>
                  <div className="text-surface-foreground font-semibold">Quick Response</div>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-10 text-primary/5 animate-float">
          <MapPin className="h-32 w-32 rotate-12" />
        </div>
        <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500">
          <MapPin className="h-24 w-24 -rotate-12" />
        </div>
      </section>

      {/* Map + grid */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          {/* Interactive stylized map */}
          <div className="mb-16">
            <ServiceAreaMap />
          </div>

          {/* Cards */}
          <div className="text-center mb-12">
            <ElectricSectionTag label="Where We Work" icon={MapPin} tone="light" variant="electric-v1-2" className="mb-4 justify-center" />
            <h2 className="text-4xl md:text-5xl mb-4">
              Cities We <span className="text-primary">Service</span>
            </h2>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {serviceAreas.map((a) => (
              <div
                key={a.slug}
                className="p-8 rounded-2xl bg-card border border-border shadow-card hover:shadow-elegant hover:border-primary/50 transition-all flex flex-col"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="h-12 w-12 rounded-lg bg-gradient-electric shadow-glow flex items-center justify-center shrink-0">
                    <MapPin className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="text-2xl md:text-3xl font-display mb-1">
                      {a.name}
                    </h3>
                    <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                      British Columbia
                    </p>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed mb-5">
                  {a.description}
                </p>
                <ul className="space-y-2 mb-6">
                  {a.highlights.map((h) => (
                    <li
                      key={h}
                      className="flex items-center gap-2 text-sm text-foreground/85"
                    >
                      <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-electric">
        <div className="container mx-auto px-4 text-center text-primary-foreground">
          <h2 className="text-4xl md:text-5xl mb-4">Not Sure If We Cover You?</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            We serve all of the Lower Mainland. Give us a call — we'll let you
            know if we can be on-site.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="xl"
              variant="outline"
              className="border-2 border-surface bg-surface text-surface-foreground hover:border-surface"
            >
              <a href="tel:+17783444567">
                <Phone className="h-5 w-5" /> Call +1 (778) 344-4567
              </a>
            </Button>
            <Button
              asChild
              size="xl"
              variant="electric"
              className="border-2 border-surface"
            >
              <Link to="/free-estimate">Get Free Estimate</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
