import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  CheckCircle2,
  Factory,
  Home,
  MessageCircle,
  Phone,
  PlugZap,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import gkLogo from "@/assets/gk-logo.jpeg";

export const Route = createFileRoute("/Sample-Contact")({
  head: () => ({
    meta: [
      { title: "Sample Contact Designs — GK Electric" },
      {
        name: "description",
        content:
          "25 professional contact and service selector design samples for GK Electric electrical services in Surrey and the Lower Mainland.",
      },
    ],
  }),
  component: SampleContactPage,
});

const services = [
  { label: "Residential", to: "/services/residential" as const, icon: Home },
  { label: "Commercial", to: "/services/commercial" as const, icon: Building2 },
  { label: "Industrial", to: "/services/industrial" as const, icon: Factory },
  { label: "EV Charger", to: "/ev-charger" as const, icon: PlugZap },
];

const contactActions = [
  { label: "Contact US", sub: "Call our team", href: "tel:+17783444567", icon: Phone, external: true },
  { label: "Request a Quote", sub: "Get project pricing", href: "/free-estimate", icon: BadgeCheck, external: false },
  { label: "WhatsApp US", sub: "Chat with us now", href: "https://wa.me/17783444567", icon: MessageCircle, external: true },
];

const trust = ["Free Quotes", "Clear Pricing", "Licensed & Insured", "Permit-Ready Work"];

const palettes = [
  "from-slate-950 via-slate-900 to-amber-950",
  "from-white via-amber-50 to-white",
  "from-[#0c111d] via-[#111827] to-[#020617]",
  "from-[#f7f7f2] via-white to-[#fff7df]",
  "from-black via-[#17120a] to-black",
  "from-[#101828] via-[#1f2937] to-[#111827]",
  "from-[#fffaf0] via-[#f8fafc] to-white",
  "from-[#06131f] via-[#0f172a] to-[#2a1d05]",
  "from-[#111111] via-[#25200f] to-[#111111]",
  "from-[#f5f6fc] via-white to-[#fff3cc]",
  "from-[#070707] via-[#161616] to-[#29210d]",
  "from-[#fbfbf8] via-[#fff7e0] to-white",
  "from-[#1a2030] via-[#101522] to-black",
  "from-white via-[#f5f5f0] to-[#fff0bd]",
  "from-[#171717] via-[#0f172a] to-[#332507]",
  "from-[#fffdf7] via-white to-[#edf2f7]",
  "from-[#030712] via-[#111827] to-[#422006]",
  "from-[#f8fafc] via-[#fffbeb] to-white",
  "from-[#09090b] via-[#18181b] to-[#451a03]",
  "from-[#fff7ed] via-white to-[#f8fafc]",
  "from-[#101010] via-[#1c1917] to-black",
  "from-[#f6f7f9] via-white to-[#fff1c2]",
  "from-[#0b1120] via-[#020617] to-[#1f1300]",
  "from-white via-[#fafafa] to-[#fff7db]",
  "from-[#111827] via-[#0b0f19] to-[#2b1b02]",
];

function ServiceButton({ label, to, icon: Icon, dark }: { label: string; to: string; icon: typeof Home; dark?: boolean }) {
  return (
    <Link
      to={to as never}
      className={`group flex items-center justify-between rounded-2xl border p-4 text-sm font-black uppercase tracking-[0.12em] transition-all duration-300 hover:-translate-y-1 ${
        dark
          ? "border-white/15 bg-white/[0.06] text-white hover:border-amber-400 hover:bg-amber-400 hover:text-slate-950"
          : "border-slate-200 bg-white text-slate-950 shadow-sm hover:border-amber-400 hover:bg-amber-50"
      }`}
    >
      <span className="flex items-center gap-3">
        <Icon className="h-5 w-5 text-amber-500 transition group-hover:text-current" />
        {label}
      </span>
      <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
    </Link>
  );
}

function ActionLink({ action, dark }: { action: (typeof contactActions)[number]; dark?: boolean }) {
  const Icon = action.icon;
  const classes = `group flex items-center gap-4 rounded-2xl border p-4 transition-all duration-300 hover:-translate-y-1 ${
    dark
      ? "border-white/15 bg-white/[0.07] text-white hover:border-amber-400 hover:bg-white/[0.12]"
      : "border-slate-200 bg-white text-slate-950 shadow-sm hover:border-amber-400 hover:shadow-lg"
  }`;
  const content = (
    <>
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-slate-950 shadow-[0_0_24px_rgba(245,181,38,0.28)]">
        <Icon className="h-5 w-5" />
      </span>
      <span>
        <span className="block text-sm font-black uppercase tracking-[0.12em]">{action.label}</span>
        <span className={`mt-1 block text-sm ${dark ? "text-white/60" : "text-slate-500"}`}>{action.sub}</span>
      </span>
    </>
  );

  if (action.external) {
    return (
      <a href={action.href} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noreferrer" : undefined} className={classes}>
        {content}
      </a>
    );
  }

  return (
    <Link to={action.href as never} className={classes}>
      {content}
    </Link>
  );
}

function TrustPills({ dark }: { dark?: boolean }) {
  return (
    <div className="flex flex-wrap gap-2">
      {trust.map((item) => (
        <span
          key={item}
          className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-[11px] font-black uppercase tracking-[0.1em] ${
            dark ? "border-white/15 bg-white/[0.06] text-white/75" : "border-slate-200 bg-white text-slate-600"
          }`}
        >
          <CheckCircle2 className="h-3.5 w-3.5 text-amber-500" />
          {item}
        </span>
      ))}
    </div>
  );
}

function DesignCard({ index }: { index: number }) {
  const dark = index % 2 === 1 || [3, 5, 8, 9, 11, 13, 15, 17, 19, 21, 23, 25].includes(index);
  const palette = palettes[index - 1];
  const shape = index % 5;
  const isDesignOne = index === 1;
  const heroTitle = isDesignOne ? "Connect With GK Electric" : "Licensed Electricians in Surrey & Lower Mainland";
  const heroSubtitle = isDesignOne
    ? "Clear support for electrical quotes, service calls, and urgent project needs"
    : "Residential, Commercial, Industrial & EV Charger Electrical Services";
  const heroIntro = isDesignOne
    ? "Tell us what you need and our team will guide you toward the right next step."
    : "Choose the electrical service you need or contact GK Electric for a clear quote, emergency support, and code-compliant work across Surrey, BC.";
  const serviceIntro = isDesignOne
    ? "Select the electrical service that matches your project and connect directly with the right GK Electric service page."
    : "Select the service that matches your project.";

  return (
    <section
      className={`relative overflow-hidden rounded-[2rem] border p-5 md:p-7 lg:p-8 ${
        dark ? "border-white/10 text-white" : "border-slate-200 text-slate-950"
      } bg-gradient-to-br ${palette} shadow-[0_24px_80px_rgba(15,23,42,0.12)]`}
    >
      <div className="pointer-events-none absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "linear-gradient(90deg,currentColor 1px,transparent 1px),linear-gradient(currentColor 1px,transparent 1px)", backgroundSize: shape === 0 ? "32px 32px" : "44px 44px" }} />
      <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-amber-400/20 blur-3xl" />
      <div className="relative grid grid-cols-12 gap-5">
        <div className={`${shape === 1 ? "col-span-12 lg:col-span-7" : shape === 2 ? "col-span-12 lg:col-span-5" : "col-span-12 lg:col-span-6"}`}>
          <div className="mb-5 flex items-center justify-between gap-4">
            <div className="inline-flex items-center gap-3 rounded-full bg-amber-400 px-4 py-2 text-xs font-black uppercase tracking-[0.16em] text-slate-950">
              <Sparkles className="h-4 w-4" /> Design {String(index).padStart(2, "0")}
            </div>
            <img src={gkLogo} alt="GK Electric logo" className="h-10 w-10 rounded-full object-contain" />
          </div>
          <h2 className="font-display text-3xl font-black uppercase leading-[0.95] tracking-tight md:text-5xl">
            {heroTitle}
          </h2>
          <p className={`mt-4 text-base font-semibold leading-relaxed md:text-lg ${dark ? "text-white/75" : "text-slate-600"}`}>
            {heroSubtitle}
          </p>
          <p className={`mt-4 max-w-2xl text-sm leading-relaxed ${dark ? "text-white/62" : "text-slate-500"}`}>
            {heroIntro}
          </p>
          <TrustPills dark={dark} />
        </div>

        <div className={`${shape === 1 ? "col-span-12 lg:col-span-5" : shape === 2 ? "col-span-12 lg:col-span-7" : "col-span-12 lg:col-span-6"}`}>
          <div className={`h-full rounded-[1.5rem] border p-4 ${dark ? "border-white/12 bg-black/20" : "border-slate-200 bg-white/70"} backdrop-blur-md`}>
            <div className="mb-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-xs font-black uppercase tracking-[0.18em] text-amber-500">Checkout our services</div>
                <p className={`mt-2 text-sm ${dark ? "text-white/60" : "text-slate-500"}`}>
                  {serviceIntro}
                </p>
              </div>
              <Zap className="h-8 w-8 text-amber-500" />
            </div>
            <div className={`grid gap-3 ${shape === 3 ? "sm:grid-cols-4" : "sm:grid-cols-2"}`}>
              {services.map((service) => (
                <ServiceButton key={service.label} {...service} dark={dark} />
              ))}
            </div>
          </div>
        </div>

        <div className="col-span-12">
          <div className={`grid gap-4 rounded-[1.5rem] border p-4 md:grid-cols-[1.05fr_1.45fr] ${dark ? "border-white/12 bg-white/[0.055]" : "border-slate-200 bg-white/80"}`}>
            <div>
              <h3 className="font-display text-2xl font-black uppercase tracking-tight">Ready to start your electrical project?</h3>
              <p className={`mt-3 text-sm leading-relaxed ${dark ? "text-white/62" : "text-slate-500"}`}>
                Talk with our team for free quotes, clear project pricing, emergency support, and permit-backed electrical work done safely and professionally.
              </p>
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              {contactActions.map((action) => (
                <ActionLink key={action.label} action={action} dark={dark} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SampleContactPage() {
  return (
    <div className="min-h-screen bg-[#f5f6f2] text-slate-950">
      <Header />
      <main className="pt-24">
        <section className="px-4 py-12 md:py-16">
          <div className="mx-auto max-w-[1500px] text-center">
            <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-amber-200 bg-white px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-amber-700 shadow-sm">
              <Sparkles className="h-4 w-4" /> 25 Contact Section Concepts
            </div>
            <h1 className="font-display text-4xl font-black uppercase leading-tight tracking-tight md:text-7xl">
              Sample Contact & Service Selector Designs
            </h1>
            <p className="mx-auto mt-5 max-w-3xl text-lg leading-relaxed text-slate-600">
              Professional 12-column grid concepts for GK Electric service selection, quote requests, emergency support, WhatsApp contact, and licensed electrical trust signals.
            </p>
          </div>
        </section>

        <section className="px-4 pb-16">
          <div className="mx-auto grid max-w-[1500px] gap-8">
            {Array.from({ length: 25 }).map((_, index) => (
              <DesignCard key={index + 1} index={index + 1} />
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
