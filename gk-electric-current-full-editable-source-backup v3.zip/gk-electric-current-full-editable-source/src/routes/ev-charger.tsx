import { createFileRoute, Link } from "@tanstack/react-router";
import { DecorEVCar } from "@/components/decor/LineArt";
import { Plug, CheckCircle2, Zap, Home, Building2, Car, ArrowRight } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ServiceConnections } from "@/components/ServiceConnections";
import { Button } from "@/components/ui/button";
import evImage from "@/assets/ev-charger.jpg";

export const Route = createFileRoute("/ev-charger")({
  head: () => ({
    meta: [
      { title: "EV Charger Installation — Home & Commercial | GK Electric" },
      { name: "description", content: "Professional EV charger installation for home and commercial properties. Fast, safe, code-compliant — compatible with Tesla, Ford, Hyundai, BMW and all major EV brands." },
      { property: "og:title", content: "EV Charger Installation | GK Electric" },
      { property: "og:description", content: "Licensed electricians installing home and commercial EV chargers across Surrey, BC and the Lower Mainland. Free estimate." },
      { property: "og:image", content: evImage },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: evImage },
    ],
  }),
  component: EVPage,
});

function EVPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <section className="relative py-24 md:py-32 bg-surface text-surface-foreground overflow-hidden">
        <DecorEVCar side="br" />
        <img src={evImage} alt="EV charger installation" width={1600} height={1200} className="absolute inset-0 w-full h-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-overlay" />
        <div className="container relative mx-auto px-4 z-10">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest mb-6">
              <Plug className="h-3 w-3" /> EV Charging Specialists
            </div>
            <h1 data-reveal className="text-5xl md:text-7xl mb-6"><span className="text-typewriter">EV Charger Installation</span></h1>
            <p className="text-xl text-surface-foreground/85 mb-10 leading-relaxed">
              Power up your electric vehicle at home or work. GK Electric installs Level 2 EV chargers — fast, safe, and compatible with every major EV brand.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild variant="electric" size="xl">
                <Link to="/contact">Get Free Quote <ArrowRight className="h-5 w-5" /></Link>
              </Button>
              <Button asChild variant="outlineLight" size="xl">
                <a href="tel:+17783444567">Call +1 (778) 344-4567</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            {[
              { icon: Home, title: "Home EV Charger Installation", desc: "Level 2 home chargers professionally installed in your garage or driveway. Permits and Technical Safety BC inspection included." },
              { icon: Building2, title: "Commercial EV Charging Setup", desc: "Multi-unit charging stations for offices, condos, retail and fleets. Load management and access systems." },
              { icon: Zap, title: "Fast & Safe Installation", desc: "Code-compliant installations done right the first time. Most home installs completed in a single day." },
              { icon: Car, title: "All Major EV Brands", desc: "Tesla, Ford, Hyundai, Kia, BMW, Mercedes, Volvo, Polestar — we install every brand of charger." },
            ].map((b) => (
              <div key={b.title} className="p-8 rounded-2xl bg-card border border-border shadow-card hover:shadow-elegant transition-all">
                <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-gradient-electric shadow-glow mb-5">
                  <b.icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <h3 className="text-2xl mb-3">{b.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-muted/40">
        <div className="container mx-auto px-4 grid lg:grid-cols-2 gap-12 items-center">
          <div className="overflow-hidden rounded-2xl shadow-elegant aspect-[4/3]">
            <img src={evImage} alt="EV charger" loading="lazy" width={1600} height={1200} className="w-full h-full object-cover" />
          </div>
          <div>
            <h2 className="text-4xl md:text-5xl mb-6">What's Included</h2>
            <ul className="space-y-4">
              {[
                "Site assessment & load calculation",
                "Permit application & Technical Safety BC inspection",
                "Panel upgrade if required",
                "Wiring & dedicated 240V circuit",
                "Charger mounting & commissioning",
                "Walkthrough & warranty",
              ].map((it) => (
                <li key={it} className="flex items-start gap-3 text-lg">
                  <CheckCircle2 className="h-6 w-6 text-primary mt-0.5 shrink-0" />
                  <span>{it}</span>
                </li>
              ))}
            </ul>
            <Button asChild variant="electric" size="lg" className="mt-8">
              <Link to="/contact">Book Installation</Link>
            </Button>
          </div>
        </div>
      </section>

      <ServiceConnections
        current="/ev-charger"
        eyebrow="Connected EV Services"
        title="EV Charging Connected to Complete Electrical Work"
      />

      <Footer />
    </div>
  );
}
