import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  CalendarCheck,
  CheckCircle2,
  ClipboardCheck,
  FileCheck,
  FilePenLine,
  FileText,
  MessageCircle,
  Phone,
  ScrollText,
  ShieldCheck,
  Sparkles,
  Wrench,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";

export const Route = createFileRoute("/specialized-service-1")({
  head: () => ({
    meta: [
      { title: "Specialized Service Designs — Permits & Compliance | GK Electric" },
      {
        name: "description",
        content:
          "25 different visual design concepts for GK Electric's permits and compliance specialized service section, using the same approved content and dark background style.",
      },
    ],
  }),
  component: SpecializedServiceDesignsPage,
});

const intro = {
  eyebrow: "Specialized Service",
  title: "Permits & Compliance Made Simple",
  p1: "We take care of all electrical permits, inspections, and regulatory requirements from start to finish—so your project stays compliant, on schedule, and stress-free.",
  p2: "Our team works directly with local authorities to ensure all work meets the BC Electrical Safety Regulation and the Canadian Electrical Code. From permit applications to final approvals, we handle the paperwork, coordination, and compliance details for you.",
};

const handleItems = [
  { icon: FileCheck, text: "Electrical permit applications" },
  { icon: CalendarCheck, text: "Inspection scheduling & coordination" },
  { icon: BadgeCheck, text: "Code compliance verification" },
  { icon: Wrench, text: "Deficiency corrections support" },
  { icon: ClipboardCheck, text: "Final inspection & approvals" },
  { icon: ScrollText, text: "Regulatory documentation" },
  { icon: FileCheck, text: "Electric Operating Permits" },
  { icon: FileText, text: "Electric Planning Reports" },
];

const actions = [
  { icon: Phone, label: "Call Now", text: "Speak with our team", href: "tel:+17783444567", tone: "primary" },
  { icon: FilePenLine, label: "Request a Quote", text: "Get a custom quote", href: "/contact", tone: "primary" },
  { icon: MessageCircle, label: "WhatsApp Us", text: "Chat with us now", href: "https://wa.me/17783444567", tone: "whatsapp" },
];

function SectionShell({ number, name, children }: { number: number; name: string; children: React.ReactNode }) {
  return (
    <section className="relative overflow-hidden border-t border-white/10 bg-surface py-20 text-surface-foreground">
      <div className="absolute inset-0 opacity-[0.045]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />
      <div className="container relative z-10 mx-auto px-4">
        <div className="mb-8 flex items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="text-xs font-black uppercase tracking-[0.24em] text-primary">Design {String(number).padStart(2, "0")}</div>
          <div className="text-xs font-black uppercase tracking-[0.2em] text-white/35">{name}</div>
        </div>
        {children}
      </div>
    </section>
  );
}

function CopyBlock({ align = "left" }: { align?: "left" | "center" }) {
  return (
    <div className={align === "center" ? "mx-auto max-w-4xl text-center" : "max-w-3xl"}>
      <ElectricSectionTag label={intro.eyebrow} icon={ClipboardCheck} tone="dark" variant="electric-v1-2" className={align === "center" ? "mx-auto mb-6" : "mb-6"} />
      <h2 className="font-display text-4xl font-extrabold tracking-tight md:text-6xl">
        Permits & Compliance <span className="brand-highlight">Made Simple</span>
      </h2>
      <div className="mt-6 space-y-4 text-lg leading-relaxed text-surface-foreground/72">
        <p>{intro.p1}</p>
        <p>{intro.p2}</p>
      </div>
      <Button asChild variant="electric" size="lg" className="mt-8 shadow-none hover:shadow-none">
        <Link to="/services">
          More Info <ArrowRight className="h-5 w-5" />
        </Link>
      </Button>
    </div>
  );
}

function HandleGrid({ styleType = "glass" }: { styleType?: "glass" | "line" | "pill" | "solid" }) {
  const base =
    styleType === "line"
      ? "border-b border-white/10 px-1 py-4"
      : styleType === "pill"
        ? "rounded-full border border-white/12 bg-white/[0.06] px-5 py-4"
        : styleType === "solid"
          ? "rounded-2xl bg-primary p-4 text-primary-foreground"
          : "rounded-2xl border border-white/15 bg-white/[0.09] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]";
  const iconClass = styleType === "solid" ? "bg-surface/20 text-primary-foreground" : "bg-primary/20 text-primary ring-1 ring-primary/25";

  return (
    <div>
      <div className="mb-6 flex items-center gap-4">
        <span className="h-10 w-1 rounded-full bg-primary shadow-glow" />
        <h3 className="font-display text-3xl font-bold text-surface-foreground">What We Handle</h3>
      </div>
      <div className={styleType === "pill" ? "flex flex-wrap gap-3" : "grid gap-4 sm:grid-cols-2"}>
        {handleItems.map((item, index) => (
          <div key={`${item.text}-${index}`} className={`group flex items-center gap-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.12] ${base}`}>
            <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${iconClass}`}>
              <item.icon className="h-5 w-5" />
            </span>
            <span className="text-base font-semibold leading-snug text-surface-foreground">{item.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ActionStrip({ mode = "cards" }: { mode?: "cards" | "bar" | "stack" | "minimal" }) {
  return (
    <div className={`mt-8 ${mode === "bar" ? "rounded-[1.75rem] border border-white/12 bg-white/[0.055] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.28)] backdrop-blur-md" : ""}`}>
      <div className={mode === "stack" ? "space-y-3" : mode === "minimal" ? "flex flex-wrap gap-3" : "grid gap-5 md:grid-cols-[1.25fr_1fr_1fr_1fr] md:divide-x md:divide-white/10"}>
        {mode !== "minimal" && (
          <div className="flex items-center">
            <p className="font-display text-2xl font-extrabold uppercase tracking-[0.06em] text-white">Ready to start your permit-backed electrical work?</p>
          </div>
        )}
        {actions.map((action) => {
          const Icon = action.icon;
          const isExternal = action.href.startsWith("http");
          const content = (
            <>
              <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border transition-all duration-300 group-hover:scale-110 ${action.tone === "whatsapp" ? "border-green-400/35 bg-green-500/15 text-green-300 group-hover:bg-green-500 group-hover:text-white" : "border-primary/45 bg-primary/15 text-primary group-hover:bg-primary group-hover:text-primary-foreground"}`}>
                <Icon className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-extrabold uppercase tracking-[0.12em] text-white group-hover:text-primary transition-colors">{action.label}</div>
                <div className="mt-1 text-sm text-surface-foreground/55 group-hover:text-surface-foreground/80 transition-colors">{action.text}</div>
              </div>
            </>
          );

          const className = mode === "minimal"
            ? "group inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/[0.04] px-5 py-3 transition-all duration-300 hover:border-primary/45 hover:bg-white/[0.08]"
            : "group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45 hover:bg-white/[0.08] hover:shadow-[0_18px_45px_rgba(0,0,0,0.25)] md:mx-4";

          if (isExternal) return <a key={action.label} href={action.href} target="_blank" rel="noreferrer" className={className}>{content}</a>;
          if (action.href.startsWith("tel:")) return <a key={action.label} href={action.href} className={className}>{content}</a>;
          return <Link key={action.label} to="/contact" className={className}>{content}</Link>;
        })}
      </div>
    </div>
  );
}

function Variant({ n }: { n: number }) {
  const type = ((n - 1) % 25) + 1;

  if (type === 1) return <SectionShell number={n} name="Original polished grid"><div className="grid gap-12 lg:grid-cols-[2fr_3fr]"><CopyBlock /><div className="lg:pt-16"><HandleGrid /><ActionStrip mode="bar" /></div></div></SectionShell>;
  if (type === 2) return <SectionShell number={n} name="Centered hero stack"><CopyBlock align="center" /><div className="mx-auto mt-12 max-w-5xl"><HandleGrid styleType="pill" /><ActionStrip mode="minimal" /></div></SectionShell>;
  if (type === 3) return <SectionShell number={n} name="Left rail timeline"><div className="grid gap-12 lg:grid-cols-[1fr_1fr]"><CopyBlock /><div className="border-l border-primary/40 pl-6"><HandleGrid styleType="line" /><ActionStrip mode="stack" /></div></div></SectionShell>;
  if (type === 4) return <SectionShell number={n} name="Gold compliance cards"><div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr]"><HandleGrid styleType="solid" /><CopyBlock /></div><ActionStrip mode="bar" /></SectionShell>;
  if (type === 5) return <SectionShell number={n} name="Bento blocks"><CopyBlock /><div className="mt-10 grid gap-4 md:grid-cols-4"><div className="md:col-span-3"><HandleGrid /></div><div className="rounded-3xl border border-primary/30 bg-primary/10 p-6"><Sparkles className="mb-8 h-10 w-10 text-primary" /><p className="font-display text-3xl font-bold uppercase">Permit-backed electrical work</p></div></div><ActionStrip mode="bar" /></SectionShell>;
  if (type === 6) return <SectionShell number={n} name="Split command panel"><div className="grid gap-8 lg:grid-cols-2"><div className="rounded-[2rem] border border-white/10 bg-black/25 p-8"><CopyBlock /></div><div className="rounded-[2rem] border border-primary/25 bg-primary/10 p-8"><HandleGrid styleType="line" /></div></div><ActionStrip mode="minimal" /></SectionShell>;
  if (type === 7) return <SectionShell number={n} name="Dashboard layout"><div className="grid gap-5 lg:grid-cols-3"><div className="lg:col-span-2 rounded-[2rem] border border-white/10 bg-white/[0.055] p-8"><CopyBlock /></div><div className="rounded-[2rem] border border-primary/25 bg-primary/10 p-8"><ActionStrip mode="stack" /></div></div><div className="mt-6"><HandleGrid /></div></SectionShell>;
  if (type === 8) return <SectionShell number={n} name="Circular focus"><CopyBlock align="center" /><div className="mt-12 grid gap-4 md:grid-cols-4">{handleItems.map((item) => <div key={item.text} className="rounded-full border border-white/10 bg-white/[0.05] p-6 text-center"><item.icon className="mx-auto mb-4 h-7 w-7 text-primary" /><p className="text-sm font-semibold">{item.text}</p></div>)}</div><ActionStrip mode="minimal" /></SectionShell>;
  if (type === 9) return <SectionShell number={n} name="Editorial columns"><div className="columns-1 gap-8 md:columns-2"><CopyBlock /><div className="break-inside-avoid pt-6"><HandleGrid styleType="line" /></div></div><ActionStrip mode="bar" /></SectionShell>;
  if (type === 10) return <SectionShell number={n} name="Permit checklist"><div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]"><CopyBlock /><div className="rounded-[2rem] bg-white p-6 text-surface"><h3 className="mb-5 font-display text-3xl font-bold">What We Handle</h3>{handleItems.map((item) => <div key={item.text} className="flex items-center gap-3 border-b border-surface/10 py-3"><CheckCircle2 className="h-5 w-5 text-primary" /><span className="font-semibold">{item.text}</span></div>)}</div></div><ActionStrip mode="minimal" /></SectionShell>;
  if (type === 11) return <SectionShell number={n} name="Offset cards"><div className="grid gap-12 lg:grid-cols-2"><div className="lg:translate-y-12"><CopyBlock /></div><div className="lg:-translate-y-6"><HandleGrid /></div></div><ActionStrip mode="bar" /></SectionShell>;
  if (type === 12) return <SectionShell number={n} name="Top border premium"><div className="border-t-4 border-primary pt-10"><CopyBlock align="center" /></div><div className="mt-10"><HandleGrid /></div><ActionStrip mode="minimal" /></SectionShell>;
  if (type === 13) return <SectionShell number={n} name="Numbered operations"><div className="grid gap-8 lg:grid-cols-[1fr_1.2fr]"><CopyBlock /><div className="grid gap-3">{handleItems.map((item, i) => <div key={item.text} className="flex gap-4 rounded-2xl border border-white/10 bg-white/[0.055] p-4"><span className="font-display text-3xl text-primary">{String(i + 1).padStart(2, "0")}</span><div><item.icon className="mb-2 h-5 w-5 text-primary" /><p className="font-semibold">{item.text}</p></div></div>)}</div></div><ActionStrip mode="bar" /></SectionShell>;
  if (type === 14) return <SectionShell number={n} name="Glow panel"><div className="rounded-[2.5rem] border border-primary/30 bg-primary/[0.08] p-8 shadow-glow"><CopyBlock align="center" /><div className="mt-10"><HandleGrid /></div><ActionStrip mode="minimal" /></div></SectionShell>;
  if (type === 15) return <SectionShell number={n} name="Minimal lines"><div className="grid gap-12 lg:grid-cols-2"><CopyBlock /><HandleGrid styleType="line" /></div><ActionStrip mode="minimal" /></SectionShell>;
  if (type === 16) return <SectionShell number={n} name="Action first"><ActionStrip mode="bar" /><div className="mt-12 grid gap-12 lg:grid-cols-[1fr_1.1fr]"><CopyBlock /><HandleGrid /></div></SectionShell>;
  if (type === 17) return <SectionShell number={n} name="Icon wall"><CopyBlock align="center" /><div className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-[2rem] bg-white/10 md:grid-cols-4">{handleItems.map((item) => <div key={item.text} className="bg-surface p-6 text-center hover:bg-primary hover:text-primary-foreground transition-colors"><item.icon className="mx-auto mb-4 h-8 w-8" /><p className="text-sm font-bold">{item.text}</p></div>)}</div><ActionStrip mode="bar" /></SectionShell>;
  if (type === 18) return <SectionShell number={n} name="Permit blueprint"><div className="rounded-[2rem] border border-primary/20 bg-[#11172a] p-8"><div className="grid gap-10 lg:grid-cols-2"><CopyBlock /><HandleGrid styleType="line" /></div><ActionStrip mode="minimal" /></div></SectionShell>;
  if (type === 19) return <SectionShell number={n} name="Compact business card"><div className="mx-auto max-w-5xl rounded-[2rem] border border-white/10 bg-white/[0.06] p-8"><CopyBlock /><div className="mt-8"><HandleGrid styleType="pill" /></div><ActionStrip mode="minimal" /></div></SectionShell>;
  if (type === 20) return <SectionShell number={n} name="Two-tone blocks"><div className="grid overflow-hidden rounded-[2rem] border border-white/10 lg:grid-cols-2"><div className="bg-primary p-8 text-primary-foreground"><h2 className="font-display text-5xl font-bold">{intro.title}</h2><p className="mt-6 text-primary-foreground/80">{intro.p1}</p><p className="mt-4 text-primary-foreground/80">{intro.p2}</p></div><div className="bg-white/[0.06] p-8"><HandleGrid styleType="line" /></div></div><ActionStrip mode="bar" /></SectionShell>;
  if (type === 21) return <SectionShell number={n} name="Sticky mini"><div className="grid gap-12 lg:grid-cols-[0.75fr_1.25fr]"><div className="lg:sticky lg:top-24"><CopyBlock /></div><div><HandleGrid /><ActionStrip mode="stack" /></div></div></SectionShell>;
  if (type === 22) return <SectionShell number={n} name="Large typography"><div className="mb-10 font-display text-6xl font-black uppercase leading-none text-white/10 md:text-9xl">Compliance</div><div className="grid gap-12 lg:grid-cols-2"><CopyBlock /><HandleGrid /></div><ActionStrip mode="minimal" /></SectionShell>;
  if (type === 23) return <SectionShell number={n} name="Inset framed"><div className="border border-white/10 p-4"><div className="border border-primary/30 p-8"><CopyBlock align="center" /><div className="mt-10"><HandleGrid /></div><ActionStrip mode="bar" /></div></div></SectionShell>;
  if (type === 24) return <SectionShell number={n} name="Service matrix"><div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]"><div><HandleGrid /></div><div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-8"><CopyBlock /></div></div><ActionStrip mode="minimal" /></SectionShell>;
  return <SectionShell number={n} name="Final CTA showcase"><CopyBlock align="center" /><div className="mt-10"><HandleGrid styleType="solid" /></div><ActionStrip mode="bar" /></SectionShell>;
}

function SpecializedServiceDesignsPage() {
  return (
    <div className="min-h-screen bg-surface text-surface-foreground">
      <Header />
      <main className="pt-24">
        <section className="relative overflow-hidden bg-surface py-20 text-center text-surface-foreground">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />
          <div className="container relative z-10 mx-auto px-4">
            <ElectricSectionTag label="Specialized Service" icon={ClipboardCheck} tone="dark" variant="electric-v1-2" className="mx-auto mb-6" />
            <h1 className="mx-auto max-w-5xl font-display text-5xl font-extrabold uppercase tracking-tight md:text-7xl">
              25 Designs for Permits & Compliance
            </h1>
            <p className="mx-auto mt-6 max-w-3xl text-lg text-surface-foreground/70">
              Same approved content, same dark background direction, redesigned into 25 different layout styles for comparison.
            </p>
          </div>
        </section>
        {Array.from({ length: 25 }, (_, index) => <Variant key={index + 1} n={index + 1} />)}
      </main>
      <Footer />
    </div>
  );
}
