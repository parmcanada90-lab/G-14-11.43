import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import {
  Phone,
  Zap,
  ShieldCheck,
  Clock,
  Award,
  ArrowRight,
  Building2,
  Factory,
  Home,
  Plug,
  Lightbulb,
  Wrench,
  Gauge,
  Cpu,
  Headphones,
  FileCheck,
  FileText,
  Star,
  Users,
  MessageCircle,
  ClipboardCheck,
  BadgeCheck,
  MapPin,
  Flame,
  Siren,
  AlertTriangle,
  Send,
  HelpCircle,
  ChevronRight
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

import residentialImage from "@/assets/residential.jpg";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";

export const Route = createFileRoute("/surrey")({
  head: () => ({
    meta: [
      { title: "Licensed Electrician in Surrey, BC | 24/7 Emergency Service | GK Electric" },
      {
        name: "description",
        content:
          "Looking for a trusted electrician in Surrey, BC? GK Electric provides 24/7 emergency repairs, panel upgrades, EV charger installs, and commercial electrical. Licensed & insured. Fast 30-60 min arrival.",
      },
      { property: "og:title", content: "Licensed Electrician in Surrey, BC | 24/7 Emergency Service" },
      {
        property: "og:description",
        content:
          "GK Electric is Surrey's trusted electrical contractor. 24/7 emergency response, panel upgrades, EV charging stations, and residential or commercial renovations.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SurreySEOPage,
});

const SURREY_NEIGHBORHOODS = [
  { name: "Fleetwood", desc: "Fast residential panel upgrades, EV charger setups, and local wiring repairs." },
  { name: "Guildford", desc: "Commercial tenant improvements, retail lighting, and emergency home electrical services." },
  { name: "Cloverdale", desc: "Historic home rewiring, basement suite wiring, and farm/workshop power upgrades." },
  { name: "Newton", desc: "Three-phase industrial power, commercial retrofits, and rapid emergency dispatch." },
  { name: "Whalley / City Centre", desc: "High-density residential setups, office improvements, and modern lighting controls." },
  { name: "South Surrey", desc: "Premium custom home wiring, smart home integration, and outdoor landscape lighting." },
  { name: "Clayton Heights", desc: "Coach house electrical compliance, secondary suite subpanels, and appliance circuits." },
  { name: "Port Kells", desc: "Heavy industrial machinery wiring, warehouse power distribution, and regular maintenance." },
  { name: "Fraser Heights", desc: "Custom residential lighting layouts, backup generator hookups, and safety inspections." },
  { name: "Panorama Ridge", desc: "Luxury estate power planning, surge protection, and high-capacity EV charger installs." },
];

const SURREY_SERVICES = [
  {
    icon: Siren,
    title: "24/7 Emergency Repairs",
    desc: "Power outages, buzzing panels, burning smells, or tripping breakers. Sourced with a priority dispatch to Surrey neighborhoods.",
    bullet: "30-60 Min Average Arrival"
  },
  {
    icon: Gauge,
    title: "Panel & Service Upgrades",
    desc: "Upgrading older Surrey homes from 100 Amp to 200 Amp or 400 Amp service to support heat pumps and suites safely.",
    bullet: "TSBC Permitted & Inspected"
  },
  {
    icon: Plug,
    title: "EV Charger Installation",
    desc: "Level 2 smart home EV charging stations compatible with Tesla, Wallbox, ChargePoint, and all major vehicle brands.",
    bullet: "BC Hydro Rebate Approved"
  },
  {
    icon: Home,
    title: "Suite Wiring & Renovations",
    desc: "Complete electrical for kitchen/bathroom renos, basement secondary suites, and compliant coach house installations.",
    bullet: "100% Code-Compliant"
  },
  {
    icon: Building2,
    title: "Commercial & Retail Electrical",
    desc: "Tenant improvements, office power distribution, retail display lighting, and energy-saving LED upgrades.",
    bullet: "Minimal Business Downtime"
  },
  {
    icon: ShieldCheck,
    title: "Safety Inspections & Alarms",
    desc: "Interconnected smoke and carbon monoxide detectors, whole-home surge protectors, and safety grounding corrections.",
    bullet: "Peace of Mind Guaranteed"
  }
];

const SURREY_REVIEWS = [
  {
    name: "Sarah M.",
    location: "Fleetwood, Surrey",
    rating: 5,
    text: "We had a total power failure in half our house on a Sunday night. GK Electric was at our door in Fleetwood in under 45 minutes! The electrician diagnosed a blown main breaker, explained everything clearly, and had the power back on safely. Unbelievable response time and very reasonable emergency rates.",
  },
  {
    name: "Jaspreet S.",
    location: "Newton, Surrey",
    rating: 5,
    text: "Excellent service upgrading our home in Newton from 100A to 200A service. They handled all the permits with TSBC and coordinated with BC Hydro perfectly. The workmanship on the new panel is extremely neat and labeled beautifully. Highly recommend them for any panel upgrades!",
  },
  {
    name: "David K.",
    location: "South Surrey, BC",
    rating: 5,
    text: "Installed a Tesla wall connector in my garage. They did a full load assessment on my panel first to ensure everything was safe, ran the conduit neatly, and cleaned up the site perfectly. Truly professional electricians who know what they are doing.",
  },
];

const FAQS = [
  {
    q: "How fast can an emergency electrician arrive at my Surrey home?",
    a: "Our typical response time for urgent electrical emergencies in Surrey is between 30 and 60 minutes. We have local electricians stationed near major routes like Highway 10, Fraser Highway, and Highway 1 to ensure rapid transit.",
  },
  {
    q: "Are your electricians fully licensed and insured in Surrey?",
    a: "Yes, absolutely. GK Electric is a fully licensed electrical contractor regulated by Technical Safety BC (Licence # LEL0209793). All our field technicians are certified journeypersons or registered apprentices covered by comprehensive liability insurance and WorkSafeBC.",
  },
  {
    q: "Do you handle electrical permits and BC Hydro coordination?",
    a: "We take care of the entire permit process from start to finish. For service upgrades (e.g., 100A to 200A), we pull the required TSBC electrical permit, coordinate the power disconnect/reconnect schedule with BC Hydro, and host the safety inspector.",
  },
  {
    q: "What is your emergency call-out rate in Surrey?",
    a: "We offer transparent, upfront pricing. Emergency call-outs outside regular hours have a flat-rate dispatch fee which covers the immediate travel and initial diagnostics. We always explain any additional repair costs before starting any work.",
  },
];

export function SurreySEOPage() {
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    neighborhood: "",
    service: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("Request Received!", {
        description: "Our Surrey dispatch team will contact you shortly to confirm your booking.",
      });
      setFormData({
        name: "",
        email: "",
        phone: "",
        neighborhood: "",
        service: "",
        message: "",
      });
      (e.target as HTMLFormElement).reset();
    }, 800);
  };

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Electrician",
    "name": "GK Electric Surrey",
    "image": "https://gkelectric.ca/assets/gk-logo.jpeg",
    "telePhone": "+1-778-344-4567",
    "email": "info@gkelectric.ca",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "8381 128 St #105",
      "addressLocality": "Surrey",
      "addressRegion": "BC",
      "postalCode": "V3W 4G1",
      "addressCountry": "CA"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": 49.1542,
      "longitude": -122.8667
    },
    "url": "https://gkelectric.ca/surrey",
    "areaServed": [
      { "@type": "AdministrativeArea", "name": "Surrey" },
      { "@type": "AdministrativeArea", "name": "Fleetwood" },
      { "@type": "AdministrativeArea", "name": "Guildford" },
      { "@type": "AdministrativeArea", "name": "Cloverdale" },
      { "@type": "AdministrativeArea", "name": "Newton" },
      { "@type": "AdministrativeArea", "name": "Whalley" },
      { "@type": "AdministrativeArea", "name": "South Surrey" },
      { "@type": "AdministrativeArea", "name": "Clayton Heights" }
    ],
    "priceRange": "$$"
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <Toaster position="top-center" />

      <main>
        {/* HERO SECTION */}
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[75vh] flex items-center text-surface-foreground pt-28">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
          </div>
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: "50px 50px",
            }}
          />

          <div className="container mx-auto px-4 py-16 relative z-10">
            <div className="grid gap-12 lg:grid-cols-[1.1fr_0.9fr] items-center">
              <div>
                <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/25 text-primary text-xs uppercase tracking-widest font-bold mb-6">
                  <span className="flex h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                  24/7 Rapid Surrey Dispatch
                </div>
                
                <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[0.95] mb-6">
                  Surrey's Trusted <br />
                  <span className="text-primary">Local Electrician</span>
                </h1>
                
                <p className="text-lg md:text-xl text-surface-foreground/80 leading-relaxed mb-8 max-w-2xl">
                  Licensed, fully insured, and highly rated electrical services across Surrey, BC. From emergency repairs and panel upgrades to EV charger installations and commercial tenant improvements, we deliver safe, code-compliant solutions.
                </p>

                <div className="grid sm:grid-cols-2 gap-4 mb-8">
                  {[
                    "TSBC Licensed # LEL0209793",
                    "30-60 Min Average Arrival",
                    "100% Upfront Pricing",
                    "Surrey Owned & Operated"
                  ].map((benefit) => (
                    <div key={benefit} className="flex items-center gap-2.5 text-surface-foreground/90">
                      <BadgeCheck className="h-5 w-5 text-primary shrink-0" />
                      <span className="font-semibold text-sm md:text-base">{benefit}</span>
                    </div>
                  ))}
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="electric" size="xl">
                    <a href="tel:+17783444567">
                      <Phone className="h-5 w-5" /> Call Dispatch: (778) 344-4567
                    </a>
                  </Button>
                  <Button asChild variant="outlineLight" size="xl">
                    <a href="#quote-form">
                      Request Free Estimate <ArrowRight className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
              </div>

              {/* TSBC Trust Box */}
              <div className="relative">
                <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-primary to-amber-500 opacity-20 blur-xl" />
                <div className="relative bg-card border border-border/40 p-8 rounded-3xl shadow-elegant text-foreground">
                  <div className="flex items-start justify-between gap-4 mb-6">
                    <div>
                      <div className="font-sans text-xl font-extrabold uppercase leading-none tracking-[0.2em] text-foreground">
                        GK ELECTRIC
                      </div>
                      <div className="mt-1.5 text-xs uppercase tracking-widest text-muted-foreground">
                        Licensed Electrical Contractor
                      </div>
                    </div>
                    <div className="shrink-0 bg-[#00497b] px-3 py-2.5 rounded-2xl shadow-md border border-white/10">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={tsbcLogo}
                          alt="Technical Safety BC logo"
                          className="h-10 w-10 object-contain"
                          loading="lazy"
                        />
                        <div className="text-right">
                          <div className="text-[10px] uppercase tracking-wider text-white/80">TSBC Licence</div>
                          <div className="text-sm font-bold text-white"># LEL0209793</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-foreground mb-6">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-bold text-sm text-foreground uppercase tracking-wider">Emergency? Don't Wait!</h4>
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                          Smelling burning plastic, hearing crackling in your panel, or facing a partial power loss are high-risk hazards. Call our 24-hour line for immediate safety advice and rapid local dispatch.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3.5">
                    <div className="flex justify-between items-center text-sm border-b border-border/50 pb-2">
                      <span className="text-muted-foreground">Service Call Rate:</span>
                      <span className="font-bold text-foreground">$200 Flat Rate</span>
                    </div>
                    <div className="flex justify-between items-center text-sm border-b border-border/50 pb-2">
                      <span className="text-muted-foreground">Emergency Rate:</span>
                      <span className="font-bold text-foreground">$300 Flat Rate</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Surrey Arrival Time:</span>
                      <span className="font-bold text-primary">30 - 60 Minutes</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* EMERGENCY PRIORITY BANNER */}
        <section className="bg-primary/10 border-y border-primary/25 py-8 text-foreground">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 max-w-5xl mx-auto">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-2xl bg-primary flex items-center justify-center text-primary-foreground shadow-glow shrink-0">
                  <Clock className="h-6 w-6 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-display text-xl font-extrabold uppercase tracking-wide">Need an Electrician Right Now?</h3>
                  <p className="text-sm text-muted-foreground mt-0.5">We have Surrey electricians on-call 24 hours a day, 365 days a year.</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 justify-center">
                <Button asChild variant="electric" size="lg">
                  <a href="tel:+17783444567">
                    <Phone className="h-4.5 w-4.5" /> Call (778) 344-4567
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* SERVICES SECTION */}
        <section className="py-24 bg-card border-b border-border">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <ElectricSectionTag label="Surrey Electrical Services" icon={Wrench} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold tracking-tight mb-5">
                Complete Residential & Commercial Solutions
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed">
                Whether you need a minor fixture replacement or a complex high-voltage industrial installation, our Surrey-based master electricians handle it safely and efficiently.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {SURREY_SERVICES.map((s, idx) => {
                const Icon = s.icon;
                return (
                  <div
                    key={idx}
                    className="group flex flex-col justify-between p-6 rounded-2xl bg-background border border-border hover:border-primary/45 shadow-card hover:shadow-elegant transition-all duration-300"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <div className="h-12 w-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                          <Icon className="h-6 w-6" />
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-muted text-muted-foreground px-2.5 py-1 rounded-full">
                          {s.bullet}
                        </span>
                      </div>
                      <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                        {s.title}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {s.desc}
                      </p>
                    </div>
                    <div className="mt-6 pt-4 border-t border-border/50 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-primary">
                      <span>Learn More</span>
                      <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* NEIGHBORHOODS COVERAGE */}
        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] items-center max-w-6xl mx-auto">
              <div>
                <ElectricSectionTag label="Local Coverage" icon={MapPin} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6">
                  Serving Every Corner <br />
                  of <span className="text-primary">Surrey, BC</span>
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                  Our dispatch center is located locally in Surrey, allowing our fleet to easily reach any community in under an hour. We know Surrey's municipal permit requirements and property styles inside out.
                </p>
                <div className="p-6 rounded-2xl bg-card border border-border shadow-sm">
                  <h4 className="font-bold text-foreground mb-2">Need rapid service?</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    We have specialized units patrolling the Fraser Highway, King George Boulevard, and 152 Street corridors daily.
                  </p>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {SURREY_NEIGHBORHOODS.map((n) => (
                  <div
                    key={n.name}
                    className="p-5 rounded-2xl bg-card border border-border shadow-sm transition-all duration-200 hover:border-primary/30"
                  >
                    <h3 className="font-bold text-foreground flex items-center gap-2 mb-1.5">
                      <MapPin className="h-4 w-4 text-primary shrink-0" />
                      {n.name}
                    </h3>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {n.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* REVIEWS SECTION */}
        <section className="py-24 bg-card border-t border-b border-border">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <ElectricSectionTag label="Local Reviews" icon={Star} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold tracking-tight mb-5">
                What Surrey Residents Say
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed">
                Read genuine feedback from homeowners and business managers who have experienced our rapid dispatch and tidy workmanship firsthand.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {SURREY_REVIEWS.map((r, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-background border border-border shadow-sm flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center gap-1 mb-4 text-primary">
                      {[...Array(r.rating)].map((_, i) => (
                        <Star key={i} className="h-4.5 w-4.5 fill-primary" />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed italic mb-6">
                      "{r.text}"
                    </p>
                  </div>
                  <div className="pt-4 border-t border-border/50">
                    <h4 className="font-bold text-foreground text-sm">{r.name}</h4>
                    <span className="text-xs text-muted-foreground">{r.location}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ SECTION */}
        <section className="py-24 bg-muted/20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <ElectricSectionTag label="Surrey FAQ" icon={HelpCircle} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-5">
                Frequently Asked Questions
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed">
                Find quick answers regarding licensing, emergency response times, permits, and electrical upgrades in Surrey, BC.
              </p>
            </div>

            <div className="max-w-4xl mx-auto grid gap-6">
              {FAQS.map((faq, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-card border border-border shadow-sm"
                >
                  <h3 className="font-display text-xl font-bold text-foreground mb-2 flex items-start gap-2.5">
                    <HelpCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    {faq.q}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed pl-7">
                    {faq.a}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CONTACT / DISPATCH FORM */}
        <section id="quote-form" className="py-24 bg-background relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.02] pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, black 1px, transparent 0)", backgroundSize: "20px 22px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-5xl mx-auto bg-card border border-border shadow-elegant rounded-[2.5rem] overflow-hidden grid lg:grid-cols-[0.95fr_1.05fr]">
              {/* Left Column info */}
              <div className="bg-surface text-surface-foreground p-8 md:p-12 flex flex-col justify-between relative">
                <div className="absolute inset-0 opacity-[0.05] pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
                
                <div className="relative z-10">
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 border border-primary/30 text-primary text-xs uppercase tracking-widest font-bold mb-6">
                    <Zap className="h-3 w-3" /> Surrey Dispatch Hub
                  </span>
                  <h3 className="font-display text-3xl md:text-5xl font-extrabold mb-6">
                    Book an Electrician
                  </h3>
                  <p className="text-surface-foreground/75 leading-relaxed mb-8">
                    Fill out our rapid dispatch form to schedule an estimate or request emergency service. A licensed Surrey electrician will get back to you immediately.
                  </p>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <Phone className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">24/7 Phone Support</div>
                        <a href="tel:+17783444567" className="font-bold hover:text-primary text-sm md:text-base">+1 (778) 344-4567</a>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <MapPin className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">Surrey Head Office</div>
                        <div className="font-bold text-sm">8381 128 St #105, Surrey, BC V3W 4G1</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-12 pt-6 border-t border-white/10 text-xs text-surface-foreground/50 relative z-10">
                  By submitting this form, you agree to be contacted within 24 hours regarding your electrical service request.
                </div>
              </div>

              {/* Right Column Form */}
              <div className="p-8 md:p-12">
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Full Name</label>
                      <Input
                        type="text"
                        required
                        placeholder="John Doe"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="bg-muted/40 border-border rounded-xl focus:ring-2 focus:ring-primary/50 text-foreground"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Phone Number</label>
                      <Input
                        type="tel"
                        required
                        placeholder="(604) 555-0199"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="bg-muted/40 border-border rounded-xl focus:ring-2 focus:ring-primary/50 text-foreground"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Email Address</label>
                    <Input
                      type="email"
                      required
                      placeholder="john@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="bg-muted/40 border-border rounded-xl focus:ring-2 focus:ring-primary/50 text-foreground"
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Surrey Neighborhood</label>
                      <select
                        required
                        value={formData.neighborhood}
                        onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                        className="w-full h-10 px-3 py-2 text-sm bg-muted/40 border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 text-foreground"
                      >
                        <option value="" className="text-muted-foreground">Select Neighborhood...</option>
                        {SURREY_NEIGHBORHOODS.map((n) => (
                          <option key={n.name} value={n.name} className="text-foreground">{n.name}</option>
                        ))}
                        <option value="Other Surrey" className="text-foreground">Other Surrey Location</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Service Required</label>
                      <select
                        required
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full h-10 px-3 py-2 text-sm bg-muted/40 border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 text-foreground"
                      >
                        <option value="">Select Service...</option>
                        {SURREY_SERVICES.map((s) => (
                          <option key={s.title} value={s.title}>{s.title}</option>
                        ))}
                        <option value="Other">Other Electrical Work</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Message / Project Details</label>
                    <Textarea
                      required
                      rows={4}
                      placeholder="Please describe your electrical repair, panel upgrade, or installation needs..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="bg-muted/40 border-border rounded-xl focus:ring-2 focus:ring-primary/50 text-foreground"
                    />
                  </div>

                  <Button type="submit" variant="electric" className="w-full py-6 rounded-xl font-bold uppercase tracking-widest text-sm" disabled={submitting}>
                    {submitting ? "Sending Request..." : "Request Dispatch / Estimate"}
                    <Send className="h-4 w-4 ml-2" />
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </div>
  );
}
