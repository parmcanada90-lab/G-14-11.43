import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import {
  Briefcase,
  Heart,
  TrendingUp,
  Users,
  Wrench,
  ShieldCheck,
  Send,
  Sparkles,
  CheckCircle2,
  Clock,
  MapPin,
  Mail,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/careers")({
  head: () => ({
    meta: [
      { title: "Careers — Join GK Electric | Licensed Electricians Wanted" },
      {
        name: "description",
        content:
          "We're hiring licensed electricians, apprentices and helpers across the Lower Mainland BC. Send us your resume — competitive pay, steady work, real growth.",
      },
      { property: "og:title", content: "Careers at GK Electric" },
      {
        property: "og:description",
        content:
          "Join a growing electrical contractor in Surrey, BC. Send your resume — we're always looking for great electricians.",
      },
    ],
    links: [
      {
        rel: "canonical",
        href: "https://volt-craft-link.lovable.app/careers",
      },
    ],
  }),
  component: CareersPage,
});

const benefits = [
  {
    icon: TrendingUp,
    title: "Competitive Pay",
    desc: "Above-scale wages with annual reviews and performance bonuses.",
  },
  {
    icon: Heart,
    title: "Health Benefits",
    desc: "Extended health, dental and vision coverage for you and your family.",
  },
  {
    icon: Wrench,
    title: "Tools & Vehicle",
    desc: "Company truck, fuel card, and tool allowance for qualified roles.",
  },
  {
    icon: Users,
    title: "Real Mentorship",
    desc: "Apprentices work alongside Red Seal journeymen on real projects.",
  },
  {
    icon: Briefcase,
    title: "Steady Work",
    desc: "Year-round pipeline across residential, commercial and industrial.",
  },
  {
    icon: ShieldCheck,
    title: "Safety First",
    desc: "Fully insured, WorkSafeBC certified, and a no-shortcuts culture.",
  },
];

const applyHighlights = [
  { icon: Clock, label: "48-hour response", desc: "We review every resume personally within two business days." },
  { icon: MapPin, label: "Lower Mainland BC", desc: "Surrey, Vancouver, Burnaby, Langley, Coquitlam & nearby." },
  { icon: Zap, label: "Start within 2 weeks", desc: "Hiring now for residential, commercial & service roles." },
];

function CareersPage() {
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("Thanks! We've received your application.");
      (e.target as HTMLFormElement).reset();
    }, 600);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <Toaster />

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 text-surface-foreground min-h-[50vh] flex items-center">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
        </div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />

        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
          <div data-reveal="zoom" className="mb-8">
            <ElectricSectionTag label="We're Hiring" icon={Briefcase} tone="dark" variant="electric-v1-2" className="justify-center" />
          </div>
          <h1
            data-reveal
            className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6"
          >
            <span className="text-typewriter">
              Join the <span className="brand-highlight">GK Team</span>
            </span>
          </h1>
          <p data-reveal className="text-lg md:text-xl text-surface-foreground/70 max-w-2xl mx-auto mb-8 leading-relaxed" style={{ transitionDelay: "120ms" }}>
            We're always looking for licensed electricians, apprentices and
            helpers who care about doing good work. Send us your resume —
            we'll be in touch.
          </p>

          <div data-reveal className="flex flex-wrap justify-center gap-4" style={{ transitionDelay: "200ms" }}>
            <a href="#apply">
              <Button variant="electric" size="lg" className="group">
                <Send className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                Apply Now
              </Button>
            </a>
            <a href="#why">
              <Button variant="outlineLight" size="lg">Why GK Electric</Button>
            </a>
          </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-10 text-primary/5 animate-float">
          <Mail className="h-32 w-32 rotate-12" />
        </div>
        <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500">
          <Users className="h-24 w-24 -rotate-12" />
        </div>
      </section>

      {/* Why work with us */}
      <section id="why" className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div data-reveal className="mb-4">
              <ElectricSectionTag label="Why GK Electric" icon={ShieldCheck} tone="light" variant="electric-v1-2" className="justify-center" />
            </div>
            <h2 data-reveal className="text-4xl md:text-5xl mb-4" style={{ transitionDelay: "80ms" }}>
              Built for <span className="text-primary">Long Careers</span>
            </h2>
            <p data-reveal className="text-lg text-muted-foreground max-w-2xl mx-auto" style={{ transitionDelay: "160ms" }}>
              We invest in our crew because great electricians build great
              companies.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {benefits.map((b, i) => (
              <div
                key={b.title}
                data-reveal
                style={{ transitionDelay: `${i * 90}ms` }}
                className="group relative p-6 rounded-xl bg-card border border-border shadow-card hover:shadow-elegant hover:border-primary/50 hover:-translate-y-1 transition-all duration-300 glossy-hover-sweep overflow-hidden"
              >
                <div className="h-12 w-12 rounded-lg bg-gradient-electric shadow-glow mb-4 flex items-center justify-center transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
                  <b.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="text-xl mb-2">{b.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {b.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Application form */}
      <section id="apply" className="relative py-28 overflow-hidden bg-surface text-surface-foreground">
        {/* Background flourishes */}
        <div className="pointer-events-none absolute inset-0 opacity-60 [background:radial-gradient(60%_50%_at_50%_0%,color-mix(in_oklab,var(--primary)_18%,transparent),transparent_70%)]" />
        <div className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-72 w-[60rem] rounded-full bg-primary/10 blur-3xl" />
        <div className="pointer-events-none absolute bottom-10 left-10 h-40 w-40 rounded-full bg-primary/15 blur-2xl animate-float" />
        <div className="pointer-events-none absolute top-20 right-10 h-40 w-40 rounded-full bg-primary/10 blur-2xl animate-float" style={{ animationDelay: "2s" }} />

        <div className="container mx-auto px-4 max-w-6xl relative">
          <div className="text-center mb-14">
            <div data-reveal="zoom" className="mb-5">
              <ElectricSectionTag label="Apply Now" icon={Sparkles} tone="dark" variant="electric-v1-2" className="justify-center" />
            </div>
            <h2 data-reveal className="text-4xl md:text-6xl mb-4">
              Send Your <span className="text-primary">Resume</span>
            </h2>
            <p data-reveal className="text-surface-foreground/75 max-w-2xl mx-auto" style={{ transitionDelay: "120ms" }}>
              Fill out the form below and attach your resume. We review every
              application personally — no auto-responders.
            </p>
          </div>

          <div className="grid lg:grid-cols-[1fr_1.4fr] gap-8 items-start">
            {/* Highlights column */}
            <div className="space-y-4 lg:sticky lg:top-24">
              {applyHighlights.map((h, i) => (
                <div
                  key={h.label}
                  data-reveal="left"
                  style={{ transitionDelay: `${i * 100}ms` }}
                  className="group flex gap-4 p-5 rounded-xl bg-card text-card-foreground border border-border hover:border-primary/60 hover:shadow-elegant transition-all"
                >
                  <div className="shrink-0 h-11 w-11 rounded-lg bg-gradient-electric shadow-glow flex items-center justify-center transition-transform group-hover:scale-110">
                    <h.icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div>
                    <div className="font-semibold">{h.label}</div>
                    <div className="text-sm text-muted-foreground leading-relaxed">{h.desc}</div>
                  </div>
                </div>
              ))}

              <div data-reveal="left" style={{ transitionDelay: "320ms" }} className="p-5 rounded-xl border border-primary/30 bg-card text-card-foreground">
                <div className="flex items-center gap-2 text-sm font-semibold text-primary mb-2">
                  <CheckCircle2 className="h-4 w-4" /> What happens next
                </div>
                <ol className="space-y-1.5 text-sm text-muted-foreground">
                  <li>1. We review your resume within 48 hours.</li>
                  <li>2. Quick phone chat to learn about you.</li>
                  <li>3. In-person interview with the foreman.</li>
                  <li>4. Offer & start date.</li>
                </ol>
              </div>
            </div>

            {/* Form card with animated gradient border */}
            <div data-reveal="right" className="relative rounded-2xl p-[1.5px] bg-[linear-gradient(135deg,color-mix(in_oklab,var(--primary)_70%,transparent),transparent_40%,color-mix(in_oklab,var(--primary)_60%,transparent))] shadow-glow">
              <div className="rounded-2xl bg-card text-card-foreground p-8 md:p-10">
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input id="name" name="name" required placeholder="John Doe" className="mt-1.5" />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input id="email" name="email" type="email" required placeholder="john@example.com" className="mt-1.5" />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" name="phone" type="tel" required placeholder="(555) 123-4567" className="mt-1.5" />
                    </div>
                    <div>
                      <Label htmlFor="position">Position Interested In</Label>
                      <select
                        id="position"
                        name="position"
                        defaultValue=""
                        required
                        className="mt-1.5 flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <option value="" disabled>Select a role</option>
                        <option>Journeyman Electrician (FSR)</option>
                        <option>Apprentice Electrician</option>
                        <option>Electrical Helper</option>
                        <option>Project Manager / Estimator</option>
                        <option>Office / Admin</option>
                        <option>Other</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="resume">Upload Resume (PDF or DOC)</Label>
                    <Input
                      id="resume"
                      name="resume"
                      type="file"
                      accept=".pdf,.doc,.docx"
                      required
                      className="mt-1.5 py-0 pl-0 pr-3 text-muted-foreground file:mr-4 file:h-full file:rounded-md file:border-0 file:bg-primary file:px-4 file:py-2 file:text-sm file:font-semibold file:text-primary-foreground cursor-pointer"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message">Tell Us About Yourself</Label>
                    <Textarea
                      id="message"
                      name="message"
                      rows={5}
                      placeholder="Years of experience, certifications (Red Seal, FSR), areas of expertise, why you'd like to join GK Electric..."
                      className="mt-1.5"
                    />
                  </div>

                  <Button
                    type="submit"
                    variant="electric"
                    size="lg"
                    disabled={submitting}
                    className="w-full group relative overflow-hidden"
                  >
                    <Send className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    {submitting ? "Submitting..." : "Submit Application"}
                  </Button>

                  <p className="text-xs text-muted-foreground text-center">
                    By submitting, you agree to be contacted by GK Electric regarding your application.
                  </p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
