import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/blog")({
  component: BlogPage,
  head: () => ({
    meta: [
      { title: "Blog | Voltcraft Electric" },
      { name: "description", content: "Insights, guides, and updates from our master electricians." },
    ],
  }),
});

function BlogPage() {
  return (
    <main className="container mx-auto px-4 py-24">
      <h1 className="font-display text-4xl md:text-6xl uppercase tracking-tight">Blog</h1>
      <p className="mt-4 text-muted-foreground max-w-2xl">
        Stories, tips, and field notes from our team. New posts coming soon.
      </p>
    </main>
  );
}
