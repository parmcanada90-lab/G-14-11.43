import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { Home, Building2, Factory, FileCheck, CheckCircle2, ArrowRight, Plug, Lightbulb, MessageCircle, Phone } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { ServiceConnections } from "@/components/ServiceConnections";
import { Button } from "@/components/ui/button";
import residentialImage from "@/assets/residential.jpg";
import commercialImage from "@/assets/commercial.jpg";
import industrialImage from "@/assets/industrial.jpg";
import evImage from "@/assets/ev-charger.jpg";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Electrical Services — Residential, Commercial & Industrial | GK Electric" },
      { name: "description", content: "Complete electrical services: residential wiring & lighting, commercial panels & maintenance, heavy industrial installation, plus permits and code compliance." },
      { property: "og:title", content: "Electrical Services | GK Electric" },
      { property: "og:description", content: "Residential, commercial and industrial electrical services across Surrey, BC and the Lower Mainland. Licensed, insured, and code-compliant." },
      { property: "og:image", content: industrialImage },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: industrialImage },
    ],
  }),
  component: ServicesPage,
});

const sections = [
  {
    id: "residential",
    to: "/services/residential" as const,
    icon: Home,
    title: "Residential Electrical",
    img: residentialImage,
    intro: "Make your home safer, brighter and more efficient with expert residential electrical work.",
    items: [
      "Full electrical installation",
      "Lighting design & wiring",
      "Repairs & panel upgrades",
      "EV charger installation",
      "Smoke / CO detectors",
      "Pot lights & smart switches",
    ],
  },
  {
    id: "commercial",
    to: "/services/commercial" as const,
    icon: Building2,
    title: "Commercial Electrical",
    img: commercialImage,
    intro: "Reliable electrical service for offices, retail and commercial buildings.",
    items: [
      "Office & shop wiring",
      "Panel installation & upgrades",
      "Maintenance & troubleshooting",
      "Lighting retrofits (LED)",
      "Tenant improvements",
      "Emergency service",
    ],
  },
  {
    id: "industrial",
    to: "/services/industrial" as const,
    icon: Factory,
    title: "Industrial Electrical",
    img: industrialImage,
    intro: "Our specialty — heavy electrical for factories, warehouses and industrial facilities.",
    items: [
      "Heavy electrical installation",
      "Machinery wiring",
      "Load management systems",
      "Industrial maintenance",
      "Three-phase power",
      "Motor controls & VFDs",
    ],
  },
];

function ServicesPage() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    const hash = window.location.hash.replace("#", "");
    if (!hash) return;
    // Wait a tick so the section is mounted
    const t = window.setTimeout(() => {
      const el = document.getElementById(hash);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 50);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[50vh] flex items-center text-surface-foreground">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
        </div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <ElectricSectionTag label="Our Services" icon={Lightbulb} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
            <h1
              data-reveal
              className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6"
            >
              <span className="text-typewriter">
                Electrical <span className="brand-highlight">Solutions</span>
              </span>
            </h1>
            <p className="text-lg md:text-xl text-surface-foreground/70 max-w-2xl mx-auto mb-8 leading-relaxed">
              From home renovations and commercial build-outs to large-scale industrial installations, GK Electric delivers safe, code-compliant electrical solutions throughout the Lower Mainland.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="tel:+17783444567"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
                  <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    Call Us
                  </div>
                  <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
                </div>
              </a>
              <a
                href="https://wa.me/17783444567"
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
                  <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">
                    WhatsApp
                  </div>
                  <div className="text-surface-foreground font-semibold">Quick Response</div>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-10 text-primary/5 animate-float">
          <Lightbulb className="h-32 w-32 rotate-12" />
        </div>
        <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500">
          <Lightbulb className="h-24 w-24 -rotate-12" />
        </div>
      </section>

      {sections.map((s, i) => (
        <section
          key={s.title}
          id={s.id}
          className={`scroll-mt-24 ${i % 2 === 0 ? "py-24 bg-background" : "py-24 bg-muted/40"}`}
        >
          <div className="container mx-auto px-4">
            <div className={`grid gap-12 lg:grid-cols-2 items-center ${i % 2 === 1 ? "lg:[&>:first-child]:order-2" : ""}`}>
              <div className="overflow-hidden rounded-2xl shadow-elegant aspect-[4/3]">
                <img src={s.img} alt={s.title} loading="lazy" width={1600} height={1100} className="w-full h-full object-cover" />
              </div>
              <div>
                <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-gradient-electric shadow-glow mb-6">
                  <s.icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <h2 className="text-3xl md:text-5xl mb-4">{s.title}</h2>
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">{s.intro}</p>
                <ul className="grid sm:grid-cols-2 gap-3 mb-8">
                  {s.items.map((it) => (
                    <li key={it} className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                      <span>{it}</span>
                    </li>
                  ))}
                </ul>
                <div className="flex flex-col sm:flex-row gap-3">
                <Button asChild variant="electric">
                  <Link to={s.to}>More Information <ArrowRight className="h-4 w-4" /></Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/contact">Get Free Estimate</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* EV CALLOUT */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="relative overflow-hidden rounded-2xl shadow-elegant">
            <img
              src={evImage}
              alt="EV charger installation in residential garage"
              loading="lazy"
              width={1600}
              height={1200}
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-surface/90 via-surface/60 to-transparent md:via-surface/40" />
            <div className="relative p-8 md:p-12 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest mb-4">
                <Plug className="h-3 w-3" /> High Demand
              </div>
              <h2 className="font-display text-3xl md:text-4xl text-surface-foreground mb-4">
                EV Charger Installation
              </h2>
              <p className="text-surface-foreground/80 mb-6 leading-relaxed">
                Home and commercial EV chargers — fast, safe installation
                compatible with all major EV brands including Tesla, Ford,
                Rivian, Hyundai and more. Our certified electricians handle
                everything from panel load assessment to permit filing and
                final inspection.
              </p>
              <ul className="grid sm:grid-cols-2 gap-3 mb-8">
                {[
                  "Level 2 (240V) home chargers",
                  "Commercial & multi-unit setups",
                  "Panel upgrades when required",
                  "Permits & TSBC inspection",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-surface-foreground/90">
                    <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Button asChild variant="electric" size="lg">
                <Link to="/ev-charger">
                  Learn More <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* PERMITS */}
      <section className="py-24 bg-surface text-surface-foreground">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <FileCheck className="h-14 w-14 text-primary mx-auto mb-6" />
          <p className="text-sm uppercase tracking-widest font-bold text-primary mb-3">Special Service</p>
          <h2 className="text-4xl md:text-5xl mb-6">Electrical Permits & Code Compliance</h2>
          <p className="text-lg text-surface-foreground/80 mb-8 leading-relaxed">
            We handle permit approvals, electrical inspections, code-compliant
            installations, and complete project documentation — start to finish.
          </p>
          <Button asChild variant="electric" size="lg">
            <Link to="/contact">Talk to an Electrician</Link>
          </Button>
        </div>
      </section>

      <ServiceConnections
        current="/services"
        eyebrow="Service Pages"
        title="Explore Residential, Commercial, Industrial & EV Services"
      />

      <Footer />
    </div>
  );
}
