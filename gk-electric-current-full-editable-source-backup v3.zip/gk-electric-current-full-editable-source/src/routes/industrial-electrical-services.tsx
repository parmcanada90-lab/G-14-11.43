import { createFileRoute, Link } from "@tanstack/react-router";
import type { LucideIcon } from "lucide-react";
import {
  ArrowRight,
  BadgeCheck,
  Bolt,
  Cable,
  CheckCircle2,
  CircuitBoard,
  ClipboardCheck,
  Clock,
  Cpu,
  Factory,
  FileText,
  Gauge,
  HardHat,
  Home,
  Building2,
  Lightbulb,
  MessageCircle,
  Phone,
  PlugZap,
  Radar,
  Settings2,
  ShieldCheck,
  Siren,
  TimerReset,
  Truck,
  Warehouse,
  Wrench,
  Zap,
  Activity,
  ShieldAlert,
  Network,
  Leaf,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import industrialImage from "@/assets/industrial.jpg";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";

export const Route = createFileRoute("/industrial-electrical-services")({
  head: () => ({
    meta: [
      {
        title:
          "Industrial Electrical Services — Machinery, Three-Phase Power, Controls & Facility Upgrades | GK Electric",
      },
      {
        name: "description",
        content:
          "Professional industrial electrical services for facilities, warehouses, plants and production spaces, including power distribution, machinery wiring, controls, lighting, maintenance, safety upgrades and facility expansion support.",
      },
      {
        property: "og:title",
        content: "Industrial Electrical Services | GK Electric",
      },
      {
        property: "og:description",
        content:
          "Complete industrial electrical support for three-phase power, machinery wiring, controls, maintenance, lighting, code compliance and facility upgrades.",
      },
      { property: "og:image", content: industrialImage },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: industrialImage },
    ],
  }),
  component: SampleIndustrialServicesClonePage,
});

type IndustrialService = {
  icon: LucideIcon;
  title: string;
  desc: string;
};

type IndustrialCategory = {
  icon: LucideIcon;
  title: string;
  intro: string;
  services: IndustrialService[];
};

const industrialCategories: IndustrialCategory[] = [
  {
    icon: Gauge,
    title: "Power Distribution & Three-Phase Systems",
    intro:
      "Industrial-grade electrical infrastructure for plants, warehouses, and commercial facilities supporting heavy equipment and future expansion.",
    services: [
      { icon: Zap, title: "Three-Phase Power Installation", desc: "Install three-phase systems with feeders, panels, and distribution designed for high-demand commercial and industrial loads." },
      { icon: CircuitBoard, title: "Main Distribution Panels", desc: "Upgrade main distribution panels with switchgear support, breaker replacements, and organized circuit layouts for safer operation." },
      { icon: CircuitBoard, title: "Industrial Subpanels", desc: "Install subpanels for production areas, equipment zones, and facility expansion with clear and maintainable circuit organization." },
      { icon: Cable, title: "Feeders, Conduit & Cable Runs", desc: "Install feeders, conduit, and cable tray systems for safe long-distance power distribution across commercial facilities." },
      { icon: PlugZap, title: "Dedicated Equipment Circuits", desc: "Provide dedicated circuits for compressors, pumps, production lines, and heavy-duty commercial equipment." },
      { icon: Gauge, title: "Load Balancing", desc: "Analyze and balance electrical loads to improve system stability and reduce overload risks in commercial environments." },
      { icon: ShieldCheck, title: "Disconnects & Isolation Points", desc: "Install disconnects and isolation points to ensure safe maintenance access for machinery and electrical equipment." },
    ],
  },
  {
    icon: Factory,
    title: "Machinery Wiring & Equipment Hookups",
    intro:
      "Safe electrical connections and equipment readiness for industrial machinery, relocations, and production systems.",
    services: [
      { icon: Factory, title: "Machinery Connections", desc: "Electrical hookups for industrial machinery with correct voltage, protection, disconnects, and proper labeling." },
      { icon: Settings2, title: "Equipment Relocation Wiring", desc: "Safe disconnect, reroute, and reconnection of equipment during facility moves, layout changes, and upgrades." },
      { icon: Warehouse, title: "Production Line Power", desc: "Power installation for assembly lines, processing equipment, packaging systems, and warehouse operations." },
      { icon: PlugZap, title: "Compressor Circuits", desc: "Dedicated circuits for compressors with proper load sizing, protection, and maintenance access." },
      { icon: Wrench, title: "Welders, Lifts & Shop Equipment", desc: "Industrial power circuits for welders, hoists, lifts, and high-demand fabrication equipment." },
      { icon: Wrench, title: "Troubleshooting Equipment Power", desc: "Diagnosis and repair of power issues including tripping circuits, voltage drops, and equipment failures." },
    ],
  },
  {
    icon: Cpu,
    title: "Controls, Motors & Automation Support",
    intro:
      "Control wiring and motor power systems for reliable equipment operation and industrial automation support.",
    services: [
      { icon: Cpu, title: "Control Wiring", desc: "Low-voltage control wiring, relay systems, and field connections for industrial and facility automation." },
      { icon: Gauge, title: "Motor Circuits", desc: "Motor power circuits with proper protection, disconnects, and layout for reliable equipment operation." },
      { icon: Gauge, title: "Motors & VFD Wiring", desc: "Installation and wiring of motors, VFDs, starters, and troubleshooting for variable-speed systems." },
      { icon: Settings2, title: "Starter Wiring", desc: "Motor starter wiring and control connections with clean, safe terminations for industrial equipment." },
      { icon: Radar, title: "Sensors & Low-Voltage Interfaces", desc: "Electrical integration for sensors, interlocks, monitoring devices, and auxiliary control systems." },
      { icon: CircuitBoard, title: "Control Panel Support", desc: "Panel wiring, organized terminations, labeling, and support for industrial control systems and inspections." },
    ],
  },
  {
    icon: Lightbulb,
    title: "Industrial Lighting & Energy Upgrades",
    intro:
      "Efficient lighting systems that improve visibility, safety, and energy savings across industrial facilities and work areas.",
    services: [
      { icon: Lightbulb, title: "High-Bay LED Lighting", desc: "Install high-bay and low-bay LED lighting for warehouses, production floors, and large industrial spaces." },
      { icon: TimerReset, title: "Lighting Retrofits", desc: "Upgrade existing lighting systems to energy-efficient LED solutions with improved controls and performance." },
      { icon: ShieldCheck, title: "Emergency & Exit Lighting", desc: "Install and maintain emergency lighting, exit signs, and backup systems for safety compliance and visibility." },
      { icon: Lightbulb, title: "Exterior & Yard Lighting", desc: "Provide outdoor lighting for loading docks, yards, parking areas, and industrial facility security." },
      { icon: Settings2, title: "Lighting Controls", desc: "Install lighting control systems including zoning, occupancy sensors, and switching for energy efficiency." },
    ],
  },
  {
    icon: ShieldCheck,
    title: "Safety, Code Compliance & Inspection Readiness",
    intro:
      "Code-compliant workmanship, safety corrections, and professional documentation for industrial environments and inspections.",
    services: [
      { icon: ShieldCheck, title: "Code Deficiency Corrections", desc: "Correction of unsafe wiring, improper protection, labeling issues, and electrical code deficiencies." },
      { icon: ClipboardCheck, title: "Permit & Inspection Support", desc: "Electrical work planned with permit requirements, inspection readiness, and complete documentation support." },
      { icon: Zap, title: "Grounding & Bonding", desc: "Grounding and bonding inspections and improvements for safe and reliable industrial electrical systems." },
      { icon: Wrench, title: "Deficiency Repairs", desc: "Targeted repairs for failed inspections, unsafe installations, and non-compliant electrical connections." },
      { icon: BadgeCheck, title: "Panel Labeling", desc: "Clear panel schedules and circuit identification for safer maintenance and improved system organization." },
      { icon: HardHat, title: "Lockout-Aware Work Practices", desc: "Safety-focused electrical work using lockout procedures, equipment isolation, and controlled shutdown practices." },
    ],
  },
  {
    icon: Wrench,
    title: "Industrial Maintenance, Repairs & Shutdown Work",
    intro:
      "Planned maintenance and responsive repairs to keep industrial facilities operating safely and with minimal downtime.",
    services: [
      { icon: TimerReset, title: "Planned Shutdown Electrical Work", desc: "Coordinated electrical upgrades and repairs completed during scheduled downtime to reduce operational disruption." },
      { icon: CheckCircle2, title: "Preventive Maintenance", desc: "Routine inspection, testing, tightening, and repair recommendations to improve electrical system reliability." },
      { icon: Siren, title: "Emergency Troubleshooting", desc: "Fast response diagnostics and repairs for power loss, equipment failures, and urgent electrical issues." },
      { icon: Radar, title: "Thermal Issue Checks", desc: "Identify overheating, overloaded circuits, and loose connections to prevent equipment damage and downtime." },
      { icon: FileText, title: "Maintenance Documentation", desc: "Provide clear records, labeling, and maintenance notes for improved system tracking and future planning." },
      { icon: Settings2, title: "Repair Planning", desc: "Prioritized repair planning to help facilities manage downtime, materials, and safe execution efficiently." },
    ],
  },
  {
    icon: Cable,
    title: "Conduit, Cable Tray & Feeders",
    intro:
      "Protected and organized wiring pathways for safe, durable industrial power distribution and system expansion.",
    services: [
      { icon: Cable, title: "Rigid Conduit", desc: "Install durable rigid conduit systems for exposed industrial areas, equipment feeds, and protected power routing." },
      { icon: CircuitBoard, title: "Cable Tray Support", desc: "Design and install cable tray systems for organized and accessible power and low-voltage cable management." },
      { icon: ShieldCheck, title: "Armored Cable", desc: "Install armored cable for durable protection in industrial environments, equipment feeds, and production areas." },
      { icon: Cable, title: "Long-Distance Feeders", desc: "Run feeder systems across large facilities with proper sizing, protection, and voltage drop control." },
      { icon: PlugZap, title: "Overhead Drops", desc: "Install overhead power drops for machinery, workstations, and flexible industrial layouts." },
      { icon: HardHat, title: "Protected Routing", desc: "Design cable routing to protect wiring from damage caused by equipment movement, forklifts, and facility operations." },
    ],
  },
  {
    icon: HardHat,
    title: "Facility Expansion Support",
    intro:
      "Electrical planning and installation for new equipment, production areas, and industrial facility growth.",
    services: [
      { icon: Factory, title: "New Bay Power", desc: "Install electrical service for new industrial bays, shop areas, tenant spaces, and facility expansions." },
      { icon: Settings2, title: "Layout Changes", desc: "Reconfigure electrical systems when equipment layouts, workflows, or production areas are modified." },
      { icon: CircuitBoard, title: "Expansion Panels", desc: "Add and upgrade panels to support new electrical loads and future industrial growth requirements." },
      { icon: PlugZap, title: "Equipment Zones", desc: "Create organized power zones for machinery, production cells, and dedicated industrial work areas." },
      { icon: Truck, title: "Dock Power", desc: "Provide electrical systems for loading docks, including doors, lighting, and operational equipment." },
      { icon: Gauge, title: "Future Load Planning", desc: "Plan electrical capacity and distribution to support future equipment and expansion requirements." },
    ],
  },
  {
    icon: ClipboardCheck,
    title: "Electrical Testing, Commissioning & System Verification",
    intro: "Testing and validation of new and existing electrical systems to ensure safe operation, performance accuracy, and readiness for industrial use.",
    services: [
      { icon: CheckCircle2, title: "System Commissioning & Startup Testing", desc: "Final testing and verification of new electrical installations before full operational use in industrial environments." },
      { icon: BadgeCheck, title: "Electrical Acceptance Testing", desc: "Structured testing of equipment, circuits, and systems to confirm proper installation and safe performance." },
      { icon: Activity, title: "Power Quality Analysis", desc: "Evaluation of voltage stability, imbalance, and electrical disturbances affecting industrial equipment performance." },
      { icon: Gauge, title: "Load Testing & Performance Verification", desc: "Testing electrical systems under operational load conditions to ensure reliability and capacity compliance." },
    ],
  },
  {
    icon: Settings2,
    title: "Power Quality & Electrical Reliability Engineering",
    intro: "Analysis and correction of electrical performance issues to improve stability, efficiency, and equipment protection.",
    services: [
      { icon: Gauge, title: "Voltage Drop Analysis", desc: "Identify and correct voltage drop issues across long runs, heavy loads, and industrial distribution systems." },
      { icon: Zap, title: "Power Factor Correction Support", desc: "Improve electrical efficiency by addressing poor power factor and reducing unnecessary energy loss." },
      { icon: ShieldAlert, title: "Harmonics & Electrical Disturbance Checks", desc: "Detect and reduce harmonics and waveform distortion affecting sensitive industrial equipment." },
      { icon: ShieldCheck, title: "Equipment Protection Optimization", desc: "Improve electrical protection strategies for sensitive machinery and automation systems." },
    ],
  },
  {
    icon: Zap,
    title: "Backup Power & Energy Resilience Systems",
    intro: "Design and installation of backup power systems to maintain operations during outages and power interruptions.",
    services: [
      { icon: Factory, title: "Standby Generator Systems", desc: "Installation and integration of backup generators for continuous industrial power supply during outages." },
      { icon: TimerReset, title: "Automatic Transfer Switch (ATS) Installation", desc: "Safe switching systems that automatically transfer power between utility and backup sources." },
      { icon: Cpu, title: "UPS System Support", desc: "Uninterruptible power solutions for critical equipment, servers, and sensitive industrial systems." },
      { icon: ClipboardCheck, title: "Emergency Power Planning", desc: "Design of backup power strategies to support essential loads and maintain business continuity." },
    ],
  },
  {
    icon: Network,
    title: "Low Voltage & Industrial Communication Systems",
    intro: "Structured low-voltage systems for industrial communication, control, and connected facility infrastructure.",
    services: [
      { icon: Cable, title: "Structured Cabling Systems", desc: "Installation of organized data and communication cabling for industrial and commercial facilities." },
      { icon: CircuitBoard, title: "Industrial Network Wiring", desc: "Reliable network infrastructure wiring for machines, control systems, and facility communication." },
      { icon: Cpu, title: "Control System Communication Wiring", desc: "Low-voltage wiring support for automation, PLCs, and industrial control systems." },
      { icon: Radar, title: "Data & Equipment Connectivity Planning", desc: "Structured planning for reliable connectivity between industrial systems and equipment." },
    ],
  },
  {
    icon: Leaf,
    title: "Energy Optimization & Electrical Efficiency Services",
    intro: "Electrical system improvements focused on reducing energy consumption and improving operational efficiency.",
    services: [
      { icon: FileText, title: "Energy Audits & Electrical Assessment", desc: "Evaluate facility energy usage to identify inefficiencies and cost-saving opportunities." },
      { icon: Gauge, title: "Load Reduction Planning", desc: "Optimize electrical distribution to reduce unnecessary load and improve system performance." },
      { icon: Zap, title: "Electrical System Efficiency Upgrades", desc: "Upgrade outdated systems to improve energy efficiency and reduce operating costs." },
      { icon: Settings2, title: "Lighting & Power Optimization Strategies", desc: "Improve lighting and power usage efficiency across industrial and commercial facilities." },
    ],
  },
];

const categoryAccents = [
  "from-amber-400 to-yellow-500",
  "from-yellow-300 to-amber-500",
  "from-blue-400 to-cyan-500",
  "from-orange-400 to-rose-500",
  "from-red-400 to-orange-500",
  "from-slate-400 to-slate-700",
  "from-teal-400 to-cyan-600",
  "from-indigo-400 to-violet-600",
  "from-emerald-400 to-green-600",
  "from-purple-400 to-fuchsia-600",
  "from-pink-400 to-rose-600",
  "from-cyan-400 to-blue-600",
  "from-lime-400 to-emerald-600",
];

const industrialLicenceTags = [
  "Fully Licensed & Insured",
  "100% Code-Compliant Work",
  "24/7 Emergency Service",
  "Quality Workmanship Guaranteed",
] as const;

const process = [
  {
    icon: ClipboardCheck,
    title: "Evaluate Facility and Equipment Requirements",
    text: "We review equipment loads, production areas, power distribution systems, panel capacity, maintenance requirements, and operating constraints before defining the industrial electrical scope.",
  },
  {
    icon: Radar,
    title: "Plan Shutdowns, Safety, and Compliance",
    text: "Shutdown schedules, lockout procedures, permits, inspections, material sequencing, and site access requirements are coordinated before work begins.",
  },
  {
    icon: Wrench,
    title: "Install Industrial Electrical Systems",
    text: "Facility wiring, feeders, electrical panels, disconnects, motor circuits, controls, and industrial equipment connections are installed using durable methods and clear labeling.",
  },
  {
    icon: BadgeCheck,
    title: "Test, Verify, and Document",
    text: "Industrial electrical systems are tested, verified, labeled, and documented to support safe operation, maintenance planning, and inspection readiness.",
  },
];

function SampleIndustrialServicesClonePage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[58vh] flex items-center text-surface-foreground">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
          </div>
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: "50px 50px",
            }}
          />
          <div className="absolute bottom-0 left-10 text-primary/5 animate-float pointer-events-none">
            <Factory className="h-32 w-32 rotate-12" />
          </div>
          <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500 pointer-events-none">
            <Factory className="h-24 w-24 -rotate-12" />
          </div>

          <div className="container relative z-10 mx-auto px-4 py-24">
            <div className="max-w-5xl">
              <div className="max-w-4xl">
                <ElectricSectionTag label="Facilities" icon={Factory} tone="dark" variant="electric-v1-2" className="mb-8 [&>span:last-child]:!text-[15px] [&>span:last-child]:!font-normal" />
                <h1
                  data-reveal
                  className="font-display text-[80px] font-extrabold tracking-tight leading-[0.94] mb-7"
                >
                  <span className="text-typewriter">
                    Industrial <span className="brand-highlight">Services</span>
                  </span>
                </h1>
                <p className="text-[20px] font-light text-surface-foreground/75 max-w-3xl leading-relaxed mb-8">
                  Professional electrical support for industrial facilities, production spaces and warehouses, including three-phase power, machinery wiring, controls, lighting, maintenance, code compliance, conduit, cable tray, feeders and expansion planning.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="electric" size="xl">
                    <Link to="/contact">
                      Request Industrial Estimate <ArrowRight className="h-5 w-5" />
                    </Link>
                  </Button>
                  <Button asChild variant="outlineLight" size="xl">
                    <a href="tel:+17783444567">
                      <Phone className="h-5 w-5" /> Call +1 (778) 344-4567
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Industrial Services Map Section */}
        <section className="relative overflow-hidden border-y border-border bg-muted/35 py-0">
          <style>{`
            @keyframes industrialServiceTickerMove {
              from { transform: translate3d(0, 0, 0); }
              to { transform: translate3d(-50%, 0, 0); }
            }
            .industrial-service-ticker-track {
              animation: industrialServiceTickerMove 92s linear infinite;
              backface-visibility: hidden;
              transform: translate3d(0, 0, 0);
              will-change: transform;
            }
            .industrial-service-ticker:hover .industrial-service-ticker-track {
              animation-play-state: paused;
            }
          `}</style>
          <div className="flex min-h-14 items-stretch gap-0 px-0 md:px-6">
            <div className="relative z-20 flex shrink-0 items-center gap-3 self-stretch border-r border-border bg-muted/95 px-3 pr-5 md:px-0 md:pr-5">
              <span className="flex h-8 w-8 items-center justify-center !rounded-[10px] bg-gradient-electric shadow-glow">
                <Bolt className="h-4 w-4 text-primary-foreground" />
              </span>
              <div className="leading-tight">
                <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground md:text-xl">Industrial Services Map</h2>
              </div>
            </div>

            <div className="industrial-service-ticker relative flex min-w-0 flex-1 overflow-hidden py-0">
              <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-muted/95 to-transparent" />
              <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-20 bg-gradient-to-l from-muted/95 to-transparent" />
              <div className="industrial-service-ticker-track flex min-w-max items-stretch gap-0 py-0">
                {[...industrialCategories, ...industrialCategories].map((category, index) => {
                  const CategoryIcon = category.icon;
                  const accent = categoryAccents[index % industrialCategories.length] || "from-amber-400 to-yellow-500";
                  return (
                    <a
                      key={`${category.title}-${index}`}
                      href={`#industrial-service-${index % industrialCategories.length}`}
                      className="group/service-news relative flex min-h-14 shrink-0 items-center gap-2 self-stretch rounded-none border-r border-border/80 px-8 pb-[3px] text-left transition-all duration-200 hover:bg-white focus:outline-none focus:ring-2 focus:ring-primary/40"
                    >
                      <span className={`flex h-7 w-7 shrink-0 items-center justify-center !rounded-[10px] bg-gradient-to-br ${accent} shadow-sm transition-colors duration-200`}>
                        <CategoryIcon className="h-4 w-4 text-primary-foreground" />
                      </span>
                      <span className="whitespace-nowrap font-display text-base font-bold uppercase tracking-wide text-foreground antialiased transition-colors duration-200">
                        {category.title}
                      </span>
                      <span className="pointer-events-none absolute inset-x-0 bottom-0 h-[3px] origin-center scale-x-0 bg-primary transition-transform duration-200 group-hover/service-news:scale-x-100" aria-hidden />
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 md:py-28 bg-muted/35">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 lg:grid-cols-[1fr_0.82fr] lg:items-center mb-14">
              <div className="max-w-3xl" data-reveal>
                <ElectricSectionTag label="Industrial Electrical Services" icon={ClipboardCheck} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-4xl md:text-6xl font-bold mb-5">
                  Reliable Power Solutions for Industrial Facilities
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  Comprehensive industrial electrical services for manufacturing plants, warehouses, processing facilities, and industrial operations. From equipment installations and power distribution systems to maintenance, troubleshooting, automation support, and facility expansions, we provide safe, efficient, and code-compliant electrical solutions that minimize downtime and support productivity.
                </p>
              </div>

              <div data-reveal="right" className="relative">
                <article className="group relative flex border-2 flex-col overflow-hidden rounded-3xl border-foreground/30 bg-transparent p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary hover:shadow-elegant">
                  <div className="flex items-start justify-between gap-4">
                    <div className="text-left">
                      <div className="font-sans text-lg font-extrabold uppercase leading-none tracking-[0.22em] text-foreground">
                        GK ELECTRIC
                      </div>
                      <div className="mt-1 text-[12px] uppercase tracking-widest text-muted-foreground">
                        Licensed Electricians
                      </div>
                    </div>
                    <div className="shrink-0">
                      <div className="shrink-0 rounded-2xl bg-[#00497b] px-3 py-2.5 shadow-xl ring-2 ring-white/90">
                        <div className="flex items-center justify-end gap-3">
                          <img
                            src={tsbcLogo}
                            alt="Technical Safety BC logo"
                            className="h-12 w-12 object-contain"
                            loading="lazy"
                          />
                          <div className="text-right text-white">
                            <div className="text-[0.95rem] tracking-wider text-white">TSBC Licence</div>
                            <div className="text-[1.1rem] tracking-[1.5px] font-bold text-white"># LEL0209793</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 grid grid-cols-2 gap-2.5">
                    {industrialLicenceTags.map((tag) => (
                      <div
                        key={tag}
                        className="flex min-h-9 w-full items-center gap-1.5 rounded-[10px] border border-primary/20 bg-primary/10 px-3 py-1.5 text-[14px] font-medium leading-none text-foreground shadow-sm"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                        <span className="truncate">{tag}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-5 flex-none flex items-start justify-between gap-5">
                    <div className="w-full text-left">
                      <div className="mb-4 h-1 w-14 rounded-full bg-foreground" />
                      <h2 className="whitespace-nowrap font-sans text-[clamp(0.78rem,1.7vw,0.95rem)] font-semibold uppercase leading-none tracking-[0.18em] text-foreground">
                        Proudly Serving the Lower Mainland, BC
                      </h2>
                    </div>
                  </div>

                  <div className="relative z-10 mt-3 grid grid-cols-3 gap-2">
                    {[
                      { label: "Residential", to: "/residential-electrical-services" as const, icon: Home },
                      { label: "Commercial", to: "/commercial-electrical-services" as const, icon: Building2 },
                      { label: "Industrial", to: "/industrial-electrical-services" as const, icon: Factory },
                    ].map((item) => (
                      <Link
                        key={item.label}
                        to={item.to}
                        className="group/service flex flex-col items-center justify-center gap-1.5 rounded-xl border border-border bg-muted/40 px-2.5 py-3 text-center transition-all duration-300 hover:border-primary/45 hover:bg-primary/[0.1]"
                      >
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center !rounded-[10px] border border-primary/20 bg-primary/15 text-primary transition-all duration-300 group-hover/service:bg-primary group-hover/service:text-primary-foreground">
                          <item.icon className="h-4.5 w-4.5" />
                        </div>
                        <div className="font-sans text-[18px] font-bold uppercase tracking-wide text-foreground leading-tight">
                          {item.label}
                        </div>
                      </Link>
                    ))}
                  </div>
                </article>
              </div>
            </div>

            <div className="space-y-10">
              {industrialCategories.map((category, index) => {
                const CategoryIcon = category.icon;
                const accent = categoryAccents[index % industrialCategories.length] || "from-amber-400 to-yellow-500";
                return (
                  <article id={`industrial-service-${index}`} key={category.title} data-reveal className="scroll-mt-28 relative rounded-[2rem] border border-border bg-card shadow-card transition-all duration-300 hover:border-primary/40">
                    <div className="absolute right-6 top-6 text-primary/5 pointer-events-none">
                      <CategoryIcon className="h-28 w-28 -rotate-12" />
                    </div>
                    <div className="grid gap-0 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
                      <div className="relative h-full bg-surface text-surface-foreground p-8 md:p-10 rounded-t-[2rem] lg:rounded-l-[2rem] lg:rounded-tr-none">
                        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />
                        <div className="relative z-10 lg:sticky lg:top-28 lg:self-start" data-reveal="left">
                          <div className={`mb-6 flex h-16 w-16 items-center justify-center !rounded-[10px] bg-gradient-to-br ${accent} shadow-glow`}>
                            <CategoryIcon className="h-8 w-8 text-primary-foreground" />
                          </div>
                          <h3 className="font-display text-3xl md:text-4xl font-extrabold mb-4">{category.title}</h3>
                          <p className="text-surface-foreground/70 leading-relaxed">{category.intro}</p>
                        </div>
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4 p-6 md:p-8">
                        {category.services.map((service, serviceIndex) => {
                          const ServiceIcon = service.icon;
                          return (
                            <div key={service.title} data-reveal="right" className="group rounded-2xl border border-border bg-background p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:bg-primary/5" style={{ transitionDelay: `${serviceIndex * 55}ms` }}>
                              <div className="mb-4 flex h-12 w-12 items-center justify-center !rounded-[10px] bg-primary/10 text-primary transition-all group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-110">
                                <ServiceIcon className="h-6 w-6" />
                              </div>
                              <h4 className="font-display text-xl font-bold text-foreground mb-2">{service.title}</h4>
                              <p className="text-sm text-muted-foreground leading-relaxed">{service.desc}</p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-24 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] items-center">
              <div data-reveal="left">
                <ElectricSectionTag label="Industrial Facilities We Service" icon={Factory} tone="light" variant="electric-v1-2" className="mb-6" />
                <h2 className="font-display text-4xl md:text-5xl font-bold mb-5">
                  Industrial Electrical Services for Manufacturing, Processing, and Operational Facilities
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed mb-8">
                  GK ELECTRIC provides professional industrial electrical services for facility owners, operations managers, manufacturers, and industrial contractors. We support industrial electrical installations, power distribution systems, facility wiring, equipment connections, panel upgrades, maintenance, troubleshooting, shutdown projects, and code-compliance requirements.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="electric" size="lg">
                    <Link to="/contact">Request An Estimate</Link>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                      <MessageCircle className="h-5 w-5" /> WhatsApp
                    </a>
                  </Button>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2" data-reveal="right">
                {[
                  { title: "Manufacturing facilities", icon: Factory },
                  { title: "Processing and production plants", icon: Settings2 },
                  { title: "Warehouses and distribution centres", icon: Warehouse },
                  { title: "Industrial workshops and fabrication facilities", icon: Wrench },
                  { title: "Packaging and assembly operations", icon: Cpu },
                  { title: "Logistics and transportation facilities", icon: Truck },
                  { title: "Utility and infrastructure facilities", icon: Bolt },
                  { title: "Industrial storage and service yards", icon: TimerReset },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.title} className="rounded-2xl border border-border bg-card p-5 shadow-sm transition-all hover:border-primary/50 hover:shadow-card">
                      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <p className="font-semibold text-foreground">{item.title}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
              <div>
                <ElectricSectionTag label="Complete Industrial Electrical Coverage" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-3xl md:text-5xl font-extrabold leading-tight mb-4">
                  <span className="text-primary">GK ELECTRIC</span> provides licensed and professional industrial electrical services, including electrical repairs, installations, upgrades, maintenance, troubleshooting, and code-compliant solutions for manufacturing facilities, warehouses, processing plants, and industrial operations.
                </h2>
                <p className="text-surface-foreground/70 text-base md:text-lg leading-relaxed max-w-3xl">
                  One licensed team for industrial power distribution, facility wiring, electrical panel upgrades, motor and equipment connections, control systems, electrical permits, safety repairs, preventive maintenance, lighting installations, and complete industrial electrical installations.
                </p>
              </div>
              <div className="flex flex-col items-center gap-4">
                {[
                  { icon: Home, label: "Residential", to: "/services/residential" as const },
                  { icon: Building2, label: "Commercial", to: "/services/commercial" as const },
                  { icon: Factory, label: "Industrial", to: "/services/industrial" as const },
                ].map((item) => (
                  <Link key={item.label} to={item.to} className="group/coverage relative mx-auto flex w-1/2 min-w-[220px] max-w-[320px] items-center justify-center gap-3 overflow-hidden rounded-[5px] border border-primary/45 bg-transparent px-5 py-3.5 text-primary backdrop-blur-sm transition-all duration-500 ease-out hover:-translate-y-0.5 hover:border-primary hover:text-primary-foreground hover:shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2 focus:ring-offset-surface before:absolute before:inset-0 before:origin-left before:scale-x-0 before:bg-gradient-electric before:transition-transform before:duration-500 before:ease-out hover:before:scale-x-100">
                    <div className="relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-[5px] bg-transparent text-primary transition-all duration-500 group-hover/coverage:rotate-3 group-hover/coverage:scale-105 group-hover/coverage:text-primary-foreground">
                      <item.icon className="h-10 w-10" />
                    </div>
                    <div className="relative z-10 font-display text-base font-extrabold uppercase tracking-[0.18em]">{item.label}</div>
                    <ArrowRight className="relative z-10 h-5 w-5 opacity-70 transition-all duration-500 group-hover/coverage:translate-x-1.5 group-hover/coverage:opacity-100" />
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-start">
              <div className="lg:sticky lg:top-28" data-reveal="left">
                <ElectricSectionTag label="Professional Workflow" icon={HardHat} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">
                  Built for Safety, Uptime, and Clean Execution
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                  Industrial electrical projects require detailed planning, coordination, and precise execution. We organize every scope around facility safety, equipment reliability, operational uptime, shutdown windows, and regulatory compliance.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="electric" size="lg">
                    <Link to="/contact">
                      Request an Industrial Electrical Estimate <ArrowRight className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                      <MessageCircle className="h-4 w-4" /> WhatsApp
                    </a>
                  </Button>
                </div>
              </div>
              <div className="grid gap-5">
                {process.map((step, index) => (
                  <div key={step.title} data-reveal="right" className="group rounded-2xl border border-border bg-card p-6 shadow-card hover:shadow-elegant hover:border-primary/40 hover:-translate-y-1 transition-all duration-300" style={{ transitionDelay: `${index * 90}ms` }}>
                    <div className="flex gap-5 items-start">
                      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors shrink-0">
                        <step.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                      </div>
                      <div>
                        <div className="mb-1 text-xs font-bold uppercase tracking-[0.25em] text-primary">Step-{index + 1}</div>
                        <h3 className="font-display text-xl font-bold text-foreground mb-2">{step.title}</h3>
                        <p className="text-muted-foreground leading-relaxed">{step.text}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <ElectricSectionTag label="Ready To Get Started" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-6 justify-center" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold mb-6">
                Need Industrial Electrical Support?
              </h2>
              <p className="text-lg text-surface-foreground/70 leading-relaxed mb-8 max-w-2xl mx-auto">
                Speak with GK Electric about facility upgrades, machinery power, three-phase systems, controls, maintenance, lighting or shutdown electrical work.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="electric" size="xl">
                  <a href="tel:+17783444567">
                    <Phone className="h-5 w-5" /> Call +1 (778) 344-4567
                  </a>
                </Button>
                <Button asChild variant="outline" size="xl" className="bg-white/5 border-white/15 text-white hover:bg-white/10">
                  <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                    <MessageCircle className="h-5 w-5" /> WhatsApp Quick Response
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
