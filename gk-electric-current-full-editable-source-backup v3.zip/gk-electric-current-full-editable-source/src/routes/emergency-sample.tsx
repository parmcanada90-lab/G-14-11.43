import { createFileRoute, Link } from "@tanstack/react-router";
import {
  AlertTriangle,
  ArrowRight,
  BellRing,
  Building2,
  CheckCircle2,
  Flame,
  Gauge,
  Home,
  MapPin,
  Phone,
  PlugZap,
  ShieldAlert,
  Siren,
  TimerReset,
  Wrench,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const Route = createFileRoute("/emergency-sample")({
  head: () => ({
    meta: [
      { title: "Emergency Service Section Samples | GK Electric" },
      {
        name: "description",
        content:
          "Light-background emergency electrical service section samples for GK Electric.",
      },
    ],
  }),
  component: EmergencySamplePage,
});

const phoneNumber = "+1 (778) 344-4567";
const phoneHref = "tel:+17783444567";

const emergencyCards = [
  {
    icon: Siren,
    title: "24/7 Emergency Repairs",
    desc: "Urgent help for outages, sparks, burning smells, buzzing panels and unsafe wiring.",
  },
  {
    icon: Zap,
    title: "Power Outages",
    desc: "Fast troubleshooting for full or partial power loss in homes and businesses.",
  },
  {
    icon: Flame,
    title: "Burning Smell or Sparks",
    desc: "Immediate safety checks for overheated outlets, arcing and fire-risk warning signs.",
  },
  {
    icon: AlertTriangle,
    title: "Breaker & Panel Issues",
    desc: "Diagnosis for tripping breakers, warm devices, overloaded panels and electrical faults.",
  },
];

const warningSigns = ["Burning smell", "Sparking outlets", "Buzzing panel", "Repeated breaker trips", "Partial power loss", "Hot switches"];
const steps = ["Call emergency line", "Safety guidance", "Electrician dispatched", "Hazard isolated", "Repair completed", "System tested"];

function Eyebrow({ children, dark = false }: { children: React.ReactNode; dark?: boolean }) {
  return (
    <div className={`mb-4 inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-black uppercase tracking-[0.18em] ${dark ? "bg-white/12 text-white" : "bg-primary/10 text-primary"}`}>
      <Siren className="h-4 w-4" />
      {children}
    </div>
  );
}

function EmergencyCTA({ dark = false, compact = false }: { dark?: boolean; compact?: boolean }) {
  return (
    <div className={`flex flex-col gap-3 ${compact ? "sm:flex-col" : "sm:flex-row"}`}>
      <a
        href={phoneHref}
        className={`inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-black uppercase tracking-[0.12em] transition hover:-translate-y-0.5 ${dark ? "bg-primary text-primary-foreground hover:bg-white" : "bg-surface text-white hover:bg-primary hover:text-primary-foreground"}`}
      >
        <Phone className="h-4 w-4" /> Call {phoneNumber}
      </a>
      <Link
        to="/emergency-electrician-surrey"
        className={`inline-flex items-center justify-center gap-2 rounded-full border px-6 py-3 text-sm font-black uppercase tracking-[0.12em] transition hover:-translate-y-0.5 ${dark ? "border-white/25 text-white hover:bg-white hover:text-surface" : "border-border text-foreground hover:border-primary hover:text-primary"}`}
      >
        Emergency Details <ArrowRight className="h-4 w-4" />
      </Link>
    </div>
  );
}

function SampleShell({ number, title, children }: { number: string; title: string; children: React.ReactNode }) {
  return (
    <section className="border-t border-border bg-white py-16 md:py-20">
      <div className="container mx-auto px-4">
        <div className="mb-8 flex items-center justify-between gap-4 border-b border-border pb-4">
          <div>
            <div className="text-xs font-black uppercase tracking-[0.2em] text-primary">Design {number}</div>
            <h2 className="font-display text-2xl font-bold text-foreground md:text-3xl">{title}</h2>
          </div>
          <div className="hidden h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary md:flex">{number}</div>
        </div>
        {children}
      </div>
    </section>
  );
}

function EmergencyCardGrid() {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {emergencyCards.map((card) => (
        <div key={card.title} className="rounded-3xl border border-border bg-card p-6 shadow-card transition hover:-translate-y-2 hover:shadow-elegant">
          <card.icon className="mb-8 h-9 w-9 text-primary" />
          <h4 className="font-display text-2xl font-bold">{card.title}</h4>
          <p className="mt-3 text-sm text-muted-foreground">{card.desc}</p>
        </div>
      ))}
    </div>
  );
}

function EmergencySamplePage() {
  return (
    <div className="min-h-screen bg-white text-foreground">
      <Header />
      <main className="pt-24">
        <section className="bg-gradient-to-b from-primary/10 via-white to-white py-20">
          <div className="container mx-auto px-4 text-center">
            <Eyebrow>Emergency Section Concepts</Eyebrow>
            <h1 className="mx-auto max-w-5xl font-display text-5xl font-black uppercase leading-tight md:text-7xl">
              Light Background Emergency Service Designs
            </h1>
            <p className="mx-auto mt-6 max-w-3xl text-lg text-muted-foreground">
              GK Electric emergency service message, redesigned in multiple white/light section styles for review.
            </p>
          </div>
        </section>

        <SampleShell number="01" title="Split Hero with Emergency Cards">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <div>
              <Eyebrow>24/7 Emergency Service</Eyebrow>
              <h3 className="font-display text-5xl font-black uppercase leading-tight">Emergency Electrician in Surrey</h3>
              <p className="mt-5 text-lg text-muted-foreground">Fast support for dangerous electrical issues, power failures and urgent repairs.</p>
              <div className="mt-8"><EmergencyCTA /></div>
            </div>
            <EmergencyCardGrid />
          </div>
        </SampleShell>

        <SampleShell number="02" title="Centered Premium Panel">
          <div className="rounded-[2rem] border border-border bg-gradient-to-br from-white via-primary/5 to-white p-8 text-center shadow-elegant md:p-12">
            <Eyebrow>Immediate Response</Eyebrow>
            <h3 className="mx-auto max-w-4xl font-display text-5xl font-black uppercase">Power outage, sparks, or burning smell?</h3>
            <p className="mx-auto mt-5 max-w-2xl text-muted-foreground">Our licensed electricians respond to urgent electrical hazards across Surrey and the Lower Mainland.</p>
            <div className="mt-8 flex justify-center"><EmergencyCTA /></div>
          </div>
        </SampleShell>

        <SampleShell number="03" title="Timeline Dispatch Process">
          <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr]">
            <div className="rounded-3xl bg-surface p-8 text-white">
              <Eyebrow dark>Rapid Dispatch</Eyebrow>
              <h3 className="font-display text-4xl font-black uppercase">From call to safe power.</h3>
              <p className="mt-4 text-white/70">Clear steps for urgent electrical repair.</p>
              <div className="mt-8"><EmergencyCTA dark compact /></div>
            </div>
            <div className="space-y-4">
              {steps.map((step, index) => (
                <div key={step} className="flex items-center gap-5 rounded-2xl border border-border bg-white p-5 shadow-card">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary font-black text-primary-foreground">{index + 1}</div>
                  <div className="font-bold">{step}</div>
                </div>
              ))}
            </div>
          </div>
        </SampleShell>

        <SampleShell number="04" title="Alert Banner with Service Grid">
          <div className="overflow-hidden rounded-[2rem] border border-primary/20 bg-primary/5">
            <div className="flex flex-col justify-between gap-5 bg-primary p-6 text-primary-foreground md:flex-row md:items-center">
              <div className="flex items-center gap-4"><BellRing className="h-8 w-8" /><div><h3 className="font-display text-3xl font-bold">Electrical emergency?</h3><p className="opacity-80">Call now before a small warning becomes a hazard.</p></div></div>
              <a href={phoneHref} className="rounded-full bg-surface px-6 py-3 text-sm font-black uppercase tracking-widest text-white">Call Now</a>
            </div>
            <div className="grid gap-0 md:grid-cols-4">
              {emergencyCards.map((card) => <div key={card.title} className="border-t border-primary/15 bg-white p-6 md:border-l"><card.icon className="mb-5 h-8 w-8 text-primary" /><h4 className="font-bold">{card.title}</h4></div>)}
            </div>
          </div>
        </SampleShell>

        <SampleShell number="05" title="Diagonal Feature Cards">
          <div className="grid gap-5 md:grid-cols-4">
            {emergencyCards.map((card, index) => (
              <div key={card.title} className={`rounded-[2rem] border border-border bg-white p-6 shadow-card transition hover:-translate-y-3 ${index % 2 ? "md:mt-10" : ""}`}>
                <div className="mb-8 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><card.icon className="h-7 w-7" /></div>
                <h3 className="font-display text-2xl font-bold">{card.title}</h3>
                <p className="mt-3 text-sm text-muted-foreground">{card.desc}</p>
              </div>
            ))}
          </div>
        </SampleShell>

        <SampleShell number="06" title="Warning Signs Checklist">
          <div className="grid gap-8 lg:grid-cols-2">
            <div><Eyebrow>Do not ignore</Eyebrow><h3 className="font-display text-5xl font-bold">Call if you notice these signs.</h3></div>
            <div className="rounded-3xl border border-border bg-white p-6 shadow-card">{warningSigns.map((sign) => <div key={sign} className="flex items-center gap-4 border-b border-border py-4 last:border-b-0"><CheckCircle2 className="h-6 w-6 text-primary" /><span className="font-bold">{sign}</span></div>)}</div>
          </div>
        </SampleShell>

        <SampleShell number="07" title="Commercial Emergency Style">
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="rounded-3xl bg-surface p-8 text-white lg:col-span-1"><Building2 className="mb-8 h-12 w-12 text-primary" /><h3 className="font-display text-4xl font-bold">Business power failure?</h3><p className="mt-4 text-white/70">Minimize downtime with priority electrical troubleshooting.</p></div>
            <div className="grid gap-4 sm:grid-cols-2 lg:col-span-2">{["Retail outages", "Office panels", "Restaurant power", "Security systems"].map((item) => <div key={item} className="rounded-2xl border border-border bg-white p-6 shadow-card"><Gauge className="mb-4 h-7 w-7 text-primary" /><strong>{item}</strong></div>)}</div>
          </div>
        </SampleShell>

        <SampleShell number="08" title="Residential Emergency Style">
          <div className="rounded-[2rem] border border-border bg-muted p-8">
            <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
              <div><Home className="mb-6 h-12 w-12 text-primary" /><h3 className="font-display text-5xl font-bold">Keep your home safe tonight.</h3><p className="mt-4 text-muted-foreground">Urgent help for homeowners experiencing unsafe electrical warning signs.</p></div>
              <div className="rounded-3xl bg-white p-6 shadow-card"><EmergencyCTA compact /><div className="mt-6 space-y-3">{["Family safety", "Fast diagnosis", "Clean repairs"].map((item) => <div key={item} className="flex items-center gap-2"><CheckCircle2 className="h-5 w-5 text-primary" />{item}</div>)}</div></div>
            </div>
          </div>
        </SampleShell>

        <SampleShell number="09" title="Local Surrey Layout">
          <div className="rounded-[2rem] bg-gradient-to-br from-white to-primary/10 p-8 shadow-card md:p-12">
            <div className="grid gap-8 lg:grid-cols-[0.75fr_1.25fr] lg:items-center">
              <div><MapPin className="mb-6 h-12 w-12 text-primary" /><h3 className="font-display text-5xl font-bold">Surrey emergency electrician.</h3><p className="mt-4 text-muted-foreground">Local-first layout for city service pages.</p></div>
              <div className="grid gap-3 sm:grid-cols-2">{["Fleetwood", "Guildford", "Newton", "Cloverdale", "South Surrey", "Whalley"].map((city) => <div key={city} className="rounded-2xl bg-white p-4 font-bold shadow-card"><MapPin className="mb-2 h-5 w-5 text-primary" />{city}</div>)}</div>
            </div>
          </div>
        </SampleShell>

        <SampleShell number="10" title="Final Conversion Section">
          <div className="relative overflow-hidden rounded-[2.5rem] bg-surface p-8 text-white shadow-elegant md:p-14">
            <div className="absolute right-0 top-0 h-64 w-64 rounded-full bg-primary/20 blur-3xl" />
            <div className="relative grid gap-8 lg:grid-cols-[1fr_0.8fr] lg:items-center">
              <div><Eyebrow dark>Final CTA</Eyebrow><h3 className="font-display text-5xl font-black uppercase md:text-7xl">Need emergency electrical help now?</h3><p className="mt-5 max-w-2xl text-white/70">A strong closing conversion section with dark card on a light page.</p></div>
              <div className="rounded-3xl border border-white/10 bg-white/[0.06] p-6 backdrop-blur-md"><EmergencyCTA dark compact /><div className="mt-6 text-sm text-white/60">Licensed electricians • Surrey & Lower Mainland • Safety-first repairs</div></div>
            </div>
          </div>
        </SampleShell>
      </main>
      <Footer />
    </div>
  );
}
