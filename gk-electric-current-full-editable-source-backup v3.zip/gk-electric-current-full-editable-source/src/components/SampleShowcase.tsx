import { Link } from "@tanstack/react-router";
import { ArrowRight, Building2, Factory, Home, Plug, Sparkles } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import residentialImage from "@/assets/residential.jpg";
import commercialImage from "@/assets/commercial.jpg";
import industrialImage from "@/assets/industrial.jpg";
import evImage from "@/assets/ev-charger.jpg";

const services = [
  {
    icon: Home,
    title: "Residential",
    desc: "Full home electrical for safer, brighter, more efficient living spaces.",
    img: residentialImage,
    to: "/services/residential" as const,
    tag: "Click for Residential Services",
  },
  {
    icon: Building2,
    title: "Commercial",
    desc: "Reliable power for offices, retail and commercial buildings.",
    img: commercialImage,
    to: "/services/commercial" as const,
    tag: "Click for Commercial Services",
  },
  {
    icon: Factory,
    title: "Industrial",
    desc: "Heavy electrical for factories, warehouses and industrial facilities.",
    img: industrialImage,
    to: "/services/industrial" as const,
    tag: "Click for Industrial Services",
  },
] as const;

const tagStyles: Record<number, string> = {
  1: "right-5 top-5 translate-y-2 rounded-full border border-primary/40 bg-surface/85 px-4 py-2 text-primary opacity-0 shadow-glow backdrop-blur-md group-hover:translate-y-0 group-hover:opacity-100",
  2: "left-5 top-5 -translate-x-3 rounded-full bg-primary px-4 py-2 text-primary-foreground opacity-0 shadow-glow group-hover:translate-x-0 group-hover:opacity-100",
  3: "right-0 top-7 translate-x-full rounded-l-2xl bg-white/90 px-5 py-3 text-surface shadow-xl group-hover:translate-x-0",
  4: "left-1/2 top-1/2 -translate-x-1/2 -translate-y-[35%] scale-90 rounded-2xl border border-white/25 bg-surface/75 px-5 py-3 text-white opacity-0 shadow-2xl backdrop-blur-md group-hover:-translate-y-1/2 group-hover:scale-100 group-hover:opacity-100",
  5: "right-5 top-5 origin-top-right -rotate-6 rounded-xl bg-primary/95 px-4 py-2 text-primary-foreground opacity-0 shadow-glow group-hover:rotate-0 group-hover:opacity-100",
  6: "left-5 top-5 translate-y-2 rounded-full border border-primary/50 bg-black/55 px-4 py-2 text-primary opacity-0 shadow-[0_0_30px_rgba(245,181,38,0.45)] backdrop-blur group-hover:translate-y-0 group-hover:opacity-100 group-hover:animate-pulse",
  7: "right-5 bottom-32 translate-y-3 rounded-full bg-white px-4 py-2 text-surface opacity-0 shadow-xl group-hover:translate-y-0 group-hover:opacity-100",
  8: "left-5 top-5 -translate-y-3 rounded-2xl border border-white/20 bg-white/10 px-4 py-3 text-white opacity-0 shadow-xl backdrop-blur-md group-hover:translate-y-0 group-hover:opacity-100",
  9: "inset-x-5 top-5 -translate-y-3 rounded-xl bg-primary/90 px-4 py-2 text-center text-primary-foreground opacity-0 shadow-glow group-hover:translate-y-0 group-hover:opacity-100",
  10: "right-5 top-5 translate-y-2 rounded-full border border-white/25 bg-surface/90 px-4 py-2 text-white opacity-0 shadow-2xl backdrop-blur-md after:absolute after:right-8 after:top-full after:border-8 after:border-transparent after:border-t-surface/90 group-hover:translate-y-0 group-hover:opacity-100",
};

type SampleShowcaseProps = {
  variant: number;
};

export function SampleShowcase({ variant }: SampleShowcaseProps) {
  const tagClassName = tagStyles[variant] ?? tagStyles[1];
  const isSampleThree = variant === 3;
  const moreInformationClassName = isSampleThree
    ? "mt-auto inline-flex items-center gap-2 rounded-full border border-primary/70 bg-transparent px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary shadow-none transition-all duration-300 hover:border-primary hover:bg-transparent hover:text-primary-glow hover:shadow-none"
    : "mt-auto inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary px-5 py-3 text-sm font-bold uppercase tracking-widest text-primary-foreground transition-all duration-300";

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 pt-28">
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="mb-14 text-center">
              <ElectricSectionTag label={`Full Image Showcase (15) — Sample ${variant}`} icon={Sparkles} tone="light" variant="electric-v1-2" className="mb-6 justify-center" />
              <h1 className="font-display text-4xl md:text-6xl font-extrabold tracking-tight">
                Hover Tag <span className="text-primary">Effect</span>
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
                Same full-image service showcase layout with only the hover tag effect changed.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {services.map((s, i) => (
                <Link
                  key={s.title}
                  to={s.to}
                  data-reveal="zoom"
                  style={{ transitionDelay: `${i * 120}ms` }}
                  className="group relative min-h-[430px] overflow-hidden rounded-[2rem] shadow-elegant transition-all duration-500"
                  aria-label={s.tag}
                >
                  <img
                    src={s.img}
                    alt={`${s.title} electrical service`}
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/45 to-transparent" />
                  <div className={`absolute z-10 text-xs font-black uppercase tracking-[0.18em] transition-all duration-500 ${tagClassName}`}>
                    {s.tag}
                  </div>
                  <div className="absolute inset-x-0 bottom-0 p-7 text-surface-foreground">
                    <div className="flex min-h-[220px] flex-col items-start">
                      <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                        <s.icon className="h-7 w-7" />
                      </div>
                      <h3 className="mb-3 text-3xl font-bold leading-tight">{s.title}</h3>
                      <p className={`${isSampleThree ? "mb-4 h-[4.25rem]" : "mb-5 h-[4.25rem]"} text-sm leading-relaxed text-surface-foreground/75`}>
                        {s.desc}
                      </p>
                      <div className={moreInformationClassName}>
                        More Information <ArrowRight className="h-4 w-4" />
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            <div data-reveal className="relative mt-16 overflow-hidden rounded-2xl shadow-elegant group">
              <img
                src={evImage}
                alt="EV charger installation in residential garage"
                loading="lazy"
                width={1600}
                height={1200}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-surface/90 via-surface/60 to-transparent md:via-surface/40" />
              <div className={`absolute z-10 text-xs font-black uppercase tracking-[0.18em] transition-all duration-500 ${tagClassName}`}>
                Click for EV Charger Installation
              </div>
              <div className="relative p-8 md:p-12 max-w-xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold uppercase tracking-widest mb-4">
                  <Plug className="h-3 w-3" /> High Demand
                </div>
                <h2 className="font-display text-3xl md:text-4xl text-surface-foreground mb-4">
                  EV Charger Installation
                </h2>
                <p className="text-surface-foreground/80 mb-6 leading-relaxed">
                  Home and commercial EV chargers — fast, safe installation compatible with all major EV brands.
                </p>
                <Link to="/ev-charger" className={moreInformationClassName}>
                  More Information <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
