import {
  MapPin,
  Calendar,
  DollarSign,
  Users,
  CheckCircle2,
  Quote,
} from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { categoryMeta, type Project } from "@/data/projects";

export function ProjectDialog({
  project,
  onClose,
}: {
  project: Project | null;
  onClose: () => void;
}) {
  return (
    <Dialog open={!!project} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl p-0 overflow-hidden max-h-[90vh] overflow-y-auto">
        {project && (
          <div>
            <div className="relative aspect-[16/9] bg-muted">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover"
              />
              <div
                className={`absolute top-4 left-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                  project.status === "Completed"
                    ? "bg-emerald-500 text-white"
                    : "bg-primary text-primary-foreground"
                }`}
              >
                {project.status}
              </div>
            </div>

            <div className="p-6 md:p-8">
              <div className="flex items-start justify-between gap-4 mb-4">
                <h3 className="text-2xl md:text-3xl font-display">{project.title}</h3>
                <span className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-muted text-muted-foreground text-sm font-semibold">
                  {(() => {
                    const Icon = categoryMeta[project.category].icon;
                    return <Icon className="h-4 w-4" />;
                  })()}
                  {categoryMeta[project.category].label}
                </span>
              </div>

              <p className="text-muted-foreground leading-relaxed mb-6">
                {project.description}
              </p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                {[
                  { icon: MapPin, label: "Location", value: project.location },
                  { icon: Calendar, label: "Duration", value: project.duration },
                  { icon: DollarSign, label: "Budget", value: project.budget },
                  { icon: Users, label: "Client", value: project.client },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="p-3 rounded-lg bg-muted/50 border border-border"
                  >
                    <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground mb-1">
                      <item.icon className="h-3.5 w-3.5 text-primary" />
                      {item.label}
                    </div>
                    <div className="text-sm font-semibold text-foreground">
                      {item.value}
                    </div>
                  </div>
                ))}
              </div>

              <h4 className="text-sm uppercase tracking-wider font-bold text-foreground mb-3">
                Key Features
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-6">
                {project.features.map((feat) => (
                  <div
                    key={feat}
                    className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border border-border text-sm"
                  >
                    <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                    <span className="text-foreground">{feat}</span>
                  </div>
                ))}
              </div>

              {project.testimonial && (
                <div className="border-l-4 border-primary bg-muted/40 p-5 rounded-r-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Quote className="h-4 w-4 text-primary" />
                    <span className="text-sm font-bold uppercase tracking-wider">
                      Client Testimonial
                    </span>
                  </div>
                  <p className="italic text-foreground/90 mb-2">
                    “{project.testimonial.quote}”
                  </p>
                  <p className="text-sm text-primary font-semibold">
                    — {project.testimonial.author}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
