import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "btn-sweep bg-primary text-primary-foreground shadow hover:text-primary-foreground",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline:
          "btn-fill-up border border-input bg-background shadow-sm hover:border-primary",
        secondary: "btn-sweep bg-secondary text-secondary-foreground shadow-sm hover:text-primary-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "link-underline-grow text-primary",
        electric: "btn-shine bg-gradient-electric text-primary-foreground font-bold uppercase tracking-wide shadow-glow hover:scale-[1.03] hover:shadow-elegant transition-all",
        hero: "btn-sweep bg-primary text-primary-foreground font-bold uppercase tracking-wide shadow-glow hover:text-primary-foreground",
        outlineLight: "btn-fill-up border-2 border-primary bg-surface/40 backdrop-blur-sm text-primary font-bold uppercase tracking-wide hover:border-primary",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-9 rounded-md px-4 text-xs",
        lg: "h-12 rounded-md px-8 text-base",
        xl: "h-14 rounded-md px-10 text-base",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
