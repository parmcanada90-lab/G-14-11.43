import { MapPin, DollarSign, Star, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { categoryMeta, type Project } from "@/data/projects";

export function ProjectCard({
  project,
  onView,
}: {
  project: Project;
  onView: (p: Project) => void;
}) {
  const CatIcon = categoryMeta[project.category].icon;
  return (
    <article className="relative z-0 group-hover:z-20 overflow-hidden rounded-xl bg-card shadow-card group-hover:shadow-elegant transition-[transform,box-shadow,border-color,color] duration-500 border border-border group-hover:border-primary/50 transform-gpu group-hover:-translate-y-1 will-change-transform flex flex-col">
      <div className="aspect-[4/3] overflow-hidden bg-muted relative">
        <img
          src={project.image}
          alt={project.title}
          loading="lazy"
          width={1280}
          height={960}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div
          className={`absolute top-3 right-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
            project.status === "Completed"
              ? "bg-emerald-500 text-white"
              : "bg-primary text-primary-foreground"
          }`}
        >
          {project.status}
        </div>
      </div>
      <div className="p-6 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-3">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-muted text-muted-foreground text-xs font-semibold">
            <CatIcon className="h-3.5 w-3.5" />
            {categoryMeta[project.category].label}
          </span>
          <span className="inline-flex items-center gap-1 text-sm font-semibold text-foreground">
            <Star className="h-4 w-4 fill-primary text-primary" />
            {project.rating}
          </span>
        </div>

        <h3 className="text-xl mb-2 group-hover:text-primary transition-colors">
          {project.title}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-3">
          {project.description}
        </p>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm mb-4">
          <span className="inline-flex items-center gap-1.5 text-foreground/80">
            <MapPin className="h-4 w-4 text-primary" />
            {project.location}
          </span>
          <span className="inline-flex items-center gap-1.5 text-foreground/80">
            <DollarSign className="h-4 w-4 text-primary" />
            {project.budget}
          </span>
        </div>

        <div className="flex flex-wrap gap-2 mb-5">
          {project.features.slice(0, 2).map((feat) => (
            <span
              key={feat}
              className="px-2.5 py-1 rounded-md bg-muted text-xs text-foreground/80"
            >
              {feat}
            </span>
          ))}
          {project.features.length > 2 && (
            <span className="px-2.5 py-1 rounded-md bg-primary/10 text-xs text-primary font-semibold">
              +{project.features.length - 2} more
            </span>
          )}
        </div>

        <div className="mt-auto">
          <Button
            variant="electric"
            size="default"
            className="w-full"
            onClick={() => onView(project)}
          >
            View Project <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </article>
  );
}
