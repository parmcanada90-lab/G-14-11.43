import type { LucideIcon } from "lucide-react";
import { Zap } from "lucide-react";

type SectionKickerProps = {
  label: string;
  icon?: LucideIcon;
  tone?: "light" | "dark";
  className?: string;
};

export function SectionKicker({
  label,
  icon: Icon = Zap,
  tone = "light",
  className = "",
}: SectionKickerProps) {
  const isDark = tone === "dark";

  return (
    <div className={`section-kicker ${className}`}>
      <span className="section-kicker__rail" aria-hidden="true">
        <span className="section-kicker__current" />
      </span>
      <span
        className={`section-kicker__icon ${
          isDark ? "section-kicker__icon--dark" : "section-kicker__icon--light"
        }`}
        aria-hidden="true"
      >
        <Icon className="h-4 w-4" />
      </span>
      <span
        className={`section-kicker__text ${
          isDark ? "section-kicker__text--dark" : "section-kicker__text--light"
        }`}
      >
        {label}
      </span>
    </div>
  );
}
