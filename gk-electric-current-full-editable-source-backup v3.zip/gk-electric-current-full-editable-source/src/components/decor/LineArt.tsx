/**
 * Decorative line-art illustrations.
 * Each component renders a positioned, low-opacity SVG suitable as a
 * background flourish in a `relative overflow-hidden` section.
 *
 * All shapes use `currentColor` so they inherit from the parent text color.
 * Pass `className` to override position/size/opacity.
 */
import type { SVGProps } from "react";
import { cn } from "@/lib/utils";

type DecorProps = {
  className?: string;
  side?: "br" | "bl" | "tr" | "tl";
};

const sideMap: Record<NonNullable<DecorProps["side"]>, string> = {
  br: "bottom-0 right-0",
  bl: "bottom-0 left-0",
  tr: "top-0 right-0",
  tl: "top-0 left-0",
};

function Wrap({
  className,
  side = "br",
  children,
  width = "w-[340px] md:w-[480px]",
}: DecorProps & { children: React.ReactNode; width?: string }) {
  return (
    <div
      aria-hidden="true"
      className={cn(
        "pointer-events-none select-none absolute hidden md:block z-10",
        "opacity-[0.22] text-current animate-float",
        sideMap[side],
        width,
        className,
      )}
    >
      {children}
    </div>
  );
}

const svg: SVGProps<SVGSVGElement> = {
  xmlns: "http://www.w3.org/2000/svg",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2.5,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

/* ---------- Home hero: lightning bolt + outlet ---------- */
export function DecorBoltOutlet(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        <path d="M220 40 L120 200 L190 200 L160 360 L300 170 L220 170 L260 40 Z" />
        <rect x="40" y="240" width="120" height="140" rx="12" />
        <circle cx="80" cy="290" r="6" />
        <circle cx="120" cy="290" r="6" />
        <path d="M100 320 v30" />
        <path d="M30 60 l40 40 M70 60 l-40 40" />
      </svg>
    </Wrap>
  );
}

/* ---------- Testimonials: two electricians at a panel (real artwork) ---------- */
import panelCrewSketch from "@/assets/panel-crew-sketch.png";
import panelCrewGold from "@/assets/panel-crew-gold.png";

export function DecorPanelCrew(p: DecorProps) {
  return (
    <Wrap {...p} width="w-[380px] md:w-[560px]">
      <img
        src={panelCrewGold}
        alt=""
        className="hidden dark:block w-full h-auto select-none align-bottom"
        draggable={false}
      />
      <img
        src={panelCrewSketch}
        alt=""
        className="block dark:hidden w-full h-auto select-none align-bottom"
        draggable={false}
      />
    </Wrap>
  );
}

/* ---------- Services index: toolbox ---------- */
export function DecorToolbox(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        <path d="M60 220 h280 v140 h-280 z" />
        <path d="M120 220 v-30 a20 20 0 0 1 20 -20 h120 a20 20 0 0 1 20 20 v30" />
        <path d="M60 270 h280" />
        {/* tools spilling */}
        <path d="M80 180 l40 -40 l20 20 l-40 40 z" />
        <circle cx="76" cy="184" r="6" />
        <path d="M250 160 l60 -10 l5 25 l-60 10 z" />
        <path d="M210 140 l30 30 M225 125 l30 30" />
        <path d="M340 200 c20 -20 40 -10 50 10" />
      </svg>
    </Wrap>
  );
}

/* ---------- Residential: house with wiring ---------- */
export function DecorHouseWiring(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        <path d="M60 200 L200 80 L340 200 V360 H60 Z" />
        <path d="M140 360 v-100 h60 v100" />
        <rect x="220" y="240" width="70" height="60" />
        {/* wires inside */}
        <path d="M80 220 q60 -20 120 0 t120 0" />
        <path d="M80 280 q60 -20 120 0 t120 0" />
        <path d="M80 330 q60 -20 120 0 t120 0" />
        {/* bulb on roof */}
        <circle cx="200" cy="50" r="14" />
        <path d="M194 64 v10 h12 v-10" />
        <path d="M186 36 l-10 -8 M214 36 l10 -8 M200 30 v-12" />
      </svg>
    </Wrap>
  );
}

/* ---------- Commercial: building w/ light grid ---------- */
export function DecorOfficeBuilding(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        <path d="M80 40 h240 v320 h-240 z" />
        {Array.from({ length: 6 }).map((_, r) =>
          Array.from({ length: 4 }).map((_, c) => (
            <rect
              key={`${r}-${c}`}
              x={100 + c * 50}
              y={70 + r * 45}
              width={36}
              height={28}
            />
          )),
        )}
        <path d="M40 360 h320" />
        <path d="M200 40 v-25 l-10 -10 h20 z" />
      </svg>
    </Wrap>
  );
}

/* ---------- Industrial: factory + transformer ---------- */
export function DecorFactory(p: DecorProps) {
  return (
    <Wrap {...p} width="w-[380px] md:w-[540px]">
      <svg {...svg} viewBox="0 0 540 400">
        <path d="M40 360 V200 l60 40 V200 l60 40 V200 l60 40 V120 h120 V360 z" />
        <path d="M100 80 h40 v60 h-40 z" />
        <path d="M120 80 v-25 M105 55 h30" />
        <path d="M260 200 h60 M260 240 h60 M260 280 h60" />
        {/* transformer tower */}
        <path d="M400 360 V160 M480 360 V160 M400 160 l80 -40 l-80 -40 l80 -40" />
        <path d="M440 360 V120" />
        <path d="M380 200 h120 M380 240 h120" />
      </svg>
    </Wrap>
  );
}

/* ---------- EV Charger: car + charger ---------- */
export function DecorEVCar(p: DecorProps) {
  return (
    <Wrap {...p} width="w-[380px] md:w-[560px]">
      <svg {...svg} viewBox="0 0 560 400">
        {/* car */}
        <path d="M60 260 l40 -80 h220 l50 80 v60 h-310 z" />
        <path d="M120 180 l-20 80 h260 l-30 -80 z" />
        <circle cx="140" cy="320" r="28" />
        <circle cx="320" cy="320" r="28" />
        {/* charger */}
        <rect x="430" y="180" width="80" height="160" rx="8" />
        <rect x="450" y="210" width="40" height="50" />
        <path d="M470 260 v40" />
        {/* cable to car */}
        <path d="M430 280 c-30 20 -50 20 -80 0" />
        {/* bolt on screen */}
        <path d="M468 220 l-6 14 h8 l-4 14 l12 -18 h-8 l6 -10 z" />
      </svg>
    </Wrap>
  );
}

/* ---------- Projects: blueprint grid + compass ---------- */
export function DecorBlueprint(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        <rect x="40" y="40" width="320" height="320" />
        {Array.from({ length: 7 }).map((_, i) => (
          <path key={`v${i}`} d={`M${80 + i * 40} 40 v320`} opacity={0.6} />
        ))}
        {Array.from({ length: 7 }).map((_, i) => (
          <path key={`h${i}`} d={`M40 ${80 + i * 40} h320`} opacity={0.6} />
        ))}
        {/* compass */}
        <circle cx="280" cy="280" r="46" />
        <path d="M280 240 l8 40 l-8 40 l-8 -40 z" />
        <circle cx="280" cy="280" r="4" />
      </svg>
    </Wrap>
  );
}

/* ---------- Service areas: map pin + transmission tower ---------- */
export function DecorMapTower(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        <path d="M120 360 c-60 -90 -80 -130 -80 -180 a80 80 0 0 1 160 0 c0 50 -20 90 -80 180 z" />
        <circle cx="120" cy="180" r="28" />
        {/* tower */}
        <path d="M280 360 V120 M340 360 V120 M280 120 l30 -30 l30 30" />
        <path d="M280 200 l60 -30 M280 170 l60 30" />
        <path d="M280 260 l60 -30 M280 230 l60 30" />
        <path d="M280 320 l60 -30 M280 290 l60 30" />
      </svg>
    </Wrap>
  );
}

/* ---------- About: hard hat + multimeter ---------- */
export function DecorHatMeter(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        {/* hard hat */}
        <path d="M60 200 a100 80 0 0 1 200 0 z" />
        <path d="M40 200 h240" />
        <path d="M140 130 v-30 h40 v30" />
        {/* multimeter */}
        <rect x="220" y="220" width="140" height="140" rx="10" />
        <rect x="240" y="240" width="100" height="40" rx="4" />
        <circle cx="260" cy="320" r="10" />
        <circle cx="320" cy="320" r="10" />
        <path d="M260 330 v40 M320 330 v40" />
      </svg>
    </Wrap>
  );
}

/* ---------- Careers: climbing electrician on pole ---------- */
export function DecorClimber(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        <path d="M200 40 V380" />
        <path d="M160 90 h80 M150 130 h100 M160 170 h80" />
        <circle cx="240" cy="200" r="14" />
        <path d="M240 214 v40 l-20 50 M240 254 l25 50" />
        <path d="M240 230 l-30 -20 M240 230 l30 -10" />
        <path d="M200 60 l-30 -20 M200 60 l30 -20" />
      </svg>
    </Wrap>
  );
}

/* ---------- Contact: phone handset + bolt ---------- */
export function DecorPhoneBolt(p: DecorProps) {
  return (
    <Wrap {...p}>
      <svg {...svg} viewBox="0 0 400 400">
        <path d="M80 140 c0 -40 30 -70 70 -70 l30 0 l30 60 l-40 30 c20 50 60 90 110 110 l30 -40 l60 30 l0 30 c0 40 -30 70 -70 70 c-120 0 -220 -100 -220 -220 z" />
        <path d="M310 60 l-20 40 h25 l-15 50 l40 -60 h-25 l15 -30 z" />
      </svg>
    </Wrap>
  );
}
