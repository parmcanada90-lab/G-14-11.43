import type { LucideIcon } from "lucide-react";
import { Zap } from "lucide-react";

export type ElectricSectionTagTone = "light" | "dark";
export type ElectricSectionTagVariant = "electric-v1-2";

type ElectricSectionTagProps = {
  label: string;
  icon?: LucideIcon;
  tone?: ElectricSectionTagTone;
  variant?: ElectricSectionTagVariant;
  className?: string;
};

export function ElectricSectionTag({
  label,
  icon: Icon = Zap,
  tone = "light",
  variant = "electric-v1-2",
  className = "",
}: ElectricSectionTagProps) {
  const isDark = tone === "dark";

  if (variant !== "electric-v1-2") return null;

  return (
    <div className={`flex flex-wrap items-center gap-4 ${className}`} data-variant={variant} data-tone={tone}>
      <span
        className="relative h-[5px] w-24 overflow-hidden rounded-full shadow-[0_0_16px_oklch(0.78_0.18_75_/_0.24)] md:w-36"
        style={{ backgroundColor: "color-mix(in oklab, var(--primary) 85%, transparent)" }}
      >
        <span className="electric-v1-2-current absolute inset-y-0 left-0 w-16 rounded-full bg-gradient-to-r from-transparent via-white to-primary" />
      </span>
      <span className="electric-v1-2-icon relative flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_28px_oklch(0.78_0.18_75_/_0.42)]">
        <span className="absolute inset-[-5px] rounded-full border border-primary/35" />
        <Icon className="relative h-4.5 w-4.5" />
      </span>
      <span className={`text-xs font-bold uppercase tracking-[0.24em] md:text-sm ${isDark ? "text-white" : "text-foreground"}`}>
        {label}
      </span>
    </div>
  );
}
