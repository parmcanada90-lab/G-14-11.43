import { Link } from "@tanstack/react-router";
import type { LucideIcon } from "lucide-react";
import {
  ArrowRight,
  BadgeCheck,
  Building2,
  Cable,
  CheckCircle2,
  CircuitBoard,
  ClipboardCheck,
  Cpu,
  Factory,
  Gauge,
  HardHat,
  Home,
  LampCeiling,
  Lightbulb,
  MessageCircle,
  PanelTop,
  Phone,
  Plug,
  PlugZap,
  Radar,
  Settings2,
  ShieldCheck,
  Sparkles,
  TimerReset,
  Trees,
  Wrench,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import { commercialCloneCategories } from "@/lib/commercialElectricalCloneContent";

type ServiceCategory = {
  icon: LucideIcon;
  title: string;
  description: string;
  services: string[];
  accent: string;
};

type ProcessStep = {
  icon: LucideIcon;
  title: string;
  text: string;
};

type ServicePageConfig = {
  eyebrow: string;
  eyebrowIcon: LucideIcon;
  titleStart: string;
  titleHighlight: string;
  intro: string;
  primaryIcon: LucideIcon;
  secondaryIcon: LucideIcon;
  categoryEyebrow: string;
  categoryTitle: string;
  categoryIntro: string;
  processTitle: string;
  processIntro: string;
  ctaTitle: string;
  ctaText: string;
  estimateLabel: string;
  categories: ServiceCategory[];
  highlights: Array<{ icon: LucideIcon; label: string; value: string }>;
  process: ProcessStep[];
};

export const serviceCloneConfigs: Record<"residential" | "commercial" | "industrial", ServicePageConfig> = {
  residential: {
    eyebrow: "Homes",
    eyebrowIcon: Home,
    titleStart: "Residential",
    titleHighlight: "Services",
    intro:
      "Keep your home safe, efficient, and fully powered with expert residential electrical services. From electrical repairs and lighting upgrades to panel replacements, EV charger installations, rewiring, permits, and safety inspections, we deliver reliable, code-compliant solutions for every home.",
    primaryIcon: Home,
    secondaryIcon: LampCeiling,
    categoryEyebrow: "Home Electrical Services",
    categoryTitle: "Complete Electrical Care For Your Home",
    categoryIntro:
      "Organized by project type so homeowners can quickly find the right solution for repairs, upgrades, renovations, new construction, safety improvements and future-ready power.",
    processTitle: "Safe, Planned, Professional",
    processIntro:
      "Residential electrical work should feel clear and stress-free from the first call to final testing. We review your needs, explain safe options, complete the work cleanly and confirm everything is ready for everyday use.",
    ctaTitle: "Need Reliable Electrical Work At Home?",
    ctaText:
      "Speak with GK Electric about repairs, upgrades, renovations, inspections, EV charging, panel work or complete home wiring.",
    estimateLabel: "Request Residential Estimate",
    highlights: [
      { icon: TimerReset, label: "Fast Scheduling", value: "Quick response for home electrical needs" },
      { icon: ShieldCheck, label: "Code Compliant", value: "Safety-first work with proper protection" },
      { icon: Home, label: "Complete Homes", value: "Small repairs to full home rewiring" },
      { icon: Sparkles, label: "Clean Finish", value: "Tidy workmanship and polished details" },
    ],
    process: [
      { icon: Phone, title: "Discuss The Electrical Need", text: "Share the repair, upgrade, renovation or safety concern so the scope can be understood clearly." },
      { icon: ClipboardCheck, title: "Review Safety, Load And Code", text: "Panel capacity, circuit protection, permits and inspection needs are reviewed before installation." },
      { icon: Wrench, title: "Complete Clean Installation", text: "Work is performed with tidy routing, reliable materials and respect for occupied homes." },
      { icon: ShieldCheck, title: "Test And Walk Through", text: "Devices, breakers, detectors, chargers and controls are tested before final handoff." },
    ],
    categories: [
      {
        icon: Home,
        title: "New Construction Electrical",
        description: "Complete electrical planning, rough-in and finishing for new custom homes, laneway homes and residential builds.",
        accent: "from-amber-400 to-yellow-500",
        services: ["New home electrical layout", "Service entrance and main panel", "Full rough-in wiring", "Lighting and outlet placement", "Dedicated appliance circuits", "Permit and inspection support"],
      },
      {
        icon: PanelTop,
        title: "Panels, Breakers & Service Upgrades",
        description: "Main panel improvements, breaker safety, capacity planning and power upgrades for modern homes.",
        accent: "from-yellow-300 to-amber-500",
        services: ["100A to 200A service upgrades", "Main panel replacement", "Subpanel installation", "Breaker replacement", "AFCI and GFCI upgrades", "Load calculations"],
      },
      {
        icon: Cable,
        title: "Home Wiring, Rewiring & Suites",
        description: "Clean, code-compliant wiring for older homes, additions, renovations and secondary suites.",
        accent: "from-blue-400 to-cyan-500",
        services: ["Whole-home rewiring", "Aluminum wiring corrections", "Basement suite wiring", "Kitchen and bathroom wiring", "Low-voltage cabling", "Permit-ready documentation"],
      },
      {
        icon: LampCeiling,
        title: "Lighting Design & Installation",
        description: "Interior, exterior, feature and security lighting designed to make homes brighter and safer.",
        accent: "from-orange-400 to-rose-500",
        services: ["Pot light installation", "LED upgrades", "Chandeliers and pendants", "Under-cabinet lighting", "Landscape lighting", "Dimmers and scene controls"],
      },
      {
        icon: Plug,
        title: "Outlets, Switches & Appliance Circuits",
        description: "Convenience and safety upgrades for everyday home power needs.",
        accent: "from-violet-400 to-purple-600",
        services: ["Outlet repair", "New switch locations", "USB and smart outlets", "GFCI outlets", "Dedicated appliance circuits", "Troubleshooting dead outlets"],
      },
      {
        icon: PlugZap,
        title: "EV Chargers & Future-Ready Power",
        description: "Home charging solutions with panel checks, dedicated circuits and safe Level 2 installation.",
        accent: "from-emerald-400 to-green-600",
        services: ["Level 2 EV chargers", "Garage charger circuits", "Hardwired charger setup", "Load management", "Panel capacity checks", "Permit coordination"],
      },
      {
        icon: ShieldCheck,
        title: "Safety, Detectors & Protection",
        description: "Protection systems that help prevent shocks, fire risks, surge damage and code issues.",
        accent: "from-red-400 to-orange-500",
        services: ["Smoke detectors", "Carbon monoxide detectors", "Surge protection", "Grounding corrections", "Safety inspections", "Code deficiency repairs"],
      },
      {
        icon: Trees,
        title: "Outdoor, Garage & Specialty Power",
        description: "Weather-rated electrical systems for outdoor living, detached buildings and specialty equipment.",
        accent: "from-lime-400 to-emerald-600",
        services: ["Outdoor outlets", "Garage power upgrades", "Detached building wiring", "Hot tub connections", "Patio lighting", "Seasonal power outlets"],
      },
    ],
  },
  commercial: {
    eyebrow: "Business Spaces",
    eyebrowIcon: Building2,
    titleStart: "Commercial",
    titleHighlight: "Services",
    intro:
      "Power your business with dependable commercial electrical work for offices, retail spaces, restaurants, tenant improvements, lighting retrofits, panels, maintenance, permits and emergency troubleshooting.",
    primaryIcon: Building2,
    secondaryIcon: CircuitBoard,
    categoryEyebrow: "Business Electrical Services",
    categoryTitle: "Commercial Power Built Around Operations",
    categoryIntro:
      "Designed for active workplaces, customer-facing spaces and growing businesses that need reliable power, safe installations and minimal disruption.",
    processTitle: "Planned Around Business Continuity",
    processIntro:
      "We coordinate access, scheduling, shutdown windows and inspection needs so commercial projects stay organized and your team can keep moving.",
    ctaTitle: "Need Reliable Commercial Electrical Work?",
    ctaText:
      "Talk to GK Electric about tenant improvements, panel upgrades, lighting retrofits, equipment circuits, maintenance or inspection-ready corrections.",
    estimateLabel: "Request Commercial Estimate",
    highlights: [
      { icon: Building2, label: "Business Ready", value: "Office, retail, restaurant and warehouse support" },
      { icon: TimerReset, label: "Minimal Downtime", value: "Scheduling planned around active operations" },
      { icon: ClipboardCheck, label: "Inspection Ready", value: "Permit-aware and code-compliant workmanship" },
      { icon: Lightbulb, label: "Energy Smart", value: "LED retrofits and efficient lighting controls" },
    ],
    process: [
      { icon: Phone, title: "Scope The Space", text: "We review your business type, electrical demand, layout, equipment and operating hours." },
      { icon: ClipboardCheck, title: "Plan Access And Compliance", text: "Permits, inspection needs, shutdown windows and safe work areas are mapped before work starts." },
      { icon: Wrench, title: "Install With Coordination", text: "Commercial wiring, panels, lighting and circuits are installed with clean routing and clear labeling." },
      { icon: BadgeCheck, title: "Test For Operations", text: "Final circuits, lights, emergency systems and equipment connections are checked before handoff." },
    ],
    categories: [
      { icon: ClipboardCheck, title: "Tenant Improvements", description: "Electrical rough-in, finishing and inspection support for commercial build-outs and renovations.", accent: "from-amber-400 to-yellow-500", services: ["Office TI electrical", "Retail build-outs", "Restaurant improvements", "Permit-ready wiring", "Demising wall changes", "Final device finishing"] },
      { icon: Building2, title: "Office Electrical", description: "Reliable power and lighting for offices, clinics, studios and shared work environments.", accent: "from-blue-400 to-cyan-500", services: ["Workstation power", "Boardroom circuits", "Printer outlets", "Lighting controls", "Dedicated circuits", "After-hours scheduling"] },
      { icon: Sparkles, title: "Retail & Showroom Power", description: "Clean customer-facing electrical installations for stores, showrooms, salons and service-based spaces.", accent: "from-fuchsia-400 to-pink-600", services: ["Display lighting", "POS power", "Signage circuits", "Feature wall wiring", "Storefront lighting", "Customer-area devices"] },
      { icon: LampCeiling, title: "Commercial Lighting & LED Retrofits", description: "Efficient lighting upgrades that improve visibility, savings and customer experience.", accent: "from-orange-400 to-rose-500", services: ["LED retrofit programs", "Track lighting", "Warehouse lighting", "Exterior lighting", "Control systems", "Feature lighting"] },
      { icon: CircuitBoard, title: "Electrical Service Upgrades & Utility Coordination", description: "Commercial service upgrades, distribution planning and utility-ready coordination for growing business demand.", accent: "from-yellow-300 to-amber-500", services: ["Service upgrade planning", "Utility coordination", "Metering equipment", "Main distribution panels", "Feeder installation", "Circuit directory labeling"] },
      { icon: PlugZap, title: "Restaurant & Equipment Circuits", description: "Safe dedicated circuits and equipment power for kitchens, HVAC and high-demand devices.", accent: "from-red-400 to-orange-500", services: ["Kitchen circuits", "Hood power", "GFCI protection", "Equipment disconnects", "HVAC connections", "Load balancing"] },
      { icon: Settings2, title: "Equipment, HVAC & Dedicated Circuits", description: "Dedicated electrical support for commercial equipment, mechanical systems and high-demand devices.", accent: "from-cyan-400 to-blue-600", services: ["Mechanical equipment wiring", "Compressor circuits", "Dedicated receptacles", "Disconnect switches", "Surge protection", "Equipment relocation power"] },
      { icon: PlugZap, title: "EV Charging Infrastructure", description: "Commercial EV charger infrastructure for staff parking, customer charging, strata properties and fleet needs.", accent: "from-emerald-400 to-green-600", services: ["Level 2 charger stations", "Fleet charging prep", "Parking-area conduit", "Load management systems", "Panel readiness review", "EV permit documentation"] },
      { icon: Gauge, title: "Generator & Backup Power Systems", description: "Backup power planning and electrical connections that help businesses stay prepared during outages.", accent: "from-teal-400 to-cyan-600", services: ["Standby generator connections", "Transfer switch installation", "Critical-load panels", "Backup power inlet wiring", "Load shedding controls", "Emergency power testing"] },
      { icon: ShieldCheck, title: "Fire Alarm & Integrated Safety Systems", description: "Electrical infrastructure for fire alarm devices and integrated commercial safety system requirements.", accent: "from-red-500 to-amber-500", services: ["Fire alarm power", "Alarm device wiring", "Strobe and horn circuits", "Monitoring interface power", "Safety system rough-in", "Verification support wiring"] },
      { icon: Cpu, title: "Smart Building / Automation Systems", description: "Modern controls and automation-ready electrical systems for efficient, connected commercial spaces.", accent: "from-indigo-400 to-violet-600", services: ["Occupancy sensors", "Automated lighting controls", "Smart thermostat wiring", "Energy monitoring circuits", "Building control power", "Automation panel feeds"] },
      { icon: ShieldCheck, title: "Emergency Lighting & Exit Systems", description: "Safety-focused electrical support for compliant pathways and protected commercial areas.", accent: "from-lime-400 to-emerald-600", services: ["Emergency light installation", "Exit sign wiring", "Battery unit checks", "Egress lighting", "Common-area safety power", "Life-safety inspection support"] },
      { icon: Cable, title: "Low-Voltage Ready Infrastructure", description: "Power pathways for data, POS, security, access control and connected business systems.", accent: "from-indigo-400 to-violet-600", services: ["Data room power", "Network rack circuits", "Security power", "Camera power", "Access control rough-in", "Conduit pathways"] },
      { icon: Wrench, title: "Maintenance & Troubleshooting", description: "Fast diagnostics and planned service to keep commercial spaces operating safely.", accent: "from-slate-400 to-slate-700", services: ["Breaker trips", "Dead outlets", "Flickering lights", "Preventive maintenance", "Thermal issue checks", "Urgent service calls"] },
      { icon: ClipboardCheck, title: "Permits, Code & Inspection Readiness", description: "Professional documentation, correction work and installation standards for compliant commercial spaces.", accent: "from-amber-300 to-yellow-500", services: ["Permit applications", "Code corrections", "Inspection support", "Electrical reports", "As-built labeling", "Final compliance review"] },
    ],
  },
  industrial: {
    eyebrow: "Facilities",
    eyebrowIcon: Factory,
    titleStart: "Industrial",
    titleHighlight: "Services",
    intro:
      "Support demanding facilities with industrial electrical service for three-phase power, machinery wiring, controls, VFDs, lighting, maintenance, shutdown work, safety corrections and code-compliant upgrades.",
    primaryIcon: Factory,
    secondaryIcon: Settings2,
    categoryEyebrow: "Industrial Electrical Services",
    categoryTitle: "Heavy Electrical Support For Productive Facilities",
    categoryIntro:
      "Structured around facility power, machinery, controls, maintenance and safety so plant teams can quickly identify the right industrial electrical service.",
    processTitle: "Built For Uptime, Safety And Control",
    processIntro:
      "Industrial work is planned around production needs, lockout awareness, equipment requirements, shutdown windows and clear documentation.",
    ctaTitle: "Need Industrial Electrical Support?",
    ctaText:
      "Speak with GK Electric about facility upgrades, machinery power, three-phase systems, controls, maintenance, lighting or shutdown electrical work.",
    estimateLabel: "Request Industrial Estimate",
    highlights: [
      { icon: Gauge, label: "Three-Phase Power", value: "Distribution and high-demand facility circuits" },
      { icon: Factory, label: "Machinery Wiring", value: "Equipment hookups and production support" },
      { icon: Cpu, label: "Controls Ready", value: "Motors, VFDs, sensors and panel support" },
      { icon: HardHat, label: "Shutdown Aware", value: "Coordinated work for operating facilities" },
    ],
    process: [
      { icon: Radar, title: "Walk The Facility", text: "Equipment loads, access, shutdown needs and production constraints are reviewed first." },
      { icon: ClipboardCheck, title: "Engineer The Scope", text: "Feeders, panels, controls, protection, labeling and code needs are planned before installation." },
      { icon: Wrench, title: "Install Industrial-Grade Systems", text: "Conduit, cable, panels, disconnects and controls are installed using durable methods." },
      { icon: BadgeCheck, title: "Test, Label And Document", text: "Systems are tested, labeled and reviewed for maintenance clarity and inspection readiness." },
    ],
    categories: [
      { icon: Gauge, title: "Power Distribution & Three-Phase", description: "Industrial-grade power infrastructure for plants, shops, warehouses and expansions.", accent: "from-yellow-300 to-amber-500", services: ["Three-phase power installation", "Main distribution panels", "Subpanels", "Feeders, conduit and cable runs", "Disconnects", "Load balancing", "Dedicated equipment circuits"] },
      { icon: Factory, title: "Machinery Wiring & Equipment Hookups", description: "Safe connection, relocation and readiness for equipment that keeps production moving.", accent: "from-orange-400 to-red-500", services: ["Machinery connections", "Equipment relocation wiring", "Production line power", "Compressor circuits", "Welders and lifts", "Troubleshooting equipment power"] },
      { icon: Cpu, title: "Controls, Motors & VFDs", description: "Control wiring and motor-power services for dependable equipment operation.", accent: "from-indigo-400 to-violet-600", services: ["Control wiring", "Motor circuits", "Motors and VFD wiring", "Starters", "Sensors and low-voltage interfaces", "Control panel support"] },
      { icon: Lightbulb, title: "Industrial Lighting & Energy Upgrades", description: "Bright, efficient and safer lighting for warehouses, production floors and yards.", accent: "from-amber-400 to-yellow-500", services: ["High-bay LED lighting", "Lighting retrofits", "Emergency lights", "Exit signs", "Exterior and yard lighting", "Lighting controls"] },
      { icon: ShieldCheck, title: "Safety & Code Compliance", description: "Code-compliant workmanship, safety corrections and clean documentation.", accent: "from-emerald-400 to-green-600", services: ["Code deficiency corrections", "Permit and inspection support", "Grounding and bonding", "Deficiency repairs", "Inspection readiness", "Panel labeling", "Lockout-aware work practices"] },
      { icon: TimerReset, title: "Maintenance & Shutdown Work", description: "Responsive service and planned maintenance for uptime-sensitive facilities.", accent: "from-slate-400 to-slate-700", services: ["Planned shutdown electrical work", "Preventive maintenance", "Emergency troubleshooting", "Thermal issue checks", "Maintenance documentation", "Circuit records", "Repair planning"] },
      { icon: Cable, title: "Conduit, Cable Tray & Feeders", description: "Clean, protected pathways for industrial cable runs and equipment expansions.", accent: "from-blue-400 to-cyan-500", services: ["Rigid conduit", "Cable tray support", "Armored cable", "Long-distance feeders", "Overhead drops", "Protected routing"] },
      { icon: HardHat, title: "Facility Expansion Support", description: "Electrical planning for new equipment zones, bays, storage areas and production changes.", accent: "from-lime-400 to-emerald-600", services: ["New bay power", "Layout changes", "Expansion panels", "Equipment zones", "Dock power", "Future load planning"] },
    ],
  },
};

export function ServiceClonePage({ type }: { type: "residential" | "commercial" | "industrial" }) {
  const config = serviceCloneConfigs[type];
  const PrimaryIcon = config.primaryIcon;
  const SecondaryIcon = config.secondaryIcon;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: `${config.titleStart} Electrical Services`,
    provider: {
      "@type": "Electrician",
      name: "GK Electric",
      telephone: "+1-778-344-4567",
      areaServed: "British Columbia Lower Mainland",
    },
    serviceType: config.categories.map((category) => category.title),
    description: config.intro,
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main>
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[58vh] flex items-center text-surface-foreground">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
          </div>
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: "50px 50px",
            }}
          />
          <div className="container mx-auto px-4 py-24 relative z-10">
            <div className="max-w-5xl mx-auto text-center">
              <ElectricSectionTag label={config.eyebrow} icon={config.eyebrowIcon} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
              <h1
                data-reveal
                className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6"
              >
                <span className="text-typewriter">
                  {config.titleStart} <span className="brand-highlight">{config.titleHighlight}</span>
                </span>
              </h1>
              <p className="text-lg md:text-xl text-surface-foreground/70 max-w-3xl mx-auto mb-8 leading-relaxed">
                {config.intro}
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href="tel:+17783444567"
                  className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
                >
                  <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
                    <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">Call Us</div>
                    <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
                  </div>
                </a>
                <a
                  href="https://wa.me/17783444567"
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
                >
                  <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
                    <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">WhatsApp</div>
                    <div className="text-surface-foreground font-semibold">Quick Response</div>
                  </div>
                </a>
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-10 text-primary/5 animate-float pointer-events-none">
            <PrimaryIcon className="h-32 w-32 rotate-12" />
          </div>
          <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500 pointer-events-none">
            <SecondaryIcon className="h-24 w-24 -rotate-12" />
          </div>
        </section>

        <section className="py-12 bg-background border-b border-border">
          <div className="container mx-auto px-4">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {config.highlights.map((item) => (
                <div key={item.label} data-reveal="zoom" className="group rounded-2xl bg-card border border-border p-5 shadow-card hover:shadow-elegant hover:border-primary/40 hover:-translate-y-1 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:scale-105 transition-all duration-300">
                      <item.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                    </div>
                    <div>
                      <h2 className="font-display text-lg font-bold text-foreground">{item.label}</h2>
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.value}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-14">
              <ElectricSectionTag label={config.categoryEyebrow} icon={ClipboardCheck} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 data-reveal className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">
                {config.categoryTitle}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                {config.categoryIntro}
              </p>
            </div>

            <div className={`grid md:grid-cols-2 gap-6 ${type === "commercial" ? "xl:grid-cols-3" : "xl:grid-cols-4"}`}>
              {(type === "commercial" ? commercialCloneCategories : config.categories).map((category, index) => (
                <article
                  key={category.title}
                  data-reveal={type === "commercial" ? true : "zoom"}
                  className={`group relative overflow-hidden rounded-3xl bg-card border border-border shadow-card hover:shadow-elegant hover:border-primary/40 transition-all duration-500 ${type === "commercial" ? "hover:-translate-y-1" : "hover:-translate-y-2"}`}
                  style={{ transitionDelay: `${(index % (type === "commercial" ? 3 : 4)) * 60}ms` }}
                >
                  <div className={`absolute inset-x-0 top-0 ${type === "commercial" ? "h-1" : "h-1.5"} bg-gradient-to-r ${category.accent}`} />
                  {type !== "commercial" && <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/5 blur-2xl group-hover:bg-primary/10 transition-colors" />}
                  <div className="p-7 relative">
                    <div className={type === "commercial" ? "mb-5" : "flex items-start gap-4 mb-5"}>
                      {type === "commercial" ? (
                        <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${category.accent} flex items-center justify-center shadow-glow group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300`}>
                          <category.icon className="h-7 w-7 text-primary-foreground" />
                        </div>
                      ) : (
                        <>
                          <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${category.accent} flex items-center justify-center shadow-glow group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300`}>
                            <category.icon className="h-7 w-7 text-primary-foreground" />
                          </div>
                          <div>
                            <h3 className="font-display text-2xl font-bold text-foreground leading-tight">{category.title}</h3>
                            <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{category.description}</p>
                          </div>
                        </>
                      )}
                    </div>
                    {type === "commercial" && (
                      <>
                        <h3 className="font-display text-2xl font-bold text-foreground mb-2">{category.title}</h3>
                        <p className="text-sm text-muted-foreground leading-relaxed mb-5">{category.description}</p>
                      </>
                    )}
                    <ul className={type === "commercial" ? "grid gap-2" : "space-y-3"}>
                      {category.services.map((service) => (
                        <li key={service} className={`flex items-start text-sm text-foreground/85 ${type === "commercial" ? "gap-2" : "gap-3"}`}>
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                          {type === "commercial" ? service : <span>{service}</span>}
                        </li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {type === "commercial" && (
          <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
            <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
            <div className="container mx-auto px-4 relative z-10">
              <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
                <div>
                  <ElectricSectionTag label="Complete Electrical Coverage" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-5" />
                  <h2 className="font-display text-3xl md:text-5xl font-extrabold leading-tight mb-4">
                    <span className="text-primary">GK ELECTRIC</span> provides all types of residential, commercial and industrial electrical services.
                  </h2>
                  <p className="text-surface-foreground/70 text-base md:text-lg leading-relaxed max-w-3xl">
                    One licensed team for home upgrades, business power, facility wiring, permits, safety repairs, EV chargers, panels, lighting and complete electrical installations.
                  </p>
                </div>
                <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-1">
                  {[
                    { icon: Home, label: "Residential", to: "/services/residential" as const },
                    { icon: Building2, label: "Commercial", to: "/services/commercial" as const },
                    { icon: Factory, label: "Industrial", to: "/services/industrial" as const },
                  ].map((item) => (
                    <Link key={item.label} to={item.to} className="group/coverage flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.055] p-4 backdrop-blur-sm transition-all duration-300 hover:border-primary/45 hover:bg-primary/[0.08] focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-surface">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-primary/15 text-primary transition-all duration-300 group-hover/coverage:bg-primary group-hover/coverage:text-primary-foreground">
                        <item.icon className="h-6 w-6" />
                      </div>
                      <div className="font-display text-xl font-bold tracking-wide">{item.label}</div>
                      <ArrowRight className="ml-auto h-5 w-5 text-primary opacity-70 transition-transform duration-300 group-hover/coverage:translate-x-1 group-hover/coverage:opacity-100" />
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-start">
              <div className="lg:sticky lg:top-28" data-reveal="left">
                <ElectricSectionTag label="Our Process" icon={Radar} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">
                  {config.processTitle}
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                  {config.processIntro}
                </p>
                <Button asChild variant="electric" size="lg">
                  <Link to="/contact">
                    {config.estimateLabel} <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
              <div className="grid gap-5">
                {config.process.map((step, index) => (
                  <div key={step.title} data-reveal="right" className="group rounded-2xl border border-border bg-card p-6 shadow-card hover:shadow-elegant hover:border-primary/40 hover:-translate-y-1 transition-all duration-300" style={{ transitionDelay: `${index * 90}ms` }}>
                    <div className={`flex gap-5 ${type === "commercial" ? "items-center" : "items-start"}`}>
                      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors">
                        <step.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                      </div>
                      <div>
                        <h3 className="font-display text-xl font-bold text-foreground mb-2">{index + 1}. {step.title}</h3>
                        <p className="text-muted-foreground leading-relaxed">{step.text}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <ElectricSectionTag label="Ready To Get Started" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-6 justify-center" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold mb-6">
                {config.ctaTitle}
              </h2>
              <p className="text-lg text-surface-foreground/70 leading-relaxed mb-8 max-w-2xl mx-auto">
                {config.ctaText}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="electric" size="xl">
                  <a href="tel:+17783444567">
                    <Phone className="h-5 w-5" /> Call +1 (778) 344-4567
                  </a>
                </Button>
                <Button asChild variant="outline" size="xl" className="bg-white/5 border-white/15 text-white hover:bg-white/10">
                  <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                    <MessageCircle className="h-5 w-5" /> WhatsApp Quick Response
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </div>
  );
}
