import { Star, Quote } from "lucide-react";
import { testimonials } from "@/data/testimonials";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";

export function Testimonials() {
  return (
    <section className="py-24 bg-muted/40">
      <div className="container mx-auto px-4">
        <div className="text-left mb-12">
          <ElectricSectionTag label="Client Stories" icon={Star} className="mb-6" />
          <h2 className="text-4xl md:text-6xl mb-4">
            What Our <span className="text-primary">Clients Say</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Real feedback from homeowners, property managers and contractors
            across the Lower Mainland.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="group relative p-6 rounded-2xl bg-card border border-border shadow-card hover:shadow-elegant hover:border-primary/50 transition-all flex flex-col"
            >
              <Quote className="absolute top-5 right-5 h-8 w-8 text-primary/15 group-hover:text-primary group-hover:fill-primary/20 transition-all duration-300" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="h-4 w-4 fill-primary text-primary"
                  />
                ))}
              </div>
              <p className="text-foreground/90 leading-relaxed mb-6 flex-1">
                "{t.quote}"
              </p>
              <div className="pt-4 border-t border-border">
                <div className="font-bold text-foreground">{t.name}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider mt-0.5">
                  {t.role}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
