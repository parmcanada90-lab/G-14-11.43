import { Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, MessageCircle, Phone, ShieldCheck, Sparkles } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { ServiceConnections } from "@/components/ServiceConnections";
import { Button } from "@/components/ui/button";
import type { ServiceSlug } from "@/data/servicePageDetails";
import { servicePageDetails } from "@/data/servicePageDetails";

export function ServicePageTemplate({ slug }: { slug: ServiceSlug }) {
  const detail = servicePageDetails[slug];
  const HeroIcon = detail.heroIcon;
  const MainIcon = detail.icon;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <section className="relative overflow-hidden bg-surface text-surface-foreground py-24 md:py-32">
        <img
          src={detail.image}
          alt={detail.imageAlt}
          width={1600}
          height={1100}
          className="absolute inset-0 h-full w-full object-cover opacity-28"
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
        <div className="absolute -left-20 top-20 h-72 w-72 rounded-full bg-primary/20 blur-3xl animate-float" />
        <div className="absolute right-10 bottom-10 text-primary/10 animate-float delay-500 pointer-events-none">
          <HeroIcon className="h-32 w-32 -rotate-12" />
        </div>

        <div className="container relative z-10 mx-auto px-4">
          <div className="max-w-4xl">
            <ElectricSectionTag label={detail.eyebrow} icon={MainIcon} tone="dark" variant="electric-v1-2" className="mb-8" />
            <h1 data-reveal className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tight leading-[0.95] mb-7">
              <span className="text-typewriter">{detail.title}</span>
            </h1>
            <p className="text-lg md:text-xl text-surface-foreground/82 max-w-3xl leading-relaxed mb-8">
              {detail.intro}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild variant="electric" size="xl">
                <Link to="/contact">Get Free Estimate <ArrowRight className="h-5 w-5" /></Link>
              </Button>
              <Button asChild variant="outlineLight" size="xl">
                <a href="tel:+17783444567">Call +1 (778) 344-4567</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-background border-b border-border/60">
        <div className="container mx-auto px-4">
          <div className="grid gap-4 md:grid-cols-4">
            {detail.bullets.map((item) => (
              <div key={item} className="group rounded-2xl border border-border bg-card p-5 shadow-card transition-all hover:-translate-y-1 hover:border-primary/50 hover:shadow-elegant">
                <CheckCircle2 className="mb-3 h-6 w-6 text-primary transition-transform group-hover:scale-110" />
                <p className="font-semibold text-foreground">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-muted/35">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center mb-14" data-reveal>
            <ElectricSectionTag label="What We Do" icon={Sparkles} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-5">
              Complete {detail.shortTitle}
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed">
              GK Electric handles the full electrical scope — planning, troubleshooting, installation, upgrades, safety corrections, permits and inspection-ready finishing.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {detail.services.map((service) => {
              const Icon = service.icon;
              return (
                <div key={service.title} data-reveal className="group rounded-2xl border border-border bg-card p-7 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/60 hover:shadow-elegant">
                  <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-electric shadow-glow transition-transform group-hover:scale-110">
                    <Icon className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <h3 className="font-display text-2xl font-bold mb-3">{service.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{service.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid gap-12 lg:grid-cols-[0.95fr_1.05fr] items-center">
            <div className="relative overflow-hidden rounded-3xl shadow-elegant aspect-[4/3]" data-reveal="left">
              <img src={detail.image} alt={detail.imageAlt} loading="lazy" width={1600} height={1100} className="h-full w-full object-cover transition-transform duration-700 hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-surface/70 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 rounded-2xl border border-white/15 bg-surface/80 p-5 text-surface-foreground backdrop-blur-md">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="h-6 w-6 text-primary" />
                  <span className="font-bold uppercase tracking-widest text-sm">Licensed • Insured • Code Compliant</span>
                </div>
              </div>
            </div>

            <div data-reveal="right">
              <p className="text-sm uppercase tracking-[0.35em] font-bold text-primary mb-4">Professional Process</p>
              <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">Built Carefully From Start to Finish</h2>
              <div className="space-y-4 mb-8">
                {detail.process.map((step, index) => (
                  <div key={step} className="flex gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm transition-all hover:border-primary/50">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">{index + 1}</div>
                    <p className="pt-2 font-medium text-foreground">{step}</p>
                  </div>
                ))}
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {detail.trust.map((item) => (
                  <div key={item} className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-surface text-surface-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "linear-gradient(90deg, white 1px, transparent 1px), linear-gradient(white 1px, transparent 1px)", backgroundSize: "44px 44px" }} />
        <div className="container relative z-10 mx-auto px-4 text-center max-w-3xl">
          <p className="text-sm uppercase tracking-[0.35em] font-bold text-primary mb-4">Need Electrical Help?</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-5">Tell Us About Your {detail.shortTitle.replace(" Services", "")} Project</h2>
          <p className="text-surface-foreground/75 text-lg leading-relaxed mb-8">
            Whether it is a small repair, a full installation or a complex upgrade, our licensed electricians can review your scope and recommend the right next step.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button asChild variant="electric" size="xl"><Link to="/contact">Request Estimate</Link></Button>
            <Button asChild variant="outlineLight" size="xl"><a href="https://wa.me/17783444567" target="_blank" rel="noreferrer"><MessageCircle className="h-5 w-5" /> WhatsApp Quick Response</a></Button>
          </div>
        </div>
      </section>

      <ServiceConnections current={detail.path as any} />
      <Footer />
    </div>
  );
}
