import { useState } from "react";
import { MapPin, ExternalLink } from "lucide-react";
import { serviceAreas } from "@/data/serviceAreas";

/**
 * Real Google Maps embed framed by our service-area city picker.
 * The map is centered on the Lower Mainland and zoomed to cover every
 * city we serve — from West Vancouver in the north-west to Chilliwack
 * in the east and White Rock at the southern border.
 */
const MAP_CENTER = "49.20,-122.55"; // roughly Surrey/Coquitlam — middle of our coverage
const MAP_ZOOM = 9;

const MAPS_EMBED = `https://www.google.com/maps?q=${MAP_CENTER}&z=${MAP_ZOOM}&output=embed`;
const MAPS_LINK = `https://www.google.com/maps/@${MAP_CENTER},${MAP_ZOOM}z`;

export function ServiceAreaMap() {
  const [active, setActive] = useState<string>(
    serviceAreas.find((a) => a.featured)?.slug ?? serviceAreas[0].slug,
  );
  const current = serviceAreas.find((a) => a.slug === active) ?? serviceAreas[0];

  // Build a per-city embed when a chip is selected so the map re-centers.
  const cityQuery = encodeURIComponent(`${current.name}, BC, Canada`);
  const cityEmbed = `https://www.google.com/maps?q=${cityQuery}&z=11&output=embed`;

  return (
    <div className="rounded-3xl overflow-hidden border border-border shadow-elegant bg-surface">
      {/* Map */}
      <div className="relative">
        <iframe
          key={current.slug}
          title={`GK Electric service area — ${current.name}, Lower Mainland BC`}
          src={current.slug === serviceAreas[0].slug && active === serviceAreas[0].slug ? cityEmbed : cityEmbed}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          className="w-full h-[460px] border-0 block"
          allowFullScreen
        />

        {/* Floating info card */}
        <div className="absolute left-4 top-4 right-4 sm:right-auto sm:max-w-xs bg-card/95 backdrop-blur border border-border rounded-2xl p-4 shadow-elegant pointer-events-none">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-lg bg-gradient-electric shadow-glow flex items-center justify-center shrink-0">
              <MapPin className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-widest font-bold text-primary mb-1">
                Now viewing
              </p>
              <h3 className="text-lg font-display mb-1 truncate">{current.name}</h3>
              <p className="text-xs text-muted-foreground leading-snug line-clamp-3">
                {current.description}
              </p>
            </div>
          </div>
        </div>

        {/* Open in Maps */}
        <a
          href={MAPS_LINK}
          target="_blank"
          rel="noopener noreferrer"
          className="absolute right-4 bottom-4 inline-flex items-center gap-2 px-3 py-2 rounded-full bg-card/95 backdrop-blur border border-border text-xs font-semibold text-foreground hover:text-primary transition-colors shadow-elegant"
        >
          Open in Google Maps <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>

      {/* City chips */}
      <div className="p-4 bg-surface/60 border-t border-border">
        <p className="text-[10px] uppercase tracking-widest font-bold text-primary mb-3">
          Tap a city to zoom the map
        </p>
        <div className="flex flex-wrap gap-2">
          {serviceAreas.map((a) => {
            const isActive = a.slug === active;
            return (
              <button
                key={a.slug}
                type="button"
                onClick={() => setActive(a.slug)}
                className={
                  "px-3 py-1.5 rounded-full text-xs font-semibold transition-all border " +
                  (isActive
                    ? "bg-primary text-primary-foreground border-primary shadow-glow"
                    : "bg-card/40 text-surface-foreground/80 border-border hover:border-primary/50 hover:text-primary")
                }
              >
                {a.name}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
