import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export type FeatureItem = {
  icon: LucideIcon;
  title: string;
  desc: string;
};

interface FeatureCarouselProps {
  items: FeatureItem[];
  autoPlayMs?: number;
  progressWidthClass?: string;
}

function useCardsPerView() {
  const [n, setN] = useState(3);
  useEffect(() => {
    const calc = () => {
      const w = window.innerWidth;
      if (w >= 1024) setN(3);
      else if (w >= 640) setN(2);
      else setN(1);
    };
    calc();
    window.addEventListener("resize", calc);
    return () => window.removeEventListener("resize", calc);
  }, []);
  return n;
}

export function FeatureCarousel({ items, autoPlayMs = 4500, progressWidthClass = "" }: FeatureCarouselProps) {
  const cardsPerView = useCardsPerView();
  const len = items.length;
  // Infinite loop: clone items at both ends
  const extended = [...items, ...items, ...items];
  const baseOffset = len; // start in the middle copy

  const [index, setIndex] = useState(0); // logical index 0..len-1
  const [paused, setPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [animate, setAnimate] = useState(true);
  const rafRef = useRef<number | null>(null);
  const startRef = useRef<number | null>(null);

  // Progress-driven autoplay
  useEffect(() => {
    if (paused) return;
    startRef.current = null;
    const tick = (t: number) => {
      if (startRef.current === null) startRef.current = t;
      const elapsed = t - startRef.current;
      const p = Math.min(1, elapsed / autoPlayMs);
      setProgress(p);
      if (p >= 1) {
        setAnimate(true);
        setIndex((i) => i + 1);
        startRef.current = t;
        setProgress(0);
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [paused, autoPlayMs, index]);

  // Seamless wrap: when index crosses boundaries, snap back without animation
  useEffect(() => {
    if (index >= len) {
      const id = setTimeout(() => {
        setAnimate(false);
        setIndex((i) => i - len);
      }, 700);
      return () => clearTimeout(id);
    }
    if (index < 0) {
      const id = setTimeout(() => {
        setAnimate(false);
        setIndex((i) => i + len);
      }, 700);
      return () => clearTimeout(id);
    }
  }, [index, len]);

  // Re-enable animation after a snap
  useEffect(() => {
    if (!animate) {
      const id = requestAnimationFrame(() => setAnimate(true));
      return () => cancelAnimationFrame(id);
    }
  }, [animate]);

  const goPrev = () => {
    setAnimate(true);
    setIndex((i) => i - 1);
    setProgress(0);
  };
  const goNext = () => {
    setAnimate(true);
    setIndex((i) => i + 1);
    setProgress(0);
  };

  const slidePct = 100 / cardsPerView;
  const trackIndex = index + baseOffset;
  const normalizedIndex = ((index % len) + len) % len;

  return (
    <div
      className="relative"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="flex items-center gap-3">
        {/* Left arrow */}
        <button
          onClick={goPrev}
          aria-label="Previous"
          className="shrink-0 h-11 w-11 rounded-full border border-surface-foreground/15 hover:border-primary/50 hover:bg-primary/10 hover:text-primary text-surface-foreground/70 flex items-center justify-center transition-colors backdrop-blur-sm"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>

        {/* Track: clip horizontally only, so vertical hover lifts aren't cut */}
        <div className="[overflow-x:hidden] [overflow-y:visible] flex-1 py-6 -my-6">
          <div
            className="flex"
            style={{
              transform: `translateX(-${trackIndex * slidePct}%)`,
              transition: animate ? "transform 700ms ease-out" : "none",
            }}
          >
            {extended.map((f, i) => (
              <div
                key={`${f.title}-${i}`}
                className="shrink-0 px-2"
                style={{ width: `${slidePct}%` }}
              >
                <div className="group h-full p-6 rounded-2xl bg-surface-foreground/5 backdrop-blur-md border border-surface-foreground/10 hover:border-primary/40 hover:bg-surface-foreground/[0.08] hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/20 transition-all duration-300">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                    <f.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h4 className="text-base font-bold mb-2">{f.title}</h4>
                  <p className="text-xs text-surface-foreground/60 leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right arrow */}
        <button
          onClick={goNext}
          aria-label="Next"
          className="shrink-0 h-11 w-11 rounded-full border border-surface-foreground/15 hover:border-primary/50 hover:bg-primary/10 hover:text-primary text-surface-foreground/70 flex items-center justify-center transition-colors backdrop-blur-sm"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      {/* Progress bar */}
      <div className={`mt-8 ${progressWidthClass || "px-14"}`}>
        <div className="relative h-[3px] w-full rounded-full bg-surface-foreground/10 overflow-hidden">
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-primary/80 to-primary rounded-full"
            style={{
              width: `${((normalizedIndex + progress) / len) * 100}%`,
              transition: progress === 0 ? "width 0.5s ease-out" : "none",
            }}
          />
        </div>
      </div>
    </div>
  );
}
