import { ShieldCheck, Zap } from "lucide-react";
import gkLogo from "@/assets/gk-logo.jpeg";
import { cn } from "@/lib/utils";

export function GKEnergyMark({ className }: { className?: string }) {
  return (
    <div className={cn("gk-energy-mark", className)} aria-label="GK Electric animated brand mark">
      <div className="gk-energy-orbit gk-energy-orbit-one" />
      <div className="gk-energy-orbit gk-energy-orbit-two" />
      <div className="gk-energy-rays" />

      <div className="gk-energy-card">
        <div className="gk-energy-logo-wrap">
          <span className="gk-energy-spark gk-energy-spark-a"><Zap className="h-4 w-4" /></span>
          <span className="gk-energy-spark gk-energy-spark-b"><Zap className="h-5 w-5" /></span>
          <img src={gkLogo} alt="GK Electric logo" className="gk-energy-logo" />
        </div>

        <div className="gk-energy-copy">
          <span className="gk-energy-kicker">GK Electric</span>
          <strong>Power Ready</strong>
          <span className="gk-energy-subline">
            <ShieldCheck className="h-3.5 w-3.5" /> Licensed • Insured
          </span>
        </div>
      </div>
    </div>
  );
}
