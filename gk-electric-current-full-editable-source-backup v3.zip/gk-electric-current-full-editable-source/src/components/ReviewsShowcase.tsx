import { Star, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { featuredReviews, reviewStats } from "@/data/reviews";

export function ReviewsShowcase() {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-3 gap-10 items-start">
          {/* Aggregate badge */}
          <div className="lg:sticky lg:top-24">
            <ElectricSectionTag label="Verified Reviews" icon={Star} className="mb-6" />
            <h2 className="text-4xl md:text-5xl mb-6">
              Rated <span className="text-primary">{reviewStats.average} / 5</span>
            </h2>
            <div className="flex items-center gap-2 mb-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-6 w-6 fill-primary text-primary" />
              ))}
            </div>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              From <strong className="text-foreground">{reviewStats.count}+</strong>{" "}
              verified Google reviews across Surrey and the Lower Mainland.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button asChild variant="electric">
                <a
                  href={reviewStats.googleUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  Leave a Review <ExternalLink className="h-4 w-4" />
                </a>
              </Button>
              <Button asChild variant="outline">
                <a
                  href={reviewStats.googleUrl}
                  target="_blank"
                  rel="noreferrer"
                >
                  See All Reviews
                </a>
              </Button>
            </div>
          </div>

          {/* Review cards */}
          <div className="lg:col-span-2 grid gap-5">
            {featuredReviews.map((r) => (
              <div
                key={r.author}
                className="p-6 rounded-2xl bg-card border border-border shadow-card"
              >
                <div className="flex items-start gap-4 mb-3">
                  <div className="h-11 w-11 rounded-full bg-gradient-electric text-primary-foreground font-bold flex items-center justify-center shrink-0 text-lg shadow-glow">
                    {r.initial}
                  </div>
                  <div className="flex-1">
                    <div className="font-bold text-foreground">{r.author}</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <div className="flex gap-0.5">
                        {Array.from({ length: r.rating }).map((_, i) => (
                          <Star
                            key={i}
                            className="h-3.5 w-3.5 fill-primary text-primary"
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        • {r.date}
                      </span>
                    </div>
                  </div>
                </div>
                <p className="text-foreground/85 leading-relaxed">{r.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
