import { useEffect, useRef, useState } from "react";
import { FolderKanban, ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ProjectCard } from "@/components/ProjectCard";
import { ProjectDialog } from "@/components/ProjectDialog";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { projects, type Project } from "@/data/projects";

export function FeaturedProjects() {
  const [openProject, setOpenProject] = useState<Project | null>(null);
  const [isDesktop, setIsDesktop] = useState(false);
  const [currentProjectIndex, setCurrentProjectIndex] = useState(0);
  const visible = projects.slice(0, 6);
  // Duplicate the list so translating by half the track creates a seamless loop
  const loop = [...visible, ...visible];
  const mobileLoopSets = 25;
  const mobileStartSet = Math.floor(mobileLoopSets / 2);
  const mobileStartPosition = visible.length * mobileStartSet;
  const mobileSlides = Array.from({ length: mobileLoopSets }, () => visible).flat();

  const trackRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const pausedRef = useRef(false);
  const mobilePositionRef = useRef(mobileStartPosition);
  const wrapTimerRef = useRef<number | null>(null);
  const scrollIdleTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const desktopQuery = window.matchMedia("(min-width: 1024px)");

    const updateDesktop = () => {
      setIsDesktop(desktopQuery.matches);
    };

    updateDesktop();
    desktopQuery.addEventListener("change", updateDesktop);

    return () => {
      desktopQuery.removeEventListener("change", updateDesktop);
    };
  }, []);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;

    if (!isDesktop) {
      track.style.transform = "translate3d(0, 0, 0)";
      return;
    }

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (reduce.matches) return;

    // Pixels per second — desktop/laptop only. Slower cycle for a calmer marquee.
    const getSpeed = () => {
      const cycle = 55;
      const halfWidth = track.scrollWidth / 2;
      return halfWidth / cycle;
    };

    let speed = getSpeed();
    let offset = 0;
    let last = performance.now();
    let raf = 0;

    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      if (!pausedRef.current && !document.hidden) {
        offset += speed * dt;
        const half = track.scrollWidth / 2;
        if (half > 0 && offset >= half) offset -= half;
        track.style.transform = `translate3d(${-offset}px, 0, 0)`;
      }
      raf = requestAnimationFrame(tick);
    };

    const onResize = () => {
      speed = getSpeed();
    };
    const onVisibility = () => {
      // Avoid huge dt jump after tab was hidden
      last = performance.now();
    };

    raf = requestAnimationFrame(tick);
    window.addEventListener("resize", onResize);
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [isDesktop]);

  const scrollToMobilePosition = (position: number, behavior: ScrollBehavior = "smooth") => {
    const viewport = viewportRef.current;
    const track = trackRef.current;
    const card = track?.children[position] as HTMLElement | undefined;

    if (!viewport || !card) return;

    const left = card.offsetLeft - (viewport.clientWidth - card.clientWidth) / 2;
    viewport.scrollTo({ left, behavior });
  };

  const normalizeMobilePosition = (position: number) => {
    const safeStart = visible.length * 2;
    const safeEnd = visible.length * (mobileLoopSets - 2);

    if (position < safeStart) {
      return position + visible.length * mobileStartSet;
    }

    if (position >= safeEnd) {
      return position - visible.length * mobileStartSet;
    }

    return position;
  };

  const moveMobileProject = (direction: -1 | 1) => {
    if (isDesktop) return;

    if (wrapTimerRef.current) {
      window.clearTimeout(wrapTimerRef.current);
    }

    const nextPosition = mobilePositionRef.current + direction;
    const nextIndex = ((nextPosition % visible.length) + visible.length) % visible.length;

    mobilePositionRef.current = nextPosition;
    scrollToMobilePosition(nextPosition, "smooth");
    setCurrentProjectIndex(nextIndex);

    wrapTimerRef.current = window.setTimeout(() => {
      const normalizedPosition = normalizeMobilePosition(nextPosition);
      if (normalizedPosition !== nextPosition) {
        mobilePositionRef.current = normalizedPosition;
        scrollToMobilePosition(normalizedPosition, "auto");
      }
    }, 460);
  };

  const updateMobileProjectIndex = () => {
    if (isDesktop) return;

    const viewport = viewportRef.current;
    const track = trackRef.current;
    if (!viewport || !track) return;

    const viewportCenter = viewport.scrollLeft + viewport.clientWidth / 2;
    let closestIndex = 0;
    let closestDistance = Number.POSITIVE_INFINITY;

    Array.from(track.children).forEach((child, index) => {
      const card = child as HTMLElement;
      const cardCenter = card.offsetLeft + card.clientWidth / 2;
      const distance = Math.abs(viewportCenter - cardCenter);

      if (distance < closestDistance) {
        closestDistance = distance;
        closestIndex = index;
      }
    });

    const realIndex = closestIndex % visible.length;

    mobilePositionRef.current = closestIndex;
    setCurrentProjectIndex(realIndex);

    if (scrollIdleTimerRef.current) {
      window.clearTimeout(scrollIdleTimerRef.current);
    }

    scrollIdleTimerRef.current = window.setTimeout(() => {
      const normalizedPosition = normalizeMobilePosition(closestIndex);
      if (normalizedPosition !== closestIndex) {
        mobilePositionRef.current = normalizedPosition;
        scrollToMobilePosition(normalizedPosition, "auto");
      }
    }, 140);
  };

  useEffect(() => {
    if (isDesktop) return;

    const init = window.requestAnimationFrame(() => {
      mobilePositionRef.current = mobileStartPosition;
      scrollToMobilePosition(mobileStartPosition, "auto");
      setCurrentProjectIndex(0);
    });

    return () => {
      window.cancelAnimationFrame(init);
      if (wrapTimerRef.current) window.clearTimeout(wrapTimerRef.current);
      if (scrollIdleTimerRef.current) window.clearTimeout(scrollIdleTimerRef.current);
    };
  }, [isDesktop]);

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 flex items-center justify-between gap-8 flex-wrap">
          <div className="text-left max-w-2xl">
            <ElectricSectionTag label="Our Portfolio" icon={FolderKanban} className="mb-6" />
            <h2 className="text-4xl md:text-6xl mb-4">
              Featured <span className="text-primary">Projects</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              A glimpse of our recent work across residential, commercial and
              industrial electrical installations.
            </p>
          </div>
        </div>
      </div>

      {/* Desktop: slow marquee. Tablet/phone: manual touch carousel with one-card snapping. */}
      <div className="relative">
        {!isDesktop && (
          <>
            <button
              type="button"
              aria-label="Previous featured project"
              onClick={() => moveMobileProject(-1)}
              className="absolute left-3 top-1/2 z-30 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-border/70 bg-background/90 text-foreground shadow-lg shadow-black/15 backdrop-blur-md transition-all duration-300 hover:-translate-x-0.5 hover:scale-105 hover:border-primary/60 hover:bg-primary hover:text-primary-foreground hover:shadow-primary/20 active:scale-95 lg:hidden"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              aria-label="Next featured project"
              onClick={() => moveMobileProject(1)}
              className="absolute right-3 top-1/2 z-30 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-border/70 bg-background/90 text-foreground shadow-lg shadow-black/15 backdrop-blur-md transition-all duration-300 hover:translate-x-0.5 hover:scale-105 hover:border-primary/60 hover:bg-primary hover:text-primary-foreground hover:shadow-primary/20 active:scale-95 lg:hidden"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </>
        )}
        <div
          ref={viewportRef}
          className={`relative touch-pan-x ${isDesktop ? "overflow-hidden" : "no-scrollbar overflow-x-auto overscroll-x-contain snap-x snap-mandatory scroll-smooth pb-2"}`}
          onScroll={updateMobileProjectIndex}
          onMouseEnter={() => {
            if (isDesktop) pausedRef.current = true;
          }}
          onMouseLeave={() => {
            if (isDesktop) pausedRef.current = false;
          }}
          style={{
            maskImage:
              "linear-gradient(to right, transparent, black 5%, black 95%, transparent)",
            WebkitMaskImage:
              "linear-gradient(to right, transparent, black 5%, black 95%, transparent)",
            scrollbarWidth: "none",
            msOverflowStyle: "none",
          }}
        >
          <div
            ref={trackRef}
            className={`flex w-max gap-8 px-4 ${isDesktop ? "will-change-transform" : ""}`}
          >
            {(isDesktop ? loop : mobileSlides).map((p, i) => (
              <div
                key={`${p.id}-${i}`}
                className="relative w-[85vw] sm:w-[420px] md:w-[440px] lg:w-[460px] shrink-0 snap-center group hover:z-20"
              >
                <ProjectCard project={p} onView={setOpenProject} />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4">
        {/* CTA */}
        <div className="text-center mt-12 flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild variant="electric" size="lg">
            <Link to="/projects">
              View All Projects <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link to="/contact">
              Start Your Project <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>

      </div>

      <ProjectDialog project={openProject} onClose={() => setOpenProject(null)} />
    </section>
  );
}
