import { Zap } from "lucide-react";

type SectionTagVariant =
  | "line"
  | "electric-v1"
  | "electric-v1-2"
  | "electric-v4"
  | "electric-v4-2";

type SectionTagTone = "light" | "dark";

type SectionTagProps = {
  label?: string;
  variant?: SectionTagVariant;
  tone?: SectionTagTone;
  className?: string;
};

const textBase = "text-xs font-bold uppercase tracking-[0.24em] md:text-sm";

export function SectionTag({
  label = "Who We Are",
  variant = "electric-v1-2",
  tone = "light",
  className = "",
}: SectionTagProps) {
  const dark = tone === "dark";
  const textColor = dark ? "text-white" : "text-foreground";

  if (variant === "line") {
    return (
      <div className={`flex items-center gap-4 ${className}`}>
        <span className="h-px w-20 bg-primary md:w-28" />
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_22px_oklch(0.78_0.18_75_/_0.32)]">
          <Zap className="h-4 w-4" />
        </span>
        <span className={`${textBase} ${textColor}`}>{label}</span>
      </div>
    );
  }

  if (variant === "electric-v1") {
    return (
      <div className={`flex items-center gap-4 ${className}`}>
        <span className="electric-line-pulse relative h-px w-24 overflow-hidden bg-primary/45 md:w-32">
          <span className="absolute inset-y-0 left-0 w-10 bg-gradient-to-r from-transparent via-primary to-transparent" />
        </span>
        <span className="electric-icon-pulse flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_22px_oklch(0.78_0.18_75_/_0.32)]">
          <Zap className="h-4 w-4" />
        </span>
        <span className={`${textBase} ${textColor}`}>{label}</span>
      </div>
    );
  }

  if (variant === "electric-v4") {
    return (
      <div className={`flex items-center gap-4 ${className}`}>
        <span className="h-px w-20 bg-primary md:w-28" />
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_22px_oklch(0.78_0.18_75_/_0.32)]">
          <Zap className="h-4 w-4" />
        </span>
        <span className={`electric-text-underline relative pb-1 ${textBase} ${textColor}`}>{label}</span>
      </div>
    );
  }

  if (variant === "electric-v4-2") {
    return (
      <div className={`flex items-center gap-4 ${className}`}>
        <span className="electric-line-strong relative h-0.5 w-24 overflow-hidden rounded-full bg-primary/55 md:w-32">
          <span className="absolute inset-y-0 left-0 w-14 bg-gradient-to-r from-transparent via-white to-transparent" />
        </span>
        <span className="electric-icon-strong flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_28px_oklch(0.78_0.18_75_/_0.45)]">
          <Zap className="h-4.5 w-4.5" />
        </span>
        <span className={`electric-text-underline-strong relative pb-1.5 ${textBase} ${textColor}`}>{label}</span>
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-4 ${className}`}>
      <span className="electric-line-strong relative h-0.5 w-24 overflow-hidden rounded-full bg-primary/60 md:w-36">
        <span className="absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-transparent via-white to-transparent" />
      </span>
      <span className="electric-icon-strong electric-icon-ring relative flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_30px_oklch(0.78_0.18_75_/_0.5)]">
        <Zap className="h-4.5 w-4.5" />
      </span>
      <span className={`electric-text-underline-strong electric-text-flicker relative pb-1.5 ${textBase} ${textColor}`}>{label}</span>
    </div>
  );
}
