import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  ClipboardCheck,
  Layers3,
  MessageCircle,
  Phone,
  ShieldCheck,
  Sparkles,
  Wrench,
  Zap,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import commercialImage from "@/assets/commercial.jpg";
import {
  commercialCloneCategories,
  commercialCloneDescription,
  commercialCloneHighlights,
  commercialCloneProcess,
  commercialCloneSchema,
  commercialCloneTitle,
} from "@/lib/commercialElectricalCloneContent";

type Variant = "clone" | "modern" | "premium";

function ContactPills({ dark = true, center = true }: { dark?: boolean; center?: boolean }) {
  const base = dark
    ? "bg-white/5 border-white/10 hover:bg-white/10 text-surface-foreground"
    : "bg-card border-border hover:border-primary/40 text-foreground shadow-card";
  const muted = dark ? "text-surface-foreground/50" : "text-muted-foreground";
  return (
    <div className={`flex flex-wrap gap-4 ${center ? "justify-center" : ""}`}>
      <a href="tel:+17783444567" className={`group inline-flex items-center gap-3 px-6 py-3 rounded-full border transition-all duration-300 ${base}`}>
        <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
          <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
        </div>
        <div className="text-left">
          <div className={`text-xs uppercase tracking-wider ${muted}`}>Call Us</div>
          <div className="font-semibold">+1 (778) 344-4567</div>
        </div>
      </a>
      <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer" className={`group inline-flex items-center gap-3 px-6 py-3 rounded-full border transition-all duration-300 ${base} hover:border-green-500/30`}>
        <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
          <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
        </div>
        <div className="text-left">
          <div className={`text-xs uppercase tracking-wider ${muted}`}>WhatsApp</div>
          <div className="font-semibold">Quick Response</div>
        </div>
      </a>
    </div>
  );
}

function CloneLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main>
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[58vh] flex items-center text-surface-foreground">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
          </div>
          <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`, backgroundSize: "50px 50px" }} />
          <div className="container mx-auto px-4 py-24 relative z-10">
            <div className="max-w-5xl mx-auto text-center">
              <ElectricSectionTag label="Business Spaces" icon={Building2} tone="dark" variant="electric-v1-2" className="mb-8 justify-center" />
              <h1 data-reveal className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold text-surface-foreground tracking-tight mb-6">
                <span className="text-typewriter">Commercial <span className="brand-highlight">Services</span></span>
              </h1>
              <p className="text-lg md:text-xl text-surface-foreground/70 max-w-3xl mx-auto mb-8 leading-relaxed">{commercialCloneDescription}</p>
              <ContactPills />
            </div>
          </div>
          <div className="absolute bottom-0 left-10 text-primary/5 animate-float pointer-events-none"><Building2 className="h-32 w-32 rotate-12" /></div>
          <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500 pointer-events-none"><ClipboardCheck className="h-24 w-24 -rotate-12" /></div>
        </section>

        <section className="py-12 bg-background border-b border-border">
          <div className="container mx-auto px-4">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {commercialCloneHighlights.map((item) => (
                <div key={item.label} data-reveal="zoom" className="group rounded-2xl bg-card border border-border p-5 shadow-card hover:shadow-elegant hover:border-primary/40 hover:-translate-y-1 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:scale-105 transition-all duration-300">
                      <item.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                    </div>
                    <div>
                      <h2 className="font-display text-lg font-bold text-foreground">{item.label}</h2>
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.value}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-14">
              <ElectricSectionTag label="Business Electrical Services" icon={ClipboardCheck} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 data-reveal className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">Commercial Power Built Around Operations</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">Detailed commercial service categories with the same deep list style as the residential sample page.</p>
            </div>
            <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
              {commercialCloneCategories.map((category, index) => (
                <article key={category.title} data-reveal="zoom" className="group relative overflow-hidden rounded-3xl bg-card border border-border shadow-card hover:shadow-elegant hover:-translate-y-2 hover:border-primary/40 transition-all duration-500" style={{ transitionDelay: `${(index % 4) * 60}ms` }}>
                  <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${category.accent}`} />
                  <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/5 blur-2xl group-hover:bg-primary/10 transition-colors" />
                  <div className="p-7 relative">
                    <div className="flex items-start gap-4 mb-5">
                      <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${category.accent} flex items-center justify-center shadow-glow group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300`}>
                        <category.icon className="h-7 w-7 text-primary-foreground" />
                      </div>
                      <div>
                        <h3 className="font-display text-2xl font-bold text-foreground leading-tight">{category.title}</h3>
                        <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{category.description}</p>
                      </div>
                    </div>
                    <ul className="space-y-3">
                      {category.services.map((service) => (
                        <li key={service} className="flex items-start gap-3 text-sm text-foreground/85"><CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" /><span>{service}</span></li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-start">
              <div className="lg:sticky lg:top-28" data-reveal="left">
                <ElectricSectionTag label="Our Process" icon={Wrench} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">Planned Around Business Continuity</h2>
                <p className="text-lg text-muted-foreground leading-relaxed mb-8">We coordinate access, scheduling, shutdown windows and inspection needs so commercial projects stay organized and your team can keep moving.</p>
                <Button asChild variant="electric" size="lg"><Link to="/contact">Request Commercial Estimate <ArrowRight className="h-4 w-4" /></Link></Button>
              </div>
              <div className="grid gap-5">
                {commercialCloneProcess.map((step, index) => (
                  <div key={step} data-reveal="right" className="group rounded-2xl border border-border bg-card p-6 shadow-card hover:shadow-elegant hover:border-primary/40 hover:-translate-y-1 transition-all duration-300" style={{ transitionDelay: `${index * 90}ms` }}>
                    <div className="flex gap-5 items-center">
                      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors"><span className="font-display text-xl text-primary group-hover:text-primary-foreground">{index + 1}</span></div>
                      <p className="text-muted-foreground leading-relaxed">{step}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(commercialCloneSchema) }} />
    </div>
  );
}

function ModernLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main>
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 text-surface-foreground pt-28 pb-20 md:pt-36 md:pb-28">
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: "linear-gradient(90deg, white 1px, transparent 1px), linear-gradient(white 1px, transparent 1px)", backgroundSize: "52px 52px" }} />
          <div className="absolute -left-24 top-24 h-80 w-80 rounded-full bg-primary/20 blur-3xl animate-float" />
          <div className="absolute right-0 bottom-0 h-96 w-96 rounded-full bg-blue-500/10 blur-3xl animate-float delay-1000" />
          <div className="container mx-auto px-4 relative z-10">
            <div className="grid lg:grid-cols-[1.05fr_0.95fr] gap-12 items-center">
              <div>
                <ElectricSectionTag label="Commercial Power" icon={Building2} tone="dark" variant="electric-v1-2" className="mb-8" />
                <h1 data-reveal className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tight leading-[0.98] mb-7">Commercial <span className="brand-highlight">Services</span></h1>
                <p className="text-lg md:text-xl text-surface-foreground/72 max-w-3xl leading-relaxed mb-8">{commercialCloneDescription}</p>
                <ContactPills center={false} />
              </div>
              <div className="relative" data-reveal="right">
                <div className="absolute -inset-5 rounded-[2rem] bg-primary/20 blur-3xl" />
                <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-white/5 p-4 shadow-elegant backdrop-blur-md">
                  <img src={commercialImage} alt="Commercial electrical services" className="aspect-[4/3] w-full rounded-[1.5rem] object-cover opacity-90" />
                  <div className="grid grid-cols-3 gap-3 pt-4">
                    {[Building2, ClipboardCheck, Zap].map((Icon, index) => <div key={index} className="rounded-2xl bg-surface/80 p-4 text-center border border-white/10"><Icon className="mx-auto mb-2 h-6 w-6 text-primary" /><div className="text-xs font-bold uppercase tracking-wider text-surface-foreground/70">Ready</div></div>)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-14 bg-background border-b border-border">
          <div className="container mx-auto px-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {commercialCloneHighlights.map((item) => <div key={item.label} className="group rounded-2xl bg-card border border-border p-5 shadow-card hover:shadow-elegant hover:-translate-y-1 hover:border-primary/40 transition-all duration-300"><item.icon className="mb-3 h-7 w-7 text-primary group-hover:scale-110 transition-transform" /><h2 className="font-display text-xl font-bold text-foreground mb-1">{item.label}</h2><p className="text-sm text-muted-foreground leading-relaxed">{item.value}</p></div>)}
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-14">
              <ElectricSectionTag label="Commercial Service Categories" icon={ClipboardCheck} tone="light" variant="electric-v1-2" className="mb-5 justify-center" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">Detailed business electrical service list.</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">A modern clone with deep commercial categories, clear icons and service lists modeled after the residential sample detail structure.</p>
            </div>
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
              {commercialCloneCategories.map((category, index) => <article key={category.title} data-reveal className="group relative overflow-hidden rounded-3xl bg-card border border-border shadow-card hover:shadow-elegant hover:-translate-y-1 transition-all duration-500" style={{ transitionDelay: `${(index % 3) * 60}ms` }}><div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${category.accent}`} /><div className="p-7"><div className={`mb-5 h-14 w-14 rounded-2xl bg-gradient-to-br ${category.accent} flex items-center justify-center shadow-glow group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300`}><category.icon className="h-7 w-7 text-primary-foreground" /></div><h3 className="font-display text-2xl font-bold text-foreground mb-2">{category.title}</h3><p className="text-sm text-muted-foreground leading-relaxed mb-5">{category.description}</p><ul className="grid gap-2">{category.services.map((service) => <li key={service} className="flex items-start gap-2 text-sm text-foreground/85"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />{service}</li>)}</ul></div></article>)}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}

function PremiumLayout() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main>
        <section className="relative overflow-hidden bg-background pt-28 pb-16 md:pt-36 md:pb-24">
          <div className="absolute -top-40 -right-40 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
          <div className="container mx-auto px-4 relative z-10">
            <div className="mx-auto max-w-5xl text-center">
              <ElectricSectionTag label="Business Electrical Design" icon={Sparkles} tone="light" variant="electric-v1-2" className="mb-8 justify-center" />
              <h1 data-reveal className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tight leading-[0.98] mb-7 text-foreground">Commercial <span className="text-primary">Services</span></h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-8">{commercialCloneDescription}</p>
              <div className="flex justify-center"><ContactPills dark={false} /></div>
            </div>
          </div>
        </section>

        <section className="pb-12 bg-background">
          <div className="container mx-auto px-4">
            <div className="relative overflow-hidden rounded-[2rem] border border-border bg-surface shadow-elegant">
              <img src={commercialImage} alt="Commercial electrician service" className="h-[360px] w-full object-cover opacity-60" />
              <div className="absolute inset-0 bg-gradient-to-r from-surface/95 via-surface/55 to-transparent" />
              <div className="absolute left-6 top-6 bottom-6 max-w-lg rounded-3xl border border-white/10 bg-white/[0.06] p-7 text-surface-foreground backdrop-blur-md">
                <ShieldCheck className="mb-5 h-12 w-12 text-primary" />
                <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">Commercial upgrades with a polished finish.</h2>
                <p className="text-surface-foreground/75 leading-relaxed">Tenant improvements, panels, lighting, equipment circuits, EV chargers, maintenance and inspection-ready corrections for active businesses.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted/35">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-3 gap-6">
              {commercialCloneHighlights.map((item) => <div key={item.label} className="rounded-3xl bg-card border border-border p-7 shadow-card"><item.icon className="mb-4 h-8 w-8 text-primary" /><h2 className="font-display text-2xl font-bold mb-2">{item.label}</h2><p className="text-muted-foreground">{item.value}</p></div>)}
            </div>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mb-14">
              <ElectricSectionTag label="Business-by-business Services" icon={Layers3} tone="light" variant="electric-v1-2" className="mb-5" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">Detailed service cards with category-specific icons.</h2>
            </div>
            <div className="columns-1 md:columns-2 xl:columns-3 gap-6 space-y-6">
              {commercialCloneCategories.map((category, index) => <article key={category.title} data-reveal className="break-inside-avoid rounded-[1.75rem] border border-border bg-card p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:shadow-elegant" style={{ transitionDelay: `${(index % 3) * 50}ms` }}><div className={`mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${category.accent} shadow-glow`}><category.icon className="h-7 w-7 text-primary-foreground" /></div><h3 className="font-display text-2xl font-bold text-foreground mb-2">{category.title}</h3><p className="text-sm text-muted-foreground leading-relaxed mb-5">{category.description}</p><ul className="space-y-2">{category.services.map((service) => <li key={service} className="flex gap-2 text-sm text-foreground/85"><Zap className="mt-0.5 h-4 w-4 shrink-0 text-primary" />{service}</li>)}</ul></article>)}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}

export function CommercialElectricalCloneVariant({ variant }: { variant: Variant }) {
  if (variant === "modern") return <ModernLayout />;
  if (variant === "premium") return <PremiumLayout />;
  return <CloneLayout />;
}

export const commercialCloneMeta = {
  title: commercialCloneTitle,
  description: commercialCloneDescription,
};
