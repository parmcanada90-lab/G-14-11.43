import { Link } from "@tanstack/react-router";
import { Phone, Mail, MapPin, Instagram, Zap } from "lucide-react";
import gkLogo from "@/assets/gk-logo.jpeg";
import { DecorToolbox } from "@/components/decor/LineArt";
import { Button } from "@/components/ui/button";

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-surface text-surface-foreground">
      <DecorToolbox side="br" className="opacity-[0.08] text-surface-foreground" />
      <div className="container mx-auto px-4 py-16">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <img src={gkLogo} alt="GK Electric logo" className="h-12 w-12 object-contain rounded-full" />
              <span className="font-display text-xl tracking-widest font-extrabold">GK ELECTRIC</span>
            </Link>
            <p className="text-sm text-surface-foreground/70 leading-relaxed mb-4">
              Licensed residential, commercial & industrial electricians.
              Reliable, fast and code-compliant electrical service.
            </p>
            <div className="flex items-center gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Follow GK Electric on Instagram"
                className="icon-pop inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Follow GK Electric on Facebook"
                className="icon-pop inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground"
              >
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-sm mb-4 text-primary">Services</h4>
            <ul className="space-y-2 text-sm text-surface-foreground/70">
              <li><Link to="/services/residential" className="hover:text-primary">Residential Electrical</Link></li>
              <li><Link to="/services/commercial" className="hover:text-primary">Commercial Electrical</Link></li>
              <li><Link to="/services/industrial" className="hover:text-primary">Industrial Electrical</Link></li>
              <li><Link to="/ev-charger" className="hover:text-primary">EV Charger Installation</Link></li>
              <li><Link to="/services" className="hover:text-primary">Permits & Compliance</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm mb-4 text-primary">Company</h4>
            <ul className="space-y-2 text-sm text-surface-foreground/70">
              <li><Link to="/about" className="hover:text-primary">About Us</Link></li>
              <li><Link to="/projects" className="hover:text-primary">Projects</Link></li>
              <li><Link to="/service-areas" className="hover:text-primary">Service Areas</Link></li>
              <li><Link to="/careers" className="hover:text-primary">Careers</Link></li>
              <li><Link to="/free-estimate" className="hover:text-primary">Free Estimate</Link></li>
              <li><Link to="/contact" className="hover:text-primary">Contact</Link></li>
              <li><Link to="/all-pages" className="text-primary hover:underline font-semibold flex items-center gap-1">Site Index / Sitemap <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded">New</span></Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm mb-4 text-primary">Contact</h4>
            <ul className="space-y-3 text-sm text-surface-foreground/70">
              <li className="flex items-start gap-2">
                <Phone className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                <a href="tel:+17783444567" className="hover:text-primary">+1 (778) 344-4567</a>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                <a href="mailto:info@gkelectric.ca" className="hover:text-primary">info@gkelectric.ca</a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                <span>8381 128 St #105<br />Surrey, BC V3W 4G1</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-surface-foreground/10 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-surface-foreground/60">
          <p>© {new Date().getFullYear()} GK Electric. All rights reserved.</p>
          <div className="group relative flex flex-col items-center gap-3 sm:items-end">
            <span className="pointer-events-none absolute bottom-full left-1/2 z-30 mb-3 -translate-x-1/2 translate-y-2 whitespace-nowrap rounded-md bg-foreground px-4 py-2 text-sm font-bold uppercase tracking-[0.28em] text-background opacity-0 shadow-xl transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
              Visit JEETIT.COM
            </span>
            <Button asChild variant="outline">
              <a
                href="https://jeetit.com"
                target="_blank"
                rel="noreferrer"
                className="border-surface-foreground/60 bg-transparent text-surface-foreground/60"
              >
                Designed &amp; Developed by Jeet IT Services
                <span className="ml-1 inline-flex h-5 w-5 items-center justify-center rounded-full border border-current/40 text-current transition-all duration-300 group-hover:scale-110 group-hover:border-primary group-hover:bg-primary group-hover:text-primary-foreground group-hover:shadow-[0_0_18px_oklch(0.78_0.18_75_/_0.35)]">
                  <Zap className="h-3 w-3 fill-current" />
                </span>
              </a>
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
}
