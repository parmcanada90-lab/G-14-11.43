import { Home, Building2, Factory, Zap, ShieldCheck, Phone, MapPin, FileText, Users, Briefcase, Info, BookOpen } from "lucide-react";
import companyBlog from "@/assets/company-blog.jpg";
import residentialImg from "@/assets/residential.jpg";
import commercialImg from "@/assets/commercial.jpg";
import industrialImg from "@/assets/industrial.jpg";
import evImg from "@/assets/ev-charger.jpg";
import companyAbout from "@/assets/company-about.jpg";
import companyCareers from "@/assets/company-careers.jpg";
import companyAreas from "@/assets/company-areas.jpg";
import companyContact from "@/assets/company-contact.jpg";
import { projects } from "@/data/projects";
import { serviceAreas } from "@/data/serviceAreas";

export type MegaCard = {
  to: string;
  image: string;
  label: string;
  cta?: string;
  icon?: typeof Home;
};

export type MegaLink = {
  to: string;
  label: string;
  icon?: typeof Home;
};

export type MegaPanel = {
  cards?: MegaCard[];
  chips?: MegaLink[];
  rightTitle: string;
  rightLinks: MegaLink[];
};

export const megaMenuConfig: Record<string, MegaPanel> = {
  "/services": {
    cards: [
      { to: "/services/residential", image: residentialImg, label: "Residential", cta: "Learn", icon: Home },
      { to: "/services/commercial", image: commercialImg, label: "Commercial", cta: "Learn", icon: Building2 },
      { to: "/services/industrial", image: industrialImg, label: "Industrial", cta: "Learn", icon: Factory },
      { to: "/ev-charger", image: evImg, label: "EV Charger", cta: "Install", icon: Zap },
    ],
    rightTitle: "Quick Links",
    rightLinks: [
      { to: "/services", label: "All Services", icon: FileText },
      { to: "/services", label: "Permits & Compliance", icon: ShieldCheck },
      { to: "/contact", label: "Emergency Service", icon: Phone },
      { to: "/contact", label: "Free Estimate", icon: Zap },
    ],
  },
  "/projects": {
    cards: projects.slice(0, 4).map((p) => ({
      to: "/projects",
      image: p.image,
      label: p.title,
      cta: "View",
    })),
    rightTitle: "Browse",
    rightLinks: [
      { to: "/projects", label: "All Projects", icon: FileText },
      { to: "/services/residential", label: "Residential Work", icon: Home },
      { to: "/services/commercial", label: "Commercial Work", icon: Building2 },
      { to: "/services/industrial", label: "Industrial Work", icon: Factory },
    ],
  },
  "/about": {
    cards: [
      { to: "/blog", image: companyBlog, label: "Blog", cta: "Read", icon: BookOpen },
      { to: "/about", image: companyAbout, label: "About Us", cta: "Learn", icon: Info },
      { to: "/careers", image: companyCareers, label: "Careers", cta: "Join", icon: Briefcase },
      { to: "/service-areas", image: companyAreas, label: "Service Areas", cta: "Explore", icon: MapPin },
    ],
    rightTitle: "Company",
    rightLinks: [
      { to: "/about", label: "About Us", icon: Info },
      { to: "/careers", label: "Careers", icon: Briefcase },
      { to: "/service-areas", label: "Service Areas", icon: MapPin },
      { to: "/contact", label: "Contact Us", icon: Phone },
    ],
  },
};
