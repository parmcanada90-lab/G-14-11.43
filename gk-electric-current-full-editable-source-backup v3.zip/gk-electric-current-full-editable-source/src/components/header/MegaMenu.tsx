import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import type { MegaPanel } from "./megaMenuConfig";

interface Props {
  panel: MegaPanel;
  onClose: () => void;
}

export function MegaMenu({ panel, onClose }: Props) {
  return (
    <div
      className="absolute left-0 right-0 top-full bg-background/98 backdrop-blur-xl shadow-elegant"
      style={{ animation: "mega-menu-enter 0.25s var(--ease-weighted)" }}
      onMouseLeave={onClose}
    >
      <div className="container mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-[1fr_280px]">
          {/* Left: cards or chips */}
          <div>
            {panel.cards && (
              <div
                className="grid gap-5 ml-auto"
                style={{ gridTemplateColumns: `repeat(${panel.cards.length}, minmax(0, 1fr))` }}
              >
                {panel.cards.map((c) => (
                  <Link
                    key={c.to + c.label}
                    to={c.to as any}
                    onClick={onClose}
                    className="group block"
                  >
                    <div className="card-lift overflow-hidden rounded-lg border border-border bg-card">
                      <div className="aspect-[4/3] overflow-hidden bg-muted">
                        <img src={c.image} alt={c.label} className="h-full w-full object-cover" loading="lazy" />
                      </div>
                      <div className="p-3">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-display text-sm uppercase tracking-wide">{c.label}</span>
                          {c.icon && <c.icon className="h-4 w-4 text-primary icon-pop" />}
                        </div>
                        <div className="mt-1 text-xs text-primary inline-flex items-center gap-1 link-underline-grow">
                          {c.cta ?? "Learn more"} <ArrowRight className="h-3 w-3" />
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
            {panel.chips && (
              <div className="flex flex-wrap gap-2">
                {panel.chips.map((chip) => (
                  <Link
                    key={chip.label}
                    to={chip.to as any}
                    onClick={onClose}
                    className="card-lift inline-flex items-center rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold hover:border-primary hover:text-primary"
                  >
                    {chip.label}
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Right column */}
          <div className="lg:border-l lg:border-border lg:pl-8">
            <div className="text-xs uppercase tracking-widest text-muted-foreground mb-3">
              {panel.rightTitle}
            </div>
            <ul className="space-y-2">
              {panel.rightLinks.map((l) => (
                <li key={l.label}>
                  <Link
                    to={l.to as any}
                    onClick={onClose}
                    className="group flex items-center gap-2 py-1.5 text-sm font-semibold text-foreground/80 hover:text-primary"
                  >
                    {l.icon && <l.icon className="h-4 w-4 icon-pop" />}
                    <span className="link-underline-grow">{l.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
