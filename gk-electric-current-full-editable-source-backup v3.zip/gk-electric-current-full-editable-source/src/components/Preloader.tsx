import { useEffect, useState } from "react";
import bolt3d from "@/assets/bolt-3d.png";

const SESSION_KEY = "gk_preload_shown";

export function Preloader() {
  const [show, setShow] = useState(() => {
    if (typeof window === "undefined") return false;
    try {
      return !sessionStorage.getItem(SESSION_KEY);
    } catch {
      return true;
    }
  });
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (!show) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const total = reduced ? 1200 : 2000;
    const leaveDelay = reduced ? 900 : 1600;

    const t1 = window.setTimeout(() => setLeaving(true), leaveDelay);
    const t2 = window.setTimeout(() => {
      setShow(false);
      try {
        sessionStorage.setItem(SESSION_KEY, "1");
      } catch {
        /* ignore */
      }
    }, total);

    // lock scroll while preloader is up
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      document.body.style.overflow = prev;
    };
  }, [show]);

  if (!show) return null;

  return (
    <div
      className={`preloader-root ${leaving ? "is-leaving" : ""}`}
      aria-hidden="true"
      role="presentation"
    >

      <div className="preloader-stage">
        <img
          src={bolt3d}
          alt=""
          className="preloader-bolt-img"
          draggable={false}
        />

        <div className="preloader-wordmark">GK ELECTRIC</div>
        <div className="preloader-tag">Powering up&hellip;</div>
      </div>
    </div>
  );
}
