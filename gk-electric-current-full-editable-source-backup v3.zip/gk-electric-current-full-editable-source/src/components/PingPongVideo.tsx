import { useEffect, useRef } from "react";

type Props = React.VideoHTMLAttributes<HTMLVideoElement> & {
  className?: string;
};

/**
 * Plays a video forward, then plays it in reverse smoothly, then loops.
 *
 * Smooth reverse is achieved by capturing each painted frame to an
 * ImageBitmap during the first forward pass, then drawing those frames
 * in reverse onto an overlay canvas. Subsequent forward passes reuse
 * the underlying <video> element.
 */
export function PingPongVideo({ className, ...props }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const v = videoRef.current;
    const c = canvasRef.current;
    if (!v || !c) return;

    const ctx = c.getContext("2d");
    if (!ctx) return;

    type Frame = { t: number; bmp: ImageBitmap };
    const frames: Frame[] = [];
    let captured = false;
    let cancelled = false;
    let reversing = false;

    const anyV = v as HTMLVideoElement & {
      requestVideoFrameCallback?: (
        cb: (now: number, meta: { mediaTime: number }) => void,
      ) => number;
    };
    const hasRVFC = typeof anyV.requestVideoFrameCallback === "function";

    const sizeCanvas = () => {
      const w = v.videoWidth;
      const h = v.videoHeight;
      if (w && h && (c.width !== w || c.height !== h)) {
        c.width = w;
        c.height = h;
      }
    };

    const captureFrame = async (mediaTime: number) => {
      if (captured || reversing) return;
      sizeCanvas();
      try {
        const bmp = await createImageBitmap(v);
        frames.push({ t: mediaTime, bmp });
      } catch {
        /* ignore */
      }
    };

    const onRVFC = (_now: number, meta: { mediaTime: number }) => {
      if (cancelled) return;
      if (!captured && !reversing) {
        captureFrame(meta.mediaTime);
      }
      if (anyV.requestVideoFrameCallback) {
        anyV.requestVideoFrameCallback(onRVFC);
      }
    };

    const startReverse = () => {
      if (reversing) return;
      reversing = true;
      captured = true; // stop capturing further frames
      v.pause();

      if (frames.length === 0) {
        // No captured frames — fall back to instant restart
        finishReverse();
        return;
      }

      // Show canvas overlay
      c.style.opacity = "1";

      const duration = frames[frames.length - 1].t;
      const start = performance.now();

      const step = () => {
        if (cancelled) return;
        const elapsed = (performance.now() - start) / 1000;
        const reverseT = Math.max(0, duration - elapsed);

        // Find nearest captured frame at reverseT
        // Frames are ordered by t ascending; binary search would be nicer
        // but linear scan from the end is fine for short clips.
        let frame = frames[0];
        for (let i = frames.length - 1; i >= 0; i--) {
          if (frames[i].t <= reverseT) {
            frame = frames[i];
            break;
          }
          frame = frames[i];
        }
        ctx.drawImage(frame.bmp, 0, 0, c.width, c.height);

        if (reverseT <= 0) {
          finishReverse();
          return;
        }
        requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };

    const finishReverse = () => {
      // Hide canvas, restart video from 0
      c.style.opacity = "0";
      reversing = false;
      try {
        v.currentTime = 0;
      } catch {
        /* ignore */
      }
      v.play().catch(() => {});
    };

    const onEnded = () => startReverse();
    const onTimeUpdate = () => {
      if (reversing) return;
      if (v.duration && v.currentTime >= v.duration - 0.05) startReverse();
    };
    const onLoadedMetadata = () => sizeCanvas();

    v.addEventListener("ended", onEnded);
    v.addEventListener("timeupdate", onTimeUpdate);
    v.addEventListener("loadedmetadata", onLoadedMetadata);

    if (hasRVFC && anyV.requestVideoFrameCallback) {
      anyV.requestVideoFrameCallback(onRVFC);
    }

    return () => {
      cancelled = true;
      v.removeEventListener("ended", onEnded);
      v.removeEventListener("timeupdate", onTimeUpdate);
      v.removeEventListener("loadedmetadata", onLoadedMetadata);
      frames.forEach((f) => f.bmp.close?.());
    };
  }, []);

  return (
    <div className={`relative ${className ?? ""}`}>
      <video
        ref={videoRef}
        {...props}
        loop={false}
        className="w-full h-full object-cover"
      />
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full object-cover pointer-events-none opacity-0 transition-opacity duration-0"
        aria-hidden="true"
      />
    </div>
  );
}
