import { useEffect, useRef, useState } from "react";
import heroResidential from "@/assets/hero-residential.jpg";
import heroCommercial from "@/assets/hero-commercial.jpg";
import heroIndustrial from "@/assets/hero-industrial.jpg";
import heroEv from "@/assets/hero-ev.jpg";

type Direction = "ltr" | "rtl";

type Slide = {
  url: string;
  eyebrow: string;
  title: string;
};

const SLIDES: Slide[] = [
  {
    url: heroResidential,
    eyebrow: "Homes",
    title: "Residential",
  },
  {
    url: heroCommercial,
    eyebrow: "Businesses",
    title: "Commercial",
  },
  {
    url: heroIndustrial,
    eyebrow: "Facilities",
    title: "Industrial",
  },
  {
    url: heroEv,
    eyebrow: "EVs",
    title: "EV Charging",
  },
];

// Slide timing
const SLIDE_MS = 3250;          // each image visible exactly 3.25s
const FADE_MS = 0;              // crossfade duration (changed from 1200 for instant switch)
const TEXT_OUT_LEAD_MS = 0;     // text starts fading out before crossfade (changed from 300)

// Pan tuning — uniform perceived speed across all slides
const SPEED_PX_PER_SEC = 90;
const MIN_OVERFLOW_RATIO = 0.25; // image must be ≥125% of viewport width

export function HeroSlideshow() {
  const [index, setIndex] = useState(0);
  const [textPhase, setTextPhase] = useState<"in" | "out">("in");
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [aspects, setAspects] = useState<number[]>([]);
  const [directions] = useState<Direction[]>(() =>
    SLIDES.map(() => (Math.random() < 0.5 ? "ltr" : "rtl")),
  );
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      setSize({ w: el.clientWidth, h: el.clientHeight });
    });
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    SLIDES.forEach((s, i) => {
      const img = new Image();
      img.src = s.url;
      img.onload = () => {
        setAspects((prev) => {
          const next = [...prev];
          next[i] = img.naturalWidth / img.naturalHeight;
          return next;
        });
      };
    });
  }, []);

  // Image always covers viewport AND overflows enough horizontally for a visible pan.
  const computeImageSize = (i: number) => {
    const a = aspects[i];
    if (!a || !size.w || !size.h) return { w: size.w, h: size.h };
    let h = size.h;
    let w = h * a;
    if (w < size.w) {
      w = size.w;
      h = w / a;
    }
    const minW = size.w * (1 + MIN_OVERFLOW_RATIO);
    if (w < minW) {
      const scale = minW / w;
      w *= scale;
      h *= scale;
    }
    return { w, h };
  };

  // Pan duration is constant-speed; may exceed SLIDE_MS (we just won't see the full pan).
  const computePanDuration = (i: number) => {
    const { w } = computeImageSize(i);
    const distance = Math.max(0, w - size.w);
    if (!distance) return SLIDE_MS;
    return Math.max(SLIDE_MS, (distance / SPEED_PX_PER_SEC) * 1000);
  };

  // Drive slide timing + text out → next slide
  useEffect(() => {
    if (!aspects[index] || !size.w) return;
    setTextPhase("in");
    const outAt = SLIDE_MS - TEXT_OUT_LEAD_MS;
    const tOut = setTimeout(() => setTextPhase("out"), outAt);
    const tNext = setTimeout(
      () => setIndex((i) => (i + 1) % SLIDES.length),
      SLIDE_MS,
    );
    return () => {
      clearTimeout(tOut);
      clearTimeout(tNext);
    };
  }, [index, aspects, size.w]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 overflow-hidden bg-black"
    >
      {SLIDES.map((s, i) => {
        const active = i === index;
        const a = aspects[i];
        const { w: imgW, h: imgH } = computeImageSize(i);
        const distance = Math.max(0, imgW - size.w);
        const panDuration = computePanDuration(i);
        return (
          <div
            key={s.url}
            className="absolute inset-0 overflow-hidden ease-out"
            style={{
              opacity: active ? 1 : 0,
              transition: `opacity ${FADE_MS}ms ease-in-out`,
            }}
            aria-hidden={!active}
          >
            {size.h > 0 && a ? (
              <PanImage
                src={s.url}
                height={imgH}
                width={imgW}
                distance={distance}
                duration={panDuration}
                direction={directions[i]}
                playing={active}
              />
            ) : null}
          </div>
        );
      })}

      {/* Balanced cinematic overlays: readable text without hiding the images */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/24 to-black/5 pointer-events-none" />
      <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/55 via-black/15 to-transparent pointer-events-none" />

      {/* Active slide text */}
      <div className="relative z-10 h-full w-full flex items-end pb-36 md:items-center md:pb-0">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-5xl" key={index}>
            <div
              className="mb-4 flex items-center gap-3 text-primary will-change-transform sm:mb-5 md:gap-4"
              style={{
                animation:
                  textPhase === "in"
                    ? "hero-label-in 850ms cubic-bezier(0.22, 1, 0.36, 1) both"
                    : "hero-text-out 600ms ease-in both",
                animationDelay: textPhase === "in" ? "0ms" : "0ms",
              }}
            >
              <span className="hero-line-grow h-px w-16 bg-primary sm:w-24 md:w-36" />
              <span className="hero-label-part hero-label-count font-display text-lg font-semibold uppercase tracking-[0.24em] sm:text-xl md:text-2xl">
                {String(index + 1).padStart(2, "0")} / {String(SLIDES.length).padStart(2, "0")}
              </span>
              <span className="hero-line-grow hero-line-grow-short h-px w-7 bg-primary sm:w-9 md:w-12" />
              <span className="hero-label-part hero-label-name font-display text-lg font-semibold uppercase tracking-[0.24em] sm:text-xl md:text-2xl">
                {SLIDES[index].eyebrow}
              </span>
            </div>
            <h1
              className="font-display text-[clamp(3.05rem,10.4vw,9.6rem)] font-bold uppercase leading-[0.86] tracking-[0.015em] text-white will-change-transform"
              style={{
                animation:
                  textPhase === "in"
                    ? "hero-title-in 1000ms cubic-bezier(0.22, 1, 0.36, 1) both"
                    : "hero-text-out 600ms ease-in both",
                animationDelay: textPhase === "in" ? "140ms" : "60ms",
                textShadow: "0 18px 60px rgba(0,0,0,0.55)",
              }}
            >
              {SLIDES[index].title}
            </h1>
          </div>
        </div>
      </div>
    </div>
  );
}

function PanImage({
  src,
  height,
  width,
  distance,
  duration,
  direction,
  playing,
}: {
  src: string;
  height: number;
  width: number;
  distance: number;
  duration: number;
  direction: Direction;
  playing: boolean;
}) {
  const ref = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const start = direction === "ltr" ? -distance / 2 - distance / 2 : distance / 2 + distance / 2;
    // Simpler: ltr starts at -distance (left edge of image at viewport left when translated),
    // but our image is positioned with left:50% + translateX(-50%) for centering.
    // We'll express transform as offset from centered baseline.
    const from = direction === "ltr" ? -distance / 2 : distance / 2;
    const to = direction === "ltr" ? distance / 2 : -distance / 2;
    el.style.transition = "none";
    el.style.transform = `translate3d(calc(-50% + ${from}px), -50%, 0)`;
    void el.offsetWidth;
    if (playing) {
      el.style.transition = `transform ${duration}ms linear`;
      el.style.transform = `translate3d(calc(-50% + ${to}px), -50%, 0)`;
    }
    // suppress unused
    void start;
  }, [src, distance, duration, direction, playing]);

  return (
    <img
      ref={ref}
      src={src}
      alt=""
      style={{
        height,
        width,
        maxWidth: "none",
        top: "50%",
        left: "50%",
      }}
      className="absolute will-change-transform select-none"
      draggable={false}
    />
  );
}
