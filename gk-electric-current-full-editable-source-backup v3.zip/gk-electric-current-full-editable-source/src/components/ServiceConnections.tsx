import { Link } from "@tanstack/react-router";
import { ArrowRight, Building2, Car, Factory, Home } from "lucide-react";

const connectedServices = [
  {
    to: "/services/residential" as const,
    title: "Residential Services",
    desc: "Complete home wiring, panels, lighting, safety devices and EV-ready upgrades.",
    icon: Home,
  },
  {
    to: "/services/commercial" as const,
    title: "Commercial Services",
    desc: "Office, retail, restaurant, strata and tenant-improvement electrical systems.",
    icon: Building2,
  },
  {
    to: "/services/industrial" as const,
    title: "Industrial Services",
    desc: "Three-phase power, machinery wiring, controls, maintenance and shutdown work.",
    icon: Factory,
  },
  {
    to: "/ev-charger" as const,
    title: "EV Charger Installation",
    desc: "Level 2 home, commercial, fleet and multi-unit charging solutions.",
    icon: Car,
  },
];

type ServiceConnectionsProps = {
  current: "/services" | "/services/residential" | "/services/commercial" | "/services/industrial" | "/ev-charger";
  eyebrow?: string;
  title?: string;
};

export function ServiceConnections({
  current,
  eyebrow = "Connected Services",
  title = "Explore Every Electrical Solution",
}: ServiceConnectionsProps) {
  return (
    <section className="py-20 bg-muted/35 border-y border-border/60">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-10" data-reveal>
          <p className="text-sm uppercase tracking-[0.35em] font-bold text-primary mb-3">{eyebrow}</p>
          <h2 className="font-display text-3xl md:text-5xl font-bold text-foreground mb-4">{title}</h2>
          <p className="text-muted-foreground leading-relaxed">
            Electrical systems overlap. A panel upgrade can support an EV charger, a tenant improvement can require lighting controls, and an industrial expansion may need maintenance planning. Move between services quickly.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {connectedServices.map((service) => {
            const Icon = service.icon;
            const active = service.to === current;
            return (
              <Link
                key={service.to}
                to={service.to}
                className={`group rounded-2xl border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-elegant ${
                  active
                    ? "bg-surface text-surface-foreground border-primary/40 shadow-glow"
                    : "bg-card text-foreground border-border hover:border-primary/50"
                }`}
              >
                <div
                  className={`mb-5 flex h-13 w-13 items-center justify-center rounded-xl transition-all duration-300 ${
                    active ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground"
                  }`}
                >
                  <Icon className="h-6 w-6" />
                </div>
                <div className="flex items-start justify-between gap-4">
                  <h3 className="font-display text-xl font-bold leading-tight">{service.title}</h3>
                  <ArrowRight className="h-5 w-5 shrink-0 opacity-50 transition-transform group-hover:translate-x-1 group-hover:opacity-100" />
                </div>
                <p className={`mt-3 text-sm leading-relaxed ${active ? "text-surface-foreground/75" : "text-muted-foreground"}`}>{service.desc}</p>
                {active && <span className="mt-5 inline-flex text-xs font-bold uppercase tracking-widest text-primary">Current Page</span>}
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
