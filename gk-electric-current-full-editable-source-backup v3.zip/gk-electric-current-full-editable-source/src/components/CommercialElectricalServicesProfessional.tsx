import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Activity,
  BadgeCheck,
  BarChart3,
  Battery,
  BatteryCharging,
  Bolt,
  Building2,
  BriefcaseBusiness,
  Cable,
  Car,
  CheckCircle2,
  CircuitBoard,
  ClipboardCheck,
  ClipboardList,
  ClipboardSignature,
  CookingPot,
  Cpu,
  CreditCard,
  DoorOpen,
  Droplets,
  FileCheck,
  FileText,
  Factory,
  Fan,
  Gauge,
  HardHat,
  Home,
  KeyRound,
  LampCeiling,
  Lightbulb,
  LayoutPanelTop,
  ListChecks,
  MessageCircle,
  Monitor,
  Network,
  Paintbrush,
  PanelsTopLeft,
  ParkingCircle,
  PanelTop,
  Phone,
  Plug,
  PlugZap,
  Power,
  Presentation,
  Printer,
  Projector,
  Radar,
  Refrigerator,
  Route,
  Search,
  Server,
  ShieldCheck,
  Sparkles,
  ShoppingBag,
  Signpost,
  SlidersHorizontal,
  Store,
  Thermometer,
  TimerReset,
  ToggleLeft,
  Unplug,
  Utensils,
  UtensilsCrossed,
  Video,
  Warehouse,
  Wind,
  Wrench,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ElectricSectionTag } from "@/components/ElectricSectionTag";
import { Button } from "@/components/ui/button";
import tsbcLogo from "@/assets/TSBC_Logo_Gear_White.png";

type CommercialCategory = {
  icon: LucideIcon;
  title: string;
  description: string;
  services: string[];
  accent: string;
};

type ProcessStep = {
  icon: LucideIcon;
  title: string;
  text: string;
};

export const commercialProfessionalMeta = {
  title: "Commercial Electrical Services — Business Power, Lighting & Maintenance | GK Electric",
  description:
    "Dependable commercial electrical services for offices, retail spaces, restaurants, tenant improvements, panels, LED lighting, EV charging, maintenance, permits and code-compliant troubleshooting across the Lower Mainland.",
};

const highlights = [
  {
    icon: Building2,
    label: "Business Ready",
    value: "Electrical support for offices, retail spaces, restaurants, warehouses and strata properties.",
  },
  {
    icon: TimerReset,
    label: "Minimal Downtime",
    value: "Scheduling coordinated around operating hours, access needs and planned shutdown windows.",
  },
  {
    icon: ClipboardCheck,
    label: "Inspection Ready",
    value: "Permit-aware workmanship, clear labeling and code-compliant commercial installations.",
  },
  {
    icon: LampCeiling,
    label: "Energy Smart",
    value: "Efficient LED lighting, controls and upgrades that improve visibility and reduce energy use.",
  },
] as const;

const commercialLicenceTags = [
  "Fully Licensed & Insured",
  "100% Code-Compliant Work",
  "24/7 Emergency Service",
  "Quality Workmanship Guaranteed",
] as const;

const businessTypes = [
  "Offices & corporate suites",
  "Retail stores & showrooms",
  "Restaurants, cafés & commercial kitchens",
  "Strata commercial units",
  "Warehouses and light industrial facilities",
  "Medical, dental & wellness clinics",
  "Salons, studios & service businesses",
  "Schools, community and shared-use facilities",
] as const;

const categories: CommercialCategory[] = [
  {
    icon: ClipboardCheck,
    title: "Tenant Improvements & Build-Outs",
    description:
      "Complete commercial electrical rough-in, finishing and inspection support for new units, renovations and leasehold improvements.",
    accent: "from-amber-400 to-yellow-500",
    services: [
      "Office Tenant Improvement Electrical",
      "Retail Unit Build-Out Wiring",
      "Restaurant and Café Electrical Renovation",
      "Commercial Rough-In and Final Finishing",
      "Demising Wall and Layout Change Wiring",
      "Permit-Ready Installation and Documentation",
      "Inspection Deficiency Corrections",
      "After-Hours Commercial Electrical Service",
    ],
  },
  {
    icon: BriefcaseBusiness,
    title: "Office Electrical Services",
    description:
      "Reliable power, lighting and device layouts for offices, clinics, studios, professional suites and shared workspaces.",
    accent: "from-blue-400 to-cyan-500",
    services: [
      "Workstation and Desk Power",
      "Boardroom Outlets and Presentation Circuits",
      "Printer, Copier and Office Equipment Outlets",
      "Office Lighting and Control Systems",
      "Dedicated Circuits for Business Equipment",
      "Data Room and Network Rack Power",
      "Floor Box and Wall Device Installation",
      "Service Calls for Active Office Spaces",
    ],
  },
  {
    icon: Store,
    title: "Retail & Showroom Electrical",
    description:
      "Clean, polished customer-facing electrical work for stores, showrooms, salons and service-based businesses.",
    accent: "from-fuchsia-400 to-pink-600",
    services: [
      "Display and Merchandise Lighting",
      "Point-of-Sale Power",
      "Feature Wall Electrical Wiring",
      "Storefront and Exterior Lighting Circuits",
      "Exterior Sign Power",
      "Customer-Area Outlets and Switches",
      "Showroom Lighting Zones",
      "Retail Code Correction Work",
    ],
  },
  {
    icon: Utensils,
    title: "Restaurant & Commercial Kitchen Electrical",
    description:
      "Commercial kitchen, dining-area and food-service electrical systems planned around equipment loads, safety and uptime.",
    accent: "from-red-400 to-orange-500",
    services: [
      "Kitchen Equipment Circuits",
      "Hood Fan and Exhaust Power",
      "GFCI Protection for Food-Service Areas",
      "Dishwasher and Appliance Connections",
      "Walk-In Cooler and Refrigeration Circuits",
      "Dining-Room Lighting and Dimming",
      "Equipment Disconnect Switches",
      "Emergency Restaurant Electrical Repairs",
    ],
  },
  {
    icon: PanelsTopLeft,
    title: "Panels, Distribution & Service Upgrades",
    description:
      "Commercial panel upgrades, distribution planning, feeders and capacity improvements for growing electrical demand.",
    accent: "from-yellow-300 to-amber-500",
    services: [
      "Commercial Panel Upgrades",
      "Subpanel Installation",
      "Main Distribution Panel Work",
      "Breaker Replacement and Load Balancing",
      "Commercial Feeder Installation",
      "Commercial Load Calculations",
      "Circuit Directory Labeling",
      "Metering and Service Equipment Coordination",
    ],
  },
  {
    icon: LampCeiling,
    title: "Commercial Lighting & LED Retrofits",
    description:
      "Efficient lighting upgrades that improve visibility, reduce energy use and enhance the look of commercial spaces.",
    accent: "from-orange-400 to-rose-500",
    services: [
      "LED Retrofit Programs",
      "Office Lighting Upgrades",
      "Retail Track Lighting",
      "Warehouse High-Bay Lighting",
      "Exterior and Parking Area Lighting",
      "Occupancy Sensor Controls",
      "Emergency Lighting Integration",
      "Lighting Troubleshooting and Repairs",
    ],
  },
  {
    icon: DoorOpen,
    title: "Emergency, Exit & Life-Safety Systems",
    description:
      "Safety-focused electrical support for compliant egress pathways, exit signage and emergency lighting systems.",
    accent: "from-lime-400 to-emerald-600",
    services: [
      "Emergency Light Installation",
      "Exit Sign Wiring",
      "Battery Backup Unit Checks",
      "Egress Lighting Improvements",
      "Common-Area Safety Power",
      "Life-Safety Inspection Support",
      "Deficiency List Corrections",
      "Emergency Lighting Maintenance",
    ],
  },
  {
    icon: TimerReset,
    title: "Maintenance, Repairs & Troubleshooting",
    description:
      "Responsive diagnostics and planned maintenance to keep offices, stores, restaurants and facilities operating safely.",
    accent: "from-slate-400 to-slate-700",
    services: [
      "Breaker Trip Diagnostics",
      "Dead Outlet Repairs",
      "Flickering Light Troubleshooting",
      "Preventive Electrical Maintenance",
      "Thermal Issue Checks",
      "Urgent Commercial Service Calls",
      "Power-Loss Troubleshooting",
      "Device Replacement and Repair",
    ],
  },
  {
    icon: Network,
    title: "Low-Voltage Ready Infrastructure",
    description:
      "Power pathways and electrical preparation for data, POS, security, access control and connected business systems.",
    accent: "from-indigo-400 to-violet-600",
    services: [
      "Data Room Power",
      "Network Rack Circuits",
      "Security Camera Power",
      "Access Control Rough-In",
      "POS System Power",
      "Conduit Pathway Installation",
      "Low-Voltage Separation Planning",
      "Server and Communications Room Support",
    ],
  },
  {
    icon: Unplug,
    title: "Equipment, HVAC & Dedicated Circuits",
    description:
      "Dedicated electrical circuits and safe equipment connections for commercial mechanical systems and high-demand devices.",
    accent: "from-cyan-400 to-blue-600",
    services: [
      "HVAC Equipment Wiring",
      "Compressor Circuits",
      "Dedicated Equipment Receptacles",
      "Disconnect Switch Installation",
      "Surge Protection",
      "Equipment Relocation Power",
      "Mechanical Room Circuits",
      "Equipment Load Balancing",
    ],
  },
  {
    icon: PlugZap,
    title: "Commercial EV Charging Infrastructure",
    description:
      "EV charger electrical infrastructure for staff parking, customer charging, strata properties and fleet requirements.",
    accent: "from-emerald-400 to-green-600",
    services: [
      "Commercial EV Charging Infrastructure",
      "Fleet Charging Preparation",
      "Parking-Area Conduit and Wiring",
      "Load Management Systems",
      "Panel Readiness Review",
      "EV Permit Documentation",
      "Customer Charging Circuit Planning",
      "Workplace Charging Upgrades",
    ],
  },
  {
    icon: ClipboardSignature,
    title: "Permits, Code & Inspection Readiness",
    description:
      "Professional documentation, correction work and installation standards for safe, compliant commercial spaces.",
    accent: "from-amber-300 to-yellow-500",
    services: [
      "Commercial Electrical Permits",
      "Code Corrections",
      "Inspection Preparation",
      "Electrical Reports",
      "Deficiency List Repairs",
      "As-Built Labeling",
      "Final Compliance Review",
      "Permit and Inspection Coordination",
    ],
  },
  {
    icon: SlidersHorizontal,
    title: "Smart Building & Automation Systems",
    description:
      "Modern controls and automation-ready electrical systems for efficient, connected commercial environments.",
    accent: "from-indigo-400 to-violet-600",
    services: [
      "Occupancy Sensors",
      "Automated Lighting Controls",
      "Smart Thermostat Wiring",
      "Energy Monitoring Circuits",
      "Building Control Power",
      "Automation Panel Feeds",
      "Lighting Control Zones",
      "Future-Ready Control Wiring",
    ],
  },
  {
    icon: BatteryCharging,
    title: "Backup Power & Critical Loads",
    description:
      "Backup power planning and electrical connections to help businesses stay prepared during outages and disruptions.",
    accent: "from-teal-400 to-cyan-600",
    services: [
      "Standby Generator Connections",
      "Transfer Switch Installation",
      "Critical-Load Panels",
      "Backup Power Inlet Wiring",
      "Load-Shedding Controls",
      "Emergency Power Testing",
      "UPS Circuit Support",
      "Business Continuity Power Planning",
    ],
  },
  {
    icon: Warehouse,
    title: "Warehouses & Light Industrial Bays",
    description:
      "Commercial-grade power and lighting support for warehouses, storage spaces, workshops and light industrial units.",
    accent: "from-lime-400 to-emerald-600",
    services: [
      "Warehouse Lighting Upgrades",
      "Bay Power Distribution",
      "Overhead Door Circuits",
      "Equipment Receptacles",
      "Loading Dock Power",
      "Conduit and Feeder Runs",
      "Shop and Tool Circuits",
      "Expansion-Ready Electrical Planning",
    ],
  },
];

function getCommercialServiceDetail(service: string, category: CommercialCategory) {
  const text = service.toLowerCase();

  const exactDetails: Record<string, { icon: LucideIcon; desc: string }> = {
    "Occupancy Sensors": {
      icon: Radar,
      desc: "Install occupancy sensors to automatically control lighting and reduce energy use in commercial spaces.",
    },
    "Automated Lighting Controls": {
      icon: SlidersHorizontal,
      desc: "Set up automated lighting systems for scheduled zones, efficiency, and easier facility management.",
    },
    "Smart Thermostat Wiring": {
      icon: Thermometer,
      desc: "Install thermostat and control wiring for efficient HVAC management and improved building comfort.",
    },
    "Energy Monitoring Circuits": {
      icon: BarChart3,
      desc: "Prepare circuits for energy monitoring systems to track usage and improve efficiency planning.",
    },
    "Building Control Power": {
      icon: Cpu,
      desc: "Provide power for building automation systems, relays, and integrated commercial control equipment.",
    },
    "Automation Panel Feeds": {
      icon: CircuitBoard,
      desc: "Install dedicated feeds for automation panels and control systems supporting smart building operations.",
    },
    "Lighting Control Zones": {
      icon: LayoutPanelTop,
      desc: "Create lighting zones for offices, retail, and common areas to improve control and efficiency.",
    },
    "Future-Ready Control Wiring": {
      icon: Cable,
      desc: "Install structured wiring pathways to support future automation, sensors, and smart building upgrades.",
    },
    "Standby Generator Connections": {
      icon: Power,
      desc: "Install standby generator connections for safe backup power and uninterrupted business operations.",
    },
    "Transfer Switch Installation": {
      icon: ToggleLeft,
      desc: "Install transfer switches to safely switch between utility power and backup generator systems.",
    },
    "Critical-Load Panels": {
      icon: Battery,
      desc: "Separate essential circuits into critical-load panels for reliable backup power during outages.",
    },
    "Backup Power Inlet Wiring": {
      icon: PlugZap,
      desc: "Install safe inlet wiring to connect backup generators to selected commercial electrical loads.",
    },
    "Load-Shedding Controls": {
      icon: SlidersHorizontal,
      desc: "Implement load-shedding systems to prioritize essential circuits during limited backup power conditions.",
    },
    "Emergency Power Testing": {
      icon: BatteryCharging,
      desc: "Test backup power systems to ensure proper operation of transfer switches and critical circuits.",
    },
    "UPS Circuit Support": {
      icon: Zap,
      desc: "Provide dedicated circuits for UPS systems supporting servers, networks, and critical electronics.",
    },
    "Business Continuity Power Planning": {
      icon: BriefcaseBusiness,
      desc: "Plan backup power systems to maintain essential business operations during electrical outages.",
    },
    "Warehouse Lighting Upgrades": {
      icon: Warehouse,
      desc: "Upgrade warehouse lighting for brighter, safer aisles and improved energy efficiency in large work areas.",
    },
    "Bay Power Distribution": {
      icon: Warehouse,
      desc: "Provide organized power distribution for warehouse bays, service areas, and production work zones.",
    },
    "Overhead Door Circuits": {
      icon: DoorOpen,
      desc: "Install electrical circuits for overhead and loading doors to ensure reliable commercial access operation.",
    },
    "Equipment Receptacles": {
      icon: Plug,
      desc: "Install heavy-duty receptacles for warehouse tools, machinery, and industrial equipment use.",
    },
    "Loading Dock Power": {
      icon: Warehouse,
      desc: "Provide power for loading dock systems including doors, levelers, lighting, and operational equipment.",
    },
    "Conduit and Feeder Runs": {
      icon: Cable,
      desc: "Install protected conduit and feeder wiring throughout warehouse spaces for safe and maintainable power distribution.",
    },
    "Shop and Tool Circuits": {
      icon: Wrench,
      desc: "Install dedicated circuits for shop tools, benches, and equipment requiring reliable daily electrical supply.",
    },
    "Expansion-Ready Electrical Planning": {
      icon: Projector,
      desc: "Design electrical systems with future capacity and flexibility for business growth and layout changes.",
    },
    "Kitchen Equipment Circuits": {
      icon: CookingPot,
      desc: "Install dedicated circuits for commercial kitchen equipment to ensure safe operation and reliable performance.",
    },
    "Hood Fan and Exhaust Power": {
      icon: Fan,
      desc: "Provide electrical connections for hood fans and exhaust systems with proper ventilation and service access.",
    },
    "GFCI Protection for Food-Service Areas": {
      icon: Droplets,
      desc: "Install GFCI protection in kitchens and wet areas to improve safety around sinks, counters, and appliances.",
    },
    "Dishwasher and Appliance Connections": {
      icon: UtensilsCrossed,
      desc: "Safe electrical connections for dishwashers and commercial appliances with proper circuit protection and terminations.",
    },
    "Walk-In Cooler and Refrigeration Circuits": {
      icon: Refrigerator,
      desc: "Install reliable refrigeration circuits to support walk-in coolers and ensure consistent food storage operation.",
    },
    "Dining-Room Lighting and Dimming": {
      icon: LampCeiling,
      desc: "Install adjustable lighting systems for dining areas to improve ambiance and customer experience.",
    },
    "Equipment Disconnect Switches": {
      icon: Unplug,
      desc: "Install disconnect switches for commercial equipment to ensure safe maintenance and code compliance.",
    },
    "Emergency Restaurant Electrical Repairs": {
      icon: Phone,
      desc: "Provide urgent troubleshooting and repair services for restaurant electrical failures and equipment outages.",
    },
    "Commercial Panel Upgrades": {
      icon: PanelsTopLeft,
      desc: "Upgrade electrical panels to increase capacity, improve organization, and support new commercial equipment loads.",
    },
    "Subpanel Installation": {
      icon: PanelTop,
      desc: "Install subpanels to improve circuit distribution and provide dedicated power for different business areas.",
    },
    "Main Distribution Panel Work": {
      icon: CircuitBoard,
      desc: "Design and upgrade main distribution panels for safe capacity, organized layouts, and reliable power delivery.",
    },
    "Breaker Replacement and Load Balancing": {
      icon: Activity,
      desc: "Replace breakers and balance electrical loads to improve system reliability and reduce overload risks.",
    },
    "Commercial Feeder Installation": {
      icon: Cable,
      desc: "Install properly sized feeders for panels, equipment, and tenant spaces with safe and efficient routing.",
    },
    "Commercial Load Calculations": {
      icon: BarChart3,
      desc: "Perform load calculations to confirm electrical capacity and support safe system upgrades or expansions.",
    },
    "Circuit Directory Labeling": {
      icon: ListChecks,
      desc: "Create clear panel labeling for easy identification of circuits and safer maintenance operations.",
    },
    "Metering and Service Equipment Coordination": {
      icon: Gauge,
      desc: "Coordinate metering and service equipment upgrades for utility compliance and smooth commercial electrical service.",
    },
    "LED Retrofit Programs": {
      icon: Lightbulb,
      desc: "Upgrade commercial lighting to LED systems to reduce energy costs and improve overall brightness.",
    },
    "Office Lighting Upgrades": {
      icon: LampCeiling,
      desc: "Improve lighting in offices, meeting rooms, and shared spaces for better comfort and visibility.",
    },
    "Retail Track Lighting": {
      icon: Sparkles,
      desc: "Install adjustable track lighting to highlight merchandise, displays, and changing retail layouts.",
    },
    "Warehouse High-Bay Lighting": {
      icon: Warehouse,
      desc: "Install high-bay lighting for warehouses to ensure bright, even coverage in storage and work areas.",
    },
    "Exterior and Parking Area Lighting": {
      icon: ParkingCircle,
      desc: "Provide exterior and parking lot lighting for safety, visibility, and secure business access after dark.",
    },
    "Occupancy Sensor Controls": {
      icon: Radar,
      desc: "Install motion-based lighting controls to reduce energy use in offices, storage rooms, and washrooms.",
    },
    "Emergency Lighting Integration": {
      icon: BatteryCharging,
      desc: "Integrate emergency lighting systems to maintain safe visibility during power outages.",
    },
    "Lighting Troubleshooting and Repairs": {
      icon: Search,
      desc: "Diagnose and repair commercial lighting issues including fixtures, switches, and dimming problems.",
    },
    "Office Tenant Improvement Electrical": {
      icon: BriefcaseBusiness,
      desc: "Electrical wiring for office TI projects including power layouts, lighting, devices, and inspection-ready installation.",
    },
    "Retail Unit Build-Out Wiring": {
      icon: ShoppingBag,
      desc: "Electrical build-out for retail spaces including sales floors, displays, counters, and back-of-house areas.",
    },
    "Restaurant and Café Electrical Renovation": {
      icon: CookingPot,
      desc: "Commercial wiring for kitchens, dining areas, refrigeration, and ventilation systems with code-compliant installation.",
    },
    "Commercial Rough-In and Final Finishing": {
      icon: Wrench,
      desc: "Complete rough-in wiring and final device installation for commercial spaces from construction to occupancy.",
    },
    "Demising Wall and Layout Change Wiring": {
      icon: LayoutPanelTop,
      desc: "Rework and reroute electrical systems for new partitions, demising walls, and commercial layout changes.",
    },
    "Permit-Ready Installation and Documentation": {
      icon: FileCheck,
      desc: "Provide code-compliant installation support, labeling, and documentation for smooth permit approval and inspections.",
    },
    "Inspection Deficiency Corrections": {
      icon: ShieldCheck,
      desc: "Correct electrical deficiencies from inspections including labeling, devices, and code compliance issues.",
    },
    "After-Hours Commercial Electrical Service": {
      icon: TimerReset,
      desc: "Flexible scheduling for commercial electrical work to minimize disruption to business operations.",
    },
    "Workstation and Desk Power": {
      icon: Monitor,
      desc: "Dedicated power for desks and workstations supporting computers, task lighting, and productivity equipment safely.",
    },
    "Boardroom Outlets and Presentation Circuits": {
      icon: Presentation,
      desc: "Install power for conference rooms, including tables, displays, and presentation equipment for reliable meetings.",
    },
    "Printer, Copier and Office Equipment Outlets": {
      icon: Printer,
      desc: "Provide dedicated outlets for printers and copiers with safe, accessible power for daily office operations.",
    },
    "Office Lighting and Control Systems": {
      icon: LampCeiling,
      desc: "Install efficient office lighting with practical controls for workspaces, meeting rooms, and shared areas.",
    },
    "Dedicated Circuits for Business Equipment": {
      icon: Plug,
      desc: "Install separate circuits for business equipment to improve reliability and reduce electrical overload issues.",
    },
    "Data Room and Network Rack Power": {
      icon: Server,
      desc: "Provide reliable, organized power for server rooms and network racks with uptime-focused installation.",
    },
    "Floor Box and Wall Device Installation": {
      icon: LayoutPanelTop,
      desc: "Install floor boxes and wall outlets aligned with furniture layouts for clean and flexible office spaces.",
    },
    "Service Calls for Active Office Spaces": {
      icon: Phone,
      desc: "Provide responsive electrical service calls for occupied offices with minimal disruption to daily operations.",
    },
    "Display and Merchandise Lighting": {
      icon: ShoppingBag,
      desc: "Install display lighting to highlight products and improve visibility for a clean, professional retail presentation.",
    },
    "Point-of-Sale Power": {
      icon: CreditCard,
      desc: "Provide reliable POS power for payment terminals, checkout counters, and essential sales equipment.",
    },
    "Feature Wall Electrical Wiring": {
      icon: Paintbrush,
      desc: "Concealed wiring for feature walls, signage, and displays to maintain a clean, finished retail appearance.",
    },
    "Storefront and Exterior Lighting Circuits": {
      icon: Store,
      desc: "Install exterior lighting circuits to improve storefront visibility, safety, and brand presentation.",
    },
    "Exterior Sign Power": {
      icon: Signpost,
      desc: "Provide dedicated, weather-protected electrical connections for illuminated business signage.",
    },
    "Customer-Area Outlets and Switches": {
      icon: ToggleLeft,
      desc: "Install durable, well-placed outlets and switches in customer areas for convenience and clean design.",
    },
    "Showroom Lighting Zones": {
      icon: Sparkles,
      desc: "Create lighting zones to enhance product displays, ambiance, and flexible control for retail staff.",
    },
    "Retail Code Correction Work": {
      icon: FileCheck,
      desc: "Correct retail electrical issues including spacing, labeling, lighting, and safety compliance for inspection readiness.",
    },
    "Workstation and desk power": {
      icon: Monitor,
      desc: "Dedicated desk and workstation power laid out for computers, docking stations, task lighting and everyday office productivity without overloaded circuits.",
    },
    "Boardroom outlets and presentation circuits": {
      icon: Presentation,
      desc: "Boardroom power for conference tables, displays, projectors and presentation equipment with clean device placement and dependable meeting-room operation.",
    },
    "Printer, copier and equipment outlets": {
      icon: Printer,
      desc: "Properly placed outlets and dedicated circuits for printers, copiers and office equipment that need stable power and accessible service locations.",
    },
    "Office lighting and control systems": {
      icon: LampCeiling,
      desc: "Office lighting and switching designed for comfortable work areas, meeting rooms and shared spaces with practical controls and efficient fixtures.",
    },
    "Dedicated circuits for business equipment": {
      icon: Plug,
      desc: "Purpose-built circuits for critical business equipment, reducing nuisance trips and supporting safe day-to-day commercial operation.",
    },
    "Data room and network rack power": {
      icon: Server,
      desc: "Reliable power for data rooms and network racks, including dedicated circuits, organized device locations and uptime-focused installation planning.",
    },
    "Floor box and wall device installation": {
      icon: LayoutPanelTop,
      desc: "Floor boxes, wall outlets and device locations installed to match furniture layouts, open office plans and clean finished commercial interiors.",
    },
    "Service calls for active office spaces": {
      icon: Phone,
      desc: "Responsive office service calls scheduled around occupied workspaces to troubleshoot issues while limiting interruption to staff and customers.",
    },
    "Display and merchandise lighting": {
      icon: ShoppingBag,
      desc: "Display lighting planned to highlight merchandise, improve customer visibility and support a polished retail shopping experience.",
    },
    "Point-of-sale power": {
      icon: CreditCard,
      desc: "Checkout and POS power for payment terminals, counters and connected sales equipment where reliable uptime is essential.",
    },
    "Feature wall electrical wiring": {
      icon: Paintbrush,
      desc: "Concealed wiring for feature walls, displays, signs and accent installations with careful routing for a clean finished look.",
    },
    "Storefront and exterior lighting circuits": {
      icon: Store,
      desc: "Storefront and exterior lighting circuits installed for visibility, safety and brand presentation outside customer-facing businesses.",
    },
    "Exterior sign power": {
      icon: Signpost,
      desc: "Dedicated sign power and switching for exterior business signage with weather-aware routing and safe electrical connections.",
    },
    "Customer-area outlets and switches": {
      icon: ToggleLeft,
      desc: "Customer-facing outlets and switches positioned for convenience, durability and a polished finish in retail and showroom spaces.",
    },
    "Showroom lighting zones": {
      icon: Sparkles,
      desc: "Zoned showroom lighting that supports displays, sales areas and ambience while keeping controls simple for staff.",
    },
    "Kitchen equipment circuits": {
      icon: CookingPot,
      desc: "Dedicated kitchen equipment circuits sized and located for food-service appliances, safe operation and practical maintenance access.",
    },
    "Hood fan and exhaust power": {
      icon: Fan,
      desc: "Power connections for hood fans and exhaust systems coordinated with kitchen equipment, ventilation requirements and service access.",
    },
    "GFCI protection for food-service areas": {
      icon: Droplets,
      desc: "GFCI protection for wet and food-service zones to improve safety around sinks, counters, appliances and preparation areas.",
    },
    "Dishwasher and appliance connections": {
      icon: UtensilsCrossed,
      desc: "Safe appliance connections for dishwashers and commercial kitchen equipment with proper circuit protection and clean terminations.",
    },
    "Walk-in cooler and refrigeration circuits": {
      icon: Refrigerator,
      desc: "Refrigeration and walk-in cooler circuits planned for dependable operation, correct loads and business-critical food storage uptime.",
    },
    "Dining-room lighting and dimming": {
      icon: LampCeiling,
      desc: "Dining-room lighting and dimming controls designed for ambience, staff control and comfortable customer experiences.",
    },
    "Equipment disconnect switches": {
      icon: Unplug,
      desc: "Disconnect switches installed for equipment safety, maintenance access and code-aware commercial appliance operation.",
    },
    "Commercial panel upgrades": {
      icon: PanelsTopLeft,
      desc: "Panel upgrades that add capacity, improve organization and prepare commercial spaces for new equipment, lighting and future loads.",
    },
    "Subpanel installation": {
      icon: PanelTop,
      desc: "Subpanels installed for added circuit capacity, cleaner distribution and better separation of business equipment or tenant areas.",
    },
    "Main distribution panel work": {
      icon: CircuitBoard,
      desc: "Main distribution work planned for safe capacity, maintainable layouts and reliable power delivery throughout the commercial property.",
    },
    "Breaker replacement and load balancing": {
      icon: Activity,
      desc: "Breaker replacement and load balancing to correct circuit issues, improve reliability and reduce stress on commercial electrical systems.",
    },
    "Load calculations": {
      icon: BarChart3,
      desc: "Commercial load calculations used to confirm capacity, plan upgrades and support safe equipment or renovation decisions.",
    },
    "Circuit directory labeling": {
      icon: ListChecks,
      desc: "Clear circuit labeling for panels and directories so maintenance teams can identify loads quickly and safely.",
    },
    "Security Camera Power": {
      icon: Video,
      desc: "Install power for security cameras with clean routing and reliable connections for monitoring systems.",
    },
    "Access Control Rough-In": {
      icon: KeyRound,
      desc: "Prepare wiring pathways for access control systems including doors, readers, and security hardware.",
    },
    "Conduit Pathway Installation": {
      icon: Route,
      desc: "Install conduit pathways for organized wiring, future expansion, and protected commercial cable routing.",
    },
    "HVAC equipment wiring": {
      icon: Wind,
      desc: "HVAC wiring coordinated for rooftop units, controls and mechanical equipment with proper circuit sizing and disconnect placement.",
    },
    "Compressor circuits": {
      icon: Gauge,
      desc: "Compressor circuits installed for high-demand equipment with load awareness, protection and dependable start-up performance.",
    },
    "Surge protection": {
      icon: ShieldCheck,
      desc: "Surge protection to help safeguard business electronics, controls and sensitive commercial equipment from power events.",
    },
    "Commercial EV Charging Infrastructure": {
      icon: PlugZap,
      desc: "Install Level 2 and DC fast EV charging stations for customers, tenants, and employees with safe, scalable commercial electrical infrastructure.",
    },
    "Fleet charging preparation": {
      icon: Car,
      desc: "Fleet charging preparation for multiple vehicles, parking layouts, panel capacity and future electrical expansion.",
    },
    "EV permit documentation": {
      icon: ClipboardSignature,
      desc: "EV charger documentation prepared for permit and inspection requirements so charging projects can move forward smoothly.",
    },
    "Commercial electrical permits": {
      icon: ClipboardSignature,
      desc: "Permit support for commercial electrical work, helping projects meet local requirements and inspection expectations.",
    },
    "Electrical reports": {
      icon: FileText,
      desc: "Electrical reports that summarize conditions, recommendations and planning details for commercial owners and project teams.",
    },
    "Final compliance review": {
      icon: ClipboardList,
      desc: "Final compliance review before turnover to confirm labeling, devices, circuits and safety items are ready for business use.",
    },
    "Occupancy sensors": {
      icon: Radar,
      desc: "Occupancy sensors installed to reduce wasted energy and automate lighting in offices, washrooms, storage rooms and common areas.",
    },
    "Smart thermostat wiring": {
      icon: Thermometer,
      desc: "Thermostat and control wiring for smarter comfort management and connected commercial HVAC control.",
    },
    "Energy monitoring circuits": {
      icon: BarChart3,
      desc: "Energy monitoring circuit preparation to help businesses track demand, identify usage patterns and plan efficiency upgrades.",
    },
    "Standby generator connections": {
      icon: Power,
      desc: "Standby generator connections prepared for safe backup power integration and business continuity during outages.",
    },
    "Transfer switch installation": {
      icon: ToggleLeft,
      desc: "Transfer switches installed to safely move selected loads between utility power and backup power sources.",
    },
    "Critical-load panels": {
      icon: Battery,
      desc: "Critical-load panels that separate essential circuits for backup power planning and priority business operations.",
    },
    "UPS circuit support": {
      icon: BatteryCharging,
      desc: "UPS circuit support for servers, network equipment and critical electronics that require short-term backup protection.",
    },
    "Warehouse lighting upgrades": {
      icon: Warehouse,
      desc: "Warehouse lighting upgrades for brighter aisles, safer work areas and improved efficiency in storage or production spaces.",
    },
    "Overhead door circuits": {
      icon: DoorOpen,
      desc: "Overhead door circuits installed for loading bays, shop doors and commercial access points with dependable operation.",
    },
    "Loading dock power": {
      icon: Warehouse,
      desc: "Loading dock power for doors, levelers, lighting and equipment used in shipping, receiving and warehouse operations.",
    },
    "Retail code-correction work": {
      icon: FileCheck,
      desc: "Retail code corrections for device spacing, lighting circuits, panel labels and safety items so stores can operate inspection-ready.",
    },
    "Emergency troubleshooting for restaurants": {
      icon: Phone,
      desc: "Urgent restaurant troubleshooting for failed circuits, equipment outages and lighting issues that can interrupt food-service operations.",
    },
    "Feeder installation": {
      icon: Cable,
      desc: "Feeder runs sized and routed for commercial panels, equipment areas and tenant spaces with clean pathway planning.",
    },
    "Metering and service-equipment coordination": {
      icon: Gauge,
      desc: "Metering and service-equipment coordination for utility-ready upgrades, service changes and organized commercial electrical turnover.",
    },
    "LED retrofit programs": {
      icon: Lightbulb,
      desc: "Planned LED retrofit programs that replace inefficient fixtures, improve brightness and reduce operating costs across business areas.",
    },
    "Office lighting upgrades": {
      icon: LampCeiling,
      desc: "Office lighting upgrades for workstations, meeting rooms and common areas where comfort, visibility and switching control matter.",
    },
    "Retail track lighting": {
      icon: Sparkles,
      desc: "Track lighting installed and aimed for merchandise displays, feature walls and flexible retail layouts that change over time.",
    },
    "Warehouse high-bay lighting": {
      icon: Warehouse,
      desc: "High-bay lighting for warehouse aisles, storage racks and work zones requiring strong output, safe coverage and efficient fixtures.",
    },
    "Exterior and parking-area lighting": {
      icon: ParkingCircle,
      desc: "Exterior and parking-area lighting for safer arrivals, better building visibility and reliable after-dark business access.",
    },
    "Occupancy sensor controls": {
      icon: Radar,
      desc: "Occupancy sensor controls that automate lighting in offices, storage rooms, washrooms and low-traffic commercial areas.",
    },
    "Emergency lighting integration": {
      icon: BatteryCharging,
      desc: "Emergency lighting integration tied into required circuits and backup units so pathways remain visible during outages.",
    },
    "Lighting troubleshooting and repairs": {
      icon: Search,
      desc: "Lighting diagnostics for failed fixtures, dimming problems, switching faults and unreliable commercial lighting zones.",
    },
    "Emergency Light Installation": {
      icon: BatteryCharging,
      desc: "Install and test emergency lighting to ensure safe evacuation routes during power outages.",
    },
    "Exit Sign Wiring": {
      icon: DoorOpen,
      desc: "Install and replace exit signs with proper wiring to maintain clear and compliant emergency egress paths.",
    },
    "Battery Backup Unit Checks": {
      icon: Battery,
      desc: "Test battery backup systems to ensure reliable operation during power loss and emergency conditions.",
    },
    "Egress Lighting Improvements": {
      icon: Route,
      desc: "Improve corridor and exit lighting to provide safer, clearer pathways during emergencies.",
    },
    "Common-Area Safety Power": {
      icon: Building2,
      desc: "Provide dedicated power for lobbies and shared areas to support safe, reliable lighting and systems.",
    },
    "Life-Safety Inspection Support": {
      icon: ClipboardCheck,
      desc: "Support inspections by correcting emergency lighting and exit system deficiencies for compliance.",
    },
    "Deficiency List Corrections": {
      icon: ListChecks,
      desc: "Complete electrical deficiency repairs including lighting, labeling, and life-safety code issues.",
    },
    "Emergency Lighting Maintenance": {
      icon: Wrench,
      desc: "Maintain emergency lighting systems to ensure ongoing reliability, safety, and code compliance.",
    },
    "Breaker Trip Diagnostics": {
      icon: Activity,
      desc: "Diagnose breaker trips to identify overloads, faulty devices, and unsafe electrical conditions.",
    },
    "Dead Outlet Repairs": {
      icon: Plug,
      desc: "Repair dead outlets in workspaces, customer areas, and equipment locations to restore safe power access.",
    },
    "Flickering Light Troubleshooting": {
      icon: Lightbulb,
      desc: "Fix flickering lights caused by wiring, fixtures, switches, or circuit issues in commercial spaces.",
    },
    "Preventive Electrical Maintenance": {
      icon: ClipboardList,
      desc: "Perform routine inspections of panels, lighting, and circuits to prevent failures and downtime.",
    },
    "Thermal Issue Checks": {
      icon: Thermometer,
      desc: "Inspect warm breakers and devices to detect overheating, overloads, or failing electrical components.",
    },
    "Urgent Commercial Service Calls": {
      icon: Phone,
      desc: "Provide fast response service for outages, tripping breakers, and critical electrical failures.",
    },
    "Power-Loss Troubleshooting": {
      icon: Power,
      desc: "Locate and repair causes of partial or full power loss in commercial electrical systems.",
    },
    "Device Replacement and Repair": {
      icon: Wrench,
      desc: "Replace and repair worn switches, outlets, and controls to restore safe and reliable operation.",
    },
    "Data Room Power": {
      icon: Server,
      desc: "Install dedicated power for data rooms supporting servers, racks, cooling, and critical business systems.",
    },
    "Network Rack Circuits": {
      icon: Network,
      desc: "Provide dedicated circuits for network racks to ensure stable and reliable communication system power.",
    },
    "POS System Power": {
      icon: CreditCard,
      desc: "Provide stable electrical power for POS terminals, checkout lanes, and business transaction systems.",
    },
    "Low-Voltage Separation Planning": {
      icon: PanelsTopLeft,
      desc: "Separate power and communication wiring to reduce interference and improve system organization.",
    },
    "Server and Communications Room Support": {
      icon: Server,
      desc: "Provide structured electrical support for server rooms including labeling, receptacles, and expansion-ready design.",
    },
    "Dedicated receptacles": {
      icon: Plug,
      desc: "Dedicated receptacles installed for equipment with specific load needs, reducing shared-circuit problems and nuisance trips.",
    },
    "Disconnect switch installation": {
      icon: Unplug,
      desc: "Disconnect switches placed for safe servicing of HVAC units, kitchen equipment, pumps and other commercial machinery.",
    },
    "Equipment relocation power": {
      icon: Route,
      desc: "Equipment relocation power rerouted or extended so moved machinery and devices have safe, code-aware electrical connections.",
    },
    "Mechanical room circuits": {
      icon: Fan,
      desc: "Mechanical room circuits for pumps, controls, fans and service receptacles in compact utility spaces with practical labeling.",
    },
    "Load balancing for equipment": {
      icon: BarChart3,
      desc: "Equipment load balancing to spread demand properly and support safer operation of high-use commercial circuits.",
    },
    "Parking-area conduit and wiring": {
      icon: ParkingCircle,
      desc: "Parking-area conduit and wiring routed for chargers, lighting or future equipment with durable pathways and expansion in mind.",
    },
    "Load management systems": {
      icon: SlidersHorizontal,
      desc: "Load management systems that help EV chargers and commercial loads share available capacity without unnecessary upgrades.",
    },
    "Panel readiness review": {
      icon: Gauge,
      desc: "Panel readiness review to confirm available capacity, breaker space and upgrade needs before adding new commercial loads.",
    },
    "Customer charging circuit planning": {
      icon: Car,
      desc: "Customer charging circuit planning for accessible EV stalls, clear routing and charging convenience at commercial properties.",
    },
    "Workplace charging upgrades": {
      icon: PlugZap,
      desc: "Workplace charging upgrades for employee parking, tenant amenities and growing EV demand at business locations.",
    },
    "Code corrections": {
      icon: FileCheck,
      desc: "Code corrections for commercial wiring, protection, labeling and device conditions that need safe compliant resolution.",
    },
    "Inspection preparation": {
      icon: ClipboardCheck,
      desc: "Inspection preparation that reviews devices, panels, labels and visible work before formal electrical review.",
    },
    "Deficiency list repairs": {
      icon: Wrench,
      desc: "Deficiency list repairs completed after inspections, audits or walkthroughs to bring commercial systems back into compliance.",
    },
    "As-built labeling": {
      icon: ListChecks,
      desc: "As-built labeling for panels, circuits and equipment so owners and maintenance teams understand the final installation.",
    },
    "Permit and inspection coordination": {
      icon: ClipboardSignature,
      desc: "Permit and inspection coordination to keep commercial electrical projects organized from application through approval.",
    },
    "Automated lighting controls": {
      icon: SlidersHorizontal,
      desc: "Automated lighting controls for scheduled zones, energy savings and easier management of offices, stores and common areas.",
    },
    "Building control power": {
      icon: Cpu,
      desc: "Building control power for automation panels, relays and low-voltage interfaces that support connected commercial systems.",
    },
    "Automation panel feeds": {
      icon: CircuitBoard,
      desc: "Automation panel feeds installed for control cabinets, smart systems and future-ready building management equipment.",
    },
    "Lighting control zones": {
      icon: LayoutPanelTop,
      desc: "Lighting control zones arranged for task areas, customer spaces and schedules so businesses can manage light where needed.",
    },
    "Future-ready control wiring": {
      icon: Cable,
      desc: "Future-ready control wiring with pathways and capacity planned for later automation, sensors and smart-building additions.",
    },
    "Backup power inlet wiring": {
      icon: Power,
      desc: "Backup power inlet wiring for safe connection points that support selected loads during planned or unexpected outages.",
    },
    "Load-shedding controls": {
      icon: SlidersHorizontal,
      desc: "Load-shedding controls that prioritize essential circuits and help backup systems serve the most important business loads.",
    },
    "Emergency power testing": {
      icon: BatteryCharging,
      desc: "Emergency power testing to verify selected backup circuits, transfer equipment and critical loads operate as intended.",
    },
    "Business-continuity power planning": {
      icon: BriefcaseBusiness,
      desc: "Business-continuity power planning for essential equipment, communications and lighting that should remain available during outages.",
    },
    "Bay power distribution": {
      icon: Warehouse,
      desc: "Bay power distribution for warehouse units, service bays and work areas needing practical access to commercial power.",
    },
    "Equipment receptacles": {
      icon: Plug,
      desc: "Equipment receptacles installed where tools, machinery and warehouse devices need durable, correctly rated connection points.",
    },
    "Conduit and feeder runs": {
      icon: Cable,
      desc: "Conduit and feeder runs installed across warehouse or shop spaces with protected routing and future maintenance access.",
    },
    "Shop and tool circuits": {
      icon: Wrench,
      desc: "Shop and tool circuits sized for benches, equipment, chargers and work areas that need dependable daily power.",
    },
    "Expansion-ready electrical planning": {
      icon: Projector,
      desc: "Expansion-ready planning that leaves capacity, pathways and panel organization for future tenants, equipment or layout changes.",
    },
    "HVAC Equipment Wiring": {
      icon: Wind,
      desc: "Install electrical wiring for HVAC systems including rooftop units, controls, and mechanical equipment.",
    },
    "Compressor Circuits": {
      icon: Gauge,
      desc: "Provide dedicated circuits for compressors with proper sizing, protection, and reliable startup performance.",
    },
    "Dedicated Equipment Receptacles": {
      icon: Plug,
      desc: "Install dedicated outlets for commercial equipment to reduce overloads and improve circuit reliability.",
    },
    "Disconnect Switch Installation": {
      icon: Unplug,
      desc: "Install safety disconnect switches for HVAC, pumps, and equipment for safe servicing and maintenance.",
    },
    "Surge Protection": {
      icon: ShieldCheck,
      desc: "Add surge protection to safeguard sensitive commercial equipment from voltage spikes and power events.",
    },
    "Equipment Relocation Power": {
      icon: Route,
      desc: "Reroute or extend electrical power safely when machinery or equipment is moved or reconfigured.",
    },
    "Mechanical Room Circuits": {
      icon: Fan,
      desc: "Install organized circuits for mechanical rooms including pumps, fans, and control systems.",
    },
    "Equipment Load Balancing": {
      icon: BarChart3,
      desc: "Balance electrical loads across circuits to improve system efficiency and reduce overload risks.",
    },
    "Fleet Charging Preparation": {
      icon: Car,
      desc: "Plan and install electrical systems for fleet charging with proper capacity, layout, and future expansion support.",
    },
    "Parking-Area Conduit and Wiring": {
      icon: ParkingCircle,
      desc: "Install durable conduit and wiring in parking areas for EV chargers, lighting, and future electrical systems.",
    },
    "Load Management Systems": {
      icon: SlidersHorizontal,
      desc: "Implement load management systems to safely balance EV charging and commercial electrical demand.",
    },
    "Panel Readiness Review": {
      icon: Gauge,
      desc: "Assess electrical panel capacity and breaker space before adding EV chargers or new commercial loads.",
    },
    "EV Permit Documentation": {
      icon: ClipboardSignature,
      desc: "Prepare permit-ready documentation to support smooth approval and installation of EV charging systems.",
    },
    "Customer Charging Circuit Planning": {
      icon: Car,
      desc: "Design charging circuits for customer EV stalls with clear layout and convenient access.",
    },
    "Workplace Charging Upgrades": {
      icon: PlugZap,
      desc: "Upgrade workplace parking with EV charging solutions for employees and tenant use.",
    },
    "Commercial Electrical Permits": {
      icon: ClipboardSignature,
      desc: "Provide permit support for commercial electrical work to meet local code and inspection requirements.",
    },
    "Code Corrections": {
      icon: FileCheck,
      desc: "Fix commercial electrical code issues including wiring, labeling, protection, and device compliance.",
    },
    "Inspection Preparation": {
      icon: ClipboardCheck,
      desc: "Prepare electrical systems for inspection by reviewing panels, devices, labels, and visible installations.",
    },
    "Electrical Reports": {
      icon: FileText,
      desc: "Provide detailed reports outlining electrical conditions, findings, and recommended improvements.",
    },
    "Deficiency List Repairs": {
      icon: Wrench,
      desc: "Complete repairs from inspection deficiency lists to restore safe and compliant electrical systems.",
    },
    "As-Built Labeling": {
      icon: ListChecks,
      desc: "Label panels, circuits, and equipment clearly for accurate identification and future maintenance use.",
    },
    "Final Compliance Review": {
      icon: ClipboardList,
      desc: "Conduct final checks to ensure commercial electrical systems meet safety and code requirements.",
    },
    "Permit and Inspection Coordination": {
      icon: ClipboardSignature,
      desc: "Manage permits and inspections from application through approval for smooth project completion.",
    },
  };

  const exactDetail = exactDetails[service];
  if (exactDetail) return exactDetail;

  if (text === "office tenant-improvement electrical") {
    return {
      icon: Building2,
      desc: "Office TI wiring for suites, clinics and professional spaces, including power layouts, lighting circuits, device locations and inspection-ready finishing.",
    };
  }

  if (text === "retail unit build-out wiring") {
    return {
      icon: Sparkles,
      desc: "Retail build-out wiring for sales floors, counters, display areas and back rooms, planned around merchandising, POS needs and customer-facing finishes.",
    };
  }

  if (text === "commercial rough-in and final device finishing") {
    return {
      icon: Cable,
      desc: "Rough-in cabling, boxes, conduits and final outlets, switches and cover plates completed cleanly from open-wall construction through final occupancy.",
    };
  }

  if (text === "demising wall and layout-change wiring") {
    return {
      icon: Wrench,
      desc: "Circuit rerouting and device relocation for demising walls, new partitions and layout changes so the finished commercial space matches the new plan.",
    };
  }

  if (text === "inspection deficiency corrections") {
    return {
      icon: FileCheck,
      desc: "Targeted correction of inspection deficiencies, labeling issues, device problems and code items so commercial electrical work can move toward approval.",
    };
  }

  if (text === "restaurant and café renovation electrical") {
    return {
      icon: Utensils,
      desc: "Food-service electrical support for kitchen equipment, dining areas, refrigeration, exhaust systems and code-compliant restaurant operations.",
    };
  }

  if (text === "permit-ready installation and documentation") {
    return {
      icon: FileCheck,
      desc: "Permit-aware documentation, code corrections, labeling and inspection preparation to help commercial projects close cleanly and safely.",
    };
  }

  if (text === "after-hours construction scheduling") {
    return {
      icon: TimerReset,
      desc: "Commercial electrical service planned for code compliance, clean workmanship, practical scheduling and reliable day-to-day business operation.",
    };
  }

  if (text.includes("code-correction") || text.includes("code correction")) {
    return {
      icon: FileCheck,
      desc: "Code-aware correction work for commercial spaces, helping electrical systems meet safety requirements and inspection expectations.",
    };
  }

  if (text.includes("service calls")) {
    return {
      icon: Phone,
      desc: "Responsive commercial service support for occupied spaces, active businesses and urgent electrical issues that need practical scheduling.",
    };
  }

  if (text.includes("scheduling") || text.includes("shutdown window")) {
    return {
      icon: TimerReset,
      desc: "Electrical work coordinated around business hours, construction access, trade schedules and downtime-sensitive commercial operations.",
    };
  }

  if (text.includes("tenant") || text.includes("build-out") || text.includes("rough-in") || text.includes("demising") || text.includes("layout-change")) {
    return {
      icon: ClipboardCheck,
      desc: "Commercial tenant wiring, rough-in, device layout and finishing coordinated around drawings, inspections, trade schedules and business occupancy needs.",
    };
  }

  if (text.includes("office") || text.includes("workstation") || text.includes("boardroom") || text.includes("printer") || text.includes("copier") || text.includes("floor box")) {
    return {
      icon: Building2,
      desc: "Clean office power planning for workstations, meeting rooms, equipment areas and daily business operations with organized circuits and minimal disruption.",
    };
  }

  if (text.includes("data") || text.includes("network") || text.includes("server") || text.includes("communications") || text.includes("rack")) {
    return {
      icon: Cpu,
      desc: "Dedicated power and pathway support for network racks, communication rooms, server equipment and technology systems that need reliable uptime.",
    };
  }

  if (text.includes("retail") || text.includes("display") || text.includes("merchandise") || text.includes("showroom") || text.includes("feature wall") || text.includes("customer-area")) {
    return {
      icon: Sparkles,
      desc: "Polished customer-facing electrical work for displays, sales floors, showrooms and retail layouts where appearance, safety and reliability matter.",
    };
  }

  if (text.includes("point-of-sale") || text.includes("pos")) {
    return {
      icon: Cable,
      desc: "Reliable point-of-sale power and pathway planning for checkout areas, payment terminals, counters and connected retail equipment.",
    };
  }

  if (text.includes("storefront") || text.includes("sign") || text.includes("exterior") || text.includes("parking")) {
    return {
      icon: LampCeiling,
      desc: "Exterior lighting and sign power installed with weather-aware routing, safe switching, clean circuit planning and business visibility in mind.",
    };
  }

  if (text.includes("restaurant") || text.includes("kitchen") || text.includes("café") || text.includes("hood") || text.includes("dishwasher") || text.includes("cooler") || text.includes("refrigeration") || text.includes("dining")) {
    return {
      icon: Utensils,
      desc: "Food-service electrical support for kitchen equipment, dining areas, refrigeration, exhaust systems and code-compliant restaurant operations.",
    };
  }

  if (text.includes("gfci") || text.includes("egress") || text.includes("life-safety") || text.includes("common-area") || text.includes("battery backup")) {
    return {
      icon: ShieldCheck,
      desc: "Safety-focused wiring and protection for commercial areas that require dependable operation, compliant protection and inspection-ready installation.",
    };
  }

  if (text.includes("panel") || text.includes("distribution") || text.includes("breaker") || text.includes("metering") || text.includes("service-equipment")) {
    return {
      icon: CircuitBoard,
      desc: "Commercial panels, breakers, distribution equipment and service upgrades planned for capacity, clear labeling and maintenance-friendly organization.",
    };
  }

  if (text.includes("feeder") || text.includes("conduit") || text.includes("cable") || text.includes("pathway")) {
    return {
      icon: Cable,
      desc: "Clean feeder, conduit and cable pathway installation for commercial spaces, equipment zones, future systems and organized power distribution.",
    };
  }

  if (text.includes("load")) {
    return {
      icon: Gauge,
      desc: "Load calculations, balancing and capacity review to support safe commercial operation, new equipment, renovations and future electrical demand.",
    };
  }

  if (text.includes("lighting") || text.includes("led") || text.includes("high-bay") || text.includes("track lighting")) {
    return {
      icon: LampCeiling,
      desc: "Commercial lighting upgrades designed to improve visibility, reduce energy use and create practical lighting zones for business spaces.",
    };
  }

  if (text.includes("occupancy") || text.includes("sensor") || text.includes("automated") || text.includes("control") || text.includes("thermostat") || text.includes("energy monitoring") || text.includes("automation")) {
    return {
      icon: Radar,
      desc: "Smart controls, sensors and automation-ready wiring that improve efficiency, convenience and future flexibility for commercial buildings.",
    };
  }

  if (text.includes("emergency light") || text.includes("exit sign") || text.includes("emergency lighting")) {
    return {
      icon: ShieldCheck,
      desc: "Emergency lighting and exit sign wiring installed for safer egress, inspection readiness and dependable life-safety performance.",
    };
  }

  if (text.includes("troubleshooting") || text.includes("diagnostics") || text.includes("dead outlet") || text.includes("flickering") || text.includes("power-loss") || text.includes("urgent")) {
    return {
      icon: TimerReset,
      desc: "Responsive commercial troubleshooting to identify faults, restore power, reduce downtime and correct electrical issues safely.",
    };
  }

  if (text.includes("maintenance") || text.includes("thermal") || text.includes("device replacement") || text.includes("repair")) {
    return {
      icon: Wrench,
      desc: "Planned maintenance and repair support for active businesses, helping equipment, lighting and devices stay safe and dependable.",
    };
  }

  if (text.includes("security") || text.includes("camera") || text.includes("access-control")) {
    return {
      icon: Radar,
      desc: "Electrical preparation for security cameras, access-control systems and low-voltage devices with separated pathways and reliable power points.",
    };
  }

  if (text.includes("hvac") || text.includes("compressor") || text.includes("mechanical")) {
    return {
      icon: Gauge,
      desc: "Dedicated commercial equipment circuits for HVAC, compressors and mechanical rooms with proper load planning, protection and service access.",
    };
  }

  if (text.includes("dedicated receptacles") || text.includes("dedicated circuits") || text.includes("disconnect") || text.includes("surge") || text.includes("equipment relocation")) {
    return {
      icon: PlugZap,
      desc: "Purpose-built circuits, receptacles, disconnects and protection for high-demand commercial equipment and changing business layouts.",
    };
  }

  if (text.includes("ev") || text.includes("charger") || text.includes("fleet") || text.includes("charging") || text.includes("parking-area")) {
    return {
      icon: PlugZap,
      desc: "Commercial EV charging infrastructure planned for parking areas, fleet needs, panel readiness, permitting and scalable load management.",
    };
  }

  if (text.includes("permit") || text.includes("code") || text.includes("inspection") || text.includes("report") || text.includes("deficiency") || text.includes("as-built") || text.includes("compliance")) {
    return {
      icon: FileCheck,
      desc: "Permit-aware documentation, code corrections, labeling and inspection preparation to help commercial projects close cleanly and safely.",
    };
  }

  if (text.includes("generator") || text.includes("transfer switch") || text.includes("critical-load") || text.includes("backup") || text.includes("load-shedding") || text.includes("ups")) {
    return {
      icon: PanelTop,
      desc: "Backup and critical-load power planning for business continuity, outage readiness and essential commercial systems.",
    };
  }

  if (text.includes("warehouse") || text.includes("bay") || text.includes("overhead door") || text.includes("loading dock") || text.includes("shop") || text.includes("tool") || text.includes("expansion")) {
    return {
      icon: HardHat,
      desc: "Warehouse and light-industrial bay power for lighting, doors, docks, tools, equipment receptacles and future expansion needs.",
    };
  }

  return {
    icon: category.icon,
    desc: "Commercial electrical service planned for code compliance, clean workmanship, practical scheduling and reliable day-to-day business operation.",
  };
}

const processSteps: ProcessStep[] = [
  {
    icon: Phone,
    title: "Assess Your Commercial Electrical Requirements",
    text: "We review your business operations, occupancy requirements, equipment loads, electrical infrastructure, layout, access points, and operating hours before developing a project plan.",
  },
  {
    icon: ClipboardCheck,
    title: "Plan Permits, Safety, and Access",
    text: "Commercial electrical permits, inspections, shutdown schedules, safe work zones, and trade coordination are organized before installation begins.",
  },
  {
    icon: Wrench,
    title: "Complete the Commercial Electrical Installation",
    text: "Commercial wiring, electrical panels, lighting systems, controls, dedicated circuits, and power distribution equipment are installed using quality materials and professional workmanship.",
  },
  {
    icon: BadgeCheck,
    title: "Test for Safe Business Operations",
    text: "Electrical systems, lighting, life-safety devices, controls, and equipment connections are tested and verified to ensure safe, reliable commercial operation.",
  },
];

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Service",
  name: "Commercial Electrical Services",
  provider: {
    "@type": "Electrician",
    name: "GK Electric",
    telephone: "+1-778-344-4567",
    areaServed: "British Columbia Lower Mainland",
  },
  serviceType: categories.map((category) => category.title),
  description: commercialProfessionalMeta.description,
};

function ContactPills() {
  return (
    <div className="flex flex-wrap justify-center gap-4">
      <a
        href="tel:+17783444567"
        className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-primary/30 transition-all duration-300"
      >
        <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all">
          <Phone className="h-5 w-5 text-primary group-hover:text-primary-foreground" />
        </div>
        <div className="text-left">
          <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">Call Us</div>
          <div className="text-surface-foreground font-semibold">+1 (778) 344-4567</div>
        </div>
      </a>
      <a
        href="https://wa.me/17783444567"
        target="_blank"
        rel="noreferrer"
        className="group inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-green-500/30 transition-all duration-300"
      >
        <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center group-hover:bg-green-500 group-hover:scale-110 transition-all">
          <MessageCircle className="h-5 w-5 text-green-400 group-hover:text-white" />
        </div>
        <div className="text-left">
          <div className="text-xs text-surface-foreground/50 uppercase tracking-wider">WhatsApp</div>
          <div className="text-surface-foreground font-semibold">Quick Response</div>
        </div>
      </a>
    </div>
  );
}

export function CommercialElectricalServicesProfessional({ useRequestedCopy = false }: { useRequestedCopy?: boolean } = {}) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main>
        <section className="relative overflow-hidden bg-gradient-to-br from-surface via-surface to-surface/95 min-h-[58vh] flex items-center text-surface-foreground">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float delay-1000" />
          </div>
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: "50px 50px",
            }}
          />
          <div className="container relative z-10 mx-auto px-4 py-24">
            <div className="max-w-5xl">
              <div className="max-w-4xl">
                <ElectricSectionTag label="Business Spaces" icon={Building2} tone="dark" variant="electric-v1-2" className="mb-8 [&>span:last-child]:!text-[15px] [&>span:last-child]:!font-normal" />
                <h1
                  data-reveal
                  className="font-display text-[80px] font-extrabold tracking-tight leading-[0.94] mb-7"
                >
                  <span className="text-typewriter">
                    Commercial <span className="brand-highlight">Services</span>
                  </span>
                </h1>
                <p className="text-[20px] font-light text-surface-foreground/75 max-w-3xl leading-relaxed mb-8">
                  Dependable commercial electrical services for offices, retail spaces, restaurants, tenant improvements, panels, LED lighting, EV charging, maintenance, permits and code-compliant troubleshooting.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="electric" size="xl">
                    <Link to="/contact">
                      Request Commercial Estimate <ArrowRight className="h-5 w-5" />
                    </Link>
                  </Button>
                  <Button asChild variant="outlineLight" size="xl">
                    <a href="tel:+17783444567">
                      <Phone className="h-5 w-5" /> Call +1 (778) 344-4567
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-10 text-primary/5 animate-float pointer-events-none">
            <Building2 className="h-32 w-32 rotate-12" />
          </div>
          <div className="absolute top-20 right-20 text-primary/5 animate-float delay-500 pointer-events-none">
            <Building2 className="h-24 w-24 -rotate-12" />
          </div>
        </section>

        <section className="relative overflow-hidden border-y border-border bg-muted/35 py-0">
          <style>{`
            @keyframes commercialServiceTickerMove {
              from { transform: translate3d(0, 0, 0); }
              to { transform: translate3d(-50%, 0, 0); }
            }
            .commercial-service-ticker-track {
              animation: commercialServiceTickerMove 92s linear infinite;
              backface-visibility: hidden;
              transform: translate3d(0, 0, 0);
              will-change: transform;
            }
            .commercial-service-ticker:hover .commercial-service-ticker-track {
              animation-play-state: paused;
            }
          `}</style>
          <div className="flex min-h-14 items-stretch gap-0 px-0 md:px-6">
            <div className="relative z-20 flex shrink-0 items-center gap-3 self-stretch border-r border-border bg-muted/95 px-3 pr-5 md:px-0 md:pr-5">
              <span className="flex h-8 w-8 items-center justify-center !rounded-[10px] bg-gradient-electric shadow-glow">
                <Bolt className="h-4 w-4 text-primary-foreground" />
              </span>
              <div className="leading-tight">
                <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground md:text-xl">Commercial Services Map</h2>
              </div>
            </div>

            <div className="commercial-service-ticker relative flex min-w-0 flex-1 overflow-hidden py-0">
              <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-muted/95 to-transparent" />
              <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-20 bg-gradient-to-l from-muted/95 to-transparent" />
              <div className="commercial-service-ticker-track flex min-w-max items-stretch gap-0 py-0">
                {[...categories, ...categories].map((category, index) => (
                  <a
                    key={`${category.title}-${index}`}
                    href={`#commercial-service-${index % categories.length}`}
                    className="group/service-news relative flex min-h-14 shrink-0 items-center gap-2 self-stretch rounded-none border-r border-border/80 px-8 pb-[3px] text-left transition-all duration-200 hover:bg-white focus:outline-none focus:ring-2 focus:ring-primary/40"
                  >
                    <span className={`flex h-7 w-7 shrink-0 items-center justify-center !rounded-[10px] bg-gradient-to-br ${category.accent || "from-amber-400 to-yellow-500"} shadow-sm transition-colors duration-200`}>
                      <category.icon className="h-4 w-4 text-primary-foreground" />
                    </span>
                    <span className="whitespace-nowrap font-display text-base font-bold uppercase tracking-wide text-foreground antialiased transition-colors duration-200">
                      {category.title}
                    </span>
                    <span className="pointer-events-none absolute inset-x-0 bottom-0 h-[3px] origin-center scale-x-0 bg-primary transition-transform duration-200 group-hover/service-news:scale-x-100" aria-hidden />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Removed highlights section */}

        <section className="py-20 md:py-28 bg-muted/35">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 lg:grid-cols-[1fr_0.82fr] lg:items-center mb-14">
              <div className="max-w-3xl" data-reveal>
                <ElectricSectionTag label={useRequestedCopy ? "Commercial Electrical Services" : "Complete Service Coverage"} icon={ClipboardCheck} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-4xl md:text-6xl font-bold mb-5">
                  {useRequestedCopy ? "Professional Electrical Solutions for Businesses" : "Commercial Electrical Services"}
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  {useRequestedCopy
                    ? "Complete commercial electrical services for offices, retail stores, restaurants, multi-unit properties, and commercial facilities. From electrical installations and service upgrades to lighting systems, maintenance, tenant improvements, and code-compliance work, our experienced electricians deliver reliable power solutions that support business operations and long-term growth."
                    : "Explore a complete range of commercial electrical services, organized for business owners, property managers and project teams who need safe power, reliable installations, code-compliant upgrades and practical business-ready electrical planning."}
                </p>
              </div>

              <div data-reveal="right" className="relative">
                <article className="group relative flex border-2 flex-col overflow-hidden rounded-3xl border-foreground/30 bg-transparent p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary hover:shadow-elegant">
                  <div className="flex items-start justify-between gap-4">
                    <div className="text-left">
                      <div className="font-sans text-lg font-extrabold uppercase leading-none tracking-[0.22em] text-foreground">
                        GK ELECTRIC
                      </div>
                      <div className="mt-1 text-[12px] uppercase tracking-widest text-muted-foreground">
                        Licensed Electricians
                      </div>
                    </div>
                    <div className="shrink-0">
                      <div className="shrink-0 rounded-2xl bg-[#00497b] px-3 py-2.5 shadow-xl ring-2 ring-white/90">
                        <div className="flex items-center justify-end gap-3">
                          <img
                            src={tsbcLogo}
                            alt="Technical Safety BC logo"
                            className="h-12 w-12 object-contain"
                            loading="lazy"
                          />
                          <div className="text-right text-white">
                            <div className="text-[0.95rem] tracking-wider text-white">TSBC Licence</div>
                            <div className="text-[1.1rem] tracking-[1.5px] font-bold text-white"># LEL0209793</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 grid grid-cols-2 gap-2.5">
                    {commercialLicenceTags.map((tag) => (
                      <div
                        key={tag}
                        className="flex min-h-9 w-full items-center gap-1.5 rounded-[10px] border border-primary/20 bg-primary/10 px-3 py-1.5 text-[14px] font-medium leading-none text-foreground shadow-sm"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                        <span className="truncate">{tag}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-5 flex-none flex items-start justify-between gap-5">
                    <div className="w-full text-left">
                      <div className="mb-4 h-1 w-14 rounded-full bg-foreground" />
                      <h2 className="whitespace-nowrap font-sans text-[clamp(0.78rem,1.7vw,0.95rem)] font-semibold uppercase leading-none tracking-[0.18em] text-foreground">
                        Proudly Serving the Lower Mainland, BC
                      </h2>
                    </div>
                  </div>

                  <div className="relative z-10 mt-3 grid grid-cols-3 gap-2">
                    {[
                      { label: "Residential", to: "/residential-electrical-services" as const, icon: Home },
                      { label: "Commercial", to: "/commercial-electrical-services" as const, icon: Building2 },
                      { label: "Industrial", to: "/industrial-electrical-services" as const, icon: Factory },
                    ].map((item) => (
                      <Link
                        key={item.label}
                        to={item.to}
                        className="group/service flex flex-col items-center justify-center gap-1.5 rounded-xl border border-border bg-muted/40 px-2.5 py-3 text-center transition-all duration-300 hover:border-primary/45 hover:bg-primary/[0.1]"
                      >
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center !rounded-[10px] border border-primary/20 bg-primary/15 text-primary transition-all duration-300 group-hover/service:bg-primary group-hover/service:text-primary-foreground">
                          <item.icon className="h-4.5 w-4.5" />
                        </div>
                        <div className="font-sans text-[18px] font-bold uppercase tracking-wide text-foreground leading-tight">
                          {item.label}
                        </div>
                      </Link>
                    ))}
                  </div>
                </article>
              </div>
            </div>

            <div className="space-y-10">
              {categories.map((category, index) => {
                const CategoryIcon = category.icon;
                return (
                  <article id={`commercial-service-${index}`} key={category.title} data-reveal className="scroll-mt-28 relative rounded-[2rem] border border-border bg-card shadow-card transition-all duration-300 hover:border-primary/40">
                    <div className="absolute right-6 top-6 text-primary/5 pointer-events-none">
                      <CategoryIcon className="h-28 w-28 -rotate-12" />
                    </div>
                    <div className="grid gap-0 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
                      <div className="relative h-full bg-surface text-surface-foreground p-8 md:p-10 rounded-t-[2rem] lg:rounded-l-[2rem] lg:rounded-tr-none">
                        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px" }} />
                        <div className="relative z-10 lg:sticky lg:top-28 lg:self-start" data-reveal="left">
                          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-electric shadow-glow">
                            <CategoryIcon className="h-8 w-8 text-primary-foreground" />
                          </div>
                          <h3 className="font-display text-3xl md:text-4xl font-extrabold mb-4">{category.title}</h3>
                          <p className="text-surface-foreground/70 leading-relaxed">{category.description}</p>
                        </div>
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4 p-6 md:p-8">
                        {category.services.map((service, serviceIndex) => {
                          const detail = getCommercialServiceDetail(service, category);
                          const ServiceIcon = detail.icon;
                          return (
                            <div key={service} data-reveal="right" className="group rounded-2xl border border-border bg-background p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:bg-primary/5" style={{ transitionDelay: `${serviceIndex * 55}ms` }}>
                              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-all group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-110">
                                <ServiceIcon className="h-6 w-6" />
                              </div>
                              <h4 className="font-display text-xl font-bold text-foreground mb-2">{service}</h4>
                              <p className="text-sm text-muted-foreground leading-relaxed">{detail.desc}</p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] items-center">
              <div data-reveal="left">
                <ElectricSectionTag label={useRequestedCopy ? "Commercial Properties We Service" : "Business Types"} icon={HardHat} tone="light" variant="electric-v1-2" className="mb-6" />
                <h2 className="font-display text-4xl md:text-5xl font-bold mb-5">
                  {useRequestedCopy ? "Commercial Electrical Services for a Wide Range of Business Facilities" : "Commercial Spaces We Support"}
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed mb-8">
                  {useRequestedCopy
                    ? "GK Electric provides professional commercial electrical services for businesses, property managers, and commercial property owners. We support electrical installations, tenant improvements, renovations, service upgrades, lighting systems, troubleshooting, maintenance, and code-compliance projects across a variety of commercial spaces."
                    : "GK Electric can support small service calls, planned renovations, full tenant improvements, safety corrections and ongoing maintenance for a wide range of business spaces."}
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="electric" size="lg">
                    <Link to="/services/commercial">View Current Commercial Page</Link>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                      <MessageCircle className="h-5 w-5" /> WhatsApp
                    </a>
                  </Button>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2" data-reveal="right">
                {businessTypes.map((type, index) => {
                  const icons = useRequestedCopy
                    ? [BriefcaseBusiness, ShoppingBag, UtensilsCrossed, KeyRound, Warehouse, Activity, Sparkles, Presentation]
                    : [Building2, LampCeiling, Wrench, Cpu, Radar, Gauge, ShieldCheck, TimerReset];
                  const Icon = icons[index % icons.length];
                  return (
                    <div key={type} className="rounded-2xl border border-border bg-card p-5 shadow-sm transition-all hover:border-primary/50 hover:shadow-card">
                      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <p className="font-semibold text-foreground">{type}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
              <div>
                <ElectricSectionTag label={useRequestedCopy ? "Complete Commercial Electrical Coverage" : "Complete Electrical Coverage"} icon={Zap} tone="dark" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-3xl md:text-5xl font-extrabold leading-tight mb-4">
                  {useRequestedCopy ? (
                    <>
                      <span className="text-primary">GK ELECTRIC</span> provides licensed and professional commercial electrical services, including electrical repairs, installations, upgrades, maintenance, troubleshooting, and code-compliant solutions for businesses, offices, retail spaces, warehouses, and commercial facilities.
                    </>
                  ) : (
                    <>
                      <span className="text-primary">GK ELECTRIC</span> provides all types of residential, commercial and industrial electrical services.
                    </>
                  )}
                </h2>
                <p className="text-surface-foreground/70 text-base md:text-lg leading-relaxed max-w-3xl">
                  {useRequestedCopy
                    ? "One licensed team for commercial power systems, electrical panel upgrades, tenant improvements, lighting installations, electrical permits, dedicated circuits, equipment connections, safety repairs, energy-efficient upgrades, and complete commercial electrical installations."
                    : "One licensed team for home upgrades, business power, facility wiring, permits, safety repairs, EV chargers, panels, lighting and complete electrical installations."}
                </p>
              </div>
              <div className={useRequestedCopy ? "flex flex-col items-center gap-4" : "grid gap-3 sm:grid-cols-3 lg:grid-cols-1"}>
                {[
                  { icon: Home, label: "Residential", to: "/residential-electrical-services" as const },
                  { icon: Building2, label: "Commercial", to: "/commercial-electrical-services" as const },
                  { icon: Factory, label: "Industrial", to: "/industrial-electrical-services" as const },
                ].map((item) => (
                  useRequestedCopy ? (
                    <Link key={item.label} to={item.to} className="group/coverage relative mx-auto flex w-1/2 min-w-[220px] max-w-[320px] items-center justify-center gap-3 overflow-hidden rounded-[5px] border border-primary/45 bg-transparent px-5 py-3.5 text-primary backdrop-blur-sm transition-all duration-500 ease-out hover:-translate-y-0.5 hover:border-primary hover:text-primary-foreground hover:shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2 focus:ring-offset-surface before:absolute before:inset-0 before:origin-left before:scale-x-0 before:bg-gradient-electric before:transition-transform before:duration-500 before:ease-out hover:before:scale-x-100">
                      <div className="relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-[5px] bg-transparent text-primary transition-all duration-500 group-hover/coverage:rotate-3 group-hover/coverage:scale-105 group-hover/coverage:text-primary-foreground">
                        <item.icon className="h-10 w-10" />
                      </div>
                      <div className="relative z-10 font-display text-base font-extrabold uppercase tracking-[0.18em]">{item.label}</div>
                      <ArrowRight className="relative z-10 h-5 w-5 opacity-70 transition-all duration-500 group-hover/coverage:translate-x-1.5 group-hover/coverage:opacity-100" />
                    </Link>
                  ) : (
                    <Link key={item.label} to={item.to} className="group/coverage flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.055] p-4 backdrop-blur-sm transition-all duration-300 hover:border-primary/45 hover:bg-primary/[0.08] focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-surface">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-primary/20 bg-primary/15 text-primary transition-all duration-300 group-hover/coverage:bg-primary group-hover/coverage:text-primary-foreground">
                        <item.icon className="h-6 w-6" />
                      </div>
                      <div className="font-display text-xl font-bold tracking-wide">{item.label}</div>
                      <ArrowRight className="ml-auto h-5 w-5 text-primary opacity-70 transition-transform duration-300 group-hover/coverage:translate-x-1 group-hover/coverage:opacity-100" />
                    </Link>
                  )
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-start">
              <div className="lg:sticky lg:top-28" data-reveal="left">
                <ElectricSectionTag label="Our Process" icon={Wrench} tone="light" variant="electric-v1-2" className="mb-5" />
                <h2 className="font-display text-4xl md:text-6xl font-extrabold text-foreground mb-5">
                  Planned Around Business Continuity
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                  Commercial electrical projects require careful coordination to minimize disruption and support daily operations. We organize access, scheduling, permits, inspections, and shutdown windows so your business can continue operating safely and efficiently.
                </p>
                <Button asChild variant="electric" size="lg">
                  <Link to="/contact">
                    Request A Commercial Electrical Estimate <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
              <div className="grid gap-5">
                {processSteps.map((step, index) => (
                  <div key={step.title} data-reveal="right" className="group rounded-2xl border border-border bg-card p-6 shadow-card hover:shadow-elegant hover:border-primary/40 hover:-translate-y-1 transition-all duration-300" style={{ transitionDelay: `${index * 90}ms` }}>
                    <div className="flex gap-5 items-start">
                      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary transition-colors shrink-0">
                        <step.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
                      </div>
                      <div>
                        {useRequestedCopy ? (
                          <div className="mb-1 text-xs font-bold uppercase tracking-[0.25em] text-primary">Step-{index + 1}</div>
                        ) : null}
                        <h3 className="font-display text-xl font-bold text-foreground mb-2">
                          {useRequestedCopy ? step.title : `${index + 1}. ${step.title}`}
                        </h3>
                        <p className="text-muted-foreground leading-relaxed">{step.text}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-surface text-surface-foreground relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "24px 24px" }} />
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <ElectricSectionTag label="Ready To Get Started" icon={Zap} tone="dark" variant="electric-v1-2" className="mb-6 justify-center" />
              <h2 className="font-display text-4xl md:text-6xl font-extrabold mb-6">
                Need Reliable Commercial Electrical Work?
              </h2>
              <p className="text-lg text-surface-foreground/70 leading-relaxed mb-8 max-w-2xl mx-auto">
                Talk to GK Electric about tenant improvements, panel upgrades, lighting retrofits, equipment circuits, maintenance, permits or inspection-ready corrections.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="electric" size="xl">
                  <a href="tel:+17783444567">
                    <Phone className="h-5 w-5" /> Call +1 (778) 344-4567
                  </a>
                </Button>
                <Button asChild variant="outline" size="xl" className="bg-white/5 border-white/15 text-white hover:bg-white/10">
                  <a href="https://wa.me/17783444567" target="_blank" rel="noreferrer">
                    <MessageCircle className="h-5 w-5" /> WhatsApp Quick Response
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </div>
  );
}
