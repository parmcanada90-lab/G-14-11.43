import { Link } from "@tanstack/react-router";
import { Phone, Menu, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import gkLogo from "@/assets/gk-logo.jpeg";
import { megaMenuConfig } from "./header/megaMenuConfig";
import { MegaMenu } from "./header/MegaMenu";

const navLinks = [
  { to: "/" as const, label: "Home" },
  { to: "/services" as const, label: "Services" },
  { to: "/projects" as const, label: "Projects" },
  { to: "/about" as const, label: "Company" },
  { to: "/contact" as const, label: "Contact" },
];

type BarProps = {
  /** When true, render in solid (white bg / black text) mode at rest. */
  solid: boolean;
  /** Extra classes for the <header> wrapper (e.g. translate, transition). */
  wrapperClassName?: string;
};

function HeaderBar({ solid: solidAtRest, wrapperClassName = "" }: BarProps) {
  const [open, setOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const openTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearTimers = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    if (openTimer.current) clearTimeout(openTimer.current);
  };

  const scheduleOpen = (to: string) => {
    clearTimers();
    if (!(to in megaMenuConfig)) {
      setActiveMenu(null);
      return;
    }
    openTimer.current = setTimeout(() => setActiveMenu(to), 120);
  };

  const scheduleClose = () => {
    clearTimers();
    closeTimer.current = setTimeout(() => setActiveMenu(null), 180);
  };

  const navTextStyle = { fontWeight: 400, letterSpacing: "1px" };

  // forceSolid = white-bg/black-text rendering. Always true for the
  // secondary header. For the primary header, when a mega menu or mobile
  // menu is open so all menu text sits on a real visible surface.
  const forceSolid = solidAtRest || activeMenu !== null || open;

  return (
    <header
      className={`group ${
        solidAtRest ? "fixed" : "absolute"
      } top-0 left-0 right-0 z-50 w-full border-b ${
        forceSolid
          ? `${solidAtRest && !activeMenu ? "border-border/50" : "border-transparent"} bg-background`
          : "border-transparent bg-transparent hover:border-border/50 hover:bg-background"
      } ${wrapperClassName}`}
      onMouseLeave={scheduleClose}
    >
      <div className="container mx-auto flex h-18 items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2 group/logo">
          <img
            src={gkLogo}
            alt="GK Electric logo"
            className="h-12 w-12 object-contain group-hover/logo:scale-105 transition-transform border-0 rounded-full"
          />
          <div className="leading-tight text-left" style={{ width: "230px" }}>
            <div
              className={`font-display uppercase tracking-normal mx-0 px-0 transition-colors duration-500 ${
                forceSolid ? "text-foreground" : "text-white group-hover:text-foreground"
              }`}
              style={{
                fontSize: "22px",
                fontWeight: 500,
                letterSpacing: "0px",
                lineHeight: 1,
                transform: "scaleX(1.5)",
                transformOrigin: "left center",
              }}
            >
              GK ELECTRIC
            </div>
            <div
              className={`text-[10px] uppercase transition-colors duration-500 ${
                forceSolid ? "text-muted-foreground" : "text-white/70 group-hover:text-muted-foreground"
              }`}
              style={{
                display: "inline-block",
                fontSize: "12px",
                fontWeight: 400,
                letterSpacing: "1.5px",
                lineHeight: 1.1,
                whiteSpace: "nowrap",
              }}
            >
              Licensed Electricians
            </div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {navLinks.map((l) => (
            <div key={l.to} onMouseEnter={() => scheduleOpen(l.to)}>
              <Link
                to={l.to}
                className={`px-4 py-2 text-sm font-semibold uppercase tracking-wide rounded-md transition-colors duration-500 ${
                  forceSolid
                    ? "text-foreground/80 hover:text-foreground"
                    : "text-white group-hover:text-foreground/80 group-hover:hover:text-foreground"
                }`}
                style={navTextStyle}
                activeProps={{ className: "text-primary" }}
                activeOptions={{ exact: l.to === "/" }}
              >
                <span className="link-underline-grow">{l.label}</span>
              </Link>
            </div>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <a
            href="tel:+17783344567"
            className={`flex items-center gap-2 text-sm font-semibold transition-colors duration-500 ${
              forceSolid ? "text-foreground hover:text-primary" : "text-white group-hover:text-foreground"
            }`}
            style={navTextStyle}
          >
            <Phone className="h-4 w-4 icon-pop" />
            +1 (778) 334-4567
          </a>
          <Button asChild variant="electric" size="sm">
            <Link to="/contact" style={navTextStyle}>FREE ESTIMATE</Link>
          </Button>
        </div>

        <button
          className={`lg:hidden p-2 transition-colors duration-500 ${
            forceSolid ? "text-foreground" : "text-white group-hover:text-foreground"
          }`}
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mega-menu panel (desktop) */}
      {activeMenu && megaMenuConfig[activeMenu] && (
        <div onMouseEnter={clearTimers} onMouseLeave={scheduleClose}>
          <MegaMenu panel={megaMenuConfig[activeMenu]} onClose={() => setActiveMenu(null)} />
        </div>
      )}


      {open && (
        <nav className="lg:hidden border-t border-border bg-background text-foreground shadow-xl">
          <div className="container mx-auto max-h-[calc(100vh-72px)] overflow-y-auto px-4 py-4 flex flex-col gap-1">
            {navLinks.map((l) => (
              <div key={l.to} className="rounded-xl">
                <Link
                  to={l.to}
                  onClick={() => setOpen(false)}
                  className="block px-4 py-3 text-sm font-semibold uppercase tracking-wide rounded-md hover:bg-muted"
                  style={navTextStyle}
                  activeProps={{ className: "text-primary bg-muted" }}
                  activeOptions={{ exact: l.to === "/" }}
                >
                  {l.label}
                </Link>

                {megaMenuConfig[l.to] && (
                  <div className="mb-2 ml-4 border-l border-border/80 pl-3">
                    {megaMenuConfig[l.to].cards && (
                      <div className="grid grid-cols-2 gap-2 py-2">
                        {megaMenuConfig[l.to].cards!.map((card) => (
                          <Link
                            key={`${l.to}-${card.label}`}
                            to={card.to as any}
                            onClick={() => setOpen(false)}
                            className="group overflow-hidden rounded-xl border border-border bg-card hover:border-primary/35"
                          >
                            <div className="relative h-20 overflow-hidden">
                              <img src={card.image} alt={card.label} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
                              <div className="absolute inset-0 bg-surface/45" />
                              <div className="absolute bottom-2 left-2 text-xs font-bold uppercase tracking-wide text-white">
                                {card.label}
                              </div>
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}

                    <div className="grid gap-1 py-1">
                      {megaMenuConfig[l.to].rightLinks.map((item) => (
                        <Link
                          key={`${l.to}-${item.label}`}
                          to={item.to as any}
                          onClick={() => setOpen(false)}
                          className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold text-muted-foreground hover:bg-muted hover:text-foreground"
                        >
                          {item.icon && <item.icon className="h-4 w-4 text-primary" />}
                          {item.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
            <Button asChild variant="electric" className="mt-2">
              <Link to="/contact" onClick={() => setOpen(false)} style={navTextStyle}>
                FREE ESTIMATE
              </Link>
            </Button>
          </div>
        </nav>
      )}
    </header>
  );
}

export function Header() {
  const [pastHero, setPastHero] = useState(false);
  const [visible, setVisible] = useState(false);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      const heroThreshold = window.innerHeight - 100;
      const overHero = y < heroThreshold;
      setPastHero(!overHero);

      if (overHero) {
        // While over hero, the secondary header is unmounted; reset state
        setVisible(false);
      } else {
        if (y < lastScrollY.current) setVisible(true);
        else if (y > lastScrollY.current) setVisible(false);
      }
      lastScrollY.current = y;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      {/* Primary header — transparent, white text, pinned to the very
          top, never reacts to scroll. Hidden once past the hero so the
          secondary header takes over. */}
      {!pastHero && <HeaderBar solid={false} />}

      {/* Secondary header — white bg + black text, scroll-up reveal. */}
      {pastHero && (
        <HeaderBar
          solid={true}
          wrapperClassName={`transition-transform duration-500 ease-out ${
            visible ? "translate-y-0" : "-translate-y-full"
          }`}
        />
      )}
    </>
  );
}
