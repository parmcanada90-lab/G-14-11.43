import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { RouterProvider } from "@tanstack/react-router";
import { getRouter } from "./router";
import "./styles.css";

if (typeof window !== "undefined") {
  const path = window.location.pathname;
  if (path === "/Surrey" || path === "/Surrey/") {
    window.location.replace("/surrey");
  }
  if ("scrollRestoration" in window.history) {
    window.history.scrollRestoration = "manual";
  }
  window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  window.addEventListener("pageshow", () => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  });
}

const router = getRouter();

const rootEl = document.getElementById("root")!;
createRoot(rootEl).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);
