import type { LucideIcon } from "lucide-react";
import {
  Bath,
  BatteryCharging,
  Cable,
  CheckCircle2,
  ClipboardCheck,
  Cpu,
  Flame,
  Gauge,
  Home,
  LampCeiling,
  PanelTop,
  Plug,
  ShieldCheck,
  Sun,
  Trees,
  Wrench,
} from "lucide-react";

export type ResidentialSampleCategory = {
  icon: LucideIcon;
  title: string;
  description: string;
  services: string[];
  accent: string;
  tint: string;
};

export const residentialSampleCategories: ResidentialSampleCategory[] = [
  {
    icon: Home,
    title: "New Construction Electrical",
    description: "Complete electrical planning, rough-in and finishing for custom homes, laneway homes and residential builds.",
    accent: "from-amber-300 via-yellow-400 to-orange-500",
    tint: "bg-amber-500/10 text-amber-600",
    services: ["Electrical layout planning", "Main panel installation", "Full rough-in wiring", "Lighting and outlet placement", "Kitchen and laundry circuits", "Low-voltage preparation"],
  },
  {
    icon: PanelTop,
    title: "Panels, Breakers & Service Upgrades",
    description: "Capacity upgrades and breaker improvements that prepare homes for modern electrical demand.",
    accent: "from-yellow-300 via-amber-400 to-orange-500",
    tint: "bg-yellow-500/10 text-yellow-700",
    services: ["100A to 200A upgrades", "Main panel replacement", "Subpanel installation", "Breaker replacement", "AFCI/GFCI upgrades", "Load calculations"],
  },
  {
    icon: Cable,
    title: "Home Wiring, Rewiring & Suites",
    description: "Clean, code-compliant wiring for older homes, additions, renovations, basement suites and secondary suites.",
    accent: "from-blue-400 via-cyan-400 to-sky-500",
    tint: "bg-blue-500/10 text-blue-600",
    services: ["Whole-home rewiring", "Aluminum wiring corrections", "Suite wiring", "Renovation rough-ins", "Garage and laneway wiring", "Data and TV cabling"],
  },
  {
    icon: LampCeiling,
    title: "Lighting Design & Installation",
    description: "Interior, exterior, feature and security lighting designed to make homes brighter, safer and more efficient.",
    accent: "from-orange-400 via-rose-400 to-pink-500",
    tint: "bg-orange-500/10 text-orange-600",
    services: ["Pot light installation", "LED upgrades", "Pendant and chandelier wiring", "Under-cabinet lighting", "Landscape lighting", "Dimmers and scene controls"],
  },
  {
    icon: Plug,
    title: "Outlets, Switches, Circuits & Appliances",
    description: "Everyday electrical improvements that add convenience, safe appliance power and reliable room-by-room function.",
    accent: "from-violet-400 via-purple-500 to-fuchsia-600",
    tint: "bg-violet-500/10 text-violet-600",
    services: ["Outlet replacement", "New switch locations", "USB and smart outlets", "Kitchen GFCI outlets", "Dedicated appliance circuits", "Tripping circuit repairs"],
  },
  {
    icon: Flame,
    title: "HVAC, Heating & Ventilation",
    description: "Dedicated electrical connections and controls for home comfort systems, fans, heat pumps and ventilation equipment.",
    accent: "from-cyan-400 via-blue-500 to-indigo-600",
    tint: "bg-cyan-500/10 text-cyan-600",
    services: ["Heat pump circuits", "AC equipment wiring", "Baseboard heating", "Thermostat wiring", "Bathroom fan controls", "Mechanical room circuits"],
  },
  {
    icon: BatteryCharging,
    title: "EV Chargers & Future-Ready Power",
    description: "Safe Level 2 home charging solutions with panel checks, load review and dedicated charger circuits.",
    accent: "from-emerald-400 via-green-500 to-lime-600",
    tint: "bg-emerald-500/10 text-emerald-600",
    services: ["Level 2 chargers", "Garage charger circuits", "Hardwired charger setup", "EV load management", "Panel capacity checks", "Permit coordination"],
  },
  {
    icon: Sun,
    title: "Solar & Energy Storage Preparation",
    description: "Electrical readiness for solar pathways, energy monitoring, backup planning and future battery storage.",
    accent: "from-orange-300 via-amber-400 to-yellow-500",
    tint: "bg-amber-500/10 text-amber-600",
    services: ["Solar-ready conduits", "Battery readiness", "Critical-load panel planning", "Energy monitoring", "Disconnect planning", "Installer coordination"],
  },
  {
    icon: ShieldCheck,
    title: "Safety, Detectors & Protection",
    description: "Protection systems that reduce shock hazards, fire risk, surge damage and code deficiencies.",
    accent: "from-red-400 via-orange-500 to-amber-500",
    tint: "bg-red-500/10 text-red-600",
    services: ["Smoke detectors", "CO detectors", "Surge protection", "Grounding corrections", "Safety inspections", "Code repairs"],
  },
  {
    icon: Cpu,
    title: "Smart Home & Controls",
    description: "Modern controls for lighting, comfort, security, networking and connected-home convenience.",
    accent: "from-indigo-400 via-violet-500 to-purple-600",
    tint: "bg-indigo-500/10 text-indigo-600",
    services: ["Smart switches", "Smart thermostats", "Doorbell wiring", "Security camera wiring", "Occupancy sensors", "Home office power"],
  },
  {
    icon: Trees,
    title: "Outdoor, Garage & Specialty Power",
    description: "Weather-rated power for outdoor living, detached buildings, workshops and specialty equipment.",
    accent: "from-lime-400 via-emerald-500 to-teal-600",
    tint: "bg-lime-500/10 text-lime-700",
    services: ["Outdoor outlets", "Garage power upgrades", "Shed wiring", "Hot tub connections", "Pool equipment power", "Patio lighting"],
  },
  {
    icon: Wrench,
    title: "Repairs, Troubleshooting & Emergency Work",
    description: "Practical diagnostics and repairs when something is unsafe, unreliable, damaged or not working.",
    accent: "from-slate-400 via-slate-600 to-slate-800",
    tint: "bg-slate-500/10 text-slate-700",
    services: ["Breaker trips", "Buzzing devices", "Power loss diagnostics", "Flickering lights", "Faulty switches", "Inspection repair lists"],
  },
  {
    icon: Gauge,
    title: "Backup Power & Energy Efficiency",
    description: "Backup power and efficient controls that improve comfort, savings and home resilience.",
    accent: "from-teal-400 via-cyan-500 to-blue-600",
    tint: "bg-teal-500/10 text-teal-700",
    services: ["Generator transfer switches", "Inlet wiring", "LED conversions", "Timer controls", "Load management", "High-use circuit review"],
  },
  {
    icon: ClipboardCheck,
    title: "Permits, Inspections & Code Compliance",
    description: "Professional support for documented, code-compliant and inspection-ready residential electrical work.",
    accent: "from-yellow-300 via-amber-400 to-orange-500",
    tint: "bg-yellow-500/10 text-yellow-700",
    services: ["Electrical permits", "Inspection prep", "Suite compliance", "Safety reports", "Repair documentation", "Final testing"],
  },
  {
    icon: Bath,
    title: "Kitchen, Bathroom & Renovation Electrical",
    description: "Detailed renovation electrical work for the highest-use spaces in the home.",
    accent: "from-fuchsia-400 via-pink-500 to-rose-600",
    tint: "bg-fuchsia-500/10 text-fuchsia-700",
    services: ["Kitchen appliance circuits", "Vanity lighting", "Island power", "Heated floors", "Range circuits", "Renovation finishing"],
  },
];

export const residentialSampleHighlights = [
  { icon: CheckCircle2, label: "Licensed Work", value: "Code-compliant electrical service for occupied homes and new builds" },
  { icon: ShieldCheck, label: "Safety First", value: "Protection, testing and clean finishing on every installation" },
  { icon: Home, label: "Whole-Home Scope", value: "Small repairs, large upgrades, suites, panels and renovations" },
  { icon: ClipboardCheck, label: "Permit Ready", value: "Clear planning for inspections, documentation and final walkthroughs" },
];

export const residentialSampleSteps = [
  "Discuss the repair, upgrade, renovation or safety concern",
  "Review load capacity, protection, permits and code requirements",
  "Complete clean installation with reliable materials and tidy routing",
  "Test devices, breakers, controls and safety systems before handoff",
];
